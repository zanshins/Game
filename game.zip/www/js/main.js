import { installIcons, icon } from "./icons.js";
installIcons();
{ const bl = document.querySelector(".boot-logo"); if (bl) { bl.innerHTML = icon("🏰"); const sv = bl.querySelector("svg"); if (sv) { sv.style.width = "96px"; sv.style.height = "96px"; } } }
import * as SV from "./save.js";
import { Sound } from "./audio.js";
import { initUI, renderHub } from "./ui.js";
import { backActive } from "./battleui.js";

async function boot() {
  SV.load(); Sound.setMusicVolume(SV.S.settings.music); Sound.setSfxVolume(SV.S.settings.sfx);
  try { await Promise.race([Promise.all([document.fonts.load("700 16px Vazirmatn"), document.fonts.load("400 16px Lalezar")]), new Promise((r) => setTimeout(r, 1500))]); } catch (e) { /* */ }
  initUI(); renderHub();
  const rot = document.createElement("div"); rot.id = "rot"; rot.innerHTML = '<div style="font-size:60px">🔄</div><div>گوشی را افقی بگیرید</div>'; document.body.appendChild(rot);
  setTimeout(() => document.getElementById("boot").classList.add("hide"), 400);
  window.addEventListener("pagehide", () => SV.save());
  document.addEventListener("visibilitychange", () => { if (document.hidden) SV.save(); });
  // دکمه‌ی بازگشت اندروید (Capacitor)
  try { const App = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App; if (App) App.addListener("backButton", () => { const m = document.getElementById("modal"); if (m.classList.contains("on")) { m.classList.remove("on"); m.innerHTML = ""; return; } if (!backActive() && !document.getElementById("hub")) renderHub(); else if (document.getElementById("hub") && App.exitApp) App.exitApp(); }); } catch (e) { /* */ }
}
boot();
