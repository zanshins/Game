// پیوند شخصیت‌های سه‌بعدی واقعی (char3d) با نبرد: انتخاب مدل، رنگ، حرکت‌ها
import { CH, Inst, loadChars, PAL } from "./char3d.js";
const hexC = (h) => { if (Array.isArray(h)) return h.map((v) => v / 255); const n = parseInt(h.slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; };
const mul = (c, k) => c.map((v) => Math.min(1, v * k));
const SKINS = ["#f0c9a0", "#e4b48a", "#d09a6c", "#b87a50", "#9a6038", "#7a4a2c", "#f6d8b8"], HAIRS = ["#1a1210", "#2a1a10", "#4a2c14", "#6a4a24", "#8a6a3a", "#b08a4a", "#3a3a40", "#c8c0b0"];
const rnd = (seed) => { let a = seed | 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };
export const MODELS = ["Knight", "Warrior", "Ranger", "Rogue", "Cleric", "Monk", "Wizard"];
export const ready = () => CH.ok;
export async function init() { try { await loadChars(MODELS); return true; } catch (e) { console.warn("char3d", e); CH.ok = false; return false; } }
// پیکربندی هر کلاس: مدل، سلاح، انیمیشن‌ها
const C = {
  Warrior: { idle: "Idle_Weapon", walk: "Walk", run: "Run_Weapon", atk: ["Sword_AttackFast", "Sword_Attack"], guard: "Idle_Attacking", hit: "RecieveHit", die: "Death", roll: "Roll" },
  Knight: { idle: "Idle", walk: "Walking", run: "Run", atk: ["Run_swordAttack", "Run_swordRight", "swordAttackJump"], hit: null, die: "Death", roll: "Roll_sword", atkFix: 1 },
  Ranger: { idle: "Idle_Weapon", walk: "Walk", run: "Run_Holding", atk: ["Bow_Attack_Shoot"], hit: "RecieveHit", die: "Death", roll: "Roll" },
  Rogue: { idle: "Idle", walk: "Walk", run: "Run", atk: ["Dagger_Attack", "Dagger_Attack2"], hit: "RecieveHit", die: "Death", roll: "Roll" },
  Cleric: { idle: "Idle_Weapon", walk: "Walk", run: "Run_Weapon", atk: ["Staff_Attack"], hit: "RecieveHit", die: "Death", roll: "Roll", cast: "Spell1" },
  Monk: { idle: "Idle", walk: "Walk", run: "Run", atk: ["Attack", "Attack2"], hit: "RecieveHit", die: "Death", roll: "Roll" },
  Wizard: { idle: "Idle_Weapon", walk: "Walk", run: "Run_Weapon", atk: ["Staff_Attack"], hit: "RecieveHit", die: "Death", roll: "Roll", cast: "Spell2" },
};
export const CFG = C;
const TEAM = {
  ally: { cloth: ["#3a5aa8", "#2f6a9a", "#3a7a5a", "#5a4aa0"], cloth2: ["#2a3f78", "#244e70", "#285a40", "#40367a"], pants: ["#3a3a44", "#2e2a2a", "#403428"], leather: ["#5a3a1e", "#3a2a1a", "#6a4a28"], metal: ["#a9b4c8", "#b9c0cc", "#9aa6ba"] },
  foe: { cloth: ["#8a2a2a", "#6a2a3a", "#7a3a22", "#4a2630"], cloth2: ["#5a1a1a", "#40202a", "#5a2a18"], pants: ["#2a2226", "#30201e", "#241c1c"], leather: ["#3a2218", "#2a1a14", "#4a2e20"], metal: ["#7a7a88", "#6a6a78", "#8a8090"] },
};
// نوع‌ها → مدل/سلاح
export function spec(team, kind, seed) {
  const r = rnd(seed), pick = (a) => a[Math.floor(r() * a.length) % a.length];
  let m = "Warrior", weapon = null, helmet = null, pads = false, scale = 1, metal = null, gold = null;
  if (kind === "sword") m = pick(["Warrior", "Warrior", "Monk", "Rogue"]);
  else if (kind === "shield") { m = "Knight"; weapon = pick(["Sword", "ShortSword"]); helmet = pick(["Helmet1", "Helmet2"]); pads = true; }
  else if (kind === "guard" && team === "ally") { m = "Knight"; weapon = "Sword"; helmet = "Helmet3"; pads = true; gold = 1; }
  else if (kind === "archer" || kind === "warcher") m = pick(["Ranger", "Ranger", "Wizard"]);
  else if (kind === "horse") { m = pick(["Rogue", "Monk"]); scale = 1.05; }
  else if (kind === "guard") m = pick(["Warrior", "Warrior", "Rogue", "Monk"]);
  else if (kind === "heavy") { m = "Knight"; weapon = pick(["Sword", "Club"]); helmet = pick(["Helmet1", "Helmet2", "Helmet3"]); pads = true; scale = 1.08; }
  else if (kind === "captain") { m = "Knight"; weapon = "Katana"; helmet = "Helmet3"; pads = true; scale = 1.28; gold = 1; }
  const T = TEAM[team], pal = { skin: hexC(pick(SKINS)), hair: hexC(pick(HAIRS)), cloth: hexC(pick(T.cloth)), cloth2: hexC(pick(T.cloth2)), pants: hexC(pick(T.pants)), leather: hexC(pick(T.leather)), metal: hexC(pick(T.metal)), gold: hexC("#e8b838"), wood: hexC("#5a3a1c") };
  if (gold) { pal.cloth = hexC(team === "ally" ? "#2a3566" : "#3a1a4a"); pal.cloth2 = hexC(team === "ally" ? "#d8b84a" : "#8a6a2a"); pal.metal = hexC(team === "ally" ? "#e0c870" : "#8a7a9a"); }
  return { m, weapon, helmet, pads, scale, pal };
}
// قهرمان: مدل/سلاح/رنگ‌ها از S.avatar.char (ساخته‌شده در صفحه‌ی ساخت کاراکتر)
export const HERO_MODELS = { Warrior: "جنگجو", Knight: "شوالیه", Ranger: "کماندار", Rogue: "دزد", Cleric: "کشیش", Monk: "راهب", Wizard: "جادوگر" };
export function heroSpec(AV, LOOK) {
  const ch = (AV && AV.char) || {}, m = MODELS.includes(ch.m) ? ch.m : "Warrior";
  const pal = Object.assign({}, PAL, { skin: hexC(ch.skin || AV.skin || "#e4b48a"), hair: hexC(ch.hair || AV.hair || "#2a1a10"), cloth: hexC(ch.cloth || AV.tunic || "#3a5aa8"), cloth2: hexC(ch.cloth2 || "#a82a2a"), pants: hexC(ch.pants || "#2e2c34"), leather: hexC("#4a2e1a"), metal: hexC(ch.metal || "#b4bccc"), gold: hexC("#e8b838") });
  const knight = m === "Knight";
  return { m, weapon: knight ? (ch.weapon || "Sword") : null, helmet: knight ? (ch.helmet === undefined ? "Helmet1" : ch.helmet || null) : null, pads: knight ? ch.pads !== false : false, scale: ch.scale || 1.0, pal };
}
export function make(sp, seed) { const i = new Inst(sp.m, { pal: sp.pal, weapon: sp.weapon, helmet: sp.helmet, pads: sp.pads, scale: sp.scale }); i.cfg = C[sp.m]; i.ai = 0; i.phase = (seed % 7) * 0.41; i.seq = 0; i.px = null; i.pz = null; i.prevAtk = 0; i.prevHurt = 0; i.dying = false; i.sp = 0; i.atkLock = 0; i.idleNo = 0; return i; }
// هدایت انیمیشن؛ st: {x,z,atk(مقدار باقی‌مانده),atkMax,hurt,dead,roll,dt}
export function drive(inst, st) {
  const c = inst.cfg, dt = st.dt;
  if (inst.px !== null) { const d = Math.hypot(st.x - inst.px, st.z - inst.pz) / Math.max(dt, 0.001); inst.sp += (Math.min(d, 14) - inst.sp) * Math.min(1, dt * 10); }
  inst.px = st.x; inst.pz = st.z;
  if (st.dead) { if (!inst.dying) { inst.dying = true; inst.play(c.die, { loop: false, speed: Math.max(1, inst.def.anims[c.die].dur / (st.deadDur || 1.0)), fade: 0.06, restart: true }); } inst.update(dt); return; }
  if (st.block && c.guard) { inst.play(c.guard, { speed: 0.6, fade: 0.1 }); inst.prevAtk = 0; inst.update(dt); return; }
  if (st.roll > 0) { inst.play(c.roll, { loop: false, speed: inst.def.anims[c.roll].dur / 0.38, fade: 0.05 }); inst.atkLock = 0; }
  else {
    if (st.atk > 0 && inst.prevAtk <= 0.0001 + 0 || (st.atk > inst.prevAtk + 0.05 && st.atk > st.atkMax * 0.6)) {
      const nm = c.atk[(st.combo !== undefined ? st.combo : inst.seq++) % c.atk.length], d = inst.def.anims[nm].dur;
      inst.play(nm, { loop: false, speed: Math.max(1.6, d / (st.atkMax * 1.0)), fade: 0.03, restart: true }); inst.atkLock = st.atkMax * 1.0;
    } else if (st.hurt > 0 && inst.prevHurt <= 0.0001 && c.hit && inst.atkLock <= 0) { inst.play(c.hit, { loop: false, speed: 1.4, fade: 0.04, restart: true }); inst.atkLock = 0.35; inst.flash = 0.6; }
    else if (st.hurt > 0 && inst.prevHurt <= 0.0001) inst.flash = 0.7;
    inst.atkLock = Math.max(0, inst.atkLock - dt);
    if (inst.atkLock <= 0) {
      if (inst.sp > 4.2) inst.play(c.run, { speed: Math.max(0.8, Math.min(2.2, inst.sp / 7.2)), fade: 0.12 });
      else if (inst.sp > 0.7) inst.play(c.walk, { speed: Math.max(0.7, Math.min(1.9, inst.sp / 2.3)), fade: 0.12 });
      else inst.play(c.idle, { speed: 1, fade: 0.22 });
    }
  }
  inst.prevAtk = st.atk; inst.prevHurt = st.hurt; inst.update(dt);
}
