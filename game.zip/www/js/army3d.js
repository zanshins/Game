// سپاه و مهارت‌های حالت سه‌بعدی
import { S, save, pay } from "./save.js";
import { TROOPS } from "./data.js";

export const UNITS = {
  sword: { name: "شمشیرزن", hp: 150, dmg: 13, speed: 1, pack: 5, price: { coins: 2400 }, up: 500, note: "سرباز پایه، متعادل" },
  shield: { name: "سپردار", hp: 520, dmg: 7, speed: 0.85, pack: 5, price: { coins: 3600 }, up: 700, note: "جان بسیار زیاد؛ خط مقدم" },
  archer: { name: "کماندار", hp: 90, dmg: 12, speed: 0.95, pack: 10, price: { coins: 5200 }, up: 800, note: "از دور شلیک می‌کند؛ نگهبان‌های دیوار را می‌زند" },
  horse: { name: "سوارکار", hp: 260, dmg: 18, speed: 1.9, pack: 3, price: { gems: 70 }, up: 1100, note: "بسیار سریع؛ ضربه‌ی سنگین" },
  guard: { name: "جاویدان", hp: 420, dmg: 24, speed: 1.05, pack: 2, price: { gems: 140 }, up: 1600, note: "نخبه‌ی ده‌هزار نفر؛ مثل یک هیرو" },
};
export const UNIT_ORDER = ["sword", "shield", "archer", "horse", "guard"];
export const UNIT_MAX = 10;
export const MAX_BRING = 12;
export const SKILLS = {
  spec: { name: "ضربه‌ی شاهانه", icon: "💥", desc: "ضربه‌ی دایره‌ای: آسیب سنگین، گیج‌کردن دشمنان و آسیب بزرگ به دروازه", costs: [3000, 6500, 12000], gems: 0, cd: [10, 9, 8], req: 0 },
  rally: { name: "فریاد جنگ", icon: "📣", desc: "یاران را ترمیم می‌کند و چند ثانیه تندتر و قوی‌تر می‌کند", costs: [4200, 8800, 16000], cd: [26, 23, 20], req: 0 },
  ram: { name: "دروازه‌شکن", icon: "🐏", desc: "یک دژکوب غول‌پیکر به سوی دروازه می‌فرستد", costs: [7000, 14000, 26000], cd: [30, 26, 22], req: 0 },
  oil: { name: "سپر آذرخش", icon: "⚡", desc: "برای چند ثانیه نامیرا می‌شوی و دشمنان اطرافت را می‌سوزانی", costs: [0, 0, 0], gems: [90, 160, 260], cd: [32, 28, 24], req: 0 },
};
export const SKILL_ORDER = ["spec", "rally", "ram", "oil"];
export function A() {
  if (!S.army3d) S.army3d = { units: { sword: 1 }, lv: {}, skills: {}, seen: 0, order: ["sword"], given: {} };
  const a = S.army3d; a.units ||= { sword: 1 }; a.lv ||= {}; a.skills ||= {}; a.given ||= {}; return a;
}
export const unitCount = (k) => A().units[k] || 0;
export const unitLv = (k) => A().lv[k] || 1;
export const mulLv = (l) => 1 + 0.25 * (l - 1);
export const totalUnits = () => UNIT_ORDER.reduce((a, k) => a + unitCount(k), 0);
export const skillLv = (k) => A().skills[k] || 0;
export function skillCost(k) { const s = SKILLS[k], l = skillLv(k); if (l >= 3) return null; return { coins: s.costs[l] || 0, gems: s.gems ? s.gems[l] : 0 }; }
export function buySkill(k) { const c = skillCost(k); if (!c || !pay(c)) return false; A().skills[k] = skillLv(k) + 1; save(); return true; }
export function packPrice(k) { const u = UNITS[k], base = u.price, n = Math.floor(totalUnits() / 12); const m = 1 + 0.06 * n; return { coins: base.coins ? Math.round(base.coins * m / 50) * 50 : 0, gems: base.gems ? Math.round(base.gems * m) : 0 }; }
export function buyPack(k) { if (!pay(packPrice(k))) return false; A().units[k] = unitCount(k) + UNITS[k].pack; save(); return true; }
export function upCost(k) { const l = unitLv(k); return l >= UNIT_MAX ? null : { coins: Math.round(UNITS[k].up * Math.pow(1.5, l - 1)) }; }
export function upUnit(k) { const c = upCost(k); if (!c || unitCount(k) < 1 || !pay(c)) return false; A().lv[k] = unitLv(k) + 1; save(); return true; }
// غنیمت فتح: ۱ تا ۲ سرباز (بر اساس سختی کشور)
export function grantConquestTroops(nb) {
  const a = A(); if (a.given[nb.id]) return null; a.given[nb.id] = 1;
  const n = nb.power > 70 ? 2 : 1, kind = nb.power > 90 ? "guard" : ["shield", "archer", "horse", "sword", "archer", "shield"][Math.max(0, parseInt(nb.id.slice(1)) - 1) % 6];
  a.units[kind] = (a.units[kind] || 0) + n; save(); return { kind, n, name: UNITS[kind].name };
}
// یاران همراه در نبرد: بهترین‌ها تا سقف
export function pickArmy() {
  const a = A(), out = []; const order = ["guard", "horse", "shield", "sword", "archer"];
  let slots = MAX_BRING; const want = { archer: 4, shield: 3, horse: 2, guard: 2, sword: 5 };
  for (const k of order) { const n = Math.min(unitCount(k), want[k], slots); for (let i = 0; i < n; i++) out.push(k); slots -= n; }
  for (const k of UNIT_ORDER) { while (slots > 0 && out.filter((x) => x === k).length < unitCount(k)) { out.push(k); slots--; } }
  void a; return out.slice(0, MAX_BRING);
}
export function applyLosses(lost) { // ۷۰٪ بازمی‌گردند
  const a = A(), back = {}; for (const k of Object.keys(lost)) { const n = lost[k], die = Math.round(n * 0.3 + (n === 1 && Math.random() < 0.3 ? 1 : 0)); const gone = Math.min(a.units[k] || 0, Math.min(n, die)); a.units[k] = Math.max(k === "sword" ? 1 : 0, (a.units[k] || 0) - gone); back[k] = gone; }
  if (totalUnits() < 1) a.units.sword = 1; save(); return back;
}
export const troopBase = (k) => { const t = TROOPS[k]; return t; };
