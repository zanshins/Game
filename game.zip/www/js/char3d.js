// موتور WebGL2 برای شخصیت‌های اسکلتی (مدل‌های FBX تبدیل‌شده). هر شخصیت در یک تایل از اطلس رسم و سپس روی بوم دوبعدی کپی می‌شود.
const TAU = Math.PI * 2;
export const CH = { ok: false, gl: null, canvas: null, lib: {}, props: null, err: "" };
const BASE = "assets/chars/";
let gl, prog, loc = {}, boneTex, ROWS = 192, atlasW = 2048, atlasH = 2048, rowCtr = 0;
let cx = 0, cy = 0, rowH = 0;

// ---------- ریاضی ----------
const m4 = () => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
function mul(o, a, b) { // o = a*b (ستونی)
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
  return o;
}
function compose(o, t, q, s) {
  const x = q[0], y = q[1], z = q[2], w = q[3];
  const xx = x * x, yy = y * y, zz = z * z, xy = x * y, xz = x * z, yz = y * z, wx = w * x, wy = w * y, wz = w * z;
  o[0] = (1 - 2 * (yy + zz)) * s[0]; o[1] = 2 * (xy + wz) * s[0]; o[2] = 2 * (xz - wy) * s[0]; o[3] = 0;
  o[4] = 2 * (xy - wz) * s[1]; o[5] = (1 - 2 * (xx + zz)) * s[1]; o[6] = 2 * (yz + wx) * s[1]; o[7] = 0;
  o[8] = 2 * (xz + wy) * s[2]; o[9] = 2 * (yz - wx) * s[2]; o[10] = (1 - 2 * (xx + yy)) * s[2]; o[11] = 0;
  o[12] = t[0]; o[13] = t[1]; o[14] = t[2]; o[15] = 1; return o;
}
function eulerM(rx, ry, rz) { // ترتیب XYZ فبکس: Rz*Ry*Rx — برحسب درجه
  rx *= Math.PI / 180; ry *= Math.PI / 180; rz *= Math.PI / 180;
  const cx = Math.cos(rx), sx = Math.sin(rx), cy = Math.cos(ry), sy = Math.sin(ry), cz = Math.cos(rz), sz = Math.sin(rz), o = m4();
  o[0] = cz * cy; o[1] = sz * cy; o[2] = -sy; o[4] = cz * sy * sx - sz * cx; o[5] = sz * sy * sx + cz * cx; o[6] = cy * sx; o[8] = cz * sy * cx + sz * sx; o[9] = sz * sy * cx - cz * sx; o[10] = cy * cx; return o;
}
function scaleM(s) { const o = m4(); o[0] = o[5] = o[10] = s; return o; }
function transM(x, y, z) { const o = m4(); o[12] = x; o[13] = y; o[14] = z; return o; }

// ---------- شیدر ----------
const VS = `#version 300 es
precision highp float; precision highp int;
in vec3 a_pos; in vec3 a_nor; in uvec4 a_bi; in vec4 a_bw; in uint a_reg;
uniform sampler2D u_bones; uniform int u_row, u_skin; uniform mat4 u_attach, u_world, u_vp;
out vec3 v_n; flat out uint v_reg; out float v_h; out vec3 v_wp;
void main(){
  vec4 p = vec4(a_pos,1.0); vec3 n = a_nor;
  if (u_skin==1){
    mat4 m = mat4(0.0);
    for(int i=0;i<4;i++){ float w=a_bw[i]; if(w>0.0){ int b=int(a_bi[i]);
      mat4 bm = mat4(texelFetch(u_bones, ivec2(b*4,u_row),0), texelFetch(u_bones, ivec2(b*4+1,u_row),0), texelFetch(u_bones, ivec2(b*4+2,u_row),0), texelFetch(u_bones, ivec2(b*4+3,u_row),0));
      m += bm*w; } }
    p = m*p; n = mat3(m)*n;
  } else { p = u_attach*p; n = mat3(u_attach)*n; }
  vec4 wp = u_world*p; gl_Position = u_vp*wp; v_wp = wp.xyz;
  v_n = normalize(mat3(u_world)*n); v_reg=a_reg; v_h = p.y*0.005;
}`;
const FS = `#version 300 es
precision highp float;
in vec3 v_n; flat in uint v_reg; in float v_h; in vec3 v_wp; uniform vec3 u_cam; uniform vec2 u_fogd;
uniform vec3 u_pal[9]; uniform vec3 u_L, u_V, u_fogc, u_sky, u_gnd; uniform float u_fog, u_flash, u_t;
out vec4 o;
void main(){
  vec3 N = normalize(v_n); if(!gl_FrontFacing) N=-N;
  uint r = v_reg; vec3 base = u_pal[r];
  float nd = dot(N,u_L);
  float diff = clamp(nd*0.62+0.38,0.0,1.0); diff = diff*diff*(3.0-2.0*diff)*0.65+diff*0.35;
  vec3 hemi = mix(u_gnd,u_sky,N.y*0.5+0.5);
  float ao = clamp(0.62+v_h*0.0+N.y*0.2,0.45,1.0);
  vec3 col = base*(hemi*0.62*ao + vec3(1.0,0.93,0.8)*diff*0.78);
  float rim = pow(1.0-max(dot(N,u_V),0.0),3.0);
  col += rim*0.20*mix(vec3(1.0),u_sky,0.5)*(0.3+max(nd,0.0));
  if(r==6u||r==7u){ vec3 H=normalize(u_L+u_V); col += pow(max(dot(N,H),0.0), r==7u?30.0:18.0)*(r==7u?0.75:0.5); col = mix(col, col*mix(u_gnd,u_sky,N.y*0.5+0.5)*1.6, 0.25); }
  if(r==0u){ col += vec3(0.5,0.12,0.06)*0.10*pow(1.0-abs(dot(N,u_V)),2.0); }
  col = mix(col,u_fogc,u_fog); if(u_fogd.y>0.0){ float fd=clamp((length(v_wp-u_cam)-u_fogd.x)/(u_fogd.y-u_fogd.x),0.0,1.0); col=mix(col,u_fogc,fd*fd); }
  col = mix(col,vec3(1.0,0.25,0.2),u_flash);
  o = vec4(col,1.0);
}`;
function compile(t, src) { const s = gl.createShader(t); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; }

export const PAL = { skin: [0.93, 0.74, 0.58], cloth: [0.3, 0.38, 0.62], cloth2: [0.24, 0.3, 0.5], pants: [0.28, 0.24, 0.22], leather: [0.34, 0.22, 0.13], hair: [0.18, 0.12, 0.08], metal: [0.62, 0.65, 0.7], gold: [0.9, 0.7, 0.25], wood: [0.42, 0.27, 0.14] };
const PALKEYS = ["skin", "cloth", "cloth2", "pants", "leather", "hair", "metal", "gold", "wood"];
export const palFlat = (p) => { const o = new Float32Array(27); PALKEYS.forEach((k, i) => { const c = (p && p[k]) || PAL[k]; o[i * 3] = c[0]; o[i * 3 + 1] = c[1]; o[i * 3 + 2] = c[2]; }); return o; };

// ---------- بارگذاری ----------
function makeVAO(def, buf, m) {
  const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
  const f = (off, n, loc_, size, type, norm, ints) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Uint8Array(buf, off, n), gl.STATIC_DRAW); gl.enableVertexAttribArray(loc_); if (ints) gl.vertexAttribIPointer(loc_, size, type, 0, 0); else gl.vertexAttribPointer(loc_, size, type, norm, 0, 0); };
  f(m.pos[0], m.pos[1], 0, 3, gl.FLOAT, false); f(m.nor[0], m.nor[1], 1, 3, gl.FLOAT, false);
  if (m.skinned) { f(m.bi[0], m.bi[1], 2, 4, gl.UNSIGNED_BYTE, false, true); f(m.bw[0], m.bw[1], 3, 4, gl.UNSIGNED_BYTE, true); }
  else { gl.disableVertexAttribArray(2); gl.vertexAttribI4ui(2, 0, 0, 0, 0); gl.disableVertexAttribArray(3); gl.vertexAttrib4f(3, 1, 0, 0, 0); }
  f(m.reg[0], m.reg[1] > 0 ? m.reg[1] : m.n, 4, 1, gl.UNSIGNED_BYTE, false, true);
  gl.bindVertexArray(null); return vao;
}
let EXT = null; // زمینه‌ی WebGL موتور جهان (حالت "ext")؛ اطلس مستقل برای پیش‌نمایش‌ها ("atlas")
const ctxs = { atlas: null, ext: null }; let mode = "atlas";
export function useGL(g) { if (EXT && EXT !== g && ctxs.ext) { ctxs.ext = null; if (mode === "ext") mode = "atlas"; } EXT = g; }
export function setMode(m) { mode = m; const c = ctxs[m]; CH.ok = !!(c && Object.keys(c.lib).length); if (c) sel(m); }
export const getMode = () => mode;
function sel(m) { const c = ctxs[m]; if (!c) return false; gl = c.gl; prog = c.prog; loc = c.loc; boneTex = c.boneTex; CH.lib = c.lib; CH.props = c.props; CH.gl = gl; if (m === "atlas") CH.canvas = c.canvas; return true; }
function setupCtx(m) {
  let g, canvas = null;
  if (m === "ext") { if (!EXT) throw new Error("no ext gl"); g = EXT; }
  else { canvas = document.createElement("canvas"); canvas.width = atlasW; canvas.height = atlasH; g = canvas.getContext("webgl2", { alpha: true, premultipliedAlpha: true, antialias: true, preserveDrawingBuffer: true }); if (!g) throw new Error("no webgl2"); }
  gl = g; const p = gl.createProgram(); gl.attachShader(p, compile(gl.VERTEX_SHADER, VS)); gl.attachShader(p, compile(gl.FRAGMENT_SHADER, FS));
  gl.bindAttribLocation(p, 0, "a_pos"); gl.bindAttribLocation(p, 1, "a_nor"); gl.bindAttribLocation(p, 2, "a_bi"); gl.bindAttribLocation(p, 3, "a_bw"); gl.bindAttribLocation(p, 4, "a_reg");
  gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
  const l = {}; for (const u of ["u_bones", "u_row", "u_skin", "u_attach", "u_world", "u_vp", "u_pal", "u_L", "u_V", "u_fogc", "u_sky", "u_gnd", "u_fog", "u_flash", "u_t", "u_cam", "u_fogd"]) l[u] = gl.getUniformLocation(p, u);
  const bt = gl.createTexture(); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, bt);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, 64 * 4, ROWS, 0, gl.RGBA, gl.FLOAT, null);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  ctxs[m] = { gl, prog: p, loc: l, boneTex: bt, lib: {}, props: null, canvas };
}
export async function loadChars(names, onProgress) {
  const m = mode; if (!ctxs[m]) setupCtx(m); sel(m);
  if (!CH.props) {
    const pj = await (await fetch(BASE + "props.json")).json(), pb = await (await fetch(BASE + "props.bin")).arrayBuffer();
    sel(m); const pr = {}; for (const k in pj) { const mm = pj[k]; pr[k] = { n: mm.n, bbox: mm.bbox, vao: makeVAO(null, pb, { pos: [mm.pos, mm.n * 12], nor: [mm.nor, mm.n * 12], reg: [mm.reg, mm.n], skinned: false, n: mm.n }) }; } ctxs[m].props = pr; CH.props = pr;
  }
  let i = 0;
  for (const nm of names) {
    if (ctxs[m].lib[nm]) continue;
    const meta = await (await fetch(BASE + nm + ".json")).json(), buf = await (await fetch(BASE + nm + ".bin")).arrayBuffer(); sel(m);
    const nb = meta.bones.length, ibm = new Float32Array(buf, meta.ibm, nb * 16);
    const def = { name: nm, meta, nb, ibm, buf, g: 1.85 / meta.h, meshes: meta.meshes.map((mm) => ({ ...mm, vao: makeVAO(def_, buf, mm) })), anims: {} };
    for (const a of meta.anims) def.anims[a.name] = { ...a, data: new Float32Array(buf, a.off, a.nf * nb * 7) };
    def.bidx = {}; meta.bones.forEach((b, k) => (def.bidx[b.n] = k));
    ctxs[m].lib[nm] = def; if (onProgress) onProgress(++i / names.length);
  }
  CH.ok = true;
}
const def_ = null;

// ---------- نمونه‌ی شخصیت ----------
const _q = new Float32Array(4), _t = new Float32Array(3), _m = m4();
export class Inst {
  constructor(name, o = {}) {
    this.mode = mode; this.def = ctxs[mode].lib[name]; const nb = this.def.nb;
    this.pal = palFlat(o.pal); this.weapon = o.weapon || null; this.helmet = o.helmet || null; this.pads = !!o.pads; this.scale = o.scale || 1; this.bw = o.bw || 1;
    this.cur = { a: null, t: 0, loop: true, speed: 1 }; this.prev = null; this.fade = 0; this.fadeDur = 0.15; this.done = false;
    this.G = []; for (let i = 0; i < nb; i++) this.G.push(m4());
    this.loT = new Float32Array(nb * 3); this.loQ = new Float32Array(nb * 4);
    this.skin = new Float32Array(64 * 16); this.flash = 0; this.phase = Math.random() * 3;
    this.rowIdx = -1; this.yawOff = o.yawOff === undefined ? 0 : o.yawOff;
    this.play(o.anim || "Idle");
  }
  has(a) { return !!this.def.anims[a]; }
  play(a, o = {}) {
    if (!this.def.anims[a]) return false;
    if (this.cur.a === a && !o.restart) { this.cur.speed = o.speed || this.cur.speed; return true; }
    this.prev = this.cur.a ? { ...this.cur } : null; this.fade = this.prev ? 1 : 0; this.fadeDur = o.fade === undefined ? 0.14 : o.fade;
    this.cur = { a, t: o.t || 0, loop: o.loop !== false, speed: o.speed || 1 }; this.done = false; return true;
  }
  get len() { return this.cur.a ? this.def.anims[this.cur.a].dur : 0; }
  get prog() { return this.cur.a ? this.cur.t / this.def.anims[this.cur.a].dur : 0; }
  update(dt) {
    const adv = (s) => { if (!s || !s.a) return; const d = this.def.anims[s.a].dur; s.t += dt * s.speed; if (s.loop) s.t %= d; else if (s.t >= d) { s.t = d; if (s === this.cur) this.done = true; } };
    adv(this.cur); if (this.prev) { adv(this.prev); this.fade -= dt / Math.max(0.01, this.fadeDur); if (this.fade <= 0) { this.prev = null; this.fade = 0; } }
    this.flash = Math.max(0, this.flash - dt * 4);
  }
  sample(s, T, Q, w, first) {
    const A = this.def.anims[s.a], nb = this.def.nb, f = Math.min(A.nf - 1, (s.t / A.dur) * (A.nf - 1)), i0 = Math.floor(f), i1 = Math.min(A.nf - 1, i0 + 1), u = f - i0, d = A.data;
    for (let b = 0; b < nb; b++) {
      const a0 = (i0 * nb + b) * 7, a1 = (i1 * nb + b) * 7;
      const tx = d[a0] + (d[a1] - d[a0]) * u, ty = d[a0 + 1] + (d[a1 + 1] - d[a0 + 1]) * u, tz = d[a0 + 2] + (d[a1 + 2] - d[a0 + 2]) * u;
      let qx = d[a0 + 3], qy = d[a0 + 4], qz = d[a0 + 5], qw = d[a0 + 6], rx = d[a1 + 3], ry = d[a1 + 4], rz = d[a1 + 5], rw = d[a1 + 6];
      if (qx * rx + qy * ry + qz * rz + qw * rw < 0) { rx = -rx; ry = -ry; rz = -rz; rw = -rw; }
      let x = qx + (rx - qx) * u, y = qy + (ry - qy) * u, z = qz + (rz - qz) * u, ww = qw + (rw - qw) * u; const n = 1 / Math.hypot(x, y, z, ww); x *= n; y *= n; z *= n; ww *= n;
      if (first) { T[b * 3] = tx; T[b * 3 + 1] = ty; T[b * 3 + 2] = tz; Q[b * 4] = x; Q[b * 4 + 1] = y; Q[b * 4 + 2] = z; Q[b * 4 + 3] = ww; }
      else { // آمیزش با نمونه‌ی قبلی
        T[b * 3] += (tx - T[b * 3]) * w; T[b * 3 + 1] += (ty - T[b * 3 + 1]) * w; T[b * 3 + 2] += (tz - T[b * 3 + 2]) * w;
        let ox = Q[b * 4], oy = Q[b * 4 + 1], oz = Q[b * 4 + 2], ow = Q[b * 4 + 3]; if (ox * x + oy * y + oz * z + ow * ww < 0) { x = -x; y = -y; z = -z; ww = -ww; }
        let nx = ox + (x - ox) * w, ny = oy + (y - oy) * w, nz = oz + (z - oz) * w, nw = ow + (ww - ow) * w; const l = 1 / Math.hypot(nx, ny, nz, nw);
        Q[b * 4] = nx * l; Q[b * 4 + 1] = ny * l; Q[b * 4 + 2] = nz * l; Q[b * 4 + 3] = nw * l;
      }
    }
  }
  pose() {
    const d = this.def, nb = d.nb, bones = d.meta.bones;
    if (this.prev) { this.sample(this.prev, this.loT, this.loQ, 1, true); this.sample(this.cur, this.loT, this.loQ, 1 - this.fade, false); }
    else this.sample(this.cur, this.loT, this.loQ, 1, true);
    for (let b = 0; b < nb; b++) {
      const t = this.loT.subarray(b * 3, b * 3 + 3), q = this.loQ.subarray(b * 4, b * 4 + 4);
      compose(_m, t, q, bones[b].s);
      if (bones[b].p < 0) this.G[b].set(_m); else mul(this.G[b], this.G[bones[b].p], _m);
      mul(this.skin.subarray(b * 16, b * 16 + 16), this.G[b], d.ibm.subarray(b * 16, b * 16 + 16));
    }
  }
  boneM(name) { const k = this.def.bidx[name]; return k === undefined ? null : this.G[k]; }
}

// ---------- رسم ----------
const WEAPON_ATT = { // سلاح‌های جداگانه (شوالیه)؛ مقیاس‌ها نسبت به واحد استخوان (یک واحد = ۱۰۰ سانتی‌متر)
  Sword: { bone: "Palm.R", rot: [90, 6.3, -90], t: [0, 0, 0], s: 0.85 }, Katana: { bone: "Palm.R", rot: [90, 6.3, -90], t: [0, 0, 0], s: 0.85 }, ShortSword: { bone: "Palm.R", rot: [90, 6.3, -90], t: [0, 0, 0], s: 0.8 }, Club: { bone: "Palm.R", rot: [90, 6.3, -90], t: [0, 0, 0], s: 0.85 },
  Helmet1: { bone: "Head", rot: [-90, 0, 0], t: [0, 0.6, 0], s: 1.1 }, Helmet2: { bone: "Head", rot: [-90, 0, 0], t: [0, 0.6, 0], s: 1.1 }, Helmet3: { bone: "Head", rot: [-90, 0, 0], t: [0, 0.6, 0], s: 1.1 }, ShoulderPads: { bone: "Torso", rot: [-90, 0, 0], t: [0, 0.25, 0], s: 1.1 },
};
export const ATT = WEAPON_ATT;
export function frameBegin() { if (!ctxs.atlas || !sel("atlas")) return; gl.bindFramebuffer(gl.FRAMEBUFFER, null); gl.disable(gl.SCISSOR_TEST); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); cx = 0; cy = 0; rowH = 0; rowCtr = 0; }
const _w = m4(), _wm = m4(), _vp = m4(), _s = m4(), _a = m4();
let uploaded = 0;
export function frameEnd() {}
// ثبت و رسم یک نمونه در تایل؛ مقدار برگشتی همان مستطیل برای drawImage
// cam: {R,U,D} محورهای دید در جهان؛ k پیکسل‌به‌ازای‌واحد (css)؛ dpr
export function renderInst(inst, p, view) {
  if (!ctxs.atlas || inst.mode !== "atlas" || !sel("atlas") || rowCtr >= ROWS) return null;
  const sc = (inst.scale || 1) * (p.sc || 1), hw = 1.75 * sc, Scss = 2 * hw * view.k, S = Math.max(48, Math.min(512, Math.ceil(Scss * view.dpr / 16) * 16));
  if (cx + S > atlasW) { cx = 0; cy += rowH; rowH = 0; } if (cy + S > atlasH) return null; rowH = Math.max(rowH, S);
  const tx = cx, ty = cy; cx += S;
  inst.pose();
  const r = rowCtr++; gl.bindTexture(gl.TEXTURE_2D, boneTex); gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, r, 64 * 4, 1, gl.RGBA, gl.FLOAT, inst.skin);
  // مدل → جهان
  const g = inst.def.g * sc, yaw = p.yaw + inst.yawOff;
  const c = Math.cos(yaw), s = Math.sin(yaw);
  _w.fill(0); _w[0] = c * g * inst.bw; _w[2] = -s * g * inst.bw; _w[5] = g; _w[8] = s * g * inst.bw; _w[10] = c * g * inst.bw; _w[12] = p.x; _w[13] = p.y; _w[14] = p.z; _w[15] = 1;
  _w[0] = c * g; _w[2] = -s * g; _w[8] = s * g; _w[10] = c * g; // (عرض بدن را بعداً با bw در شیدر نداریم؛ ساده نگه داشتیم)
  const cwx = p.x, cwy = p.y + 0.95 * sc, cwz = p.z, R = view.R, U = view.U, D = view.D, zr = 14;
  _vp.fill(0);
  _vp[0] = R[0] / hw; _vp[4] = R[1] / hw; _vp[8] = R[2] / hw; _vp[12] = -(R[0] * cwx + R[1] * cwy + R[2] * cwz) / hw;
  _vp[1] = U[0] / hw; _vp[5] = U[1] / hw; _vp[9] = U[2] / hw; _vp[13] = -(U[0] * cwx + U[1] * cwy + U[2] * cwz) / hw;
  _vp[2] = D[0] / zr; _vp[6] = D[1] / zr; _vp[10] = D[2] / zr; _vp[14] = -(D[0] * cwx + D[1] * cwy + D[2] * cwz) / zr; _vp[15] = 1;
  gl.enable(gl.SCISSOR_TEST); gl.viewport(tx, atlasH - ty - S, S, S); gl.scissor(tx, atlasH - ty - S, S, S);
  gl.clear(gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.disable(gl.CULL_FACE);
  gl.useProgram(prog);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, boneTex); gl.uniform1i(loc.u_bones, 0); gl.uniform1i(loc.u_row, r);
  gl.uniformMatrix4fv(loc.u_world, false, _w); gl.uniformMatrix4fv(loc.u_vp, false, _vp);
  gl.uniform3fv(loc.u_pal, inst.pal);
  const L = view.L; gl.uniform3f(loc.u_L, L[0], L[1], L[2]); gl.uniform3f(loc.u_V, -D[0], -D[1], -D[2]);
  gl.uniform3fv(loc.u_fogc, view.fogc); gl.uniform3fv(loc.u_sky, view.sky); gl.uniform3fv(loc.u_gnd, view.gnd);
  gl.uniform1f(loc.u_fog, p.fog || 0); gl.uniform1f(loc.u_flash, Math.min(0.7, inst.flash * 0.7 + (p.flash || 0)));
  gl.uniform1i(loc.u_skin, 1);
  for (const m of inst.def.meshes) { if (!m.skinned) continue; gl.bindVertexArray(m.vao); gl.drawArrays(gl.TRIANGLES, 0, m.n); }
  gl.uniform1i(loc.u_skin, 0);
  for (const m of inst.def.meshes) { if (m.skinned) continue; const G = inst.G[m.bone]; gl.uniformMatrix4fv(loc.u_attach, false, G); gl.bindVertexArray(m.vao); gl.drawArrays(gl.TRIANGLES, 0, m.n); }
  const drawProp = (nm) => { const pr = CH.props[nm], at = (inst.attOv && inst.attOv[nm]) || WEAPON_ATT[nm], G = inst.boneM(at.bone); if (!pr || !G) return; const rm = eulerM(at.rot[0], at.rot[1], at.rot[2]); mul(_a, G, mul(_s, transM(at.t[0], at.t[1], at.t[2]), mul(_wm, rm, scaleM(at.s)))); gl.uniformMatrix4fv(loc.u_attach, false, _a); gl.bindVertexArray(pr.vao); gl.drawArrays(gl.TRIANGLES, 0, pr.n); };
  if (inst.weapon) drawProp(inst.weapon); if (inst.helmet) drawProp(inst.helmet); if (inst.pads) drawProp("ShoulderPads");
  gl.bindVertexArray(null);
  return { sx: tx, sy: atlasH - ty - S, S, Scss, cwx, cwy, cwz };
}
export function blit(ctx, t, scrX, scrY, alpha = 1) {
  if (!t) return; const a = ctx.globalAlpha; if (alpha !== 1) ctx.globalAlpha = a * alpha;
  ctx.drawImage(CH.canvas, t.sx, atlasH - t.sy - t.S, t.S, t.S, scrX - t.Scss / 2, scrY - t.Scss / 2, t.Scss, t.Scss);
  if (alpha !== 1) ctx.globalAlpha = a;
}

// ---------- رسم مستقیم در زمینه‌ی مشترک (بدون اطلس) ----------
export function charsBegin() { rowCtr = 0; }
const _dw = m4();
// sc: {vp, L, V, fogc, sky, gnd, cam:[x,y,z], fogd:[near,far]}
export function drawDirect(inst, p, sc) {
  if (!ctxs.ext || inst.mode !== "ext" || !sel("ext") || rowCtr >= ROWS) return false;
  inst.pose();
  const r = rowCtr++; gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, boneTex); gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, r, 64 * 4, 1, gl.RGBA, gl.FLOAT, inst.skin);
  const g = inst.def.g * (inst.scale || 1) * (p.sc || 1), yaw = p.yaw + inst.yawOff, c = Math.cos(yaw), s = Math.sin(yaw);
  _dw.fill(0); _dw[0] = c * g; _dw[2] = -s * g; _dw[5] = g; _dw[8] = s * g; _dw[10] = c * g; _dw[12] = p.x; _dw[13] = p.y; _dw[14] = p.z; _dw[15] = 1;
  gl.useProgram(prog); gl.uniform1i(loc.u_bones, 0); gl.uniform1i(loc.u_row, r); gl.uniformMatrix4fv(loc.u_world, false, _dw); gl.uniformMatrix4fv(loc.u_vp, false, sc.vp);
  gl.uniform3fv(loc.u_pal, inst.pal); gl.uniform3fv(loc.u_L, sc.L); gl.uniform3fv(loc.u_V, sc.V); gl.uniform3fv(loc.u_fogc, sc.fogc); gl.uniform3fv(loc.u_sky, sc.sky); gl.uniform3fv(loc.u_gnd, sc.gnd);
  gl.uniform3fv(loc.u_cam, sc.cam); gl.uniform2fv(loc.u_fogd, sc.fogd); gl.uniform1f(loc.u_fog, 0); gl.uniform1f(loc.u_flash, Math.min(0.7, inst.flash * 0.7 + (p.flash || 0)));
  gl.uniform1i(loc.u_skin, 1);
  for (const m of inst.def.meshes) { if (!m.skinned) continue; gl.bindVertexArray(m.vao); gl.drawArrays(gl.TRIANGLES, 0, m.n); }
  gl.uniform1i(loc.u_skin, 0);
  for (const m of inst.def.meshes) { if (m.skinned) continue; gl.uniformMatrix4fv(loc.u_attach, false, inst.G[m.bone]); gl.bindVertexArray(m.vao); gl.drawArrays(gl.TRIANGLES, 0, m.n); }
  const drawProp = (nm) => { const pr = CH.props[nm], at = (inst.attOv && inst.attOv[nm]) || WEAPON_ATT[nm], G = at && inst.boneM(at.bone); if (!pr || !G) return; const rm = eulerM(at.rot[0], at.rot[1], at.rot[2]); mul(_a, G, mul(_s, transM(at.t[0], at.t[1], at.t[2]), mul(_wm, rm, scaleM(at.s)))); gl.uniformMatrix4fv(loc.u_attach, false, _a); gl.bindVertexArray(pr.vao); gl.drawArrays(gl.TRIANGLES, 0, pr.n); };
  if (inst.weapon) drawProp(inst.weapon); if (inst.helmet) drawProp(inst.helmet); if (inst.pads) drawProp("ShoulderPads");
  gl.bindVertexArray(null); return true;
}
