// موتور جهان سه‌بعدی (WebGL2): زمین ارتفاعی، آب، مدل‌های نمونه‌ای (instanced)، شخصیت‌های اسکلتی، سایه، ذرات.
// همه‌چیز در یک زمینه‌ی GL و یک دوربین پرسپکتیو؛ رابط کاربری با DOM/بوم دوبعدی روی آن.
import * as C3 from "./char3d.js";
export const W3 = { ok: false, gl: null, canvas: null, models: {}, cam: { x: 0, y: 0, z: 0, yaw: 0, pitch: 0.9, dist: 40, fov: 0.75 }, time: 0, scale: 1, stats: { draws: 0, tris: 0, inst: 0 } };
let gl, T = null; // T: زمین
const P = {}; // برنامه‌ها
const M4 = () => new Float32Array(16);
function persp(o, fov, asp, n, f) { const t = 1 / Math.tan(fov / 2); o.fill(0); o[0] = t / asp; o[5] = t; o[10] = (f + n) / (n - f); o[11] = -1; o[14] = (2 * f * n) / (n - f); return o; }
function lookAt(o, e, c, u) {
  let zx = e[0] - c[0], zy = e[1] - c[1], zz = e[2] - c[2], l = Math.hypot(zx, zy, zz); zx /= l; zy /= l; zz /= l;
  let xx = u[1] * zz - u[2] * zy, xy = u[2] * zx - u[0] * zz, xz = u[0] * zy - u[1] * zx; l = Math.hypot(xx, xy, xz); xx /= l; xy /= l; xz /= l;
  const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
  o[0] = xx; o[1] = yx; o[2] = zx; o[3] = 0; o[4] = xy; o[5] = yy; o[6] = zy; o[7] = 0; o[8] = xz; o[9] = yz; o[10] = zz; o[11] = 0;
  o[12] = -(xx * e[0] + xy * e[1] + xz * e[2]); o[13] = -(yx * e[0] + yy * e[1] + yz * e[2]); o[14] = -(zx * e[0] + zy * e[1] + zz * e[2]); o[15] = 1; return o;
}
function mul4(o, a, b) { for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3]; return o; }
function inv4(m) { // معکوس ماتریس 4x4
  const a = m, o = new Float32Array(16), b00 = a[0] * a[5] - a[1] * a[4], b01 = a[0] * a[6] - a[2] * a[4], b02 = a[0] * a[7] - a[3] * a[4], b03 = a[1] * a[6] - a[2] * a[5], b04 = a[1] * a[7] - a[3] * a[5], b05 = a[2] * a[7] - a[3] * a[6], b06 = a[8] * a[13] - a[9] * a[12], b07 = a[8] * a[14] - a[10] * a[12], b08 = a[8] * a[15] - a[11] * a[12], b09 = a[9] * a[14] - a[10] * a[13], b10 = a[9] * a[15] - a[11] * a[13], b11 = a[10] * a[15] - a[11] * a[14];
  let d = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06; if (!d) return o; d = 1 / d;
  o[0] = (a[5] * b11 - a[6] * b10 + a[7] * b09) * d; o[1] = (a[2] * b10 - a[1] * b11 - a[3] * b09) * d; o[2] = (a[13] * b05 - a[14] * b04 + a[15] * b03) * d; o[3] = (a[10] * b04 - a[9] * b05 - a[11] * b03) * d;
  o[4] = (a[6] * b08 - a[4] * b11 - a[7] * b07) * d; o[5] = (a[0] * b11 - a[2] * b08 + a[3] * b07) * d; o[6] = (a[14] * b02 - a[12] * b05 - a[15] * b01) * d; o[7] = (a[8] * b05 - a[10] * b02 + a[11] * b01) * d;
  o[8] = (a[4] * b10 - a[5] * b08 + a[7] * b06) * d; o[9] = (a[1] * b08 - a[0] * b10 - a[3] * b06) * d; o[10] = (a[12] * b04 - a[13] * b02 + a[15] * b00) * d; o[11] = (a[9] * b02 - a[8] * b04 - a[11] * b00) * d;
  o[12] = (a[5] * b07 - a[4] * b09 - a[6] * b06) * d; o[13] = (a[0] * b09 - a[1] * b07 + a[2] * b06) * d; o[14] = (a[13] * b01 - a[12] * b03 - a[14] * b00) * d; o[15] = (a[8] * b03 - a[9] * b01 + a[10] * b00) * d; return o;
}
function sh(t, s) { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o) + "\n" + s.slice(0, 80)); return o; }
function prog(name, vs, fs, attrs, unis) {
  const p = gl.createProgram(); gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs)); attrs.forEach((a, i) => gl.bindAttribLocation(p, i, a)); gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(name + ": " + gl.getProgramInfoLog(p));
  const u = {}; unis.forEach((k) => (u[k] = gl.getUniformLocation(p, k))); P[name] = { p, u };
}
const COMMON_FOG = `uniform vec3 u_cam; uniform vec3 u_fogc; uniform vec2 u_fogd;
vec3 applyFog(vec3 c, vec3 wp){ float d=clamp((length(wp-u_cam)-u_fogd.x)/(u_fogd.y-u_fogd.x),0.0,1.0); return mix(c,u_fogc,d*d*(3.0-2.0*d)); }`;
const NOISE = `float h21(vec2 p){ p=fract(p*vec2(123.34,456.21)); p+=dot(p,p+45.32); return fract(p.x*p.y); }
float vn(vec2 p){ vec2 i=floor(p),f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(h21(i),h21(i+vec2(1,0)),f.x),mix(h21(i+vec2(0,1)),h21(i+vec2(1,1)),f.x),f.y); }`;
function build() {
  const common = ["u_vp", "u_cam", "u_fogc", "u_fogd", "u_L", "u_sky", "u_gnd", "u_time"];
  // --- زمین ---
  prog("terrain", `#version 300 es
in vec3 a_p; in vec3 a_n; in vec4 a_c; uniform mat4 u_vp; out vec3 v_n; out vec3 v_c; out vec3 v_wp; out float v_w;
void main(){ v_n=a_n; v_c=a_c.rgb; v_w=a_c.a; v_wp=a_p; gl_Position=u_vp*vec4(a_p,1.0); }`, `#version 300 es
precision highp float; in vec3 v_n; in vec3 v_c; in vec3 v_wp; in float v_w; uniform vec3 u_L,u_sky,u_gnd; uniform float u_time; out vec4 o;
${COMMON_FOG}${NOISE}
void main(){
  vec3 N=normalize(v_n); float n1=vn(v_wp.xz*0.35), n2=vn(v_wp.xz*1.7), n3=vn(v_wp.xz*7.0);
  vec3 c=v_c*(0.86+0.2*n1+0.10*n2+0.06*n3);
  float grass = clamp(v_c.g-v_c.r*0.9-0.02,0.0,1.0)*step(0.5,N.y);
  c += grass*0.07*(n3-0.5)*vec3(0.6,1.0,0.3); // ریزه‌ی چمن
  float d=max(dot(N,u_L),0.0); float h=0.5+0.5*N.y; vec3 hemi=mix(u_gnd,u_sky,h);
  vec3 col=c*(hemi*0.62+vec3(1.0,0.94,0.82)*d*0.85);
  col=applyFog(col,v_wp); o=vec4(col,1.0); }`, ["a_p", "a_n", "a_c"], ["u_vp", "u_cam", "u_fogc", "u_fogd", "u_L", "u_sky", "u_gnd", "u_time"]);
  // --- مدل‌های نمونه‌ای ---
  prog("model", `#version 300 es
in vec3 a_p; in vec3 a_n; in vec4 a_c; in vec4 i_m0; in vec4 i_m1; in vec4 i_m2; in vec4 i_m3; in vec4 i_k0; in vec4 i_k1;
uniform mat4 u_vp; uniform float u_time; uniform float u_sway; uniform float u_h; out vec3 v_n; out vec4 v_c; out vec3 v_wp; out float v_ao; out vec4 v_k;
void main(){ mat4 M=mat4(i_m0,i_m1,i_m2,i_m3); vec3 p=a_p;
  float hh=clamp(p.y/max(u_h,0.01),0.0,1.0);
  if(u_sway>0.0){ float ph=i_m3.x*0.7+i_m3.z*0.9; p.x+=sin(u_time*1.7+ph+p.y*0.6)*u_sway*hh*hh*u_h; p.z+=cos(u_time*1.3+ph*1.3+p.y*0.5)*u_sway*0.7*hh*hh*u_h; }
  vec4 wp=M*vec4(p,1.0); v_wp=wp.xyz; v_n=mat3(M)*a_n; v_c=a_c; v_k=i_k0; v_ao=mix(0.62,1.0,smoothstep(0.0,0.5,hh)); gl_Position=u_vp*wp; v_team=i_k1.rgb; }`.replace("out vec4 v_k;", "out vec4 v_k; out vec3 v_team;"), `#version 300 es
precision highp float; in vec3 v_n; in vec4 v_c; in vec3 v_wp; in float v_ao; in vec4 v_k; in vec3 v_team; uniform vec3 u_L,u_sky,u_gnd; out vec4 o;
${COMMON_FOG}${NOISE}
void main(){
  vec3 N=normalize(v_n); if(!gl_FrontFacing) N=-N; vec3 base=v_c.rgb; if(v_c.a>0.5 && v_k.w>0.5) base=v_team;
  base*=v_k.rgb; base*=0.9+0.2*vn(v_wp.xz*3.1+v_wp.y);
  float d=max(dot(N,u_L),0.0); vec3 hemi=mix(u_gnd,u_sky,0.5+0.5*N.y);
  vec3 col=base*(hemi*0.6*v_ao+vec3(1.0,0.94,0.82)*d*0.9*mix(0.8,1.0,v_ao));
  col=applyFog(col,v_wp); o=vec4(col,1.0); }`, ["a_p", "a_n", "a_c", "i_m0", "i_m1", "i_m2", "i_m3", "i_k0", "i_k1"], ["u_vp", "u_cam", "u_fogc", "u_fogd", "u_L", "u_sky", "u_gnd", "u_time", "u_sway", "u_h"]);
  // --- آب ---
  prog("water", `#version 300 es
in vec2 a_p; uniform mat4 u_vp; uniform vec4 u_box; uniform float u_wl; out vec3 v_wp; out vec2 v_uv;
void main(){ vec2 w=mix(u_box.xy,u_box.zw,a_p); v_wp=vec3(w.x,u_wl,w.y); v_uv=a_p; gl_Position=u_vp*vec4(v_wp,1.0); }`, `#version 300 es
precision highp float; in vec3 v_wp; in vec2 v_uv; uniform sampler2D u_ht; uniform vec2 u_hr; uniform float u_time,u_wl; uniform vec3 u_L,u_sky; out vec4 o;
${COMMON_FOG}${NOISE}
void main(){
  float hn=texture(u_ht,v_uv).r; float ground=u_hr.x+hn*u_hr.y; float depth=u_wl-ground;
  if(depth<-0.02) discard;
  vec2 q=v_wp.xz; float w1=vn(q*0.45+vec2(u_time*0.35,u_time*0.2)), w2=vn(q*1.3-vec2(u_time*0.5,-u_time*0.3));
  vec3 N=normalize(vec3((w1-0.5)*0.5+(w2-0.5)*0.25,1.0,(vn(q*0.6+7.0+u_time*0.3)-0.5)*0.5));
  vec3 V=normalize(u_cam-v_wp); float fres=pow(1.0-max(dot(N,V),0.0),3.0);
  vec3 shallow=vec3(0.22,0.72,0.72), deep=vec3(0.03,0.2,0.38);
  float k=smoothstep(0.0,5.0,depth); vec3 c=mix(shallow,deep,k);
  c=mix(c,u_sky*0.95,fres*0.55);
  vec3 H=normalize(u_L+V); c+=pow(max(dot(N,H),0.0),90.0)*vec3(1.0,0.95,0.85)*0.9;
  float foam=smoothstep(0.7,0.0,depth+ (w2-0.5)*0.5+sin(u_time*1.6+q.x*0.6+q.y*0.4)*0.12); foam*=smoothstep(0.35,0.65,vn(q*2.2+u_time*0.2)+0.25);
  c=mix(c,vec3(0.95),clamp(foam,0.0,1.0)*0.85);
  float a=clamp(0.35+smoothstep(0.0,1.2,depth)*0.6+foam*0.4,0.0,0.97);
  c=applyFog(c,v_wp); o=vec4(c,a); }`, ["a_p"], ["u_vp", "u_cam", "u_fogc", "u_fogd", "u_L", "u_sky", "u_time", "u_box", "u_wl", "u_ht", "u_hr"]);
  // --- آسمان ---
  prog("sky", `#version 300 es
out vec2 v_u; void main(){ vec2 p=vec2((gl_VertexID<<1)&2, gl_VertexID&2); v_u=p; gl_Position=vec4(p*2.0-1.0,0.999,1.0); }`, `#version 300 es
precision highp float; in vec2 v_u; uniform vec3 u_top,u_hor,u_sun; uniform vec2 u_sunp; uniform float u_hz; out vec4 o;
void main(){ float t=smoothstep(u_hz-0.25,u_hz+0.55,v_u.y); vec3 c=mix(u_hor,u_top,t); float s=pow(max(1.0-length((v_u-u_sunp)*vec2(1.6,1.0)),0.0),6.0); c+=u_sun*s*0.55; o=vec4(c,1.0); }`, [], ["u_top", "u_hor", "u_sun", "u_sunp", "u_hz"]);
  // --- بیلبورد/ذره/سایه ---
  prog("bb", `#version 300 es
in vec2 a_q; in vec3 a_c; in float a_s; in vec4 a_col; uniform mat4 u_vp; uniform vec3 u_r; uniform vec3 u_u; uniform int u_flat; out vec2 v_q; out vec4 v_col;
void main(){ vec3 c=a_c; vec3 R=u_flat==1?vec3(1,0,0):u_r; vec3 U=u_flat==1?vec3(0,0,1):u_u; vec3 w=c+(R*a_q.x+U*a_q.y)*a_s; v_q=a_q; v_col=a_col; gl_Position=u_vp*vec4(w,1.0); }`, `#version 300 es
precision mediump float; in vec2 v_q; in vec4 v_col; uniform vec3 u_fogc; out vec4 o;
void main(){ float d=length(v_q); float a=smoothstep(1.0,0.2,d); o=vec4(v_col.rgb,v_col.a*a); }`, ["a_q", "a_c", "a_s", "a_col"], ["u_vp", "u_r", "u_u", "u_flat", "u_fogc"]);
}
// ---------- بارگذاری مدل‌ها ----------
async function loadPack(base, name) {
  const [meta, bin] = await Promise.all([fetch(base + name + ".json").then((r) => r.json()), fetch(base + name + ".bin").then((r) => r.arrayBuffer())]);
  for (const n in meta) {
    const m = meta[n], vao = gl.createVertexArray(); gl.bindVertexArray(vao);
    const mk = (off, bytes, idx, size, type, norm) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Uint8Array(bin, off, bytes), gl.STATIC_DRAW); gl.enableVertexAttribArray(idx); gl.vertexAttribPointer(idx, size, type, norm, 0, 0); };
    const col4 = m.c4 !== undefined ? !!m.c4 : name === "world";
    mk(m.pos, m.n * 12, 0, 3, gl.FLOAT, false); mk(m.nor, m.n * 3, 1, 3, gl.BYTE, true);
    if (col4) mk(m.col, m.n * 4, 2, 4, gl.UNSIGNED_BYTE, true); else { mk(m.col, m.n * 3, 2, 3, gl.UNSIGNED_BYTE, true); }
    const ib = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, ib); const cap = 1024; gl.bufferData(gl.ARRAY_BUFFER, cap * 24 * 4, gl.DYNAMIC_DRAW);
    for (let k = 0; k < 6; k++) { const loc = 3 + k; gl.enableVertexAttribArray(loc); const sz = k < 4 ? 4 : 4; gl.vertexAttribPointer(loc, sz, gl.FLOAT, false, 96, k * 16); gl.vertexAttribDivisor(loc, 1); }
    gl.bindVertexArray(null);
    W3.models[n] = { vao, n: m.n, h: m.h, w: m.w, ib, cap, data: new Float32Array(cap * 24), cnt: 0, sway: 0 };
  }
}
export async function initWorld(canvas, opt = {}) {
  try {
    gl = canvas.getContext("webgl2", { alpha: false, antialias: opt.aa !== false, powerPreference: "high-performance", depth: true, stencil: false });
    if (!gl) throw new Error("no webgl2"); W3.gl = gl; W3.canvas = canvas; build();
    gl.getExtension("EXT_color_buffer_float");
    C3.useGL(gl);
    await Promise.all([loadPack(opt.base || "assets/env/", "env"), loadPack(opt.base || "assets/env/", "world"), loadPack(opt.base || "assets/env/", "lod")]);
    for (const n in W3.models) { const m = W3.models[n]; if (/Tree|Palm|Bush|Flower|Plant|Grass|Petals/.test(n)) m.sway = /Grass|Flower|Plant|Petals/.test(n) ? 0.06 : 0.018; }
    // اشکال ساده: ذره/بیلبورد
    qb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, qb); bbData = new Float32Array(BBMAX * 4 * 10); gl.bufferData(gl.ARRAY_BUFFER, bbData.byteLength, gl.DYNAMIC_DRAW);
    bbVao = gl.createVertexArray(); gl.bindVertexArray(bbVao); gl.bindBuffer(gl.ARRAY_BUFFER, qb);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 40, 0); gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 40, 8); gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 1, gl.FLOAT, false, 40, 20); gl.enableVertexAttribArray(3); gl.vertexAttribPointer(3, 4, gl.FLOAT, false, 40, 24);
    const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); const ix = new Uint16Array(BBMAX * 6); for (let i = 0; i < BBMAX; i++) ix.set([i * 4, i * 4 + 1, i * 4 + 2, i * 4, i * 4 + 2, i * 4 + 3], i * 6); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, ix, gl.STATIC_DRAW);
    gl.bindVertexArray(null);
    wb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, wb); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1]), gl.STATIC_DRAW);
    wVao = gl.createVertexArray(); gl.bindVertexArray(wVao); gl.bindBuffer(gl.ARRAY_BUFFER, wb); gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0); gl.bindVertexArray(null);
    skyVao = gl.createVertexArray();
    W3.ok = true; return true;
  } catch (e) { console.warn("world3d", e); W3.ok = false; W3.err = String(e && e.message || e); return false; }
}
// ---------- زمین ----------
// o: {x0,z0,x1,z1,nx,nz,h:(x,z)=>y, color:(x,z,y,slope)=>[r,g,b] (0..1), wl: ترازِ آب}
export function setTerrain(o) {
  const { x0, z0, x1, z1, nx, nz } = o, dx = (x1 - x0) / (nx - 1), dz = (z1 - z0) / (nz - 1), hs = new Float32Array(nx * nz);
  let hmin = 1e9, hmax = -1e9;
  for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) { const y = o.h(x0 + i * dx, z0 + j * dz); hs[j * nx + i] = y; if (y < hmin) hmin = y; if (y > hmax) hmax = y; }
  const pos = new Float32Array(nx * nz * 3), nor = new Float32Array(nx * nz * 3), col = new Uint8Array(nx * nz * 4);
  for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) {
    const k = j * nx + i, y = hs[k], yl = hs[j * nx + Math.max(0, i - 1)], yr = hs[j * nx + Math.min(nx - 1, i + 1)], yu = hs[Math.max(0, j - 1) * nx + i], yd = hs[Math.min(nz - 1, j + 1) * nx + i];
    let gx = (yl - yr) / (2 * dx), gz = (yu - yd) / (2 * dz); const l = Math.hypot(gx, 1, gz);
    pos[k * 3] = x0 + i * dx; pos[k * 3 + 1] = y; pos[k * 3 + 2] = z0 + j * dz; nor[k * 3] = gx / l; nor[k * 3 + 1] = 1 / l; nor[k * 3 + 2] = gz / l;
    const c = o.color(pos[k * 3], pos[k * 3 + 2], y, 1 - 1 / l); col[k * 4] = c[0] * 255; col[k * 4 + 1] = c[1] * 255; col[k * 4 + 2] = c[2] * 255; col[k * 4 + 3] = 255;
  }
  const idx = new Uint32Array((nx - 1) * (nz - 1) * 6); let q = 0;
  for (let j = 0; j < nz - 1; j++) for (let i = 0; i < nx - 1; i++) { const a = j * nx + i, b = a + 1, c = a + nx, d = c + 1; if ((i + j) & 1) idx.set([a, c, b, b, c, d], q); else idx.set([a, c, d, a, d, b], q); q += 6; }
  if (T) { gl.deleteVertexArray(T.vao); gl.deleteTexture(T.tex); }
  const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
  const buf = (arr, i, size, type, norm) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, arr, gl.STATIC_DRAW); gl.enableVertexAttribArray(i); gl.vertexAttribPointer(i, size, type, norm, 0, 0); };
  buf(pos, 0, 3, gl.FLOAT, false); buf(nor, 1, 3, gl.FLOAT, false); buf(col, 2, 4, gl.UNSIGNED_BYTE, true);
  const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW); gl.bindVertexArray(null);
  // بافت ارتفاع برای آب (R8)
  const tex = gl.createTexture(), px = new Uint8Array(nx * nz), rg = Math.max(0.001, hmax - hmin); for (let k = 0; k < nx * nz; k++) px[k] = ((hs[k] - hmin) / rg) * 255;
  gl.bindTexture(gl.TEXTURE_2D, tex); gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1); gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, nx, nz, 0, gl.RED, gl.UNSIGNED_BYTE, px);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  T = { vao, n: idx.length, tex, nx, nz, x0, z0, x1, z1, dx, dz, hs, hmin, hmax, wl: o.wl === undefined ? -1e9 : o.wl };
}
export function heightAt(x, z) {
  if (!T) return 0; const fx = Math.max(0, Math.min(T.nx - 1.001, (x - T.x0) / T.dx)), fz = Math.max(0, Math.min(T.nz - 1.001, (z - T.z0) / T.dz)), i = fx | 0, j = fz | 0, u = fx - i, v = fz - j, h = T.hs, k = j * T.nx + i;
  return (h[k] * (1 - u) + h[k + 1] * u) * (1 - v) + (h[k + T.nx] * (1 - u) + h[k + T.nx + 1] * u) * v;
}
// ---------- نور و محیط ----------
export const ENV = { L: [0.45, 0.75, 0.35], sky: [0.62, 0.74, 0.95], gnd: [0.5, 0.44, 0.36], fogc: [0.72, 0.8, 0.9], fogd: [60, 220], top: [0.28, 0.5, 0.86], hor: [0.78, 0.86, 0.95], sun: [1, 0.9, 0.7], hz: 0.5 };
// ---------- دوربین ----------
const V = M4(), Pj = M4(), VP = M4(); let IVP = M4(), CP = [0, 0, 0], CR = [1, 0, 0], CU = [0, 1, 0], vw = 1, vh = 1;
export function resize(w, h, dprMax = 2) {
  const d = Math.min(window.devicePixelRatio || 1, dprMax) * W3.scale; vw = w; vh = h; W3.canvas.width = Math.max(2, (w * d) | 0); W3.canvas.height = Math.max(2, (h * d) | 0); W3.canvas.style.width = w + "px"; W3.canvas.style.height = h + "px";
}
export function updateCamera() {
  const c = W3.cam, cp = Math.cos(c.pitch), sp = Math.sin(c.pitch), sy = Math.sin(c.yaw), cy = Math.cos(c.yaw);
  CP = [c.x - sy * cp * c.dist, c.y + sp * c.dist, c.z - cy * cp * c.dist];
  if (c.minY !== undefined) { const gy = heightAt(CP[0], CP[2]) + c.minY; if (CP[1] < gy) CP[1] = gy; }
  lookAt(V, CP, [c.x, c.y, c.z], [0, 1, 0]); persp(Pj, c.fov, vw / vh, 0.5, 700); mul4(VP, Pj, V); IVP = inv4(VP);
  CR = [V[0], V[4], V[8]]; CU = [V[1], V[5], V[9]]; W3.eye = CP; W3.vp = VP;
}
export function project(x, y, z) { const w = VP[3] * x + VP[7] * y + VP[11] * z + VP[15]; if (w <= 0.001) return null; return [(((VP[0] * x + VP[4] * y + VP[8] * z + VP[12]) / w) * 0.5 + 0.5) * vw, (1 - ((VP[1] * x + VP[5] * y + VP[9] * z + VP[13]) / w) * 0.5 - 0.5) * vh, w]; }
// پرتو از نقطه‌ی صفحه؛ برخورد با زمین
export function pick(sx, sy) {
  const nx = (sx / vw) * 2 - 1, ny = 1 - (sy / vh) * 2, un = (z) => { const v = [nx, ny, z, 1], o = [0, 0, 0, 0]; for (let r = 0; r < 4; r++) o[r] = IVP[r] * v[0] + IVP[4 + r] * v[1] + IVP[8 + r] * v[2] + IVP[12 + r] * v[3]; return [o[0] / o[3], o[1] / o[3], o[2] / o[3]]; };
  const a = un(-1), b = un(1), d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], l = Math.hypot(...d); d[0] /= l; d[1] /= l; d[2] /= l;
  let t = 0, prev = 0; const e = CP, max = 900;
  for (let i = 0; i < 400 && t < max; i++) { const x = e[0] + d[0] * t, y = e[1] + d[1] * t, z = e[2] + d[2] * t, g = heightAt(x, z); if (y < g) { let lo = prev, hi = t; for (let k = 0; k < 8; k++) { const m = (lo + hi) / 2; if (e[1] + d[1] * m < heightAt(e[0] + d[0] * m, e[2] + d[2] * m)) hi = m; else lo = m; } const r = (lo + hi) / 2; return [e[0] + d[0] * r, e[2] + d[2] * r]; } prev = t; t += Math.max(0.4, (y - g) * 0.5); }
  return null;
}
// ---------- نمونه‌ها ----------
const _m = new Float32Array(16);
export const LOD = { d: 55 };
export function inst(name, x, y, z, yaw, s, o = {}) {
  let m = W3.models[name]; if (!m) return false;
  if (!o.noLod) { const lo = W3.models[name + "@lo"]; if (lo) { const dd = Math.hypot(x - CP[0], y - CP[1], z - CP[2]); if (dd > LOD.d + s * m.h * 0.5) m = lo; } }
  const r = Math.max(m.w, m.h) * s * 0.55 + 1;
  if (!o.noCull) { const px = project(x, y + m.h * s * 0.4, z); if (!px) { if (Math.hypot(x - CP[0], z - CP[2]) > r * 2) return false; } else { const k = (r / px[2]) * vh * 0.9 / Math.tan(W3.cam.fov / 2) * 0.5 + 6; if (px[0] < -k || px[0] > vw + k || px[1] < -k || px[1] > vh + k) return false; } }
  if (m.cnt >= m.cap) return false;
  const d = m.data, b = m.cnt * 24, c = Math.cos(yaw), sn = Math.sin(yaw), sy = o.sy || s;
  if (o.rx) { const cr = Math.cos(o.rx), sr = Math.sin(o.rx); // M = Ry(yaw)*Rx(rx)*S
    d[b] = c * s; d[b + 1] = 0; d[b + 2] = -sn * s; d[b + 3] = 0; d[b + 4] = sn * sr * sy; d[b + 5] = cr * sy; d[b + 6] = c * sr * sy; d[b + 7] = 0; d[b + 8] = sn * cr * s; d[b + 9] = -sr * s; d[b + 10] = c * cr * s; d[b + 11] = 0; }
  else { d[b] = c * s; d[b + 1] = 0; d[b + 2] = -sn * s; d[b + 3] = 0; d[b + 4] = 0; d[b + 5] = sy; d[b + 6] = 0; d[b + 7] = 0; d[b + 8] = sn * s; d[b + 9] = 0; d[b + 10] = c * s; d[b + 11] = 0; } d[b + 12] = x; d[b + 13] = y; d[b + 14] = z; d[b + 15] = 1;
  const t = o.tint; d[b + 16] = t ? t[0] : 1; d[b + 17] = t ? t[1] : 1; d[b + 18] = t ? t[2] : 1; d[b + 19] = o.team ? 1 : 0;
  const tm = o.team || [0, 0, 0]; d[b + 20] = tm[0]; d[b + 21] = tm[1]; d[b + 22] = tm[2]; d[b + 23] = 0; m.cnt++; return true;
}
// ---------- بیلبورد/ذره ----------
const BBMAX = 3000; let qb, bbData, bbVao, bbN = 0, wb, wVao, skyVao; const bbAdd = [];
export function puff(x, y, z, size, r, g, b, a, additive) { (additive ? bbAdd : bbPuff).push(x, y, z, size, r, g, b, a); }
const bbPuff = [], bbSh = [];
export function shadow(x, y, z, r, a = 0.4) { bbSh.push(x, y + 0.04, z, r, 0, 0, 0, a); }
// لکه‌ی رنگیِ تخت روی زمین (حلقه‌ها، نشانگرها)
export function decal(x, y, z, r, cr, cg, cb, a = 0.5) { bbSh.push(x, y + 0.05, z, r, cr, cg, cb, a); }
function drawBB(list, flat, additive) {
  const n = list.length / 8; if (!n) return; gl.useProgram(P.bb.p); gl.uniformMatrix4fv(P.bb.u.u_vp, false, VP); gl.uniform3fv(P.bb.u.u_r, CR); gl.uniform3fv(P.bb.u.u_u, CU); gl.uniform1i(P.bb.u.u_flat, flat ? 1 : 0);
  gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, additive ? gl.ONE : gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); gl.bindVertexArray(bbVao);
  const qs = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
  for (let s0 = 0; s0 < n; s0 += BBMAX) {
    const cnt = Math.min(BBMAX, n - s0); let o = 0;
    for (let i = 0; i < cnt; i++) { const k = (s0 + i) * 8; for (const q of qs) { bbData[o++] = q[0]; bbData[o++] = q[1]; bbData[o++] = list[k]; bbData[o++] = list[k + 1]; bbData[o++] = list[k + 2]; bbData[o++] = list[k + 3]; bbData[o++] = list[k + 4]; bbData[o++] = list[k + 5]; bbData[o++] = list[k + 6]; bbData[o++] = list[k + 7]; } }
    // چیدمان 12 عدد: q(2) c(3) s(4) col(4) → 13؛ بسته‌بندی در 12: s.x فقط، col در 4
    gl.bindBuffer(gl.ARRAY_BUFFER, qb); gl.bufferSubData(gl.ARRAY_BUFFER, 0, bbData, 0, cnt * 40); gl.drawElements(gl.TRIANGLES, cnt * 6, gl.UNSIGNED_SHORT, 0);
  }
  gl.bindVertexArray(null); gl.depthMask(true); gl.disable(gl.BLEND); list.length = 0;
}
// ---------- فریم ----------
export function frameBegin(dt) {
  W3.time += dt || 0.016; const g = gl; g.bindFramebuffer(g.FRAMEBUFFER, null); g.viewport(0, 0, W3.canvas.width, W3.canvas.height); g.disable(g.SCISSOR_TEST); g.depthMask(true); g.clearColor(ENV.hor[0], ENV.hor[1], ENV.hor[2], 1); g.clear(g.COLOR_BUFFER_BIT | g.DEPTH_BUFFER_BIT);
  updateCamera(); W3.stats.draws = 0; W3.stats.inst = 0; for (const n in W3.models) W3.models[n].cnt = 0; C3.charsBegin();
  // آسمان
  const s = ENV.sunp || [0.3, 0.9]; g.useProgram(P.sky.p); g.disable(g.DEPTH_TEST); const u = P.sky.u; g.uniform3fv(u.u_top, ENV.top); g.uniform3fv(u.u_hor, ENV.hor); g.uniform3fv(u.u_sun, ENV.sun); g.uniform2fv(u.u_sunp, s);
  const hz = (() => { const p = project(CP[0] + Math.sin(W3.cam.yaw) * 500, 0, CP[2] + Math.cos(W3.cam.yaw) * 500); return p ? 1 - p[1] / vh : 0.6; })(); g.uniform1f(u.u_hz, hz);
  g.bindVertexArray(skyVao); g.drawArrays(g.TRIANGLES, 0, 3); g.bindVertexArray(null); g.enable(g.DEPTH_TEST); g.depthFunc(g.LEQUAL); g.enable(g.CULL_FACE); g.cullFace(g.BACK);
}
function setEnv(p) { const u = P[p].u, g = gl; g.useProgram(P[p].p); if (u.u_vp) g.uniformMatrix4fv(u.u_vp, false, VP); if (u.u_cam) g.uniform3fv(u.u_cam, CP); if (u.u_fogc) g.uniform3fv(u.u_fogc, ENV.fogc); if (u.u_fogd) g.uniform2fv(u.u_fogd, ENV.fogd); if (u.u_L) g.uniform3fv(u.u_L, ENV.L); if (u.u_sky) g.uniform3fv(u.u_sky, ENV.sky); if (u.u_gnd) g.uniform3fv(u.u_gnd, ENV.gnd); if (u.u_time) g.uniform1f(u.u_time, W3.time); }
export function drawTerrain() { if (!T) return; setEnv("terrain"); gl.bindVertexArray(T.vao); gl.drawElements(gl.TRIANGLES, T.n, gl.UNSIGNED_INT, 0); gl.bindVertexArray(null); W3.stats.draws++; W3.stats.tris += T.n / 3; }
export function flushModels() {
  setEnv("model"); const u = P.model.u; gl.disable(gl.CULL_FACE);
  for (const n in W3.models) { const m = W3.models[n]; if (!m.cnt) continue; gl.uniform1f(u.u_sway, m.sway); gl.uniform1f(u.u_h, m.h); gl.bindVertexArray(m.vao); gl.bindBuffer(gl.ARRAY_BUFFER, m.ib); gl.bufferSubData(gl.ARRAY_BUFFER, 0, m.data, 0, m.cnt * 24); gl.drawArraysInstanced(gl.TRIANGLES, 0, m.n, m.cnt); W3.stats.draws++; W3.stats.inst += m.cnt; W3.stats.tris += (m.n / 3) * m.cnt; }
  gl.bindVertexArray(null); gl.enable(gl.CULL_FACE);
}
let scn = null;
export function drawChar(inst_, x, y, z, yaw, o = {}) {
  const e = ENV; if (!scn) scn = { vp: VP, L: e.L, V: [0, 0, 0], fogc: e.fogc, sky: e.sky, gnd: e.gnd, cam: CP, fogd: e.fogd };
  scn.vp = VP; scn.L = e.L; scn.fogc = e.fogc; scn.sky = e.sky; scn.gnd = e.gnd; scn.cam = CP; scn.fogd = e.fogd; const d = [CP[0] - x, CP[1] - y - 1, CP[2] - z], l = Math.hypot(...d) || 1; scn.V = [d[0] / l, d[1] / l, d[2] / l];
  gl.disable(gl.CULL_FACE); const r = C3.drawDirect(inst_, { x, y, z, yaw, sc: o.sc || 1, flash: o.flash || 0 }, scn); gl.enable(gl.CULL_FACE); if (r) W3.stats.draws += 3; return r;
}
export function drawWater() {
  if (!T || T.wl < -1e8) return; setEnv("water"); const u = P.water.u; gl.uniform4f(u.u_box, T.x0, T.z0, T.x1, T.z1); gl.uniform1f(u.u_wl, T.wl); gl.uniform2f(u.u_hr, T.hmin, T.hmax - T.hmin);
  gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, T.tex); gl.uniform1i(u.u_ht, 1); gl.activeTexture(gl.TEXTURE0);
  gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); gl.disable(gl.CULL_FACE); gl.bindVertexArray(wVao); gl.drawArrays(gl.TRIANGLES, 0, 6); gl.bindVertexArray(null); gl.depthMask(true); gl.disable(gl.BLEND); gl.enable(gl.CULL_FACE); W3.stats.draws++;
}
export function frameEnd() {
  // سایه‌های نرم روی زمین، سپس ذرات
  gl.useProgram(P.bb.p); if (bbSh.length) { gl.useProgram(P.bb.p); drawBB(bbSh, true, false); }
  drawBB(bbPuff, false, false); drawBB(bbAdd, false, true);
}
export const terrainInfo = () => T;
// ثبت مدل ساخته‌شده با کد (مثلاً قایق): pos/nor Float32Array (xyz)، col Uint8Array (rgba؛ a>127 یعنی ناحیه‌ی رنگ‌پذیر تیم)
export function addMesh(name, o) {
  const n = o.pos.length / 3, vao = gl.createVertexArray(); gl.bindVertexArray(vao);
  const mk = (arr, idx, size, type, norm) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, arr, gl.STATIC_DRAW); gl.enableVertexAttribArray(idx); gl.vertexAttribPointer(idx, size, type, norm, 0, 0); };
  mk(o.pos, 0, 3, gl.FLOAT, false); mk(o.nor, 1, 3, gl.FLOAT, false); mk(o.col, 2, 4, gl.UNSIGNED_BYTE, true);
  const ib = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, ib); const cap = o.cap || 512; gl.bufferData(gl.ARRAY_BUFFER, cap * 24 * 4, gl.DYNAMIC_DRAW);
  for (let k = 0; k < 6; k++) { gl.enableVertexAttribArray(3 + k); gl.vertexAttribPointer(3 + k, 4, gl.FLOAT, false, 96, k * 16); gl.vertexAttribDivisor(3 + k, 1); }
  gl.bindVertexArray(null); W3.models[name] = { vao, n, h: o.h || 1, w: o.w || 1, ib, cap, data: new Float32Array(cap * 24), cnt: 0, sway: 0 };
}
// افزایش ظرفیت نمونه‌های یک مدل (افزودنی؛ برای صحنه‌های بزرگ مثل نقشه‌ی جهان)
export function growModel(name, cap) {
  const m = W3.models[name]; if (!m || cap <= m.cap) return !!m;
  gl.bindVertexArray(m.vao); gl.bindBuffer(gl.ARRAY_BUFFER, m.ib); gl.bufferData(gl.ARRAY_BUFFER, cap * 24 * 4, gl.DYNAMIC_DRAW); gl.bindVertexArray(null);
  m.data = new Float32Array(cap * 24); m.cap = cap; return true;
}
// نمای فعلی دوربین برای برش (صفحه‌های فرستوم) بدون تخصیص
export function frustumPlanes(out) {
  const v = W3.vp; if (!v) return out;
  for (let k = 0; k < 6; k++) {
    const a = k >> 1, s = (k & 1) ? -1 : 1; let x = v[3] + s * v[a], y = v[7] + s * v[4 + a], z = v[11] + s * v[8 + a], w = v[15] + s * v[12 + a];
    const l = Math.hypot(x, y, z) || 1; out[k * 4] = x / l; out[k * 4 + 1] = y / l; out[k * 4 + 2] = z / l; out[k * 4 + 3] = w / l;
  }
  return out;
}
