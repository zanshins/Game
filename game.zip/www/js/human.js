// انسان واقع‌گرایانه (تناسب ۷٫۵ سر، سایه‌روشن نرم، چین لباس) — برای نقشه‌ی بزرگ
const TAU = Math.PI * 2;
const hex = (c) => { const n = parseInt(c.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
export const shade = (c, t) => { const [r, g, b] = hex(c), k = t < 0 ? 0 : 255, a = Math.abs(t); return `rgb(${Math.round(r + (k - r) * a)},${Math.round(g + (k - g) * a)},${Math.round(b + (k - b) * a)})`; };
function grad(g, x0, y0, x1, y1, c) { const L = g.createLinearGradient(x0, y0, x1, y1); L.addColorStop(0, shade(c, 0.28)); L.addColorStop(0.5, c); L.addColorStop(1, shade(c, -0.42)); return L; }
function limb(g, x0, y0, x1, y1, w0, w1, c) { // عضو مخروطی با سایه
  const a = Math.atan2(y1 - y0, x1 - x0) + Math.PI / 2, dx = Math.cos(a), dy = Math.sin(a);
  g.beginPath(); g.moveTo(x0 + dx * w0, y0 + dy * w0); g.lineTo(x1 + dx * w1, y1 + dy * w1); g.arc(x1, y1, w1, a, a + Math.PI); g.lineTo(x0 - dx * w0, y0 - dy * w0); g.arc(x0, y0, w0, a + Math.PI, a + TAU); g.closePath();
  g.fillStyle = grad(g, x0 + dx * w0, y0 + dy * w0, x0 - dx * w0, y0 - dy * w0, c); g.fill(); g.strokeStyle = "rgba(15,10,20,0.55)"; g.lineWidth = 0.8; g.stroke();
}
/** o: {H, skin, hair, cloth, armor, pants, boots, cape, helm, beard, dir, walk, weapon, shield, sd} */
export function drawHuman(g, x, y, o) {
  const H = o.H || 50, u = H / 7.5, dir = o.dir || 1, ph = o.walk || 0, sw = Math.sin(ph), skin = o.skin || "#d2a074", cloth = o.cloth || "#7a4a2a", armor = o.armor, pants = o.pants || "#3a3040", boots = o.boots || "#2a1c14";
  g.save(); g.translate(x, y); g.scale(dir, 1);
  g.fillStyle = "rgba(0,0,0,0.32)"; g.beginPath(); g.ellipse(0, 0, u * 1.5, u * 0.45, 0, 0, TAU); g.fill();
  const hipY = -u * 3.7, shY = -u * 6.05, bob = Math.abs(Math.cos(ph)) * u * 0.1;
  // شنل پشت
  if (o.cape) { g.beginPath(); g.moveTo(-u * 0.55, shY + u * 0.2); g.quadraticCurveTo(-u * 1.9 - sw * u * 0.3, -u * 3.5, -u * 1.5 + sw * u * 0.4, -u * 1.0); g.lineTo(-u * 0.1, -u * 1.3); g.closePath(); g.fillStyle = grad(g, -u * 2, shY, 0, -u, o.cape); g.fill(); g.strokeStyle = "rgba(15,10,20,0.5)"; g.stroke(); }
  // پای عقب، دست عقب
  const leg = (s) => { const o2 = sw * s * u * 0.75, kx = o2 * 0.5 + s * u * 0.1, fx = o2; limb(g, s * u * 0.32, hipY, kx, -u * 1.85 - Math.abs(o2) * 0.05, u * 0.42, u * 0.3, pants); limb(g, kx, -u * 1.85, fx, -u * 0.35, u * 0.3, u * 0.24, pants);
    g.beginPath(); g.moveTo(fx - u * 0.28, -u * 0.62); g.lineTo(fx + u * 0.3, -u * 0.62); g.lineTo(fx + u * 0.65, -u * 0.05); g.lineTo(fx - u * 0.3, -u * 0.05); g.closePath(); g.fillStyle = grad(g, fx, -u * 0.6, fx, 0, boots); g.fill(); g.strokeStyle = "rgba(15,10,20,0.6)"; g.stroke(); };
  leg(-1);
  const arm = (s, back) => { const a2 = sw * -s * u * 0.7, ex = s * u * 0.2 + a2 * 0.5, ey = shY + u * 1.35, hx = ex + a2 * 0.4 + (o.weapon && s > 0 ? u * 0.5 : 0), hy = ey + u * 1.15 - (o.weapon && s > 0 ? u * 0.3 : 0);
    limb(g, s * u * 0.05, shY + u * 0.25, ex, ey, u * 0.34, u * 0.27, armor ? shade(armor, -0.15) : cloth); limb(g, ex, ey, hx, hy, u * 0.27, u * 0.22, armor ? shade(armor, 0.05) : skin); g.beginPath(); g.arc(hx, hy + u * 0.12, u * 0.22, 0, TAU); g.fillStyle = skin; g.fill(); g.stroke(); return [hx, hy]; };
  if (!o.shield) arm(-1);
  // تنه
  g.beginPath(); g.moveTo(-u * 0.8, shY); g.quadraticCurveTo(-u * 0.95, shY + u * 1.2, -u * 0.62, hipY + u * 0.25); g.lineTo(u * 0.62, hipY + u * 0.25); g.quadraticCurveTo(u * 0.95, shY + u * 1.2, u * 0.8, shY); g.quadraticCurveTo(0, shY - u * 0.28, -u * 0.8, shY); g.closePath();
  g.fillStyle = grad(g, -u, shY, u, hipY, cloth); g.fill(); g.strokeStyle = "rgba(15,10,20,0.6)"; g.lineWidth = 0.9; g.stroke();
  if (armor) { g.beginPath(); g.moveTo(-u * 0.72, shY + u * 0.05); g.quadraticCurveTo(0, shY - u * 0.15, u * 0.72, shY + u * 0.05); g.lineTo(u * 0.56, hipY - u * 0.45); g.quadraticCurveTo(0, hipY - u * 0.2, -u * 0.56, hipY - u * 0.45); g.closePath(); g.fillStyle = grad(g, -u * 0.7, shY, u * 0.7, hipY, armor); g.fill(); g.stroke();
    g.strokeStyle = "rgba(255,255,255,0.55)"; g.lineWidth = u * 0.1; g.beginPath(); g.moveTo(-u * 0.4, shY + u * 0.3); g.quadraticCurveTo(-u * 0.5, shY + u * 0.9, -u * 0.35, hipY - u * 0.7); g.stroke(); g.lineWidth = 0.9; }
  else { g.strokeStyle = "rgba(0,0,0,0.25)"; g.lineWidth = 0.8; for (const q of [-0.3, 0.15]) { g.beginPath(); g.moveTo(u * q, shY + u * 0.4); g.quadraticCurveTo(u * (q + 0.1), shY + u * 1.2, u * q * 0.9, hipY); g.stroke(); } }
  // کمربند
  g.fillStyle = "#3a2414"; g.fillRect(-u * 0.64, hipY - u * 0.12, u * 1.28, u * 0.26); g.fillStyle = "#e8c24a"; g.fillRect(-u * 0.12, hipY - u * 0.15, u * 0.24, u * 0.32);
  // دامن/ردای کوتاه
  if (o.skirt !== false) { g.beginPath(); g.moveTo(-u * 0.66, hipY + u * 0.1); g.lineTo(u * 0.66, hipY + u * 0.1); g.lineTo(u * 0.78, hipY + u * 1.0); g.lineTo(-u * 0.78, hipY + u * 1.0); g.closePath(); g.fillStyle = grad(g, 0, hipY, 0, hipY + u, o.skirtC || shade(cloth, -0.2)); g.fill(); g.strokeStyle = "rgba(15,10,20,0.5)"; g.stroke(); }
  leg(1);
  // گردن و سر
  g.fillStyle = shade(skin, -0.18); g.fillRect(-u * 0.2, shY - u * 0.55, u * 0.4, u * 0.62);
  const hy = shY - u * 1.12 - bob, hr = u * 0.74;
  g.beginPath(); g.ellipse(0, hy, hr * 0.92, hr * 1.08, 0, 0, TAU); const SG = g.createRadialGradient(-hr * 0.3, hy - hr * 0.4, 1, 0, hy, hr * 1.3); SG.addColorStop(0, shade(skin, 0.3)); SG.addColorStop(0.6, skin); SG.addColorStop(1, shade(skin, -0.4)); g.fillStyle = SG; g.fill(); g.strokeStyle = "rgba(15,10,20,0.6)"; g.lineWidth = 0.9; g.stroke();
  // گوش، چشم، ابرو، بینی، دهان (نیم‌رخ ۳/۴)
  g.fillStyle = shade(skin, -0.12); g.beginPath(); g.ellipse(-hr * 0.7, hy + hr * 0.05, hr * 0.14, hr * 0.24, 0, 0, TAU); g.fill();
  g.fillStyle = "#f4f0ea"; g.beginPath(); g.ellipse(hr * 0.38, hy - hr * 0.05, hr * 0.2, hr * 0.11, 0, 0, TAU); g.fill(); g.fillStyle = o.eye || "#2a1a10"; g.beginPath(); g.arc(hr * 0.44, hy - hr * 0.05, hr * 0.085, 0, TAU); g.fill();
  g.strokeStyle = shade(o.hair || "#2a1a10", -0.1); g.lineWidth = Math.max(1, hr * 0.12); g.lineCap = "round"; g.beginPath(); g.moveTo(hr * 0.18, hy - hr * 0.3); g.lineTo(hr * 0.62, hy - hr * 0.26); g.stroke();
  g.strokeStyle = shade(skin, -0.38); g.lineWidth = 0.9; g.beginPath(); g.moveTo(hr * 0.56, hy + hr * 0.02); g.lineTo(hr * 0.78, hy + hr * 0.3); g.lineTo(hr * 0.52, hy + hr * 0.34); g.stroke();
  g.strokeStyle = shade(skin, -0.55); g.beginPath(); g.moveTo(hr * 0.3, hy + hr * 0.6); g.lineTo(hr * 0.66, hy + hr * 0.58); g.stroke();
  // مو/ریش
  const hc = o.hair || "#2a1a10"; if (!o.helm) { g.beginPath(); g.ellipse(-hr * 0.08, hy - hr * 0.3, hr * 1.0, hr * 0.84, 0, Math.PI * 0.98, Math.PI * 2.12); g.closePath(); g.fillStyle = grad(g, 0, hy - hr, 0, hy, hc); g.fill(); g.stroke(); }
  if (o.beard) { g.beginPath(); g.moveTo(-hr * 0.5, hy + hr * 0.25); g.quadraticCurveTo(0, hy + hr * 1.7, hr * 0.62, hy + hr * 0.4); g.quadraticCurveTo(hr * 0.1, hy + hr * 0.7, -hr * 0.5, hy + hr * 0.25); g.fillStyle = grad(g, 0, hy, 0, hy + hr * 1.5, o.beardC || hc); g.fill(); g.stroke(); }
  if (o.helm) { const hc2 = o.helm; g.beginPath(); g.ellipse(0, hy - hr * 0.15, hr * 1.05, hr * 0.95, 0, Math.PI, TAU); g.lineTo(hr * 1.05, hy + hr * 0.1); g.lineTo(-hr * 1.05, hy + hr * 0.1); g.closePath(); g.fillStyle = grad(g, -hr, hy - hr, hr, hy, hc2); g.fill(); g.stroke(); g.fillStyle = shade(hc2, -0.25); g.fillRect(hr * 0.35, hy - hr * 0.05, hr * 0.28, hr * 0.7); if (o.plume) { g.fillStyle = o.plume; g.beginPath(); g.moveTo(-hr * 0.2, hy - hr * 1.0); g.quadraticCurveTo(-hr * 1.1, hy - hr * 2.0, -hr * 1.3, hy - hr * 0.7); g.lineTo(-hr * 0.4, hy - hr * 0.6); g.fill(); g.stroke(); } }
  // دست جلو و سلاح
  if (o.shield) { const [hx, hy2] = arm(-1); g.beginPath(); g.ellipse(hx + u * 0.2, hy2, u * 0.7, u * 0.95, 0, 0, TAU); g.fillStyle = grad(g, hx - u * 0.4, hy2 - u, hx + u * 0.6, hy2 + u, o.shield); g.fill(); g.strokeStyle = "rgba(15,10,20,0.7)"; g.lineWidth = 1.2; g.stroke(); g.fillStyle = "#e8c24a"; g.beginPath(); g.arc(hx + u * 0.2, hy2, u * 0.2, 0, TAU); g.fill(); }
  const [fx2, fy2] = arm(1);
  if (o.weapon === "sword") { g.save(); g.translate(fx2, fy2); g.rotate(-1.0 + sw * 0.15); g.fillStyle = "#6a4a2a"; g.fillRect(-u * 0.08, -u * 0.35, u * 0.16, u * 0.5); g.fillStyle = "#e8c24a"; g.fillRect(-u * 0.3, -u * 0.4, u * 0.6, u * 0.14); const bl = g.createLinearGradient(-u * 0.1, 0, u * 0.1, 0); bl.addColorStop(0, "#f4f8ff"); bl.addColorStop(1, "#8a98b0"); g.fillStyle = bl; g.beginPath(); g.moveTo(-u * 0.13, -u * 0.4); g.lineTo(u * 0.13, -u * 0.4); g.lineTo(u * 0.05, -u * 3.2); g.lineTo(-u * 0.05, -u * 3.2); g.closePath(); g.fill(); g.stroke(); g.restore(); }
  else if (o.weapon === "spear") { g.save(); g.translate(fx2, fy2); g.rotate(-0.12); g.strokeStyle = "#6a4a2a"; g.lineWidth = u * 0.16; g.beginPath(); g.moveTo(0, u * 1.2); g.lineTo(0, -u * 5); g.stroke(); g.fillStyle = "#cfd6e6"; g.beginPath(); g.moveTo(0, -u * 5.9); g.lineTo(u * 0.28, -u * 5); g.lineTo(-u * 0.28, -u * 5); g.closePath(); g.fill(); g.strokeStyle = "rgba(15,10,20,0.6)"; g.lineWidth = 0.8; g.stroke(); g.restore(); }
  else if (o.weapon === "bow") { g.save(); g.translate(fx2 + u * 0.2, fy2 - u * 0.4); g.strokeStyle = "#7a4a22"; g.lineWidth = u * 0.15; g.beginPath(); g.arc(0, 0, u * 1.5, -1.15, 1.15); g.stroke(); g.strokeStyle = "#e8e0d0"; g.lineWidth = 0.9; g.beginPath(); g.moveTo(Math.cos(-1.15) * u * 1.5, Math.sin(-1.15) * u * 1.5); g.lineTo(Math.cos(1.15) * u * 1.5, Math.sin(1.15) * u * 1.5); g.stroke(); g.restore(); }
  else if (o.weapon === "club") { g.save(); g.translate(fx2, fy2); g.rotate(-0.6); g.fillStyle = "#6a4a2a"; g.beginPath(); g.moveTo(-u * 0.1, u * 0.3); g.lineTo(u * 0.1, u * 0.3); g.lineTo(u * 0.45, -u * 2.2); g.lineTo(-u * 0.45, -u * 2.2); g.closePath(); g.fill(); g.strokeStyle = "rgba(15,10,20,0.7)"; g.stroke(); g.restore(); }
  g.restore();
}
