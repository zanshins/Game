// هنرِ نقشه‌ی بزرگ: زمین، جاده، پوشش گیاهی، شهر/قلعه/روستا، جانوران، قایق (همه‌ی کدها رویه‌ای)
export const TAU = Math.PI * 2;
export const mk = (w, h) => { const c = document.createElement("canvas"); c.width = Math.max(1, w | 0); c.height = Math.max(1, h | 0); return c; };
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v), mix = (a, b, t) => a + (b - a) * t, sm = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const mixc = (c1, c2, t) => [mix(c1[0], c2[0], t), mix(c1[1], c2[1], t), mix(c1[2], c2[2], t)];

// ---------------- زمین ----------------
export function bakeTerrain(P) {
  const { WW, WH, TS, elevS, fnoise, vn, hash } = P, CS = 2, gw = (WW / CS) | 0, gh = (WH / CS) | 0;
  const E = new Float32Array(gw * gh), F = new Float32Array(gw * gh);
  for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) { const fx = (x * CS) / TS, fy = (y * CS) / TS; E[y * gw + x] = elevS(fx, fy); F[y * gw + x] = fnoise(fx, fy); }
  const bg = mk(WW, WH), bx = bg.getContext("2d"), tmp = mk(gw, gh), tx = tmp.getContext("2d"), im = tx.createImageData(gw, gh), d = im.data;
  const mask = mk(gw, gh), mx = mask.getContext("2d"), mi = mx.createImageData(gw, gh), md = mi.data;
  const G1 = [84, 148, 60], G2 = [140, 180, 78], DRY = [168, 162, 88], FOR = [40, 94, 46], FOR2 = [58, 118, 56], ROCK = [124, 116, 108], ROCK2 = [92, 86, 84], SNOW = [246, 249, 255], SAND = [228, 210, 152], WET = [186, 168, 118];
  for (let y = 0; y < gh; y++) for (let x = 0; x < gw; x++) {
    const i = y * gw + x, e = E[i], fx = (x * CS) / TS, fy = (y * CS) / TS, nz = (hash(x, y, 3) - 0.5) * 9;
    const ex = E[Math.min(gw - 1, x + 1) + y * gw] - E[Math.max(0, x - 1) + y * gw], ey = E[x + Math.min(gh - 1, y + 1) * gw] - E[x + Math.max(0, y - 1) * gw];
    let c;
    if (e < 0.25) {
      const dp = clamp((0.25 - e) / 0.2, 0, 1), w = vn(fx * 5, fy * 5, 9) - 0.5;
      c = mixc([108, 200, 214], [18, 66, 124], Math.pow(dp, 0.75)); c = [c[0] + w * 10, c[1] + w * 12, c[2] + w * 12];
      const fm = sm(0.226, 0.247, e) * (0.5 + 0.5 * Math.sin(x * 0.42 + y * 0.31 + hash(x >> 2, y >> 2, 5) * 6)); c = mixc(c, [244, 252, 252], clamp(fm * 0.85, 0, 0.9));
    } else {
      const gv = vn(fx * 2.2, fy * 2.2, 6), gv2 = vn(fx * 6, fy * 6, 7);
      c = mixc(G1, G2, gv); c = mixc(c, DRY, sm(0.6, 0.78, gv2) * 0.5); c = mixc(c, [70, 140, 64], sm(0.7, 0.9, vn(fx * 9, fy * 9, 8)) * 0.35);
      const f = sm(0.55, 0.68, F[i]) * sm(0.38, 0.46, e) * (1 - sm(0.72, 0.78, e)); c = mixc(c, mixc(FOR, FOR2, vn(fx * 7, fy * 7, 12)), f * 0.92);
      const m = sm(0.69, 0.78, e); if (m > 0) { const st = vn(fx * 10, fy * 4, 13); c = mixc(c, mixc(ROCK, ROCK2, st), m); }
      const sn = sm(0.84, 0.9, e + (vn(fx * 5, fy * 5, 11) - 0.5) * 0.07); if (sn > 0) c = mixc(c, SNOW, sn);
      const K = 8 + 24 * m, sh = clamp(1 + (ex + ey) * K, 0.6, 1.4); c = [c[0] * sh, c[1] * sh, c[2] * sh];
      c = mixc(WET, c, sm(0.25, 0.256, e)); c = mixc(SAND, c, sm(0.258, 0.292, e + (vn(fx * 4, fy * 4, 14) - 0.5) * 0.02));
    }
    const o = i * 4; d[o] = clamp(c[0] + nz, 0, 255); d[o + 1] = clamp(c[1] + nz, 0, 255); d[o + 2] = clamp(c[2] + nz, 0, 255); d[o + 3] = 255;
    md[o] = 255; md[o + 1] = 255; md[o + 2] = 255; md[o + 3] = Math.round(255 * (1 - sm(0.24, 0.252, e)) * (e < 0.232 ? 1 : 0.55));
  }
  tx.putImageData(im, 0, 0); mx.putImageData(mi, 0, 0); bx.imageSmoothingEnabled = true; bx.imageSmoothingQuality = "high"; bx.drawImage(tmp, 0, 0, WW, WH);
  return { bg, mask, gw, gh, CS, E };
}
// الگوی درخشش آب
export function sparkleTile() { const c = mk(256, 256), g = c.getContext("2d"); let s = 7; const r = () => { s = (s * 16807) % 2147483647; return s / 2147483647; }; g.strokeStyle = "rgba(255,255,255,.55)"; g.lineCap = "round";
  for (let i = 0; i < 90; i++) { const x = r() * 256, y = r() * 256, l = 3 + r() * 9; g.globalAlpha = 0.25 + r() * 0.6; g.lineWidth = 1 + r() * 1.2; g.beginPath(); g.moveTo(x, y); g.lineTo(x + l, y + (r() - 0.5) * 2); g.stroke(); } return c; }
export function softBlob() { const c = mk(128, 128), g = c.getContext("2d"), gr = g.createRadialGradient(64, 64, 4, 64, 64, 62); gr.addColorStop(0, "rgba(0,0,0,.8)"); gr.addColorStop(1, "rgba(0,0,0,0)"); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); return c; }

// ---------------- جاده‌ها ----------------
export function bakeRoads(bg, nodes, cls, TS, hash) {
  const bx = bg.getContext("2d"), pts = [], edges = new Set(), segs = [];
  nodes.forEach((a, i) => { const ds = nodes.map((b, j) => [Math.hypot(a.x - b.x, a.y - b.y), j]).filter((q) => q[1] !== i).sort((p, q) => p[0] - q[0]).slice(0, 2); for (const [dd, j] of ds) { const k = Math.min(i, j) + "_" + Math.max(i, j); if (!edges.has(k) && dd < 900) { edges.add(k); segs.push([a, nodes[j]]); } } });
  const line = (arr, w, col, al) => { bx.strokeStyle = col; bx.globalAlpha = al; bx.lineWidth = w; bx.lineCap = "round"; bx.lineJoin = "round"; bx.beginPath(); let on = false; for (const p of arr) { if (!p) { on = false; continue; } if (!on) { bx.moveTo(p[0], p[1]); on = true; } else bx.lineTo(p[0], p[1]); } bx.stroke(); bx.globalAlpha = 1; };
  for (const [a, b] of segs) {
    const L = Math.hypot(b.x - a.x, b.y - a.y), n = Math.max(2, Math.floor(L / 18)), nx = -(b.y - a.y) / L, ny = (b.x - a.x) / L, arr = [];
    for (let k = 0; k <= n; k++) { const t = k / n, off = Math.sin(t * 9 + hash(a.x | 0, b.y | 0, 2) * 6) * 18 * Math.sin(t * Math.PI), x = mix(a.x, b.x, t) + nx * off, y = mix(a.y, b.y, t) + ny * off; if (cls(x / TS, y / TS) === 0) arr.push(null); else { arr.push([x, y]); pts.push([x, y]); } }
    line(arr, 11, "#6a4e2c", 0.35); line(arr, 8, "#b99458", 0.8); line(arr, 4.5, "#d6b878", 0.85);
  }
  return pts;
}

// ---------------- اسپرایت‌های ساختمان ----------------
function sprite(w, h, fn, S = 2) { const c = mk(w * S, h * S), g = c.getContext("2d"); g.scale(S, S); g.translate(w / 2, h - 10); fn(g); return { c, w, h, ox: w / 2, oy: h - 10, S }; }
function lg(g, x0, y0, x1, y1, a, b, m) { const q = g.createLinearGradient(x0, y0, x1, y1); q.addColorStop(0, a); if (m) q.addColorStop(0.5, m); q.addColorStop(1, b); return q; }
function bricks(g, x, y, w, h, al = 0.14) { g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip(); g.strokeStyle = `rgba(30,24,40,${al})`; g.lineWidth = 0.6; for (let r = 0, yy = y + 5; yy < y + h; yy += 5, r++) { g.beginPath(); g.moveTo(x, yy); g.lineTo(x + w, yy); g.stroke(); for (let xx = x + (r % 2) * 5; xx < x + w; xx += 10) { g.beginPath(); g.moveTo(xx, yy - 5); g.lineTo(xx, yy); g.stroke(); } } g.restore(); }
function stoneBox(g, x, y, w, h, c1, c2, side = 8) { // x,y گوشه‌ی بالا-چپ
  g.fillStyle = lg(g, x, y, x + w, y, c1, c2); g.fillRect(x, y, w, h); bricks(g, x, y, w, h);
  g.fillStyle = "rgba(0,0,0,.28)"; g.beginPath(); g.moveTo(x + w, y); g.lineTo(x + w + side, y - side * 0.6); g.lineTo(x + w + side, y + h - side * 0.6); g.lineTo(x + w, y + h); g.fill();
  g.fillStyle = "rgba(255,255,255,.2)"; g.beginPath(); g.moveTo(x, y); g.lineTo(x + side, y - side * 0.6); g.lineTo(x + w + side, y - side * 0.6); g.lineTo(x + w, y); g.fill();
  g.strokeStyle = "rgba(20,16,30,.55)"; g.lineWidth = 1; g.strokeRect(x, y, w, h); }
function crenel(g, x, y, w, c = "#b8b8c6") { const n = Math.max(2, Math.floor(w / 9)), cw = w / (n * 2 - 1); g.fillStyle = c; g.strokeStyle = "rgba(20,16,30,.55)"; g.lineWidth = 0.8; for (let i = 0; i < n; i++) { g.fillRect(x + i * 2 * cw, y - 5, cw, 5); g.strokeRect(x + i * 2 * cw, y - 5, cw, 5); } }
function roundTower(g, x, base, w, h, c1, c2, roof, cone = 24) { const L = x - w / 2;
  g.fillStyle = lg(g, L, 0, L + w, 0, c1, c2, "#cfcfda"); g.fillRect(L, base - h, w, h); bricks(g, L, base - h, w, h, 0.12); g.strokeStyle = "rgba(20,16,30,.55)"; g.lineWidth = 1; g.strokeRect(L, base - h, w, h);
  g.fillStyle = "#14101c"; g.beginPath(); g.moveTo(x - 2.5, base - h * 0.62); g.lineTo(x - 2.5, base - h * 0.62 - 8); g.quadraticCurveTo(x, base - h * 0.62 - 12, x + 2.5, base - h * 0.62 - 8); g.lineTo(x + 2.5, base - h * 0.62); g.fill();
  if (roof) { const ty = base - h; g.fillStyle = "rgba(0,0,0,.25)"; g.beginPath(); g.ellipse(x, ty, w * 0.62, 3.5, 0, 0, TAU); g.fill(); g.fillStyle = lg(g, L - 3, 0, L + w + 3, 0, roof[0], roof[1], roof[2]); g.beginPath(); g.moveTo(L - 3, ty); g.lineTo(x, ty - cone); g.lineTo(L + w + 3, ty); g.closePath(); g.fill(); g.strokeStyle = "rgba(20,10,10,.5)"; g.stroke(); g.strokeStyle = "rgba(0,0,0,.18)"; for (let k = 1; k < 4; k++) { g.beginPath(); g.moveTo(L - 3 + k * 2, ty - k * 5); g.lineTo(L + w + 3 - k * 2, ty - k * 5); g.stroke(); } }
  else crenel(g, L - 1, base - h, w + 2); }
function house(g, x, base, w, h, wall, roof, o = {}) { // x مرکز، base زمین
  const L = x - w / 2, top = base - h, rh = o.rh || h * 0.7, ov = 3;
  g.fillStyle = "rgba(0,0,0,.22)"; g.beginPath(); g.ellipse(x + 4, base + 1, w * 0.62, 3.5, 0, 0, TAU); g.fill();
  g.fillStyle = lg(g, L, top, L + w, base, wall[0], wall[1]); g.fillRect(L, top, w, h); g.strokeStyle = "rgba(30,20,20,.45)"; g.lineWidth = 0.9; g.strokeRect(L, top, w, h);
  if (o.timber) { g.strokeStyle = "rgba(70,44,24,.8)"; g.lineWidth = 1.2; g.beginPath(); g.moveTo(L, top + h * 0.45); g.lineTo(L + w, top + h * 0.45); g.moveTo(L + w * 0.33, top); g.lineTo(L + w * 0.33, base); g.moveTo(L + w * 0.66, top); g.lineTo(L + w * 0.66, base); g.stroke(); }
  g.fillStyle = "#3a2414"; g.fillRect(x - w * 0.12, base - h * 0.5, w * 0.24, h * 0.5); g.fillStyle = "#ffd98a"; g.fillRect(L + w * 0.12, top + h * 0.2, w * 0.18, h * 0.22); g.fillRect(L + w * 0.7, top + h * 0.2, w * 0.18, h * 0.22);
  if (o.chim) { g.fillStyle = "#7a6a66"; g.fillRect(L + w * 0.72, top - rh * 0.8, 5, rh * 0.8); }
  g.fillStyle = lg(g, L - ov, top - rh, L + w + ov, top, roof[0], roof[1]); g.beginPath(); g.moveTo(L - ov, top + 1); g.lineTo(x, top - rh); g.lineTo(L + w + ov, top + 1); g.closePath(); g.fill(); g.strokeStyle = "rgba(20,10,10,.5)"; g.stroke();
  g.fillStyle = "rgba(255,255,255,.14)"; g.beginPath(); g.moveTo(L - ov, top + 1); g.lineTo(x, top - rh); g.lineTo(x - 2, top - rh); g.lineTo(L - ov - 2, top + 1); g.fill();
  g.strokeStyle = "rgba(0,0,0,.14)"; for (let k = 1; k < 4; k++) { g.beginPath(); g.moveTo(L - ov + k * 3, top + 1 - k * rh / 4); g.lineTo(L + w + ov - k * 3, top + 1 - k * rh / 4); g.stroke(); } }
function stall(g, x, base, c) { g.fillStyle = "rgba(0,0,0,.2)"; g.beginPath(); g.ellipse(x, base + 1, 12, 3, 0, 0, TAU); g.fill(); g.fillStyle = "#6a4a2a"; g.fillRect(x - 10, base - 9, 20, 9); g.fillStyle = "#4a3018"; g.fillRect(x - 10, base - 20, 2, 11); g.fillRect(x + 8, base - 20, 2, 11);
  for (let i = 0; i < 5; i++) { g.fillStyle = i % 2 ? "#f4efe0" : c; g.beginPath(); g.moveTo(x - 12 + i * 4.8, base - 21); g.lineTo(x - 12 + (i + 1) * 4.8, base - 21); g.lineTo(x - 11 + (i + 1) * 4.4, base - 14); g.lineTo(x - 11 + i * 4.4, base - 14); g.fill(); }
  g.fillStyle = "#d84a3a"; g.beginPath(); g.arc(x - 4, base - 10, 2, 0, TAU); g.fill(); g.fillStyle = "#e8c04a"; g.beginPath(); g.arc(x + 2, base - 10, 2, 0, TAU); g.fill(); g.fillStyle = "#7ac24a"; g.beginPath(); g.arc(x + 7, base - 10, 2, 0, TAU); g.fill(); }
const THATCH = ["#d8b45a", "#a8803a"], TILE = ["#c8503a", "#8a2e24"], TILE2 = ["#4a74c0", "#2a447e"], BROWN = ["#8a6a4a", "#5a3e28"];
const PLASTER = ["#efe3c4", "#cdbd96"], PLASTER2 = ["#e4d0b0", "#bba684"], PLASTER3 = ["#d8ccb4", "#a8987a"];

export function castleSprite(state) { // open | conq | locked
  const locked = state === "locked", S1 = locked ? "#8a8a96" : "#d2d2dc", S2 = locked ? "#5a5a68" : "#9a9aaa", roof = locked ? ["#6a6a78", "#40404e", "#7a7a88"] : state === "conq" ? ["#5a8ae8", "#2a4a9a", "#7aa6ff"] : ["#e0604a", "#8a2a22", "#ff8a72"];
  const flags = [{ x: -64, y: -124 }, { x: 64, y: -124 }, { x: 0, y: -122 }];
  const sp = sprite(190, 160, (g) => {
    g.fillStyle = "rgba(0,0,0,.3)"; g.beginPath(); g.ellipse(6, 4, 88, 15, 0, 0, TAU); g.fill();
    stoneBox(g, -28, -104, 56, 58, S1, S2); crenel(g, -28, -104, 56, S1); g.fillStyle = "#14101c"; for (const wx of [-14, 8]) { g.fillRect(wx, -86, 5, 12); }
    g.fillStyle = lg(g, -28, -104, 28, -104, roof[0], roof[1]); g.beginPath(); g.moveTo(-6, -104); g.lineTo(0, -123); g.lineTo(6, -104); g.fill();
    g.strokeStyle = "#3a3040"; g.lineWidth = 1.5; g.beginPath(); g.moveTo(0, -123); g.lineTo(0, -132); g.stroke();
    stoneBox(g, -62, -48, 124, 48, S1, S2); crenel(g, -62, -48, 124, S1);
    g.fillStyle = "#1a1018"; g.beginPath(); g.moveTo(-13, 0); g.lineTo(-13, -22); g.quadraticCurveTo(0, -38, 13, -22); g.lineTo(13, 0); g.fill();
    if (!locked) { g.fillStyle = lg(g, -13, 0, 13, 0, "#6a4222", "#3a2210"); g.beginPath(); g.moveTo(-11, 0); g.lineTo(-11, -21); g.quadraticCurveTo(0, -34, 11, -21); g.lineTo(11, 0); g.fill(); g.strokeStyle = "rgba(0,0,0,.5)"; g.lineWidth = 0.8; for (let k = -8; k <= 8; k += 4) { g.beginPath(); g.moveTo(k, -3); g.lineTo(k, -26); g.stroke(); } g.strokeStyle = "#d8b24a"; g.beginPath(); g.moveTo(-11, -12); g.lineTo(11, -12); g.stroke(); }
    else { g.fillStyle = "#7a7a86"; g.fillRect(-12, -22, 24, 22); bricks(g, -12, -22, 24, 22, 0.3); }
    for (const sx of [-1, 1]) { roundTower(g, sx * 64, 6, 28, 84, S1, S2, roof, 26); g.strokeStyle = "#3a3040"; g.lineWidth = 1.5; g.beginPath(); g.moveTo(sx * 64, -104 - 4); g.lineTo(sx * 64, -121); g.stroke(); }
  }); sp.flags = flags; sp.colors = locked ? ["#8a8a96"] : state === "conq" ? ["#3f7bff", "#e8f0ff"] : ["#d83a2a", "#ffd24a"]; return sp;
}
export function townSprite() {
  const sp = sprite(270, 190, (g) => {
    g.fillStyle = "rgba(0,0,0,.28)"; g.beginPath(); g.ellipse(8, 4, 124, 18, 0, 0, TAU); g.fill();
    stoneBox(g, -108, -64, 216, 20, "#bfb49c", "#8a7e68", 6); crenel(g, -108, -64, 216, "#bfb49c");
    for (const sx of [-1, 1]) roundTower(g, sx * 108, -38, 20, 38, "#c8bda4", "#8a7e68", TILE, 16);
    const back = [[-80, -46, 30, 24, PLASTER, TILE], [-48, -46, 28, 30, PLASTER2, TILE2], [-18, -46, 30, 22, PLASTER3, BROWN], [50, -46, 30, 28, PLASTER, TILE], [80, -46, 30, 24, PLASTER2, TILE]];
    for (const [x, b, w, h, wl, rf] of back) house(g, x, b, w, h, wl, rf, { timber: x % 2 === 0, chim: true });
    stoneBox(g, -12, -112, 24, 66, "#dcd2bc", "#a69a80", 6); g.fillStyle = "#14101c"; g.fillRect(-4, -98, 8, 14); g.fillStyle = lg(g, -16, 0, 16, 0, "#e0604a", "#8a2a22"); g.beginPath(); g.moveTo(-17, -112); g.lineTo(0, -140); g.lineTo(17, -112); g.fill(); g.strokeStyle = "rgba(20,10,10,.5)"; g.stroke(); g.fillStyle = "#e8c04a"; g.beginPath(); g.arc(0, -90, 4, 0, TAU); g.fill();
    stoneBox(g, -108, -24, 216, 24, "#cfc4aa", "#968a72", 6); crenel(g, -108, -24, 216, "#cfc4aa");
    const front = [[-84, -4, 26, 20, PLASTER2, TILE2], [-56, -4, 24, 16, PLASTER, TILE], [58, -4, 26, 20, PLASTER3, TILE], [86, -4, 24, 16, PLASTER2, BROWN]]; // پشت دیوار جلو دیده نمی‌شود؛ تزئین
    g.fillStyle = "#1a1018"; g.beginPath(); g.moveTo(-14, 0); g.lineTo(-14, -18); g.quadraticCurveTo(0, -32, 14, -18); g.lineTo(14, 0); g.fill(); g.fillStyle = lg(g, -12, 0, 12, 0, "#6a4222", "#3a2210"); g.beginPath(); g.moveTo(-12, 0); g.lineTo(-12, -17); g.quadraticCurveTo(0, -28, 12, -17); g.lineTo(12, 0); g.fill();
    for (const sx of [-1, 1]) roundTower(g, sx * 26, 2, 16, 40, "#d4c8ae", "#988c74", TILE2, 16);
    stall(g, -70, 22, "#d84a3a"); stall(g, -38, 28, "#3f6ad8"); stall(g, 44, 26, "#3a9a4a"); stall(g, 76, 22, "#e8a02a");
  }); sp.flags = [{ x: -26, y: -66 }, { x: 26, y: -66 }]; sp.colors = ["#ff9a3a", "#fff0c8"]; sp.smoke = [{ x: -80 + 8, y: -78 }, { x: 50 + 8, y: -80 }, { x: 80 + 8, y: -76 }]; return sp;
}
export function villageSprite(dev) {
  const sp = sprite(190, 130, (g) => {
    g.fillStyle = "rgba(0,0,0,.22)"; g.beginPath(); g.ellipse(4, 3, 82, 12, 0, 0, TAU); g.fill();
    const H = [[-52, -10, 28, 18, PLASTER, THATCH], [-14, -18, 30, 20, PLASTER2, dev > 0 ? TILE : THATCH], [26, -12, 30, 22, PLASTER3, dev > 1 ? TILE2 : THATCH], [60, -2, 26, 16, PLASTER, THATCH], [-72, 4, 24, 15, PLASTER2, THATCH], [-28, 8, 28, 19, PLASTER, TILE], [18, 10, 28, 18, PLASTER2, THATCH]].slice(0, 4 + dev + (dev > 0 ? 0 : 0));
    H.sort((a, b) => a[1] - b[1]); for (const [x, b, w, h, wl, rf] of H) house(g, x, b, w, h, wl, rf, { timber: x % 2 === 0, chim: x % 3 === 0 });
    g.fillStyle = "#7a7a82"; g.beginPath(); g.ellipse(2, 20, 7, 3.5, 0, 0, TAU); g.fill(); g.fillStyle = "#2a4a7a"; g.beginPath(); g.ellipse(2, 19, 5, 2.4, 0, 0, TAU); g.fill();
    g.fillStyle = "#d8b45a"; g.beginPath(); g.ellipse(-90 + 18, 16, 8, 6, 0, Math.PI, 0); g.fill(); g.fillRect(-82, 16, 16, 2);
    g.strokeStyle = "#6a4a2a"; g.lineWidth = 1.2; for (let k = -70; k < 70; k += 8) { g.beginPath(); g.moveTo(k, 26); g.lineTo(k, 21); g.stroke(); } g.beginPath(); g.moveTo(-72, 23); g.lineTo(70, 23); g.stroke();
    if (dev >= 2) { g.save(); g.translate(86, -4); g.fillStyle = "#e8dcc0"; g.beginPath(); g.moveTo(-8, 0); g.lineTo(-5, -34); g.lineTo(5, -34); g.lineTo(8, 0); g.fill(); g.strokeStyle = "rgba(0,0,0,.4)"; g.stroke(); g.fillStyle = "#8a5a3a"; g.beginPath(); g.moveTo(-6, -34); g.lineTo(0, -44); g.lineTo(6, -34); g.fill(); g.restore(); }
    if (dev >= 3) { stoneBox(g, -102, -34, 20, 36, "#c8c8d2", "#8a8a98", 5); crenel(g, -102, -34, 20); }
  }); sp.flags = dev >= 1 ? [{ x: 0, y: -40 }] : []; sp.colors = ["#3f7bff", "#e8f0ff"]; sp.smoke = [{ x: -14 + 8, y: -50 }, { x: -52 + 9, y: -42 }]; if (dev === 0) sp.smoke.pop(); return sp;
}
export function homeSprite() {
  const sp = sprite(170, 140, (g) => {
    g.fillStyle = "rgba(0,0,0,.28)"; g.beginPath(); g.ellipse(4, 4, 74, 13, 0, 0, TAU); g.fill();
    stoneBox(g, -40, -56, 80, 56, "#e6dcc4", "#b4a88a", 8); bricks(g, -40, -56, 80, 56, 0.1);
    g.fillStyle = lg(g, -46, 0, 46, 0, "#5a8ae8", "#1f3f8a", "#7aa6ff"); g.beginPath(); g.moveTo(-48, -54); g.lineTo(-12, -86); g.lineTo(12, -86); g.lineTo(48, -54); g.closePath(); g.fill(); g.strokeStyle = "rgba(10,10,40,.5)"; g.stroke();
    g.fillStyle = "#1a1018"; g.beginPath(); g.moveTo(-9, 0); g.lineTo(-9, -22); g.quadraticCurveTo(0, -32, 9, -22); g.lineTo(9, 0); g.fill(); g.fillStyle = "#ffd98a"; for (const wx of [-30, 20]) g.fillRect(wx, -40, 8, 12);
    roundTower(g, -52, 0, 22, 62, "#e0d6be", "#a89c80", ["#5a8ae8", "#1f3f8a", "#7aa6ff"], 20);
    for (const [tx, c] of [[60, "#c8503a"], [78, "#d8b45a"]]) { g.fillStyle = "rgba(0,0,0,.25)"; g.beginPath(); g.ellipse(tx + 3, 4, 14, 3, 0, 0, TAU); g.fill(); g.fillStyle = c; g.beginPath(); g.moveTo(tx - 13, 3); g.lineTo(tx, -26); g.lineTo(tx + 13, 3); g.closePath(); g.fill(); g.strokeStyle = "rgba(0,0,0,.4)"; g.stroke(); g.fillStyle = "#2a1a10"; g.beginPath(); g.moveTo(tx - 3, 3); g.lineTo(tx, -9); g.lineTo(tx + 3, 3); g.fill(); }
  }); sp.flags = [{ x: -52, y: -100 }, { x: 0, y: -86 }]; sp.colors = ["#3f7bff", "#e8f0ff"]; sp.smoke = [{ x: 70, y: -22 }]; return sp;
}
export function drawSprite(g, sp, x, y, alpha = 1) { if (alpha !== 1) g.globalAlpha = alpha; g.drawImage(sp.c, x - sp.ox, y - sp.oy, sp.w, sp.h); if (alpha !== 1) g.globalAlpha = 1; }
export function drawFlag(g, x, y, col, t, ph = 0, big = 1) { // x,y محل میله؛ پرچم موج‌دار
  g.save(); g.translate(x, y); g.fillStyle = col[0]; g.strokeStyle = "rgba(0,0,0,.5)"; g.lineWidth = 0.8; g.beginPath(); g.moveTo(0, 0);
  for (let i = 0; i <= 6; i++) g.lineTo(i * 3 * big, Math.sin(t * 5 + ph + i * 0.9) * 1.6 + i * 0.1); for (let i = 6; i >= 0; i--) g.lineTo(i * 3 * big, 8 * big + Math.sin(t * 5 + ph + i * 0.9) * 1.6); g.closePath(); g.fill(); g.stroke();
  if (col[1]) { g.fillStyle = col[1]; g.fillRect(2, 3 * big, 4, 2); } g.restore(); }
export function drawSmoke(g, x, y, t, ph = 0) { for (let i = 0; i < 5; i++) { const k = ((t * 0.35 + i / 5 + ph) % 1), a = (1 - k) * 0.35; g.fillStyle = `rgba(230,230,236,${a})`; g.beginPath(); g.arc(x + Math.sin(k * 5 + i) * 3 + k * 5, y - k * 26, 2 + k * 5, 0, TAU); g.fill(); } }
export function pill(g, txt, x, y, col, size = 12, k = 1, icon) {
  g.save(); g.translate(x, y); g.scale(k, k); g.font = `800 ${size}px Vazirmatn, sans-serif`; g.textAlign = "center"; g.textBaseline = "middle"; const w = g.measureText(txt).width + 18 + (icon ? 14 : 0), h = size + 9;
  g.fillStyle = "rgba(14,16,34,.82)"; g.strokeStyle = "rgba(230,190,90,.9)"; g.lineWidth = 1.3; g.beginPath(); if (g.roundRect) g.roundRect(-w / 2, -h / 2, w, h, h / 2); else g.rect(-w / 2, -h / 2, w, h); g.fill(); g.stroke(); g.fillStyle = col || "#fff"; g.fillText(txt, 0, 1); g.restore(); }

// ---------------- جانوران ----------------
const AN = {
  wolf: { bw: 13, bh: 6.2, col: "#7d828e", dk: "#464a56", lt: "#c4c6ce", leg: 8, hs: 5.2, snout: 7, ear: 3.6, tail: 12, y: 11 },
  bear: { bw: 17, bh: 10.5, col: "#6a4a30", dk: "#3a2618", lt: "#8a6644", leg: 9, hs: 7, snout: 4.5, ear: 2.6, tail: 3, y: 12, hump: 1 },
  boar: { bw: 14, bh: 7.5, col: "#5a4636", dk: "#2e2218", lt: "#7a6450", leg: 6.5, hs: 5.4, snout: 6.5, ear: 3, tail: 4, y: 8, tusk: 1, ridge: 1 },
  lion: { bw: 14, bh: 7, col: "#c89a4a", dk: "#8a6428", lt: "#e8c880", leg: 9, hs: 5.4, snout: 4, ear: 2.4, tail: 13, y: 11, mane: 1 },
};
export function drawAnimal(g, type, x, y, dir, ph, sc = 1, t = 0, atk = 0) {
  const A = AN[type] || AN.wolf; g.save(); g.translate(x, y); g.scale(dir * sc, sc);
  g.fillStyle = "rgba(0,0,0,.28)"; g.beginPath(); g.ellipse(0, 1, A.bw * 1.15, 3.6, 0, 0, TAU); g.fill();
  const by = -A.leg - A.bh * 0.6 + Math.sin(ph * 2) * 0.5, lunge = atk * 4;
  const leg = (hx, k, far) => { const a = Math.sin(ph + k) * 0.75, lift = Math.max(0, Math.cos(ph + k)) * 3, fx = hx + a * A.leg * 0.7, fy = -lift; g.strokeStyle = far ? A.dk : A.col; g.lineCap = "round"; g.lineWidth = A.bh * 0.62; g.beginPath(); g.moveTo(hx, by + A.bh * 0.3); g.lineTo(fx, fy); g.stroke(); g.fillStyle = A.dk; g.beginPath(); g.ellipse(fx + 1, fy, 2.4, 1.6, 0, 0, TAU); g.fill(); };
  leg(-A.bw * 0.62, 0, true); leg(A.bw * 0.58, Math.PI, true);
  if (A.tail) { g.strokeStyle = A.col; g.lineWidth = A.type === "bear" ? 3 : 3.6; g.lineCap = "round"; g.beginPath(); g.moveTo(-A.bw * 0.9, by - 1); g.quadraticCurveTo(-A.bw - A.tail * 0.5, by - 4 + Math.sin(t * 6 + ph) * 2, -A.bw - A.tail * 0.8, by + 3 + Math.sin(t * 5 + ph) * 2); g.stroke(); if (type === "lion") { g.fillStyle = A.dk; g.beginPath(); g.arc(-A.bw - A.tail * 0.8, by + 3, 2.6, 0, TAU); g.fill(); } }
  const bg = g.createLinearGradient(0, by - A.bh, 0, by + A.bh); bg.addColorStop(0, A.dk); bg.addColorStop(0.45, A.col); bg.addColorStop(1, A.lt);
  g.fillStyle = bg; g.beginPath(); g.ellipse(0, by, A.bw, A.bh, 0, 0, TAU); g.fill(); if (A.hump) { g.beginPath(); g.ellipse(A.bw * 0.35, by - A.bh * 0.55, A.bw * 0.5, A.bh * 0.6, 0, 0, TAU); g.fill(); }
  if (A.ridge) { g.fillStyle = A.dk; for (let i = -3; i <= 3; i++) { g.beginPath(); g.moveTo(i * 3.5 - 1.6, by - A.bh * 0.85); g.lineTo(i * 3.5, by - A.bh - 3); g.lineTo(i * 3.5 + 1.6, by - A.bh * 0.85); g.fill(); } }
  const hx = A.bw * 0.95 + lunge, hy = by - A.bh * 0.5 - 1 - (A.hump ? 2 : 0);
  if (A.mane) { g.fillStyle = "#6a4018"; g.beginPath(); g.arc(hx - 1, hy + 1, A.hs + 3.2, 0, TAU); g.fill(); g.fillStyle = "#8a5a22"; g.beginPath(); g.arc(hx - 1.5, hy + 1, A.hs + 1.6, 0, TAU); g.fill(); }
  g.fillStyle = A.col; g.beginPath(); g.ellipse(hx, hy, A.hs, A.hs * 0.85, 0, 0, TAU); g.fill();
  g.fillStyle = A.lt; g.beginPath(); g.moveTo(hx + A.hs * 0.2, hy - 1); g.lineTo(hx + A.hs + A.snout, hy + 1.5); g.lineTo(hx + A.hs * 0.3, hy + A.hs * 0.8); g.closePath(); g.fill();
  g.fillStyle = A.col; g.beginPath(); g.moveTo(hx + A.hs * 0.1, hy - A.hs * 0.5); g.lineTo(hx + A.hs + A.snout * 0.9, hy + 0.2); g.lineTo(hx + A.hs * 0.2, hy + A.hs * 0.2); g.closePath(); g.fill();
  g.fillStyle = "#15110e"; g.beginPath(); g.ellipse(hx + A.hs + A.snout, hy + 1.2, 1.6, 1.3, 0, 0, TAU); g.fill();
  g.fillStyle = A.dk; g.beginPath(); g.moveTo(hx - A.hs * 0.6, hy - A.hs * 0.6); g.lineTo(hx - A.hs * 0.2, hy - A.hs - A.ear); g.lineTo(hx + A.hs * 0.3, hy - A.hs * 0.7); g.closePath(); g.fill();
  g.fillStyle = atk > 0 || type === "wolf" ? "#ffd24a" : "#f4f0e0"; g.beginPath(); g.arc(hx + A.hs * 0.3, hy - A.hs * 0.2, 1.3, 0, TAU); g.fill(); g.fillStyle = "#111"; g.fillRect(hx + A.hs * 0.3 + 0.2, hy - A.hs * 0.2 - 0.6, 0.9, 1.2);
  if (A.tusk) { g.fillStyle = "#f4efe0"; g.beginPath(); g.moveTo(hx + A.hs + 2, hy + 2.5); g.quadraticCurveTo(hx + A.hs + 6, hy + 2, hx + A.hs + 6, hy - 2); g.lineTo(hx + A.hs + 4.6, hy + 1.8); g.fill(); }
  if (atk > 0) { g.fillStyle = "#f6f2ea"; g.beginPath(); g.moveTo(hx + A.hs + 1, hy + 2); g.lineTo(hx + A.hs + 2.6, hy + 4.6); g.lineTo(hx + A.hs + 4, hy + 2); g.fill(); }
  leg(-A.bw * 0.6, Math.PI, false); leg(A.bw * 0.6, 0, false); g.restore();
}

// ---------------- قایق ----------------
export function drawBoat(g, x, y, dir, t, sc = 1, moving = false, rowers = 0) {
  g.save(); g.translate(x, y + Math.sin(t * 2.4) * 1.5); g.scale(dir * sc, sc);
  for (let i = 0; i < 3; i++) { const k = (t * 0.7 + i / 3) % 1; g.strokeStyle = `rgba(255,255,255,${0.5 * (1 - k)})`; g.lineWidth = 1.4; g.beginPath(); g.ellipse(0, 6, 22 + k * 16, 7 + k * 5, 0, 0, TAU); g.stroke(); }
  if (moving) for (let i = 1; i <= 6; i++) { g.fillStyle = `rgba(255,255,255,${0.42 - i * 0.06})`; g.beginPath(); g.ellipse(-24 - i * 8, 6 + Math.sin(t * 6 + i) * 1.5, 7 - i * 0.5, 2.2, 0, 0, TAU); g.fill(); }
  g.fillStyle = "rgba(0,20,40,.3)"; g.beginPath(); g.ellipse(2, 8, 26, 6, 0, 0, TAU); g.fill();
  const hull = g.createLinearGradient(0, -6, 0, 10); hull.addColorStop(0, "#9a6a3a"); hull.addColorStop(0.5, "#6a4426"); hull.addColorStop(1, "#3a2414");
  g.fillStyle = hull; g.beginPath(); g.moveTo(-26, -4); g.quadraticCurveTo(-22, 9, -6, 10); g.lineTo(12, 10); g.quadraticCurveTo(26, 8, 32, -8); g.lineTo(28, -5); g.quadraticCurveTo(0, -1, -26, -4); g.closePath(); g.fill(); g.strokeStyle = "#241408"; g.lineWidth = 1.2; g.stroke();
  g.strokeStyle = "rgba(255,220,150,.35)"; g.lineWidth = 1; g.beginPath(); g.moveTo(-22, 1); g.quadraticCurveTo(0, 5, 27, -3); g.stroke(); g.strokeStyle = "#d8b24a"; g.beginPath(); g.moveTo(-25, -3); g.quadraticCurveTo(0, 0, 29, -6); g.stroke();
  g.strokeStyle = "#4a3018"; g.lineWidth = 2.4; g.beginPath(); g.moveTo(2, -3); g.lineTo(2, -52); g.stroke();
  const bl = Math.sin(t * 2) * 2 + (moving ? 3 : 0); g.fillStyle = "#f4eede"; g.strokeStyle = "rgba(90,70,40,.6)"; g.lineWidth = 0.9; g.beginPath(); g.moveTo(4, -50); g.quadraticCurveTo(24 + bl, -34, 20 + bl, -8); g.lineTo(4, -10); g.closePath(); g.fill(); g.stroke();
  g.fillStyle = "#e8d8b8"; g.beginPath(); g.moveTo(0, -46); g.quadraticCurveTo(-12, -30, -10, -12); g.lineTo(0, -13); g.closePath(); g.fill(); g.stroke(); g.strokeStyle = "rgba(0,0,0,.12)"; for (let k = 1; k < 4; k++) { g.beginPath(); g.moveTo(4, -50 + k * 10); g.quadraticCurveTo(14, -44 + k * 9, 18 + bl * 0.6, -48 + k * 11 + 6); g.stroke(); }
  g.fillStyle = "#c83a2a"; g.beginPath(); g.moveTo(2, -52); for (let i = 0; i <= 4; i++) g.lineTo(2 - i * 3, -52 + Math.sin(t * 7 + i) * 1.2 + i * 0.4); for (let i = 4; i >= 0; i--) g.lineTo(2 - i * 3, -48 + Math.sin(t * 7 + i) * 1.2 + i * 0.4); g.fill();
  if (rowers) { g.strokeStyle = "#5a3a1a"; g.lineWidth = 1.6; const o = Math.sin(t * 5) * 6; g.beginPath(); g.moveTo(-8, -2); g.lineTo(-14 + o, 12); g.moveTo(10, -2); g.lineTo(4 + o, 12); g.stroke(); }
  g.restore();
}
export function drawChest(g, x, y, t, gem) { g.save(); g.translate(x, y); const gl = 0.5 + 0.5 * Math.sin(t * 3); g.fillStyle = `rgba(255,${gem ? 240 : 220},${gem ? 255 : 120},${0.16 + gl * 0.12})`; g.beginPath(); g.arc(0, -6, 20 + gl * 4, 0, TAU); g.fill();
  g.fillStyle = "rgba(0,0,0,.3)"; g.beginPath(); g.ellipse(1, 3, 12, 3.5, 0, 0, TAU); g.fill(); g.fillStyle = gem ? "#3a7a9a" : "#8a5a2a"; g.fillRect(-10, -11, 20, 12); g.fillStyle = gem ? "#5fd8ff" : "#b8782e"; g.beginPath(); g.moveTo(-10, -11); g.quadraticCurveTo(0, -22, 10, -11); g.fill(); g.strokeStyle = "#2a1608"; g.lineWidth = 1; g.strokeRect(-10, -11, 20, 12); g.fillStyle = "#ffd24a"; g.fillRect(-1.6, -12, 3.2, 6);
  if ((t * 2) % 2 < 0.3) { g.strokeStyle = "#fff"; g.beginPath(); g.moveTo(8, -20); g.lineTo(8, -14); g.moveTo(5, -17); g.lineTo(11, -17); g.stroke(); } g.restore(); }
export function drawCamp(g, x, y, t) { g.save(); g.translate(x, y); g.fillStyle = "rgba(255,140,40,.22)"; g.beginPath(); g.arc(0, -4, 26 + Math.sin(t * 9) * 2, 0, TAU); g.fill(); g.strokeStyle = "#4a2e18"; g.lineWidth = 3.5; g.lineCap = "round"; g.beginPath(); g.moveTo(-9, 2); g.lineTo(9, -3); g.moveTo(-9, -3); g.lineTo(9, 2); g.stroke();
  for (let i = 0; i < 3; i++) { const h = 14 + Math.sin(t * 11 + i * 2) * 4 - Math.abs(i - 1) * 4, w = 5 - Math.abs(i - 1); g.fillStyle = i === 1 ? "#ffd84a" : "#ff7a2a"; g.beginPath(); g.moveTo((i - 1) * 5 - w, -2); g.quadraticCurveTo((i - 1) * 5 - w * 0.4, -h * 0.6, (i - 1) * 5 + Math.sin(t * 9 + i) * 2, -h); g.quadraticCurveTo((i - 1) * 5 + w * 0.4, -h * 0.6, (i - 1) * 5 + w, -2); g.fill(); }
  drawSmoke(g, 0, -12, t, 0.3); g.restore(); }
// خوشه‌های نشانگر مقصد
export function drawTarget(g, x, y, t, boat) { g.save(); g.translate(x, y); g.strokeStyle = boat ? "rgba(140,220,255,.95)" : "rgba(255,230,120,.95)"; g.lineWidth = 2.2; const r = 9 + Math.sin(t * 6) * 2; g.beginPath(); g.ellipse(0, 0, r * 1.5, r * 0.8, 0, 0, TAU); g.stroke(); g.fillStyle = boat ? "#8ad8ff" : "#ffd24a"; g.beginPath(); g.moveTo(0, -4); g.lineTo(-5, -16 - Math.sin(t * 6) * 2); g.lineTo(5, -16 - Math.sin(t * 6) * 2); g.closePath(); g.fill(); g.strokeStyle = "rgba(0,0,0,.6)"; g.lineWidth = 1; g.stroke(); g.restore(); }
