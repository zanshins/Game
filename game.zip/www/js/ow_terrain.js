// زمین نقشه‌ی بزرگ: شبکه‌ی ارتفاع هموار، رنگ‌آمیزی پیکسلی با سایه‌روشن تپه، ساحل/کف، قله‌ی برفی
const TAU = Math.PI * 2, G = 4;
export function makeTerrain(WT, HT, TS, seed, vn, hash) {
  const gw = WT * G + 1, gh = HT * G + 1, E = new Float32Array(gw * gh), F = new Float32Array(gw * gh), SH = new Float32Array(gw * gh);
  const elev = (x, y) => vn(x / 9, y / 9, seed) * 0.62 + vn(x / 4, y / 4, seed + 1) * 0.26 + vn(x / 1.7, y / 1.7, seed + 3) * 0.12, fn = (x, y) => vn(x / 5, y / 5, seed + 2) * 0.75 + vn(x / 2, y / 2, seed + 4) * 0.25;
  const ss = (a, b, v) => { const t = Math.max(0, Math.min(1, (v - a) / (b - a))); return t * t * (3 - 2 * t); };
  for (let j = 0; j < gh; j++) for (let i = 0; i < gw; i++) { const fx = i / G, fy = j / G, edge = Math.min(fx, fy, WT - fx, HT - fy); let e = elev(fx, fy); e -= ss(2.6, 1.0, edge) * 0.42; if (edge < 0.9) e = Math.min(e, 0.12); E[j * gw + i] = e; F[j * gw + i] = fn(fx, fy); }
  for (let j = 0; j < gh; j++) for (let i = 0; i < gw; i++) { const gx = E[j * gw + Math.min(gw - 1, i + 1)] - E[j * gw + Math.max(0, i - 1)], gy = E[Math.min(gh - 1, j + 1) * gw + i] - E[Math.max(0, j - 1) * gw + i]; SH[j * gw + i] = -(gx + gy) * 1.0; }
  const samp = (A, fx, fy) => { const x = Math.max(0, Math.min(gw - 1.001, fx * G)), y = Math.max(0, Math.min(gh - 1.001, fy * G)), i = x | 0, j = y | 0, u = x - i, v = y - j, k = j * gw + i; return A[k] * (1 - u) * (1 - v) + A[k + 1] * u * (1 - v) + A[k + gw] * (1 - u) * v + A[k + gw + 1] * u * v; };
  const cls = (fx, fy) => { const e = samp(E, fx, fy); if (e < 0.25) return 0; if (e > 0.76) return 3; if (samp(F, fx, fy) > 0.62 && e > 0.42) return 2; return 1; };
  // نویز تایل‌پذیر
  const NZ = 256, nz = new Float32Array(NZ * NZ); for (let i = 0; i < NZ * NZ; i++) nz[i] = hash(i & 255, i >> 8, 91);
  const nzs = new Float32Array(NZ * NZ); for (let y = 0; y < NZ; y++) for (let x = 0; x < NZ; x++) { let a = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) a += nz[((y + dy) & 255) * NZ + ((x + dx) & 255)]; nzs[y * NZ + x] = a / 9; }
  // لایه‌ی خشکی (آب نیمه‌شفاف برای عمق/کف)
  function renderLand(MS) {
    const W = Math.round(WT * TS * MS), H = Math.round(HT * TS * MS), c = document.createElement("canvas"); c.width = W; c.height = H; const x = c.getContext("2d"), im = x.createImageData(W, H), d = im.data, inv = 1 / (TS * MS);
    for (let py = 0; py < H; py++) for (let px = 0; px < W; px++) {
      const fx = px * inv, fy = py * inv, n1 = nz[((py * 3) & 255) * NZ + ((px * 3) & 255)], n2 = nzs[((py >> 1) & 255) * NZ + ((px >> 1) & 255)], lo = nzs[(((py * 0.37) | 0) & 255) * NZ + (((px * 0.37) | 0) & 255)];
      let e = samp(E, fx, fy) + (n1 - 0.5) * 0.010; const f = samp(F, fx, fy), sh = samp(SH, fx, fy); let r, g, b, a = 255;
      if (e < 0.25) { const dd = Math.min(1, (0.25 - e) / 0.2); r = 12; g = 54 + (1 - dd) * 40; b = 112 + (1 - dd) * 30; a = 40 + dd * 170 * (0.6 + 0.4 * dd); const sand = ss(0.205, 0.25, e); if (sand > 0) { r = r + (140 - r) * sand * 0.8; g = g + (210 - g) * sand * 0.8; b = b + (205 - b) * sand * 0.8; a = Math.max(a * (1 - sand) , 18 + sand * 40); } const foam = ss(0.228, 0.249, e); if (foam > 0) { const fa = foam * (0.55 + n2 * 0.5); r = r + (245 - r) * fa; g = g + (250 - g) * fa; b = b + (252 - b) * fa; a = Math.max(a, 255 * fa * 0.95); } }
      else {
        const beach = 1 - ss(0.262, 0.292, e + (n2 - 0.5) * 0.02);
        if (e > 0.76) { const k = 0.8 + sh * 4.5, rock = 110 + (e - 0.76) * 140 + n2 * 22; r = rock * k; g = (rock - 4) * k; b = (rock + 8) * k; const snow = ss(0.855 + (n2 - 0.5) * 0.05, 0.905, e); if (snow > 0) { const sk = 0.92 + sh * 3.2; r += (246 * sk - r) * snow; g += (248 * sk - g) * snow; b += (255 * sk - b) * snow; } const gr = 1 - ss(0.76, 0.8, e); if (gr > 0) { r += (80 - r) * gr * 0.5; g += (120 - g) * gr * 0.5; b += (70 - b) * gr * 0.5; } }
        else {
          const fo = ss(0.58, 0.68, f) * ss(0.38, 0.48, e), dry = ss(0.55, 0.8, lo) * (1 - fo);
          r = 92 + n2 * 28 + dry * 62 - fo * 52; g = 156 + n2 * 22 + dry * 6 - fo * 62; b = 64 + n2 * 20 + dry * 4 - fo * 12;
          const hill = ss(0.62, 0.76, e); r += (120 - r) * hill * 0.35; g += (126 - g) * hill * 0.3; b += (92 - b) * hill * 0.3;
          const k = 1 + sh * 3.2; r *= k; g *= k; b *= k;
          if (beach > 0) { r += (226 - r) * beach; g += (208 - g) * beach; b += (152 - b) * beach; }
        }
        // سایه‌ی نرم لب ساحل/کف زیر آب
        a = 255;
      }
      const o = (py * W + px) * 4; d[o] = r; d[o + 1] = g; d[o + 2] = b; d[o + 3] = a;
    }
    x.putImageData(im, 0, 0); return c;
  }
  // الگوی آب متحرک
  function waterPatterns() {
    const mk = (base, n, alpha, len, seed2, dots) => { const c = document.createElement("canvas"); c.width = c.height = 256; const g = c.getContext("2d"); if (base) { const gr = g.createLinearGradient(0, 0, 256, 256); gr.addColorStop(0, base[0]); gr.addColorStop(1, base[1]); g.fillStyle = gr; g.fillRect(0, 0, 256, 256); }
      let s = seed2; const r = () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; g.lineCap = "round";
      for (let i = 0; i < n; i++) { const x0 = r() * 256, y0 = r() * 256, l = len * (0.5 + r()); for (const ox of [-256, 0, 256]) for (const oy of [-256, 0, 256]) { if (dots) { g.fillStyle = `rgba(255,255,255,${alpha * (0.4 + r() * 0.6)})`; g.fillRect(x0 + ox, y0 + oy, 1.8, 1.8); } else { g.strokeStyle = `rgba(255,255,255,${alpha})`; g.lineWidth = 1.4; g.beginPath(); g.moveTo(x0 + ox - l / 2, y0 + oy); g.quadraticCurveTo(x0 + ox, y0 + oy - 3, x0 + ox + l / 2, y0 + oy + 1); g.stroke(); } } } return c; };
    return [mk(["#2e86b4", "#1f6fa0"], 90, 0.16, 26, 11, false), mk(null, 70, 0.14, 18, 23, false), mk(null, 140, 0.6, 0, 37, true)];
  }
  return { cls, elevAt: (fx, fy) => samp(E, fx, fy), renderLand, waterPatterns, samp, E, F, G, gw, gh };
}
