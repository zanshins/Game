// موتور نبرد: دفاع (TD)، حمله به همسایه، دفاع از کشور
import { COLS, ROWS, TOWERS, TOWER_ORDER, LEVEL_COST, LEVEL_MUL, EVO_COST, EVO_BASE, SELL_RATIO, ENEMIES, MAPS, HEROES, TROOPS, buildMapRuntime, posAt, rng, heroMul, troopMul, MAX_ENERGY, ENERGY_REGEN, ATTACK_TIME } from "./data.js";
import { Sound } from "./audio.js";

let UID = 1;
const D2 = (a, b) => (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

export class Battle {
  constructor(cfg) {
    this.cfg = cfg; this.mode = cfg.mode || "td";
    this.mods = Object.assign({ dmg: 1, rate: 1, range: 1, gold: 1, start: 0, life: 0, sell: 0 }, cfg.mods || {});
    this.map = cfg.map || MAPS[cfg.mapIndex]; this.mapIndex = cfg.mapIndex ?? 0; this.rt = buildMapRuntime(this.map);
    this.rt.fly = this.rt.paths.map((p) => { const a = p.pts[0], b = p.pts[p.pts.length - 1], len = Math.hypot(b.x - a.x, b.y - a.y); return { pts: [a, b], segs: [{ a, b, len, start: 0 }], total: len }; });
    this.waves = cfg.waves || []; this.waveIdx = -1; this.spawnQ = []; this.gold = cfg.gold ?? this.map.gold + this.mods.start;
    this.maxLives = (cfg.lives ?? this.map.lives) + this.mods.life; this.lives = this.maxLives;
    this.towers = []; this.enemies = []; this.proj = []; this.fx = []; this.zones = []; this.heroes = []; this.towerAt = new Map();
    this.time = 0; this.kills = 0; this.state = "idle"; this.speed = 1; this.autoStart = false; this.countdown = 0; this.buffT = 0; this.ver = 0; this.shake = 0; this.leaks = 0; this.built = 0; this.skillsUsed = 0; this.evolves = 0; this.inWave = false;
    this.unlocked = cfg.unlocked || TOWER_ORDER; this._fe = []; this._ft = []; this.on = () => {}; this.auraT = 0; this.waveClearBonus = 0; this.earned = 0;
    for (const hk of cfg.heroes || []) if (hk) { const lvl = (cfg.heroLv || {})[hk] || 1, def = HEROES[hk]; this.heroes.push({ key: hk, def, lvl, mul: heroMul(lvl), x: -1, y: -1, tx: -1, ty: -1, deployed: false, cool: 0, cd: 0, cdMax: def.skill.cd * (1 - 0.012 * lvl), whirl: 0, swing: 0, face: 1 }); }
    this.hazards = []; this.stormT = 0; this.stormMax = 5; this.ghosts = [];
    if (this.mode === "attack") { this.setupAttack(cfg.neighbor); this.setupHazards(); }
  }
  emit(t, d) { this.on(t, d); }
  sfx(n, x, o) { Sound.sfx(n, Object.assign({ pan: x == null ? 0 : clamp((x - COLS / 2) / (COLS / 2), -0.8, 0.8) }, o)); }

  // ---------- ساخت و برج ----------
  canBuild(x, y) { return x >= 0 && y >= 0 && x < COLS && y < ROWS && !this.rt.cells.has(x + "," + y) && !this.rt.blocked.has(x + "," + y) && !this.towerAt.has(x + "," + y); }
  towerCost(k) { return TOWERS[k].cost; }
  build(kind, x, y, free = false) {
    if (!this.canBuild(x, y)) return null; const cost = this.towerCost(kind); if (!free && this.gold < cost) { this.sfx("error"); return null; }
    if (!free) this.gold -= cost;
    const t = { id: UID++, kind, x, y, cx: x + 0.5, cy: y + 0.5, lvl: 1, evo: null, cool: 0.2, ang: -Math.PI / 2, mode: "first", spent: free ? 0 : cost, kills: 0, sv: -1, st: null, born: this.time, aura: 0, fz: 0, pulse: 0, recoil: 0, hp: 1, maxhp: 1 };
    this.towers.push(t); this.towerAt.set(x + "," + y, t); this.built++; this.ver++;
    this.fxRing(t.cx, t.cy, 0.9, TOWERS[kind].color, 0.4); this.sfx(free ? "tick" : "build", t.cx); this.emit("built", t); return t;
  }
  upgradeCost(t) { if (t.lvl >= 3) return null; return Math.round(TOWERS[t.kind].cost * LEVEL_COST[t.lvl]); }
  evolveCost(t) { return t.lvl === 3 && !t.evo ? Math.round(TOWERS[t.kind].cost * EVO_COST) : null; }
  upgrade(t) { const c = this.upgradeCost(t); if (c == null) return false; if (this.gold < c) { this.sfx("error"); return false; } this.gold -= c; t.spent += c; t.lvl++; t.sv = -1; this.fxRing(t.cx, t.cy, 1.2, "#ffe58a", 0.5); this.fxBurst(t.cx, t.cy, 12, "#ffe58a", 2.2); this.sfx("upgrade", t.cx); return true; }
  evolve(t, br) { const c = this.evolveCost(t); if (c == null) return false; if (this.gold < c) { this.sfx("error"); return false; } this.gold -= c; t.spent += c; t.evo = br; t.sv = -1; this.evolves++; const col = TOWERS[t.kind].evo[br].color; this.fxRing(t.cx, t.cy, 2.4, col, 0.9); this.fxRing(t.cx, t.cy, 1.5, "#fff", 0.6); this.fxBurst(t.cx, t.cy, 36, col, 4); this.shake = 0.25; this.sfx("evolve", t.cx); this.emit("evolve", t); return true; }
  sellValue(t) { return Math.round(t.spent * (SELL_RATIO + this.mods.sell)); }
  sell(t) { this.gold += this.sellValue(t); this.towers.splice(this.towers.indexOf(t), 1); this.towerAt.delete(t.x + "," + t.y); this.ver++; this.fxBurst(t.cx, t.cy, 10, "#ffd24a", 2); this.sfx("sell", t.cx); }

  stats(t) {
    if (t.sv === this.ver && t.st) return t.st;
    const d = TOWERS[t.kind], lv = t.lvl - 1, e = t.evo ? d.evo[t.evo] : {}, m = this.mods;
    const ar = 1 + (t.auraR || 0), ag = 1 + (t.auraG || 0), kb = this.buffT > 0 ? 1.25 : 1, kr = this.buffT > 0 ? 1.5 : 1, au = 1 + (t.aura || 0), nm = this.neutral || 1;
    const eb = t.evo ? EVO_BASE : { dmg: 1, rate: 1, range: 1 };
    const s = { dmg: (d.dmg || 0) * LEVEL_MUL.dmg[lv] * (e.dmgMul || 1) * eb.dmg * m.dmg * kb * au * nm, range: (d.range || 0) * LEVEL_MUL.range[lv] * (e.rangeMul || 1) * eb.range * m.range * ag, rate: (d.rate || 1) * LEVEL_MUL.rate[lv] * (e.rateMul || 1) * eb.rate * m.rate * kr * ar * (t.enemyTower ? 0.8 : 1),
      multi: e.multi || 1, pierce: e.pierce || d.pierce || 0, chain: e.chain || d.chain || 0, slow: e.slow ?? d.slow ?? 0, slowDur: d.slowDur || 0, crit: e.crit || 0, critMul: e.critMul || 1, splash: (d.splash || 0) * (e.splashMul || 1), stun: e.stun || 0,
      burnZone: e.burnZone || 0, freezeEvery: e.freezeEvery || 0, freezeDur: e.freezeDur || 0, execute: e.execute || 0, pulse: e.pulse || 0, pulseDmg: (e.pulseDmg || 0) * LEVEL_MUL.dmg[lv] * m.dmg * nm, burn: (e.burn ?? d.burn ?? 0) * m.dmg * nm, burnDur: d.burnDur || 2.4,
      mark: e.mark || 0, ignoreArmor: !!e.ignoreArmor, knock: e.knock || 0, shred: e.shred || 0, shatter: e.shatter || 0, aoeSlow: e.aoeSlow || 0, overcharge: e.overcharge || 0, contagion: e.contagion || 0, nova: e.nova || 0, bounty: e.bounty || 0, chainFall: e.chainFall || 0.85,
      poison: (e.poison ?? d.poison ?? 0) * LEVEL_MUL.dmg[lv] * m.dmg * nm, poisonDur: d.poisonDur || 3, pcont: e.pcont || 0, men: e.men || d.men || 0, hpMul: e.hpMul || 1, tD: ((e.auraD ?? d.auraD) || 0) * (1 + lv * 0.3), tR: (e.auraR || 0) * (1 + lv * 0.3), tG: (e.auraG || 0) * (1 + lv * 0.3),
      income: (d.income || 0) * (e.incomeMul || 1) * (1 + lv * 0.5), auraOut: e.aura || 0, magic: !!d.magic, ground: !!d.ground, speed: d.speed || 10 };
    t.st = s; t.sv = this.ver; return s;
  }

  // ---------- قهرمان ----------
  deployHero(i, x, y) { const h = this.heroes[i]; if (!h) return; if (!h.deployed) { h.deployed = true; h.x = x; h.y = y; this.fxRing(x, y, 1.4, h.def.color, 0.6); this.fxBurst(x, y, 20, h.def.color, 3); this.sfx("hero_spawn", x); } h.tx = x; h.ty = y; }
  useSkill(i) {
    const h = this.heroes[i]; if (!h || !h.deployed || h.cd > 0 || this.state === "won" || this.state === "lost") return false;
    const foes = this.enemies.filter((e) => !e.dead); const dm = h.def.dmg * h.mul; h.cd = h.cdMax; this.skillsUsed++; this.sfx("skill_" + h.key, h.x); this.emit("skill", h);
    this.fxRing(h.x, h.y, 1.6, h.def.color, 0.5);
    if (h.key === "arash") {
      const tg = foes.slice().sort((a, b) => b.hp - a.hp)[0]; if (tg) {
        const dx = tg.x - h.x, dy = tg.y - h.y, L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L;
        this.fx.push({ type: "beam", x: h.x, y: h.y, x2: h.x + ux * 30, y2: h.y + uy * 30, life: 0.45, max: 0.45, color: "#ffe58a", w: 0.22 });
        for (const e of foes) { const px = e.x - h.x, py = e.y - h.y, pr = px * ux + py * uy, pd = Math.abs(px * uy - py * ux); if (pr > 0 && pd < 0.6) this.hit(e, dm * (e === tg ? 14 : 6), { src: h, magic: true, big: true }); }
      }
    } else if (h.key === "rostam") {
      for (const e of foes) if (D2(e, h) < 2.6 * 2.6) this.hit(e, dm * 7, { src: h, big: true, stun: 2 });
      this.fxRing(h.x, h.y, 2.8, "#ff9d5c", 0.7); this.fxBurst(h.x, h.y, 30, "#ff9d5c", 5); this.shake = 0.5;
    } else if (h.key === "gordafarid") h.whirl = 2.4;
    else if (h.key === "zal") {
      this.fx.push({ type: "bird", x: -2, y: h.y, life: 1.3, max: 1.3, color: "#d9f0ff" });
      for (const e of foes) this.hit(e, dm * (e.def.boss ? 4 : 6), { src: h, magic: true, big: true });
      const heal = 2 + Math.floor(h.lvl / 5); this.lives = Math.min(this.maxLives, this.lives + heal); this.sfx("heal"); this.emit("toast", `+${heal} جان ❤️`);
    } else if (h.key === "sohrab") {
      for (const e of foes) if (D2(e, h) < 3 * 3) { this.hit(e, dm * 6, { src: h, big: true, stun: 0.8 }); if (!e.boss && e.team === "enemy") e.d = Math.max(0, e.d - 1.2); }
      this.fxRing(h.x, h.y, 3, "#ff6a8a", 0.7); this.fxRing(h.x, h.y, 1.8, "#fff", 0.5); this.fxBurst(h.x, h.y, 34, "#ff6a8a", 5); this.shake = 0.45;
    } else if (h.key === "tahmineh") {
      this.buffT = Math.max(this.buffT, 8); this.lives = Math.min(this.maxLives, this.lives + 2); this.sfx("heal");
      for (const e of foes) if (D2(e, h) < 3 * 3) this.hit(e, dm * 3, { src: h, magic: true });
      this.fxRing(h.x, h.y, 3.4, "#ffb0e0", 0.9); this.fxBurst(h.x, h.y, 30, "#ffb0e0", 3.5); this.emit("toast", "+۲ جان و تقویت برج‌ها 🌹");
    } else if (h.key === "kaveh") {
      const n = 3 + Math.floor((h.lvl - 1) / 3), life = 11 + h.lvl * 0.6; this.ghosts = this.ghosts || [];
      for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2 + Math.random(), r = 0.9 + Math.random() * 0.5; this.ghosts.push({ x: h.x + Math.cos(a) * r, y: h.y + Math.sin(a) * r * 0.7, life, max: life, born: 0, dmg: (14 + h.lvl * 3.2) * this.mods.dmg, cd: 0.4 + i * 0.12, swing: 0, face: 1, kind: i % 3 === 2 ? "archer" : "sword", seed: Math.random() * 6 }); }
      this.fxRing(h.x, h.y, 3, "#9fe8ff", 0.9); this.fxBurst(h.x, h.y, 26, "#8a7a5a", 4); this.shake = 0.35; this.emit("toast", `${n} روح جنگجو از خاک برخاستند 👻`);
    }
    return true;
  }

  // ---------- موج ----------
  startWave() {
    if (this.mode === "attack" || this.state === "won" || this.state === "lost") return false; if (this.waveIdx >= this.waves.length - 1) return false;
    if (this.state === "idle") this.state = "running";
    if (this.countdown > 0 && this.waveIdx >= 0) { const b = Math.round(this.countdown * 2.5 * this.mods.gold); this.gold += b; this.emit("toast", `پاداش زودهنگام +${b}`); }
    this.waveIdx++; this.inWave = true; const w = this.waves[this.waveIdx]; this.countdown = 0; let order = 0;
    for (const g of w.groups) { let t = this.time + (g.delay || 0) + order * 0.2; for (let i = 0; i < g.count; i++, t += g.interval) this.spawnQ.push({ t, kind: g.kind, path: g.path < 0 ? i % this.rt.paths.length : Math.min(g.path, this.rt.paths.length - 1), hp: w.hpMul, gold: w.goldMul, last: g.last }); order++; }
    this.spawnQ.sort((a, b) => a.t - b.t); this.emit("wave", this.waveIdx); this.sfx("wave_start"); if (this.waves[this.waveIdx].groups.some((g) => g.kind === "boss")) { this.sfx("boss_roar"); this.shake = 0.3; }
    return true;
  }
  spawn(kind, pi, hpMul, goldMul, d0 = -0.5) {
    const def = ENEMIES[kind], path = def.flying ? this.rt.fly[pi] : this.rt.paths[pi]; const bossDef = this.map.boss;
    const e = { id: UID++, kind, def, path, pi, d: d0, hp: def.hp * hpMul, maxhp: def.hp * hpMul, speed: def.speed, armor: def.armor, flying: !!def.flying, boss: !!def.boss, gold: def.gold * goldMul * this.mods.gold, x: 0, y: 0, dx: 1, dy: 0, slowT: 0, slowAmt: 0, stunT: 0, burnT: 0, burnDps: 0, absorb: 0, absT: 0, t: 0, ability: def.boss ? bossDef.ability : null, abT: 4, chargeT: 0, wob: Math.random() * 6, hitT: 0, team: "enemy" };
    if (def.boss) { e.name = bossDef.name; if (e.ability === "frostimmune") e.armor = 0.35; }
    const p = posAt(path, d0); e.x = p.x; e.y = p.y; e.dx = p.dx || 1; e.dy = p.dy || 0; this.enemies.push(e); return e;
  }

  // ---------- حمله ----------
  setupAttack(nb) {
    this.nb = nb; this.gateMax = nb.gate; this.gate = nb.gate; this.energy = 5; this.garT = 6; this.gateHitT = 0; this.gateBreak = 0; this.timeLeft = ATTACK_TIME; this.neutral = 1 + nb.power / 420; this.state = "running"; this.spells = { rally: 0, heal: 0 }; this.rallyT = 0; this.troopsSent = 0;
    const r = rng(nb.id.charCodeAt(1) * 733 + nb.power), cand = [];
    for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS - 1; x++) { if (!this.canBuild(x, y)) continue; let near = false; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (this.rt.cells.has(x + dx + "," + (y + dy))) near = true; if (near) cand.push([x, y]); }
    for (let i = cand.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [cand[i], cand[j]] = [cand[j], cand[i]]; }
    const kinds = ["bow", "spear", "frost", "catapult", "lightning", "flame", "arcane"], placed = [];
    for (const [x, y] of cand) { if (placed.length >= nb.towers) break; if (placed.some(([a, b]) => Math.abs(a - x) + Math.abs(b - y) < 3)) continue; placed.push([x, y]); }
    placed.forEach(([x, y], i) => { const t = this.build(kinds[Math.floor(r() * Math.min(kinds.length, 3 + nb.tlvl * 1.3))], x, y, true); if (!t) return; t.lvl = clamp(nb.tlvl + (r() < 0.3 ? 1 : 0), 1, 3); t.maxhp = t.hp = 190 + t.lvl * 105 + nb.power * 2; t.sv = -1; t.enemyTower = true; });
    this.ver++;
  }
  troopLevel(k) { return (this.cfg.troopLv || {})[k] || 1; }
  deploy(kind) {
    if (this.mode !== "attack" || this.state !== "running") return false; const d = TROOPS[kind]; if (this.energy < d.energy) { this.sfx("error"); return false; }
    this.energy -= d.energy; const m = troopMul(this.troopLevel(kind)), hp = d.hp * m;
    const e = { id: UID++, kind, def: d, path: this.rt.paths[0], pi: 0, d: -0.4, hp, maxhp: hp, speed: d.speed, armor: kind === "shield" ? 0.2 : 0, flying: false, gold: 0, x: 0, y: 0, dx: 1, dy: 0, slowT: 0, slowAmt: 0, stunT: 0, burnT: 0, burnDps: 0, absorb: 0, t: 0, wob: Math.random() * 6, hitT: 0, team: "troop", taunt: !!d.tank, atk: m, cool: 0 };
    const p = posAt(e.path, e.d); e.x = p.x; e.y = p.y; this.enemies.push(e); this.troopsSent++; this.sfx("troop_spawn", 0); return true;
  }
  cast(kind) {
    if (this.mode !== "attack" || this.spells[kind] > 0) return false;
    if (kind === "rally") { this.rallyT = 6; this.spells.rally = 22; this.fxRing(COLS / 2, ROWS / 2, 6, "#ffd36b", 0.8); this.sfx("skill_kaveh"); }
    else { for (const e of this.enemies) if (e.team === "troop") { e.hp = Math.min(e.maxhp, e.hp + e.maxhp * 0.6); this.fxBurst(e.x, e.y, 6, "#7bff9a", 1.5); } this.spells.heal = 30; this.sfx("heal"); }
    return true;
  }

  // ---------- بروزرسانی ----------
  update(dt) {
    if (this.state === "won" || this.state === "lost") { this.updateFx(dt); return; }
    this.time += dt; this.shake = Math.max(0, this.shake - dt);
    if (this.buffT > 0) { this.buffT -= dt; if (this.buffT <= 0) this.ver++; }
    // موج‌ها
    if (this.mode === "td") {
      while (this.spawnQ.length && this.spawnQ[0].t <= this.time) { const s = this.spawnQ.shift(); const e = this.spawn(s.kind, s.path, s.hp, s.gold, -(this.time - s.t) * 1); if (s.last) e.finalBoss = true; }
      if (this.inWave && !this.spawnQ.length && !this.enemies.some((e) => !e.dead) && this.state === "running") this.waveDone();
      if (this.countdown > 0) { this.countdown -= dt; if (this.countdown <= 0 && this.autoStart) this.startWave(); }
    } else this.updateAttackState(dt);
    // اثر کمکی برج‌ها (تقویت ضرابخانه)
    this.auraT -= dt; if (this.auraT <= 0) { this.auraT = 0.5; this.updateAura(); }
    this.updateHazards(dt); this.updateEnemies(dt); this.updateTowers(dt); this.updateProj(dt); this.updateHeroes(dt); this.updateZones(dt); this.updateFx(dt);
    this.enemies = this.enemies.filter((e) => !e.dead);
  }
  waveDone() {
    this.inWave = false; const w = this.waves[this.waveIdx]; const bonus = Math.round((24 + this.waveIdx * 6) * this.mods.gold); let inc = bonus;
    for (const t of this.towers) if (t.kind === "bank") { const s = this.stats(t); inc += Math.round(s.income * this.mods.gold); this.fxText(t.cx, t.cy - 0.4, "+" + Math.round(s.income * this.mods.gold), "#ffd24a", 1.1); }
    this.gold += inc; this.earned += inc; this.emit("waveclear", { idx: this.waveIdx, bonus: inc }); this.sfx("wave_clear");
    if (this.waveIdx >= this.waves.length - 1) { this.finish(true); return; }
    this.countdown = 9 + 0 * w.groups.length;
  }
  updateAura() {
    for (const t of this.towers) {
      let a = 0, r = 0, g = 0;
      for (const b of this.towers) { if (b === t) continue;
        if (b.kind === "bank" && b.evo === "b" && D2(b, t) < 2.3 * 2.3) a = Math.max(a, TOWERS.bank.evo.b.aura);
        if (b.kind === "temple") { const s = this.stats(b); if (D2(b, t) < s.range * s.range) { a = Math.max(a, s.tD); r = Math.max(r, s.tR); g = Math.max(g, s.tG); } } }
      if (a !== t.aura || r !== t.auraR || g !== t.auraG) { t.aura = a; t.auraR = r; t.auraG = g; t.sv = -1; }
    }
  }
  updateEnemies(dt) {
    for (const e of this.enemies) {
      if (e.dead) continue; e.t += dt; e.hitT = Math.max(0, e.hitT - dt);
      if (e.burnT > 0) { e.burnT -= dt; this.damageRaw(e, e.burnDps * dt, null, true); if (Math.random() < dt * 6) this.fx.push({ type: "p", x: e.x + (Math.random() - 0.5) * 0.3, y: e.y - 0.1, vx: 0, vy: -0.9, life: 0.4, max: 0.4, size: 0.1, color: "#ff8a3c", add: true }); if (e.dead) continue; }
      if (e.poisT > 0) { e.poisT -= dt; this.damageRaw(e, e.poisDps * dt, null, true); if (Math.random() < dt * 5) this.fx.push({ type: "p", x: e.x + (Math.random() - 0.5) * 0.3, y: e.y - 0.1, vx: 0, vy: -0.7, life: 0.45, max: 0.45, size: 0.1, color: "#8fe04a", add: true }); if (e.dead) continue;
        if (e.pcont) { e.pt = (e.pt || 0) - dt; if (e.pt <= 0) { e.pt = 0.7; for (const o of this.enemies) if (o !== e && !o.dead && o.team === e.team && D2(o, e) < 1.1) { o.poisT = Math.max(o.poisT || 0, 2); o.poisDps = Math.max(o.poisDps || 0, e.poisDps * 0.6); o.pcont = 1; } } } }
      if (e.mark > 0) e.mark -= dt;
      if (e.burnT > 0 && e.contagious) { e.ct = (e.ct || 0) - dt; if (e.ct <= 0) { e.ct = 0.6; for (const o of this.enemies) if (o !== e && !o.dead && o.team === e.team && D2(o, e) < 1.0) { o.burnT = Math.max(o.burnT, 1.8); o.burnDps = Math.max(o.burnDps, e.burnDps * 0.7); o.contagious = true; } } }
      if (e.stunT > 0) { e.stunT -= dt; continue; }
      if (e.slowT > 0) e.slowT -= dt; else e.slowAmt = 0;
      if (e.absT > 0) { e.absT -= dt; if (e.absT <= 0) e.absorb = 0; }
      let sp = e.speed * (1 - e.slowAmt); if (e.hasteT > 0) { e.hasteT -= dt; sp *= 1.45; }
      if (e.team === "troop") { if (this.rallyT > 0) sp *= 1.6; sp *= this.hazardSlow(e); this.troopAct(e, dt); }
      if (e.boss) { sp *= this.bossAct(e, dt); if (e.dead) continue; }
      if (e.def.heals) { e.hl = (e.hl || 0) - dt; if (e.hl <= 0) { e.hl = 0.5; for (const o of this.enemies) if (o !== e && !o.dead && o.team === "enemy" && D2(o, e) < 1.7 * 1.7 && o.hp < o.maxhp) { o.hp = Math.min(o.maxhp, o.hp + o.maxhp * 0.04); this.fx.push({ type: "p", x: o.x, y: o.y - 0.2, vx: 0, vy: -0.8, life: 0.5, max: 0.5, size: 0.09, color: "#7bff9a", add: true }); } } }
      if (this.mode === "attack") {
        if (e.team === "troop") sp = this.troopFight(e, sp, dt);
        else if (e.team === "guard") { sp = this.guardFight(e, sp, dt); e.d -= sp * dt; if (e.d < 0) e.d = 0; const q = posAt(e.path, e.d); e.x = q.x; e.y = q.y; if (q.dx !== undefined) { e.dx = -q.dx; e.dy = -q.dy; } continue; }
        if (e.team === "troop" && e.d >= e.path.total) { e.d = e.path.total; this.siegeGate(e, dt); const q = posAt(e.path, e.d); e.x = q.x; e.y = q.y; continue; }
      }
      e.d += sp * dt; const p = posAt(e.path, e.d); e.x = p.x; e.y = p.y; if (p.dx !== undefined) { e.dx = p.dx; e.dy = p.dy; }
      if (e.d >= e.path.total) {
        e.dead = true;
        if (e.team === "troop") { const dmg = e.def.gate * e.atk * (this.rallyT > 0 ? 1.5 : 1); this.gate -= dmg; this.fxText(e.x - 0.4, e.y - 0.5, "-" + Math.round(dmg), "#ff8a5c", 1.2); this.fxBurst(e.x, e.y, 10, "#ffb37a", 3); this.shake = 0.15; this.sfx("gate_hit"); if (this.gate <= 0) { this.gate = 0; this.finish(true); } }
        else { const loss = e.boss ? 5 : 1; this.lives -= loss; this.leaks++; this.shake = 0.3; this.fxRing(e.x, e.y, 1.2, "#ff4d4d", 0.5); this.sfx("life_lost"); this.emit("leak", loss); if (this.lives <= 0) { this.lives = 0; this.finish(false); } }
      }
    }
  }
  bossAct(e, dt) {
    const ab = e.ability, all = ab === "all"; let m = 1; e.abT -= dt;
    if ((ab === "summon" || all) && e.abT <= 0) { e.abT = 5; for (let i = 0; i < 4; i++) this.spawn("raider", e.pi, e.maxhp / 1900 * 0.25, 0, e.d - 0.2 - i * 0.35); this.fxRing(e.x, e.y, 1.5, "#ff6a6a", 0.5); this.sfx("boss_roar"); }
    if (ab === "regen") { e.hp = Math.min(e.maxhp, e.hp + e.maxhp * (e.hp < e.maxhp * 0.5 ? 0.03 : 0.018) * dt); e.sapT = (e.sapT || 9) - dt; if (e.sapT <= 0 && e.hp < e.maxhp * 0.6) { e.sapT = 13; for (let i = 0; i < 3; i++) this.spawn("swarm" in ENEMIES ? "swarm" : "raider", e.pi, 0.5, 0, e.d - 0.25 - i * 0.3); this.fxRing(e.x, e.y, 1.8, "#58e04a", 0.6); this.emit("toast", "پیر جنگل نهال‌های جنگی صدا زد 🌿"); } }
    if (ab === "frostimmune") e.armor = e.hp > e.maxhp * 0.5 ? 0.42 : 0.2;
    if (ab === "summon" || all) { e.hwT = (e.hwT || 7) - dt; if (e.hwT <= 0) { e.hwT = 10; for (const o of this.enemies) if (!o.dead && D2(o, e) < 2.8 * 2.8) o.hasteT = 4; this.fxRing(e.x, e.y, 2.8, "#ff9a3a", 0.6); this.emit("toast", "نعره‌ی جنگ! دشمنان تندتر شدند 📣"); } }
    if (ab === "shieldphase" || all) { e.bkT = (e.bkT || 6) - dt; if (e.bkT <= 0 && e.d < e.path.total - 2.5) { e.bkT = 7.5; this.fxBurst(e.x, e.y, 14, "#d8eaff", 4); e.d += 1.3; this.fxBurst(e.x, e.y, 14, "#d8eaff", 4); this.sfx("boss_roar"); } }
    if (ab === "charge") { if (e.abT <= 0) { e.abT = 6; e.chargeT = 2.2; this.sfx("boss_roar"); } if (e.chargeT > 0) { e.chargeT -= dt; m *= 2.5; } }
    if (ab === "aura") for (const o of this.enemies) if (o !== e && !o.dead && D2(o, e) < 2.2 * 2.2) o.hp = Math.min(o.maxhp, o.hp + o.maxhp * 0.03 * dt);
    if (ab === "enrage" || all) m *= 1 + (1 - e.hp / e.maxhp) * 1.1;
    if ((ab === "shieldphase" || all) && e.abT <= 0) { e.abT = 9; e.absorb = e.maxhp * 0.16; e.absT = 6; this.fxRing(e.x, e.y, 1.6, "#8fd4ff", 0.6); }
    return m;
  }
  // ---- محاصره: سربازان پای دروازه می‌مانند و می‌کوبند؛ دروازه در برابر غیر از دروازه‌شکن زره دارد
  siegeGate(e, dt) {
    e.gt = (e.gt || 0) - dt; e.siege = true; if (e.gt > 0) return; e.gt = e.kind === "ram" ? 1.1 : 0.9;
    const ram = e.kind === "ram", dmg = e.def.gate * e.atk * (this.rallyT > 0 ? 1.5 : 1) * (ram ? 1 : 0.45) * (this.gateBreak > 0 ? 1.4 : 1);
    this.gate -= dmg; this.gateHitT = 0.15; this.fxText(e.x - 0.3 + Math.random() * 0.3, e.y - 0.5, "-" + Math.round(dmg), ram ? "#ffb347" : "#ff8a5c", ram ? 1.3 : 1); this.fxBurst(e.x + 0.3, e.y, ram ? 12 : 5, "#e8c89a", ram ? 3.5 : 2); this.shake = Math.max(this.shake, ram ? 0.22 : 0.06); this.sfx("gate_hit");
    if (this.gate <= 0) { this.gate = 0; this.fxRing(e.x + 0.4, e.y, 2.4, "#ffd24a", 0.7); this.shake = 0.6; this.finish(true); }
  }
  troopFight(e, sp, dt) {
    let g = null, bd = 0.65 * 0.65; for (const o of this.enemies) if (o.team === "guard" && !o.dead) { const dd = D2(o, e); if (dd < bd) { bd = dd; g = o; } }
    const d = e.def;
    if (d.ranged) { let far = null, fd = (d.range * 0.8) ** 2; for (const o of this.enemies) if (o.team === "guard" && !o.dead) { const dd = D2(o, e); if (dd < fd) { fd = dd; far = o; } } if (far) { e.sh = (e.sh || 0) - dt; if (e.sh <= 0) { e.sh = 0.8; this.hit(far, d.ranged * e.atk * 1.3, { src: e, magic: true }); this.fx.push({ type: "beam", x: e.x, y: e.y, x2: far.x, y2: far.y, life: 0.12, max: 0.12, color: "#a9f0b4", w: 0.05 }); } return sp * 0.4; } }
    if (!g) return sp; e.fT = (e.fT || 0) - dt; if (e.fT <= 0) { e.fT = 0.65; this.hit(g, (d.melee || 5) * e.atk * 1.5 * (this.rallyT > 0 ? 1.5 : 1), { src: e }); this.fxBurst(g.x, g.y, 3, "#fff0c0", 1.4); }
    return 0;
  }
  guardFight(e, sp, dt) {
    let t = null, bd = 0.6 * 0.6; for (const o of this.enemies) if (o.team === "troop" && !o.dead) { const dd = D2(o, e); if (dd < bd) { bd = dd; t = o; } }
    if (!t) return sp; e.fT = (e.fT || 0) - dt; if (e.fT <= 0) { e.fT = 0.8; this.damageRaw(t, e.dmg, null, false); t.hitT = 0.1; this.fxBurst(t.x, t.y, 3, "#ff8a8a", 1.4); } return 0;
  }
  spawnGuard() {
    const nb = this.nb, k = nb.power > 55 && Math.random() < 0.4 ? "shield" : "raider", def = ENEMIES[k], hp = (70 + nb.power * 2.2) * (k === "shield" ? 2.2 : 1), path = this.rt.paths[0];
    const e = { id: UID++, kind: k, def: { ...def, gold: 0 }, path, pi: 0, d: path.total - 0.2, hp, maxhp: hp, speed: 0.85 + nb.power / 400, armor: 0, flying: false, gold: 0, x: 0, y: 0, dx: -1, dy: 0, slowT: 0, slowAmt: 0, stunT: 0, burnT: 0, burnDps: 0, absorb: 0, absT: 0, t: 0, wob: Math.random() * 6, hitT: 0, team: "guard", dmg: 7 + nb.power * 0.12, cool: 0 };
    const p = posAt(path, e.d); e.x = p.x; e.y = p.y; this.enemies.push(e); this.fxBurst(e.x, e.y, 6, "#caa06a", 1.5); this.sfx("troop_spawn", 0);
  }
  troopAct(e, dt) {
    e.cool -= dt; if (e.cool > 0) return; const d = e.def, rally = this.rallyT > 0 ? 1.5 : 1;
    let best = null, bd = 99; for (const t of this.towers) { if (t.hp <= 0) continue; const dd = Math.hypot(t.cx - e.x, t.cy - e.y); if (dd < bd) { bd = dd; best = t; } }
    if (!best) return;
    if (d.ranged && bd <= d.range) { e.cool = 1; this.proj.push({ type: "tarrow", x: e.x, y: e.y, tgt: best, dmg: d.ranged * e.atk * rally, speed: 9, color: "#a9f0b4" }); this.sfx("shot_bow", e.x, { vol: 0.5 }); }
    else if (d.melee && bd <= 1.1) { e.cool = 0.6; this.damageTower(best, d.melee * e.atk * rally * 4); this.fxBurst(best.cx, best.cy, 3, "#ffe0a0", 1.5); }
  }
  damageTower(t, dmg) { t.hp -= dmg; t.hitT = 0.12; if (t.hp <= 0) { this.fxRing(t.cx, t.cy, 1.8, "#ff9d5c", 0.6); this.fxBurst(t.cx, t.cy, 26, "#caa06a", 4); this.shake = 0.25; this.sfx("tower_destroyed", t.cx); this.towers.splice(this.towers.indexOf(t), 1); this.towerAt.delete(t.x + "," + t.y); } }
  updateAttackState(dt) {
    this.energy = Math.min(MAX_ENERGY, this.energy + ENERGY_REGEN * dt * (this.rallyT > 0 ? 1.4 : 1)); this.timeLeft -= dt; if (this.rallyT > 0) this.rallyT -= dt;
    for (const k in this.spells) this.spells[k] = Math.max(0, this.spells[k] - dt);
    this.garT -= dt; this.gateHitT = Math.max(0, this.gateHitT - dt); if (this.garT <= 0 && this.gate > 0) { this.garT = Math.max(4.2, 11.5 - this.nb.power / 22); const n = 1 + (this.nb.power > 40 ? 1 : 0) + (this.nb.power > 85 ? 1 : 0); for (let i = 0; i < n; i++) setTimeout(() => this.state === "running" && this.spawnGuard(), i * 450); }
    const alive = true;
    void alive; if (this.timeLeft <= 0) this.finish(false);
  }
  finish(won) {
    if (this.state === "won" || this.state === "lost") return; this.state = won ? "won" : "lost";
    if (won) { const f = this.mode === "attack" ? clamp(this.timeLeft / ATTACK_TIME, 0, 1) : this.lives / this.maxLives; this.stars = this.mode === "attack" ? (f > 0.45 ? 3 : f > 0.2 ? 2 : 1) : f >= 0.9 ? 3 : f >= 0.5 ? 2 : 1; } else this.stars = 0;
    this.emit(won ? "win" : "lose", this.stars);
  }

  // ---------- برج‌ها و شلیک ----------
  foes(t) { return t.enemyTower ? this._ft : this._fe; }
  pick(t, s, n = 1, list) {
    const R2 = s.range * s.range, c = []; const src = list || this.foes(t);
    for (const e of src) { if (e.dead || (s.ground && e.flying)) continue; if (D2(e, t.cx !== undefined ? { x: t.cx, y: t.cy } : t) <= R2) c.push(e); }
    if (!c.length) return c; const tp = { x: t.cx, y: t.cy };
    const key = t.enemyTower ? (e) => (e.taunt ? 1000 : 0) - D2(e, tp) : t.mode === "first" ? (e) => e.d : t.mode === "close" ? (e) => -D2(e, tp) : (e) => e.hp;
    c.sort((a, b) => key(b) - key(a)); return n === 1 ? [c[0]] : c.slice(0, n);
  }
  updateGuard(t, s, dt) {
    const key = s.range.toFixed(2) + "|" + s.men + "|" + t.evo;
    if (t.gk !== key) { t.gk = key; let best = null, bd = 1e9; for (const p of this.rt.paths) for (let d = 0; d < p.total; d += 0.25) { const q = posAt(p, d), dd = Math.hypot(q.x - t.cx, q.y - t.cy); if (dd <= s.range * 0.95 && dd < bd) { bd = dd; best = q; } } t.rally = best || { x: t.cx + 0.8, y: t.cy + 0.8 };
      const old = t.men || []; t.men = []; const hp = 55 * LEVEL_MUL.dmg[t.lvl - 1] * s.hpMul; for (let i = 0; i < s.men; i++) { const o = old[i]; t.men.push({ x: o ? o.x : t.cx, y: o ? o.y : t.cy, hp: o ? Math.min(o.hp, hp) : hp, maxhp: hp, cd: 0, rez: o ? o.rez : 0, face: 1, atk: 0, id: i }); } }
    const foes = this._fe;
    for (const m of t.men) {
      if (m.hp <= 0) { m.rez -= dt; if (m.rez <= 0 && m.rez > -90) { m.hp = m.maxhp; m.rez = 0; m.x = t.cx; m.y = t.cy; this.fxBurst(m.x, m.y, 8, "#9ab8ff", 2); } continue; }
      m.atk = Math.max(0, m.atk - dt * 4); m.cd -= dt;
      const ox = Math.cos(m.id * 2.4 + 1) * 0.35, oy = Math.sin(m.id * 2.4 + 1) * 0.3; let tg = null, bd = 1.5 * 1.5;
      for (const e of foes) if (!e.dead && !e.flying && D2(e, t.rally) < bd) { bd = D2(e, t.rally); tg = e; }
      const gx = tg ? tg.x - (tg.x > m.x ? 0.35 : -0.35) : t.rally.x + ox, gy = tg ? tg.y : t.rally.y + oy, dx = gx - m.x, dy = gy - m.y, L = Math.hypot(dx, dy);
      if (L > 0.05) { const st = Math.min(L, 3 * dt); m.x += dx / L * st; m.y += dy / L * st; m.face = dx >= 0 ? 1 : -1; }
      if (tg && Math.hypot(tg.x - m.x, tg.y - m.y) < 0.6) {
        if (!tg.boss) tg.stunT = Math.max(tg.stunT || 0, 0.2);
        if (m.cd <= 0) { m.cd = 0.7; m.atk = 1; this.hit(tg, s.dmg * (1 + (s.crit && Math.random() < s.crit ? 1.6 : 0)), { src: t }); }
        m.td = (m.td || 0) - dt; if (m.td <= 0) { m.td = 0.8; m.hp -= tg.boss ? 22 : 3 + tg.def.r * 14 + (tg.def.gate ? 0 : 0); this.fxBurst(m.x, m.y, 2, "#ff8a8a", 1.2); if (m.hp <= 0) { m.rez = 7; this.fxBurst(m.x, m.y, 8, "#fff", 2); } }
      }
    }
  }
  updateTowers(dt) {
    this._fe = this.enemies.filter((e) => e.team === "enemy" && !e.dead); this._ft = this.enemies.filter((e) => e.team === "troop" && !e.dead);
    for (const t of this.towers) {
      t.recoil = Math.max(0, t.recoil - dt * 4); t.hitT = Math.max(0, (t.hitT || 0) - dt); const s = this.stats(t);
      if (t.kind === "bank" || t.kind === "temple") continue;
      if (t.kind === "guard") { this.updateGuard(t, s, dt); continue; }
      if (t.enemyTower && t.hp <= 0) continue;
      // انجماد دوره‌ای
      if (s.freezeEvery) { t.fz -= dt; if (t.fz <= 0) { const list = this.pick(t, s, 99); if (list.length) { t.fz = s.freezeEvery; for (const e of list) { e.stunT = Math.max(e.stunT, s.freezeDur); e.slowT = 2; e.slowAmt = 0.4; } this.fxRing(t.cx, t.cy, s.range, "#c9f3ff", 0.6); this.sfx("freeze", t.cx); } else t.fz = 0.3; } }
      if (s.pulse) { t.pulse -= dt; if (t.pulse <= 0) { const list = this.pick(t, s, 99); if (list.length) { t.pulse = 1; for (const e of list) this.hit(e, s.pulseDmg, { src: t, burn: s.burn }); this.fxRing(t.cx, t.cy, s.range, "#ff9d2f", 0.5); this.fxBurst(t.cx, t.cy, 14, "#ff9d2f", 3); this.sfx("explode", t.cx, { vol: 0.5 }); } else t.pulse = 0.3; } }
      t.cool -= dt; if (t.cool > 0) continue;
      const tg = this.pick(t, s, 1); if (!tg.length) { t.cool = 0.05; continue; }
      const e = tg[0]; t.ang = Math.atan2(e.y - t.cy, e.x - t.cx); t.cool = 1 / s.rate; t.recoil = 1; this.fireTower(t, s, e);
    }
  }
  fireTower(t, s, e) {
    const k = t.kind; t.shots = (t.shots || 0) + 1; const oc = s.overcharge && t.shots % s.overcharge === 0;
    const base = { src: t, magic: s.magic, crit: s.crit, critMul: s.critMul, execute: s.execute, stun: oc ? Math.max(s.stun, 0.35) : s.stun, mark: s.mark, ignoreArmor: s.ignoreArmor, knock: s.knock, shred: s.shred, shatter: s.shatter, bounty: s.bounty, mulx: oc ? 2.5 : 1 };
    if (oc) { this.fxRing(t.cx, t.cy, 1.0, "#9ff0ff", 0.3); }
    if (k === "bow" || k === "arcane") {
      const list = s.multi > 1 ? this.pick(t, s, s.multi) : [e];
      for (let i = 0; i < s.multi; i++) this.proj.push({ type: k === "bow" ? "arrow" : "orb", x: t.cx, y: t.cy, tgt: list[i % list.length], dmg: s.dmg, speed: s.speed, color: TOWERS[k].evo && t.evo ? TOWERS[k].evo[t.evo].color : TOWERS[k].color, o: base, side: i - (s.multi - 1) / 2, enemy: !!t.enemyTower, nova: s.nova && t.shots % s.nova === 0 && i === 0 ? s.dmg * 0.8 : 0 });
      this.sfx(k === "bow" ? "shot_bow" : "shot_arcane", t.cx);
    } else if (k === "spear") {
      this.sfx("shot_spear", t.cx);
      if (s.chain) this.chainHit(t, s, e, s.chain, "#b8c6ff", base);
      else { const dx = e.x - t.cx, dy = e.y - t.cy, L = Math.hypot(dx, dy) || 1; this.proj.push({ type: "spear", x: t.cx, y: t.cy, dx: dx / L, dy: dy / L, left: s.range + 0.8, dmg: s.dmg, speed: s.speed, pierce: s.pierce, hit: new Set(), o: base, color: t.evo ? TOWERS.spear.evo[t.evo].color : "#e8c27a", enemy: !!t.enemyTower }); }
    } else if (k === "catapult") {
      const T = Math.max(0.35, Math.hypot(e.x - t.cx, e.y - t.cy) / s.speed), la = e.d + (e.speed * (1 - e.slowAmt)) * T, p = e.flying ? { x: e.x, y: e.y } : posAt(e.path, Math.min(la, e.path.total));
      this.proj.push({ type: "lob", sx: t.cx, sy: t.cy, x: t.cx, y: t.cy, tx: p.x, ty: p.y, T, t: 0, dmg: s.dmg, splash: s.splash, o: base, burnZone: s.burnZone, enemy: !!t.enemyTower, color: t.evo ? TOWERS.catapult.evo[t.evo].color : "#ff9a62" }); this.sfx("shot_catapult", t.cx);
    } else if (k === "poison") {
      this.proj.push({ type: "shard", x: t.cx, y: t.cy, tgt: e, dmg: s.dmg, speed: s.speed, slow: s.slow, slowDur: s.slowDur || 1.5, o: { ...base, poison: s.poison, poisonDur: s.poisonDur, pcont: s.pcont }, color: t.evo ? TOWERS.poison.evo[t.evo].color : "#8fe04a", enemy: !!t.enemyTower }); this.sfx("shot_frost", t.cx, { vol: 0.6 });
    } else if (k === "frost") {
      this.proj.push({ type: "shard", x: t.cx, y: t.cy, tgt: e, dmg: s.dmg, speed: s.speed, slow: s.slow, slowDur: s.slowDur, aoe: s.aoeSlow, o: base, color: t.evo ? TOWERS.frost.evo[t.evo].color : "#8fe3ff", enemy: !!t.enemyTower }); this.sfx("shot_frost", t.cx);
    } else if (k === "lightning") { this.chainHit(t, s, e, s.chain, t.evo ? TOWERS.lightning.evo[t.evo].color : "#ffe45c", base, true); this.sfx("shot_lightning", t.cx); }
    else if (k === "flame") {
      this.hit(e, s.dmg, { ...base, burn: s.burn, burnDur: s.burnDur }); if (s.contagion) e.contagious = true; if (Math.random() < 0.8) this.sfx("shot_flame", t.cx);
      const dx = e.x - t.cx, dy = e.y - t.cy, L = Math.hypot(dx, dy) || 1;
      for (let i = 0; i < 3; i++) this.fx.push({ type: "p", x: t.cx + dx / L * 0.3, y: t.cy + dy / L * 0.3, vx: dx / L * 5 + (Math.random() - 0.5), vy: dy / L * 5 + (Math.random() - 0.5), life: 0.28, max: 0.28, size: 0.14, color: t.evo === "a" ? "#ff3d6a" : "#ff8a3c", add: true, grow: 1.6 });
    }
  }
  chainHit(t, s, first, n, color, base, magic) {
    const hit = new Set([first]); let cur = first, dmg = s.dmg, pts = [{ x: t.cx, y: t.cy }, { x: first.x, y: first.y }]; const src = this.foes(t);
    this.hit(first, dmg, { ...base, magic: magic || base.magic });
    for (let i = 1; i < n; i++) { let best = null, bd = 2.2 * 2.2; for (const e of src) if (!e.dead && !hit.has(e) && !(s.ground && e.flying)) { const d = D2(e, cur); if (d < bd) { bd = d; best = e; } } if (!best) break; hit.add(best); dmg *= s.chainFall; this.hit(best, dmg, { ...base, magic: magic || base.magic }); pts.push({ x: best.x, y: best.y }); cur = best; }
    this.fx.push({ type: "bolt", pts, life: 0.2, max: 0.2, color, seed: Math.random() * 99 });
  }
  updateProj(dt) {
    for (const p of this.proj) {
      if (p.dead) continue;
      if (p.type === "arrow" || p.type === "orb" || p.type === "shard" || p.type === "tarrow") {
        let tg = p.tgt; if (tg && tg.dead) { tg = null; if (p.type !== "tarrow") { let bd = 3 * 3; for (const e of this.enemies) if (!e.dead && e.team === (p.enemy ? "troop" : "enemy")) { const d = D2(e, p); if (d < bd) { bd = d; tg = e; } } p.tgt = tg; } }
        if (!tg) { p.dead = true; continue; }
        const tx = tg.cx ?? tg.x, ty = tg.cy ?? tg.y, dx = tx - p.x, dy = ty - p.y, L = Math.hypot(dx, dy), step = p.speed * dt;
        if (L <= step + 0.12) {
          p.dead = true;
          if (p.type === "tarrow") this.damageTower(tg, p.dmg * 4);
          else if (p.type === "shard") { this.hit(tg, p.dmg, { ...p.o, slow: p.slow, slowDur: p.slowDur }); if (p.aoe) { for (const e of this.enemies) if (e !== tg && !e.dead && e.team === tg.team && D2(e, tg) < p.aoe * p.aoe) { e.slowT = Math.max(e.slowT, p.slowDur); e.slowAmt = Math.max(e.slowAmt, p.slow * 0.8); } this.fxRing(tg.x, tg.y, p.aoe, "#9fd8ff", 0.3); } }
          else { this.hit(tg, p.dmg, p.o); if (p.nova) this.explode({ tx: tg.x, ty: tg.y, splash: 1.3, dmg: p.nova, o: p.o, color: "#8f7bff", enemy: p.enemy }); }
        } else { p.px = p.x; p.py = p.y; p.x += dx / L * step; p.y += dy / L * step + (p.side ? Math.sin(p.time || 0) * 0 : 0); p.time = (p.time || 0) + dt; if (p.side && !p.bent) { p.x += -dy / L * p.side * 0.25; p.y += dx / L * p.side * 0.25; p.bent = true; } p.ang = Math.atan2(dy, dx); if (p.type === "orb" || p.type === "shard") this.fx.push({ type: "p", x: p.x, y: p.y, vx: 0, vy: 0, life: 0.25, max: 0.25, size: p.type === "orb" ? 0.14 : 0.1, color: p.color, add: true }); }
      } else if (p.type === "spear") {
        const step = p.speed * dt; p.x += p.dx * step; p.y += p.dy * step; p.left -= step; p.ang = Math.atan2(p.dy, p.dx);
        for (const e of this.enemies) if (!e.dead && !p.hit.has(e) && e.team === (p.enemy ? "troop" : "enemy") && D2(e, p) < (e.def.r + 0.18) * (e.def.r + 0.18)) { p.hit.add(e); this.hit(e, p.dmg * (1 - 0.06 * (p.hit.size - 1)), p.o); if (p.hit.size >= p.pierce) { p.dead = true; break; } }
        if (p.left <= 0) p.dead = true;
      } else if (p.type === "lob") {
        p.t += dt; const u = Math.min(1, p.t / p.T); p.x = p.sx + (p.tx - p.sx) * u; p.y = p.sy + (p.ty - p.sy) * u; p.h = Math.sin(u * Math.PI) * 1.4;
        if (u >= 1) { p.dead = true; this.explode(p); }
      }
    }
    this.proj = this.proj.filter((p) => !p.dead);
  }
  explode(p) {
    const r2 = p.splash * p.splash; const team = p.enemy ? "troop" : "enemy";
    for (const e of this.enemies) if (!e.dead && e.team === team && !e.flying && D2(e, { x: p.tx, y: p.ty }) <= r2) this.hit(e, p.dmg, { ...p.o, big: true });
    this.fxRing(p.tx, p.ty, p.splash, p.color, 0.35); this.fxBurst(p.tx, p.ty, 12, p.color, 3); this.sfx("explode", p.tx, { vol: 0.8 }); this.shake = Math.max(this.shake, 0.08);
    if (p.burnZone) this.zones.push({ x: p.tx, y: p.ty, r: p.splash * 0.9, t: p.burnZone, max: p.burnZone, dps: p.dmg * 0.18, team });
  }
  updateZones(dt) { for (const z of this.zones) { z.t -= dt; for (const e of this.enemies) if (!e.dead && e.team === z.team && !e.flying && D2(e, z) < z.r * z.r) { e.burnT = Math.max(e.burnT, 0.6); e.burnDps = Math.max(e.burnDps, z.dps); } if (Math.random() < dt * 14) this.fx.push({ type: "p", x: z.x + (Math.random() - 0.5) * z.r * 1.6, y: z.y + (Math.random() - 0.5) * z.r * 1.6, vx: 0, vy: -1, life: 0.5, max: 0.5, size: 0.12, color: "#ff6a2e", add: true }); } this.zones = this.zones.filter((z) => z.t > 0); }

  // ---------- آسیب ----------
  hit(e, dmg, o = {}) {
    if (e.dead) return false; let a = dmg, crit = false;
    if (o.mulx > 1) { a *= o.mulx; crit = true; }
    if (o.crit && Math.random() < o.crit) { a *= o.critMul || 2; crit = true; }
    if (o.shatter && (e.stunT > 0 || e.slowT > 0)) { a *= o.shatter; crit = true; }
    if (e.mark > 0) a *= 1 + (e.markAmt || 0.18);
    if (!o.magic && !o.ignoreArmor) a *= 1 - Math.max(0, e.armor - (e.shred || 0)); else if (o.ignoreArmor && !o.magic) a *= 1;
    if (o.execute && !e.boss && e.hp / e.maxhp < o.execute) { a = e.hp + 1; crit = true; } else if (o.execute && e.boss && e.hp / e.maxhp < o.execute) a *= 1.6;
    if (e.absorb > 0) { const ab = Math.min(e.absorb, a); e.absorb -= ab; a -= ab; if (a <= 0) { this.fx.push({ type: "p", x: e.x, y: e.y, vx: 0, vy: 0, life: 0.15, max: 0.15, size: 0.5, color: "#8fd4ff", add: true }); return false; } }
    const frostImm = e.ability === "frostimmune";
    if (o.slow && !frostImm) { e.slowT = Math.max(e.slowT, o.slowDur || 1.5); e.slowAmt = Math.max(e.slowAmt, e.boss ? o.slow * 0.6 : o.slow); }
    if (o.stun && !e.boss) e.stunT = Math.max(e.stunT, o.stun); else if (o.stun && e.boss) e.stunT = Math.max(e.stunT, Math.min(0.6, o.stun * 0.3));
    if (o.burn && e.ability !== "aura") { e.burnT = Math.max(e.burnT, o.burnDur || 2.4); e.burnDps = Math.max(e.burnDps, o.burn); }
    if (o.poison && e.ability !== "aura") { e.poisT = Math.max(e.poisT || 0, o.poisonDur || 3); e.poisDps = Math.min(o.poison * 3.5, (e.poisDps || 0) + o.poison * 0.4); if (o.pcont) e.pcont = 1; }
    if (o.mark) { e.mark = 4; e.markAmt = o.mark; }
    if (o.shred) e.shred = Math.min(0.5, (e.shred || 0) + o.shred);
    if (o.knock && !e.boss && e.team === "enemy") { e.d = Math.max(0, e.d - o.knock); }
    e.hitT = 0.1; const k = this.damageRaw(e, a, o.src, false);
    if (k && o.bounty) { this.gold += o.bounty; this.earned += o.bounty; this.fxText(e.x, e.y - 0.6, "+" + o.bounty, "#ffd24a", 0.9); }
    if (!k && (crit || o.big || a > 40)) this.fxText(e.x, e.y - 0.35, Math.round(a) + (crit ? "!" : ""), crit ? "#ffd24a" : "#fff", crit ? 1.2 : 0.9);
    if (!k) { if (o.big) this.sfx("hit_heavy", e.x); else this.sfx("hit", e.x); }
    return k;
  }
  damageRaw(e, a, src, dot) {
    e.hp -= a; if (e.hp > 0) return false; if (e.dead) return true; e.dead = true;
    if (e.team === "troop") { this.fxBurst(e.x, e.y, 10, "#ffe0a0", 2.5); this.sfx("enemy_die", e.x, { vol: 0.5 }); return true; }
    this.kills++; if (src && src.kills !== undefined) src.kills++; this.gold += Math.round(e.gold); this.earned += Math.round(e.gold);
    this.fxBurst(e.x, e.y, e.boss ? 40 : e.def.r > 0.3 ? 14 : 8, this.map.enemyTint, e.boss ? 5 : 2.5);
    if (e.gold >= 1) this.fx.push({ type: "coin", x: e.x, y: e.y, life: 0.7, max: 0.7, amt: Math.round(e.gold) });
    this.sfx(e.boss ? "boss_die" : e.def.r > 0.3 ? "enemy_big_die" : "enemy_die", e.x);
    if (e.boss) { this.shake = 0.6; this.fxRing(e.x, e.y, 3, "#ffd24a", 0.8); }
    if (e.def.splits) for (let i = 0; i < 3; i++) this.spawn("mini", e.pi, e.maxhp / e.def.hp * 0.9, 1, e.d - i * 0.2 + 0.1);
    this.emit("kill", e); return true;
  }

  // ---------- قهرمانان ----------
  updateGhosts(dt) {
    const G = this.ghosts; if (!G || !G.length) return;
    for (let i = G.length - 1; i >= 0; i--) {
      const g = G[i]; g.born = Math.min(1, g.born + dt * 2); g.life -= dt; g.swing = Math.max(0, g.swing - dt * 5); g.cd -= dt;
      if (g.life <= 0) { this.fxBurst(g.x, g.y, 8, "#9fe8ff", 2.5); G.splice(i, 1); continue; }
      if (g.born < 1) continue;
      let best = null, bd = 16; for (const e of this.enemies) { if (e.dead) continue; const d = D2(e, g); if (d < bd) { bd = d; best = e; } }
      if (best) { const d = Math.sqrt(bd), rng = g.kind === "archer" ? 2.6 : 0.55; g.face = best.x >= g.x ? 1 : -1; if (d > rng) { const s = 2.6 * dt; g.x += (best.x - g.x) / d * s; g.y += (best.y - g.y) / d * s; } else if (g.cd <= 0) { g.cd = g.kind === "archer" ? 0.9 : 0.65; g.swing = 1; this.hit(best, g.dmg, { src: null, magic: true }); this.fxBurst(best.x, best.y, 4, "#bff4ff", 2.5); } }
    }
  }
  updateHeroes(dt) {
    this.updateGhosts(dt);
    for (const h of this.heroes) {
      if (!h.deployed) continue; h.cd = Math.max(0, h.cd - dt); h.cool -= dt; h.swing = Math.max(0, h.swing - dt * 5);
      const dx = h.tx - h.x, dy = h.ty - h.y, L = Math.hypot(dx, dy); if (h.def.melee) { /* حرکت در meleeHero */ } else if (L > 0.05) { const st = Math.min(L, 3.4 * dt); h.x += dx / L * st; h.y += dy / L * st; h.face = dx >= 0 ? 1 : -1; h.moving = true; } else h.moving = false;
      const range = h.def.range * (this.mods.range || 1);
      if (h.whirl > 0) { h.whirl -= dt; h.wt = (h.wt || 0) - dt; if (h.wt <= 0) { h.wt = 0.15; for (const e of this.enemies) if (!e.dead && e.team === "enemy" && D2(e, h) < 2.1 * 2.1) this.hit(e, h.def.dmg * h.mul * 1.4, { src: h, big: false }); this.sfx("hit_heavy", h.x, { vol: 0.4 }); } if (Math.random() < 0.8) this.fx.push({ type: "p", x: h.x + (Math.random() - 0.5) * 2, y: h.y + (Math.random() - 0.5) * 2, vx: 0, vy: 0, life: 0.2, max: 0.2, size: 0.25, color: h.def.color, add: true }); }
      if (h.def.melee) { this.meleeHero(h, dt); continue; }
      if (h.cool > 0) continue; let best = null, bd = range * range; for (const e of this.enemies) if (!e.dead && e.team === "enemy") { const d = D2(e, h); if (d < bd) { bd = d; best = e; } }
      if (!best) continue; h.cool = 1 / h.def.rate; h.swing = 1; h.face = best.x >= h.x ? 1 : -1; const dm = h.def.dmg * h.mul * this.mods.dmg;
      if (h.def.ranged || h.def.magic) { this.proj.push({ type: h.def.magic ? "orb" : "arrow", x: h.x, y: h.y, tgt: best, dmg: dm, speed: 13, color: h.def.color, o: { src: h, magic: h.def.magic }, side: 0 }); this.sfx(h.def.magic ? "shot_arcane" : "shot_bow", h.x); }
      else { for (const e of this.enemies) if (!e.dead && e.team === "enemy" && D2(e, best) < 0.9 * 0.9) this.hit(e, e === best ? dm : dm * 0.5, { src: h, big: true }); this.fx.push({ type: "slash", x: best.x, y: best.y, life: 0.2, max: 0.2, color: h.def.color, a: Math.random() * 6 }); }
    }
  }

  // قهرمان نزدیک‌زن: روی نقطه‌ی لنگر می‌ایستد؛ دشمنِ داخل «شعاع هشدار» را خودش دنبال می‌کند، می‌زند و از «شعاع افسار» جلوتر نمی‌رود
  meleeHero(h, dt) {
    const d = h.def, ax = h.tx, ay = h.ty, rng2 = d.range * (this.mods.range || 1), A = { x: ax, y: ay };
    const move = (tx, ty, sp) => { const dx = tx - h.x, dy = ty - h.y, L = Math.hypot(dx, dy); if (L > 0.04) { const st = Math.min(L, sp * dt); h.x += dx / L * st; h.y += dy / L * st; if (Math.abs(dx) > 0.02) h.face = dx >= 0 ? 1 : -1; h.moving = true; } else h.moving = false; return L; };
    if (D2(h, A) > (d.leash + 0.25) ** 2) { h.ret = true; h.tgt = null; }
    if (h.ret) { h.engaged = false; const L = move(ax, ay, 5); if (L < 0.2) h.ret = false; return; }
    let tg = h.tgt; if (tg && (tg.dead || D2(tg, A) > d.leash * d.leash)) tg = h.tgt = null;
    if (!tg) { let bd = d.aggro * d.aggro; for (const e of this.enemies) if (!e.dead && e.team === "enemy" && !e.flying && D2(e, A) <= d.leash * d.leash) { const dd = D2(e, h); if (dd < bd) { bd = dd; tg = e; } } h.tgt = tg; }
    if (!tg) { h.engaged = false; move(ax, ay, 3.4); return; }
    h.engaged = true; const dist = Math.sqrt(D2(tg, h)), reach = rng2 * 0.75;
    if (dist > reach) { move(tg.x, tg.y, 4.3); } else { h.moving = false; h.face = tg.x >= h.x ? 1 : -1; }
    if (h.cool > 0 || dist > rng2 + 0.15) return;
    h.cool = 1 / d.rate; h.swing = 1; const dm = d.dmg * h.mul * this.mods.dmg;
    for (const e of this.enemies) if (!e.dead && e.team === "enemy" && !e.flying && D2(e, tg) < 0.9 * 0.9) this.hit(e, e === tg ? dm : dm * 0.5, { src: h, big: true });
    this.fx.push({ type: "slash", x: tg.x, y: tg.y, life: 0.2, max: 0.2, color: d.color, a: Math.random() * 6 });
  }

  // ---------- خطرات نقشه‌ی همسایه ----------
  setupHazards() {
    const hz = this.map.hazard; this.hazards = []; this.stormT = 0; this.stormMax = 5; this.hzT = hz ? (hz.every || 6) * 0.6 : 0; if (!hz) return;
    if (hz.type === "icepatch") { const p = this.rt.paths[0], r = rng(77); const cells = [...this.rt.cells].map((k) => k.split(",").map(Number)).filter(([x]) => x > 1 && x < COLS - 1); for (let i = 0; i < (hz.n || 4); i++) { const c = cells[Math.floor(r() * cells.length)]; this.hazards.push({ type: "ice", x: c[0] + 0.5, y: c[1] + 0.5, r: 1.0, t: 9999, max: 9999, warn: 0 }); } void p; }
  }
  updateHazards(dt) {
    const hz = this.map.hazard; if (!hz || this.mode !== "attack") return;
    this.hzT -= dt;
    if (hz.type === "sandstorm") { if (this.stormT > 0) this.stormT -= dt; if (this.hzT <= 0) { this.hzT = hz.every; this.stormT = this.stormMax = hz.dur || 5; this.emit("toast", "طوفان شن! سربازان کند می‌شوند"); } }
    else if (hz.type === "eruption" || hz.type === "lightning") {
      if (this.hzT <= 0) { this.hzT = hz.every * (0.7 + Math.random() * 0.6); const ts = this.enemies.filter((e) => e.team === "troop" && !e.dead); const tg = ts.length ? ts[Math.floor(Math.random() * ts.length)] : null; const cell = tg ? { x: tg.x + tg.dx * 0.6, y: tg.y } : null; if (cell) { const w = hz.type === "eruption" ? 1.3 : 1.0; this.hazards.push({ type: hz.type === "eruption" ? "erupt" : "strike", x: cell.x, y: cell.y, r: hz.type === "eruption" ? 1.0 : 0.9, t: w, max: w, warn: w }); } }
    }
    for (const h of this.hazards) {
      if (h.type === "ice") continue;
      if (h.fin) { h.life -= dt; continue; }
      h.t -= dt;
      if (h.t <= 0) { h.fin = true; h.life = 0.3; h.warn = 0; const big = h.type === "erupt"; this.fxRing(h.x, h.y, h.r * 1.3, big ? "#ff6a2e" : "#bfe0ff", 0.5); this.fxBurst(h.x, h.y, big ? 24 : 16, big ? "#ff9d2f" : "#fff", 4); this.shake = Math.max(this.shake, 0.2); this.sfx(big ? "explode" : "shot_lightning", h.x);
        for (const e of this.enemies) if (!e.dead && e.team === "troop" && D2(e, h) < h.r * h.r) this.hit(e, e.maxhp * (big ? 0.22 : 0.2), { magic: true, big: true }); }
    }
    this.hazards = this.hazards.filter((h) => !h.fin || h.life > 0);
  }
  hazardSlow(e) { let m = 1; if (this.stormT > 0) m *= 0.72; if (this.hazards) for (const h of this.hazards) if (h.type === "ice" && D2(e, h) < h.r * h.r) m *= 0.65; return m; }

  // ---------- جلوه‌ها ----------
  updateFx(dt) {
    for (const f of this.fx) { f.life -= dt; if (f.type === "p" || f.type === "text") { f.x += (f.vx || 0) * dt; f.y += (f.vy || 0) * dt; } if (f.type === "bird") f.x += dt * 20; if (f.type === "coin") f.y -= dt * 0.8; }
    if (this.fx.length > 700) this.fx.splice(0, this.fx.length - 700); this.fx = this.fx.filter((f) => f.life > 0);
  }
  fxRing(x, y, r, color, life) { this.fx.push({ type: "ring", x, y, r, life, max: life, color }); }
  fxBurst(x, y, n, color, sp) { if (this.fx.length > 500) return; for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, v = (0.4 + Math.random()) * sp * 0.6; this.fx.push({ type: "p", x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 0.35 + Math.random() * 0.35, max: 0.7, size: 0.05 + Math.random() * 0.08, color, add: true }); } }
  fxText(x, y, txt, color, size) { this.fx.push({ type: "text", x, y, vx: 0, vy: -0.9, txt, color, size: size || 1, life: 0.8, max: 0.8 }); }
  towerAtCell(x, y) { return this.towerAt.get(x + "," + y) || null; }
}
