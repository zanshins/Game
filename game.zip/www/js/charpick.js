// پیش‌نمایش سه‌بعدی قهرمان + انتخاب کلاس/مدل
import * as SQ from "./squad.js";
import { CH, frameBegin, renderInst, blit } from "./char3d.js";
let initP = null;
const LIGHT = (() => { const l = [0.45, 0.8, -0.4], n = Math.hypot(...l); return l.map((v) => v / n); })();
export function glPreview(canvas, getAV, opt = {}) {
  if (!initP) initP = Promise.race([SQ.init(), new Promise((r) => setTimeout(() => r(false), 30000))]);
  let fbStop = null; initP.then((ok) => { if (!ok && alive && opt.fallback) { alive = false; cancelAnimationFrame(raf); fbStop = opt.fallback(); } });
  const ctx = canvas.getContext("2d"); let alive = true, raf = 0, inst = null, key = "", yaw = Math.PI * 0.12, auto = true, last = performance.now(), anim = 0;
  const view = { R: [1, 0, 0], U: [0, 1, 0], D: [0, 0, 1], k: 100, dpr: 1, L: LIGHT, fogc: [1, 1, 1], sky: [1, 1, 1], gnd: [0.8, 0.75, 0.7] };
  let dx0 = null; canvas.style.touchAction = "none";
  canvas.onpointerdown = (e) => { dx0 = e.clientX; auto = false; canvas.setPointerCapture?.(e.pointerId); };
  canvas.onpointermove = (e) => { if (dx0 === null) return; yaw += (e.clientX - dx0) * 0.012; dx0 = e.clientX; };
  canvas.onpointerup = canvas.onpointercancel = () => { dx0 = null; };
  const fr = () => {
    if (!alive || !canvas.isConnected) return; raf = requestAnimationFrame(fr);
    const now = performance.now(), dt = Math.min(0.05, (now - last) / 1000); last = now;
    const W = canvas.width, Hh = canvas.height; ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, W, Hh);
    const g = ctx.createRadialGradient(W / 2, Hh * 0.55, 10, W / 2, Hh * 0.55, W * 0.75); g.addColorStop(0, "#3c3060"); g.addColorStop(1, "#120d22"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, Hh);
    ctx.fillStyle = "rgba(0,0,0,0.35)"; ctx.beginPath(); ctx.ellipse(W / 2, Hh * 0.9, W * 0.22, W * 0.05, 0, 0, 6.3); ctx.fill();
    if (!SQ.ready()) { ctx.fillStyle = "#fff9"; ctx.font = "14px Vazirmatn, sans-serif"; ctx.textAlign = "center"; ctx.fillText("در حال بارگذاری مدل…", W / 2, Hh / 2); return; }
    const av = getAV(), k2 = JSON.stringify(av.char || {}) + av.skin + av.hair + av.tunic;
    if (!inst || k2 !== key) { key = k2; const sp = SQ.heroSpec(av, {}); inst = SQ.make(sp, 3); inst.preview = true; inst.play(inst.cfg.idle, { speed: 1, fade: 0.1 }); }
    if (auto) yaw += dt * 0.5;
    if (opt.anim) { anim -= dt; if (anim <= 0) { anim = 2.6; const c = inst.cfg; inst.play(c.atk[Math.floor(Math.random() * c.atk.length)], { loop: false, speed: 1.4, fade: 0.05, restart: true }); setTimeout(() => inst && inst.play(inst.cfg.idle, { speed: 1, fade: 0.2 }), 900); } }
    inst.update(dt);
    frameBegin(); view.k = Hh * 0.42 / 1.0; view.dpr = 1;
    const sc = Math.min(W / 260, Hh / 360); view.k = 150 * sc;
    const t = renderInst(inst, { x: 0, y: 0, z: 0, yaw, sc: 1, fog: 0, flash: 0 }, view);
    if (t) blit(ctx, t, W / 2, Hh * 0.9 - 0.95 * view.k * (inst.scale || 1));
  };
  fr(); return () => { alive = false; cancelAnimationFrame(raf); if (fbStop) fbStop(); };
}
export const CLASSES = [["Warrior", "جنگجو", "شمشیر و سپر، متعادل"], ["Knight", "شوالیه", "زره سنگین، سلاح و کلاه‌خود قابل انتخاب"], ["Ranger", "کماندار", "چابک و تیرانداز"], ["Rogue", "دزد", "خنجر و سرعت"], ["Cleric", "کشیش", "عصا و روحانی"], ["Monk", "راهب", "مشت‌زن"], ["Wizard", "جادوگر", "عصای جادو"]];
export const KN_WEAPONS = [["Sword", "شمشیر"], ["ShortSword", "شمشیر کوتاه"], ["Katana", "کاتانا"], ["Club", "گرز"]];
export const KN_HELMETS = [["Helmet1", "کلاه‌خود ۱"], ["Helmet2", "کلاه‌خود ۲"], ["Helmet3", "کلاه‌خود ۳"], ["", "بدون کلاه"]];
export const CLOTHS = ["#3a5aa8", "#2f6a9a", "#3a7a5a", "#5a4aa0", "#8a2a2a", "#7a3a22", "#2a2a30", "#c8b070", "#6a2a7a", "#e0e0e8"];
export const CLOTHS2 = ["#a82a2a", "#d8b84a", "#2a3566", "#1a5a3a", "#e0e0e8", "#5a3a1e", "#7a2a8a", "#222"];
export const METALS = ["#b4bccc", "#e0c870", "#8a8f9a", "#c8825a", "#6a8ab0", "#3a3a44"];
