// تجهیزات، چهره و ظاهر قهرمان سه‌بعدی (داده + نقاشی چهره + آیکون‌های تجهیزات)
const TAU = Math.PI * 2, clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const SLOTS = { sword: "سلاح", shield: "سپر", helm: "کلاه‌خود", armor: "زره", cape: "شنل", aura: "هاله" };
export const RARITY = { c: { n: "معمولی", col: "#b8c2d6" }, r: { n: "کمیاب", col: "#43a6ff" }, e: { n: "حماسی", col: "#bb6cff" }, l: { n: "افسانه‌ای", col: "#ffc531" } };
export const GEAR = {
  sword: [
    { id: "s0", name: "شمشیر آهنی", dmg: 14, cost: 0, r: "c", kind: "sword", blade: "#cfd6df", hilt: "#8a6a3a", len: 1.0 },
    { id: "s1", name: "شمشیر فولادی", dmg: 22, cost: 600, r: "c", kind: "sword", blade: "#e8f1ff", hilt: "#b0b8c8", len: 1.1 },
    { id: "s5", name: "تبرزین کاوه", dmg: 27, cost: 1500, r: "r", kind: "axe", blade: "#c8d2e2", hilt: "#6a4a2a", len: 1.0 },
    { id: "s2", name: "قمه‌ی پارسی", dmg: 30, cost: 1800, r: "r", kind: "curve", blade: "#f0e6c8", hilt: "#c8923a", len: 1.15, curve: 1 },
    { id: "s6", name: "گرز گاوسر", dmg: 36, cost: 2800, r: "r", kind: "mace", blade: "#d6a85a", hilt: "#5a3a1a", len: 1.0 },
    { id: "s3", name: "تیغ آتشین", dmg: 44, cost: 4800, r: "e", kind: "sword", blade: "#ff9a4a", hilt: "#7a2a1a", len: 1.25, glow: "#ff6a2a" },
    { id: "s7", name: "تبر ضحاک", dmg: 52, cost: 6400, r: "e", kind: "axe", blade: "#8aff7a", hilt: "#2a3a2a", len: 1.1, glow: "#58e04a" },
    { id: "s4", name: "ذوالفقار", dmg: 62, cost: 0, gems: 120, r: "l", kind: "twin", blade: "#9fe8ff", hilt: "#ffd24a", len: 1.35, glow: "#5ad0ff", twin: 1 },
    { id: "s8", name: "شمشیر جمشید", dmg: 78, cost: 0, gems: 260, r: "l", kind: "sword", blade: "#fff0a8", hilt: "#e8a317", len: 1.45, glow: "#ffd24a" },
  ],
  shield: [
    { id: "d0", name: "بدون سپر", def: 0, cost: 0, r: "c" },
    { id: "d1", name: "سپر چوبی", def: 0.1, cost: 400, r: "c", color: "#9a7248", rim: "#5a4028", shape: "round" },
    { id: "d2", name: "سپر فولادی", def: 0.18, cost: 1500, r: "c", color: "#aab4c4", rim: "#6a7486", shape: "kite" },
    { id: "d4", name: "سپر سیاوش", def: 0.23, cost: 2800, r: "r", color: "#3a8ad8", rim: "#d8e6ff", shape: "round", emblem: 2 },
    { id: "d3", name: "سپر شاهی", def: 0.29, cost: 5200, r: "e", color: "#e0b840", rim: "#8a6a1a", shape: "kite", emblem: 1 },
    { id: "d5", name: "سپر فروهر", def: 0.37, cost: 0, gems: 150, r: "l", color: "#f4e6a8", rim: "#c8862a", shape: "round", emblem: 3, glow: "#ffd24a" },
  ],
  helm: [
    { id: "h0", name: "کلاه چرمی", hp: 10, cost: 0, r: "c", color: "#8a6a4a", kind: "cap" },
    { id: "h1", name: "کلاه‌خود آهنی", hp: 28, cost: 500, r: "c", color: "#aab4c4", kind: "helm" },
    { id: "h8", name: "خود زنجیری", hp: 40, cost: 1100, r: "r", color: "#9aa4b4", kind: "coif" },
    { id: "h2", name: "کلاه‌خود پرچم‌دار", hp: 54, cost: 1900, r: "r", color: "#c8d0e0", kind: "crest", plume: "#d84a3a" },
    { id: "h5", name: "کلاه‌خود سیمرغ", hp: 70, cost: 4200, r: "e", color: "#cfe6ff", kind: "winged", plume: "#7ad0ff" },
    { id: "h6", name: "خود شاخدار ضحاک", hp: 86, cost: 5600, r: "e", color: "#5a4a58", kind: "horned" },
    { id: "h3", name: "تاج شاهی", hp: 80, cost: 4600, r: "e", color: "#ffd24a", kind: "crown" },
    { id: "h7", name: "تاج کیانی", hp: 110, cost: 0, gems: 140, r: "l", color: "#ffe27a", kind: "crown", gem: "#ff3a5a", glow: "#ffd24a" },
  ],
  armor: [
    { id: "a0", name: "جامه‌ی ساده", hp: 20, cost: 0, r: "c", color: "#6a8fb8" },
    { id: "a1", name: "زره‌ی زنجیری", hp: 60, cost: 700, r: "c", color: "#8a94a6", mail: 1 },
    { id: "a2", name: "زره‌ی فولادی", hp: 110, cost: 2000, r: "r", color: "#aab6c8", plate: 1 },
    { id: "a4", name: "جوشن سیاوش", hp: 140, cost: 3400, r: "r", color: "#3f7fc8", plate: 1, trim: "#e8f0ff" },
    { id: "a3", name: "زره‌ی زرین", hp: 190, cost: 5200, r: "e", color: "#e6bb3c", plate: 1, trim: "#fff2b0" },
    { id: "a5", name: "جوشن رستم", hp: 260, cost: 0, gems: 180, r: "l", color: "#7a1f1f", plate: 1, trim: "#ffcf5a", glow: "#ff8a3a" },
  ],
  cape: [
    { id: "c0", name: "بدون شنل", cost: 0, r: "c" },
    { id: "c1", name: "شنل سرخ", cost: 300, r: "c", color: "#c43a3a" },
    { id: "c4", name: "شنل رودخانه", cost: 1200, r: "r", color: "#2f86b8", color2: "#8fd8ee" },
    { id: "c2", name: "شنل شاهی", cost: 2400, r: "e", color: "#7a3aa8", color2: "#d8a8ff" },
    { id: "c3", name: "شنل زرین", cost: 3600, r: "e", color: "#e0a82a", color2: "#fff0a0" },
    { id: "c5", name: "شنل سیمرغ", cost: 0, gems: 110, r: "l", color: "#1fb8a0", color2: "#ffd86a", glow: "#3affd0" },
  ],
  aura: [
    { id: "x0", name: "بدون هاله", cost: 0, r: "c" },
    { id: "x4", name: "افسون یخ", cost: 2200, r: "r", kind: "frost", col: "#9fe8ff" },
    { id: "x1", name: "هاله‌ی آذرخش", cost: 3000, r: "r", kind: "flame", col: "#ff7a2a" },
    { id: "x2", name: "درفش کاویانی", cost: 5400, r: "e", kind: "banner", col: "#b84aff", col2: "#ffd24a" },
    { id: "x3", name: "هاله‌ی فروهر", cost: 0, gems: 160, r: "l", kind: "faravahar", col: "#ffd24a" },
  ],
};
export const SKINS = ["#f6dcbc", "#f2d0a8", "#e0b184", "#c68e5e", "#a8703f", "#8d5a38", "#5a3a26"];
export const HAIRS = ["#2a1a10", "#5a3a1a", "#b8782a", "#e0d4a8", "#d8d0c0", "#a02a2a", "#1a1a2a", "#6a4a8a"];
export const TUNICS = ["#6a8fb8", "#4aa86a", "#c4503a", "#8a5ac8", "#d8a83a", "#2a2f3a", "#e8e0d0", "#2f7f8a"];
export const EYECOLS = ["#3a2a1a", "#5a3a1a", "#2a6aa8", "#3a8a5a", "#6a7a8a", "#a8782a", "#1a1a22"];
export const find = (slot, id) => GEAR[slot].find((g) => g.id === id) || GEAR[slot][0];

export const FACE_OPTS = {
  shape: [["oval", "بیضی"], ["round", "گرد"], ["square", "چهارشانه"], ["long", "کشیده"]],
  eye: [["almond", "بادامی"], ["round", "گرد"], ["narrow", "باریک"], ["big", "درشت"]],
  brow: [["arched", "کمانی"], ["straight", "صاف"], ["thick", "پرپشت"], ["angry", "خشمگین"], ["soft", "نرم"]],
  nose: [["straight", "عادی"], ["small", "کوچک"], ["broad", "پهن"], ["hooked", "عقابی"]],
  mouth: [["neutral", "آرام"], ["smile", "لبخند"], ["stern", "جدی"], ["grin", "نیشخند"]],
  beard: [["none", "بدون ریش"], ["stubble", "ته‌ریش"], ["short", "کوتاه"], ["full", "پرپشت"], ["goatee", "بزی"], ["long", "بلند"], ["mus", "سبیل"], ["mgoat", "سبیل و بزی"]],
  hairStyle: [["short", "کوتاه"], ["long", "بلند"], ["bun", "گره"], ["pony", "دم‌اسبی"], ["mohawk", "موهاک"], ["bald", "طاس"]],
  build: [["slim", "باریک"], ["normal", "معمولی"], ["broad", "درشت‌هیکل"]],
};
export const SLIDERS = [["jaw", "زاویه‌ی فک", 0, 1, 0.05], ["head", "اندازه‌ی سر", 0.85, 1.15, 0.01], ["browTh", "ضخامت ابرو", 0, 1, 0.05], ["browAng", "زاویه‌ی ابرو", -1, 1, 0.1], ["noseSz", "اندازه‌ی بینی", 0.7, 1.3, 0.05], ["height", "قد", 0.9, 1.1, 0.01]];
export const DEF_FACE = { shape: "oval", jaw: 0.4, head: 1, eye: "almond", eyeCol: "#3a2a1a", brow: "arched", browTh: 0.5, browAng: 0, nose: "straight", noseSz: 1, mouth: "neutral", beard: "none", hairStyle: "short", scar: false, build: "normal", height: 1 };
export const faceOf = (av) => Object.assign({}, DEF_FACE, (av && av.face) || {});
export function defaultAvatar() { return { skin: SKINS[1], hair: HAIRS[1], tunic: TUNICS[0], sword: "s0", shield: "d0", helm: "h0", armor: "a0", cape: "c0", aura: "x0", face: Object.assign({}, DEF_FACE) }; }
export function defaultOwned() { return { s0: 1, d0: 1, h0: 1, a0: 1, c0: 1, x0: 1 }; }
export function stats(av) {
  const s = find("sword", av.sword), sh = find("shield", av.shield), h = find("helm", av.helm), a = find("armor", av.armor);
  return { dmg: s.dmg, hp: 120 + h.hp + a.hp, def: sh.def || 0 };
}
export const STAT_MAX = { dmg: 80, hp: 400, def: 0.4 };

// ---------- ظاهر کامل شخصیت (برای رندر سه‌بعدی و پیش‌نمایش) ----------
export function lookOf(av) {
  const face = faceOf(av), sw = find("sword", av.sword), sh = find("shield", av.shield), hm = find("helm", av.helm), ar = find("armor", av.armor), cp = find("cape", av.cape), au = find("aura", av.aura);
  return { skin: av.skin, hair: av.hair, tunic: av.tunic, face, weapon: sw, shield: sh.id === "d0" ? null : sh, helm: hm, armorItem: ar.id === "a0" ? null : ar, armor: ar.id === "a0" ? null : ar.color, cape: cp.id === "c0" ? null : cp, aura: au.id === "x0" ? null : au, belt: "#5a3a1a", legs: "#3a3f4a" };
}
function mulberry(a) { return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
// چهره‌ی تصادفی ولی پایدار برای هر موجود (هر کس متفاوت است)
export function randomLook(seed, o = {}) {
  const r = mulberry(seed * 9301 + 49297), pick = (a) => a[Math.floor(r() * a.length)], rr = (a, b) => a + (b - a) * r();
  const darkTone = o.darkTone, skin = darkTone ? pick(SKINS.slice(2)) : pick(SKINS);
  const old = r() < 0.2, hair = old ? pick(["#d8d0c0", "#9a9aa0", "#e0d4a8"]) : pick(HAIRS.slice(0, 7));
  const hs = [["short", 5], ["long", 2], ["bun", 1], ["pony", 1.5], ["mohawk", 0.4], ["bald", 0.8]]; let t = r() * 10.7, hairStyle = "short"; for (const [k, w] of hs) { t -= w; if (t <= 0) { hairStyle = k; break; } }
  const beard = r() < 0.5 ? pick(["stubble", "short", "full", "goatee", "long", "mus", "mgoat"]) : "none";
  const face = { shape: pick(["oval", "round", "square", "long"]), jaw: rr(0.1, 0.9), head: rr(0.92, 1.08), eye: pick(["almond", "round", "narrow", "big"]), eyeCol: pick(EYECOLS), brow: o.angry ? pick(["angry", "thick", "angry"]) : pick(["arched", "straight", "thick", "soft"]), browTh: rr(0.2, 0.9), browAng: o.angry ? rr(0.4, 1) : rr(-0.4, 0.4), nose: pick(["straight", "small", "broad", "hooked"]), noseSz: rr(0.8, 1.2), mouth: o.angry ? pick(["stern", "stern", "grin"]) : pick(["neutral", "smile", "stern", "neutral"]), beard, hairStyle, scar: r() < (o.angry ? 0.3 : 0.1), build: pick(["slim", "normal", "normal", "broad"]), height: rr(0.94, 1.06) };
  return { skin, hair, face };
}
export const buildW = (b) => (b === "slim" ? 0.86 : b === "broad" ? 1.16 : 1);

// ---------- رنگ ----------
const H2 = (h) => { if (!h || h[0] !== "#") return [128, 128, 128]; const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
export const shade = (h, k, a = 1) => { const c = H2(h); return `rgba(${Math.min(255, c[0] * k) | 0},${Math.min(255, c[1] * k) | 0},${Math.min(255, c[2] * k) | 0},${a})`; };
const SH = { oval: [0.9, 1.08], round: [1, 1], square: [0.97, 0.98], long: [0.83, 1.2] };

function headPath(ctx, wX, hY, cw, jw, cy) {
  ctx.beginPath(); ctx.moveTo(-wX, 0); ctx.bezierCurveTo(-wX, -hY * 0.78, -wX * 0.55, -hY, 0, -hY); ctx.bezierCurveTo(wX * 0.55, -hY, wX, -hY * 0.78, wX, 0);
  ctx.bezierCurveTo(wX, hY * 0.45, jw, cy, cw, hY); ctx.lineTo(-cw, hY); ctx.bezierCurveTo(-jw, cy, -wX, hY * 0.45, -wX, 0); ctx.closePath();
}
function capPath(ctx, wX, hY, v, lowY, a2) {
  const a = wX * v; ctx.beginPath(); ctx.moveTo(-a, lowY); ctx.bezierCurveTo(-a * 1.02, -hY * 0.8 * v, -a * 0.55, -hY * v, 0, -hY * v); ctx.bezierCurveTo(a * 0.55, -hY * v, a * 1.02, -hY * 0.8 * v, a, lowY); void a2;
}
function hairFill(ctx, hair, wX, hY) { const g = ctx.createLinearGradient(-wX, -hY, wX * 0.6, hY * 0.3); g.addColorStop(0, shade(hair, 1.3)); g.addColorStop(0.5, shade(hair, 1)); g.addColorStop(1, shade(hair, 0.7)); ctx.fillStyle = g; }
function strands(ctx, hair, wX, hY, n, y0, y1, R) { ctx.strokeStyle = shade(hair, 0.55, 0.55); ctx.lineWidth = Math.max(0.8, R * 0.025); for (let i = 0; i < n; i++) { const t = (i + 0.5) / n - 0.5, x0 = t * wX * 1.1; ctx.beginPath(); ctx.moveTo(x0 * 0.5, y0); ctx.quadraticCurveTo(x0 * 1.1, (y0 + y1) / 2, x0 * 1.25, y1); ctx.stroke(); } }
function eyeShape(ctx, sg, rx, ry, type, oc) {
  ctx.beginPath();
  if (type === "round" || type === "big") ctx.ellipse(0, 0, rx, ry, 0, 0, TAU);
  else { ctx.moveTo(-sg * rx, 0); ctx.quadraticCurveTo(0, -ry * 1.9, sg * rx, oc); ctx.quadraticCurveTo(0, ry * 1.7, -sg * rx, 0); ctx.closePath(); }
}
function drawEye(ctx, sg, ex, ey, R, type, col, lod) {
  const rx = R * ({ round: 0.17, almond: 0.21, narrow: 0.22, big: 0.21 }[type] || 0.2), ry = R * ({ round: 0.15, almond: 0.105, narrow: 0.07, big: 0.19 }[type] || 0.1), oc = (type === "almond" || type === "narrow") ? -R * 0.04 : 0;
  ctx.save(); ctx.translate(sg * ex, ey);
  if (lod) { ctx.fillStyle = "#f4f1ea"; eyeShape(ctx, sg, rx, ry, type, oc); ctx.fill(); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, 0, Math.max(1, ry * 0.8), 0, TAU); ctx.fill(); ctx.restore(); return; }
  ctx.fillStyle = "#f6f3ec"; eyeShape(ctx, sg, rx, ry, type, oc); ctx.fill(); ctx.save(); eyeShape(ctx, sg, rx, ry, type, oc); ctx.clip();
  const ir = Math.min(ry * 1.05, rx * 0.62); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, 0, ir, 0, TAU); ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.45)"; ctx.lineWidth = Math.max(1, R * 0.02); ctx.stroke();
  ctx.fillStyle = "#0c0c10"; ctx.beginPath(); ctx.arc(0, 0, ir * 0.5, 0, TAU); ctx.fill(); ctx.fillStyle = "rgba(255,255,255,.9)"; ctx.beginPath(); ctx.arc(-ir * 0.3, -ir * 0.3, ir * 0.22, 0, TAU); ctx.fill();
  ctx.fillStyle = "rgba(0,0,0,.18)"; ctx.fillRect(-rx, -ry * 2, rx * 2, ry * 1.05); ctx.restore();
  ctx.strokeStyle = "rgba(25,12,8,.9)"; ctx.lineWidth = Math.max(1, R * 0.05); ctx.lineCap = "round"; ctx.beginPath();
  if (type === "round" || type === "big") ctx.ellipse(0, 0, rx, ry, 0, Math.PI * 1.05, Math.PI * 1.95); else { ctx.moveTo(-sg * rx, 0); ctx.quadraticCurveTo(0, -ry * 1.9, sg * rx, oc); }
  ctx.stroke(); ctx.restore();
}
function drawBrow(ctx, sg, ex, ey, R, f, hair) {
  const style = f.brow, th = R * (0.045 + 0.1 * (f.browTh == null ? 0.5 : f.browTh)) * (style === "thick" ? 1.45 : 1), bigE = f.eye === "big" ? R * 0.04 : 0;
  let inY = style === "angry" ? R * 0.1 : style === "soft" ? -R * 0.03 : 0, outY = style === "angry" ? -R * 0.05 : style === "soft" ? R * 0.04 : 0; inY += (f.browAng || 0) * R * 0.1;
  const by = ey - R * 0.26 - bigE, ix = sg * (ex - R * 0.2), ox = sg * (ex + R * 0.24);
  ctx.strokeStyle = shade(hair, 0.72); ctx.lineWidth = th; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(ix, by + inY);
  const arch = style === "arched" ? -R * 0.11 : style === "soft" ? -R * 0.05 : style === "thick" ? -R * 0.03 : 0;
  ctx.quadraticCurveTo(sg * ex, by + (inY + outY) / 2 + arch, ox, by + outY + (style === "arched" ? R * 0.05 : 0)); ctx.stroke();
}
function drawNose(ctx, R, f, skin, hY) {
  const t = f.nose, w = R * ({ small: 0.1, straight: 0.125, broad: 0.18, hooked: 0.12 }[t] || 0.12) * (f.noseSz || 1), tip = hY * 0.4, top = R * 0.03;
  ctx.save(); ctx.lineCap = "round"; ctx.strokeStyle = shade(skin, 0.62, 0.38); ctx.lineWidth = Math.max(1, R * 0.05);
  ctx.beginPath(); ctx.moveTo(-w * 0.35, top); ctx.quadraticCurveTo(-w * 0.55, tip * 0.6, -w * 0.7, tip - R * 0.04); ctx.stroke();
  ctx.fillStyle = shade(skin, 0.7, 0.2); ctx.beginPath(); ctx.ellipse(w * 0.15, tip + R * 0.06, w * 1.1, R * 0.06, 0, 0, TAU); ctx.fill();
  ctx.fillStyle = shade(skin, 1.12, 0.55); ctx.beginPath(); ctx.ellipse(w * 0.05, tip - R * 0.05, w * 0.42, R * 0.07, 0, 0, TAU); ctx.fill();
  if (t === "hooked") { ctx.fillStyle = shade(skin, 0.78, 0.5); ctx.beginPath(); ctx.moveTo(-w * 0.3, top); ctx.quadraticCurveTo(w * 0.9, tip * 0.5, w * 0.3, tip + R * 0.09); ctx.lineTo(-w * 0.3, tip); ctx.closePath(); ctx.fill(); }
  ctx.fillStyle = "rgba(40,18,14,.62)"; for (const sg of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sg * w * 0.55, tip + R * 0.04, w * 0.26, R * 0.032, sg * 0.25, 0, TAU); ctx.fill(); }
  ctx.strokeStyle = shade(skin, 0.6, 0.45); ctx.lineWidth = Math.max(1, R * 0.035); for (const sg of [-1, 1]) { ctx.beginPath(); ctx.arc(sg * w * 0.6, tip - R * 0.01, w * 0.5, sg < 0 ? 0.35 * Math.PI : 0.05 * Math.PI, sg < 0 ? 0.95 * Math.PI : 0.65 * Math.PI); ctx.stroke(); }
  ctx.restore();
}
function drawMouth(ctx, R, f, skin, hY) {
  const y = hY * 0.64, type = f.mouth, mw = R * (type === "smile" || type === "grin" ? 0.32 : 0.27), lip = H2(skin), lc = `rgb(${lip[0] * 0.82 | 0},${lip[1] * 0.5 | 0},${lip[2] * 0.5 | 0})`;
  ctx.save(); ctx.translate(0, y); ctx.lineCap = "round"; ctx.lineJoin = "round";
  if (type === "grin") {
    ctx.fillStyle = "#3a0f10"; ctx.beginPath(); ctx.moveTo(-mw, -R * 0.02); ctx.quadraticCurveTo(0, R * 0.34, mw, -R * 0.02); ctx.quadraticCurveTo(0, R * 0.04, -mw, -R * 0.02); ctx.fill();
    ctx.fillStyle = "#f8f4ea"; ctx.beginPath(); ctx.moveTo(-mw * 0.8, 0); ctx.quadraticCurveTo(0, R * 0.1, mw * 0.8, 0); ctx.quadraticCurveTo(0, R * 0.04, -mw * 0.8, 0); ctx.fill();
    ctx.strokeStyle = lc; ctx.lineWidth = Math.max(1, R * 0.045); ctx.beginPath(); ctx.moveTo(-mw, -R * 0.02); ctx.quadraticCurveTo(0, R * 0.34, mw, -R * 0.02); ctx.stroke();
  } else {
    const cyv = type === "smile" ? R * 0.15 : type === "stern" ? -R * 0.05 : R * 0.02, ey = type === "smile" ? -R * 0.04 : type === "stern" ? R * 0.045 : 0;
    ctx.strokeStyle = lc; ctx.lineWidth = Math.max(1, R * (type === "stern" ? 0.07 : 0.055)); ctx.beginPath(); ctx.moveTo(-mw, ey); ctx.quadraticCurveTo(0, cyv, mw, ey); ctx.stroke();
    if (type !== "stern") { ctx.fillStyle = lc; ctx.globalAlpha = 0.55; ctx.beginPath(); ctx.ellipse(0, R * 0.07 + cyv * 0.4, mw * 0.55, R * 0.04, 0, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; }
    if (type === "smile") { ctx.strokeStyle = shade(skin, 0.6, 0.4); ctx.lineWidth = Math.max(1, R * 0.03); for (const sg of [-1, 1]) { ctx.beginPath(); ctx.arc(sg * (mw + R * 0.03), ey, R * 0.07, sg < 0 ? 1.3 : 1.6, sg < 0 ? 4.4 : 4.7, sg > 0); ctx.stroke(); } }
  }
  ctx.restore();
}
function mustache(ctx, wX, hY, col) {
  ctx.fillStyle = col; for (const sg of [-1, 1]) { ctx.beginPath(); ctx.moveTo(0, hY * 0.5); ctx.bezierCurveTo(sg * wX * 0.2, hY * 0.45, sg * wX * 0.45, hY * 0.53, sg * wX * 0.52, hY * 0.7); ctx.bezierCurveTo(sg * wX * 0.3, hY * 0.6, sg * wX * 0.1, hY * 0.6, 0, hY * 0.58); ctx.fill(); }
}
function beardClipped(ctx, f, wX, hY, bc) {
  const t = f.beard; if (t === "none") return;
  ctx.fillStyle = bc;
  if (t === "stubble" || t === "short" || t === "full" || t === "long") {
    const k = t === "full" || t === "long" ? 1 : 0, y0 = k ? -0.02 : 0.1;
    ctx.save(); if (t === "stubble") ctx.globalAlpha = 0.3;
    ctx.beginPath(); ctx.moveTo(-wX * 1.3, -hY * 0.15); ctx.lineTo(-wX * 0.92, -hY * 0.1); ctx.quadraticCurveTo(-wX * (k ? 0.82 : 0.78), hY * (y0 + 0.2), -wX * 0.5, hY * (k ? 0.36 : 0.42)); ctx.quadraticCurveTo(-wX * 0.2, hY * 0.5, 0, hY * 0.46); ctx.quadraticCurveTo(wX * 0.2, hY * 0.5, wX * 0.5, hY * (k ? 0.36 : 0.42)); ctx.quadraticCurveTo(wX * (k ? 0.82 : 0.78), hY * (y0 + 0.2), wX * 0.92, -hY * 0.1); ctx.lineTo(wX * 1.3, -hY * 0.15); ctx.lineTo(wX * 1.3, hY * 1.4); ctx.lineTo(-wX * 1.3, hY * 1.4); ctx.closePath(); ctx.fill(); ctx.restore();
    if (t !== "stubble") mustache(ctx, wX, hY, bc);
  } else {
    if (t === "goatee" || t === "mgoat") { ctx.beginPath(); ctx.ellipse(0, hY * 0.86, wX * 0.34, hY * 0.2, 0, 0, TAU); ctx.fill(); ctx.fillRect(-wX * 0.06, hY * 0.66, wX * 0.12, hY * 0.2); }
    if (t === "mus" || t === "mgoat") mustache(ctx, wX, hY, bc);
  }
}
const lighten = (h, k) => shade(h, k);

function helm2d(ctx, hm, wX, hY, R, front, c, sway, hair) {
  const col = hm.color, k = hm.kind, hg = () => { const g = ctx.createLinearGradient(-wX, -hY, wX, hY * 0.3); g.addColorStop(0, shade(col, 1.35)); g.addColorStop(0.5, shade(col, 1)); g.addColorStop(1, shade(col, 0.62)); return g; };
  const ol = shade(col, 0.4, 0.8), lw = Math.max(1, R * 0.045);
  if (k === "cap") {
    capPath(ctx, wX, hY, 1.06, front ? -hY * 0.3 : hY * 0.4); if (front) ctx.quadraticCurveTo(0, -hY * 0.12, -wX * 1.06, -hY * 0.3); else ctx.quadraticCurveTo(0, hY * 0.52, -wX * 1.06, hY * 0.4); ctx.fillStyle = hg(); ctx.fill(); ctx.strokeStyle = ol; ctx.lineWidth = lw; ctx.stroke();
    ctx.strokeStyle = shade(col, 0.55, 0.7); ctx.setLineDash([R * 0.1, R * 0.08]); ctx.beginPath(); ctx.moveTo(0, -hY * 1.05); ctx.lineTo(0, front ? -hY * 0.3 : hY * 0.2); ctx.stroke(); ctx.setLineDash([]); return;
  }
  if (k === "crown") {
    const y = -hY * 0.52, n = 5; ctx.fillStyle = hg(); ctx.beginPath(); ctx.moveTo(-wX * 1.05, y + R * 0.18); for (let i = 0; i < n; i++) { const x0 = -wX * 1.05 + (i / n) * wX * 2.1, x1 = -wX * 1.05 + ((i + 1) / n) * wX * 2.1; ctx.lineTo(x0, y - R * 0.04); ctx.lineTo((x0 + x1) / 2, y - R * (i % 2 ? 0.34 : 0.5)); ctx.lineTo(x1, y - R * 0.04); } ctx.lineTo(wX * 1.05, y + R * 0.18); ctx.closePath(); ctx.fill(); ctx.strokeStyle = ol; ctx.lineWidth = lw; ctx.stroke();
    ctx.fillStyle = hm.gem || "#d84a3a"; if (front) { ctx.beginPath(); ctx.arc(0, y + R * 0.05, R * 0.08, 0, TAU); ctx.fill(); ctx.strokeStyle = "rgba(255,255,255,.7)"; ctx.lineWidth = 1; ctx.stroke(); }
    ctx.strokeStyle = "rgba(255,255,255,.55)"; ctx.lineWidth = Math.max(1, R * 0.03); ctx.beginPath(); ctx.moveTo(-wX * 0.9, y + R * 0.07); ctx.lineTo(wX * 0.9, y + R * 0.07); ctx.stroke(); return;
  }
  if (k === "coif") {
    ctx.beginPath(); ctx.moveTo(-wX * 1.12, hY * 0.9); ctx.lineTo(-wX * 1.12, 0); ctx.bezierCurveTo(-wX * 1.14, -hY * 0.9, -wX * 0.5, -hY * 1.12, 0, -hY * 1.1); ctx.bezierCurveTo(wX * 0.5, -hY * 1.12, wX * 1.14, -hY * 0.9, wX * 1.12, 0); ctx.lineTo(wX * 1.12, hY * 0.9); ctx.quadraticCurveTo(0, hY * 1.25, -wX * 1.12, hY * 0.9);
    if (front) { ctx.moveTo(-wX * 0.8, -hY * 0.45); ctx.bezierCurveTo(-wX * 0.8, hY * 0.6, -wX * 0.4, hY * 0.95, 0, hY * 0.98); ctx.bezierCurveTo(wX * 0.4, hY * 0.95, wX * 0.8, hY * 0.6, wX * 0.8, -hY * 0.45); ctx.bezierCurveTo(wX * 0.5, -hY * 0.55, -wX * 0.5, -hY * 0.55, -wX * 0.8, -hY * 0.45); }
    ctx.fillStyle = hg(); ctx.fill("evenodd"); ctx.strokeStyle = ol; ctx.lineWidth = lw; ctx.stroke(); ctx.save(); ctx.clip(); ctx.strokeStyle = shade(col, 0.5, 0.4); ctx.lineWidth = 1; for (let i = -6; i < 8; i++) { ctx.beginPath(); ctx.moveTo(-wX * 1.2, i * R * 0.22); ctx.lineTo(wX * 1.2, i * R * 0.22 + R * 0.3); ctx.stroke(); } ctx.restore(); return;
  }
  // کلاه‌خود (آهنی / پرچم‌دار / سیمرغ / شاخدار)
  if (k === "winged") { for (const sg of [-1, 1]) { ctx.fillStyle = shade(hm.plume || "#7ad0ff", 1.1); ctx.strokeStyle = shade(hm.plume || "#7ad0ff", 0.5); ctx.lineWidth = Math.max(1, R * 0.03); for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.moveTo(sg * wX * 0.95, -hY * 0.3 - i * R * 0.06); ctx.quadraticCurveTo(sg * (wX * 1.6 + i * R * 0.3), -hY * 0.9 - i * R * 0.25, sg * (wX * 1.25 + i * R * 0.5), -hY * 1.15 - i * R * 0.2 + R * 0.1 * i); ctx.quadraticCurveTo(sg * (wX * 1.3 + i * R * 0.1), -hY * 0.55, sg * wX * 0.95, -hY * 0.12 - i * R * 0.06); ctx.fill(); ctx.stroke(); } } }
  if (k === "horned") { for (const sg of [-1, 1]) { ctx.fillStyle = "#efe6cc"; ctx.strokeStyle = "#6a5a3a"; ctx.lineWidth = Math.max(1, R * 0.035); ctx.beginPath(); ctx.moveTo(sg * wX * 0.8, -hY * 0.55); ctx.bezierCurveTo(sg * wX * 1.7, -hY * 0.5, sg * wX * 1.9, -hY * 1.3, sg * wX * 1.45, -hY * 1.75); ctx.bezierCurveTo(sg * wX * 1.5, -hY * 1.1, sg * wX * 1.2, -hY * 0.85, sg * wX * 0.55, -hY * 0.8); ctx.closePath(); ctx.fill(); ctx.stroke(); } }
  const low = front ? -hY * 0.12 : hY * 0.62; capPath(ctx, wX, hY, 1.1, low);
  if (front) { ctx.lineTo(wX * 0.12, low); ctx.lineTo(wX * 0.12, hY * 0.3); ctx.lineTo(-wX * 0.12, hY * 0.3); ctx.lineTo(-wX * 0.12, low); ctx.lineTo(-wX * 1.1, low); } else { ctx.quadraticCurveTo(0, hY * 0.9, -wX * 1.1, low); }
  ctx.closePath(); ctx.fillStyle = hg(); ctx.fill(); ctx.strokeStyle = ol; ctx.lineWidth = lw; ctx.stroke();
  ctx.fillStyle = "rgba(255,255,255,.35)"; ctx.beginPath(); ctx.ellipse(-wX * 0.35, -hY * 0.72, wX * 0.14, hY * 0.34, 0.5, 0, TAU); ctx.fill();
  ctx.strokeStyle = shade(col, 0.5, 0.8); ctx.lineWidth = lw * 1.4; ctx.beginPath(); ctx.moveTo(-wX * 1.08, low); ctx.lineTo(wX * 1.08, low); ctx.stroke();
  if (front) { ctx.fillStyle = shade(col, 1.2); ctx.fillRect(-wX * 0.12, -hY * 0.12, wX * 0.24, hY * 0.42); ctx.strokeStyle = ol; ctx.lineWidth = Math.max(1, R * 0.03); ctx.strokeRect(-wX * 0.12, -hY * 0.12, wX * 0.24, hY * 0.42); for (const sg of [-1, 1]) { ctx.fillStyle = hg(); ctx.beginPath(); ctx.moveTo(sg * wX * 1.08, low); ctx.lineTo(sg * wX * 0.95, hY * 0.5); ctx.lineTo(sg * wX * 0.7, hY * 0.5); ctx.lineTo(sg * wX * 0.78, low); ctx.closePath(); ctx.fill(); ctx.stroke(); } }
  if (k === "crest") { const pc = hm.plume || "#d84a3a"; ctx.fillStyle = pc; ctx.strokeStyle = shade(pc, 0.5); ctx.lineWidth = Math.max(1, R * 0.03); ctx.beginPath(); if (front) { ctx.moveTo(-R * 0.1, -hY * 1.05); ctx.bezierCurveTo(-R * 0.05, -hY * 2.0, R * 0.9, -hY * 1.9, R * 0.8 + sway * R * 0.2, -hY * 1.2); ctx.quadraticCurveTo(R * 0.3, -hY * 1.35, R * 0.1, -hY * 1.0); } else { ctx.moveTo(-R * 0.12, -hY * 1.05); ctx.bezierCurveTo(-R * 0.35, -hY * 1.7, -R * 0.3 + sway * R * 0.3, hY * 0.5, -R * 0.12 + sway * R * 0.3, hY * 1.5); ctx.lineTo(R * 0.14 + sway * R * 0.3, hY * 1.5); ctx.bezierCurveTo(R * 0.3 + sway * R * 0.3, hY * 0.5, R * 0.35, -hY * 1.7, R * 0.12, -hY * 1.05); } ctx.closePath(); ctx.fill(); ctx.stroke(); }
  void c; void hair;
}

// نقاشی سر با چهره‌ی کامل. fa = زاویه‌ی چرخش سر نسبت به دوربین (۰ = رو به دوربین، π = پشت به دوربین)
export function drawHead(ctx, x, y, R, L, fa = 0, o = {}) {
  const f = L.face || DEF_FACE, c = Math.cos(fa), s = Math.sin(fa), front = c > -0.08, sh = SH[f.shape] || SH.oval, hs = f.head || 1, j = clamp(f.jaw == null ? 0.4 : f.jaw, 0, 1);
  const wX = R * sh[0] * hs * (0.9 + 0.1 * Math.abs(c)), hY = R * sh[1] * hs, fo = s * wX * 0.5, sq = f.shape === "square" ? 1 : 0, rd = f.shape === "round" ? 1 : 0;
  const cw = wX * (0.5 - 0.35 * j + 0.28 * sq - 0.1 * rd), jw = wX * (0.95 - 0.3 * j + 0.04 * sq), cy = hY * (0.82 - 0.08 * sq);
  const skin = L.skin, hair = L.hair || "#3a2a1a", hm = L.helm, covers = hm && hm.kind !== "crown" && hm.kind !== "cap", style = f.hairStyle || "short", sway = o.sway || 0, lod = R < 7.5, bc = shade(hair, 0.82);
  const hairOn = !covers && style !== "bald";
  ctx.save(); ctx.translate(x, y); ctx.lineJoin = "round";
  const hairDrape = (sd) => { // موی بلند پشت/روی شانه
    hairFill(ctx, hair, wX, hY); ctx.beginPath(); ctx.moveTo(-wX * 1.05, -hY * 0.5); ctx.bezierCurveTo(-wX * 1.5, hY * 0.2, -wX * 1.4, hY * 1.6, -wX * 1.25 + sd * 0, hY * 2.35); ctx.quadraticCurveTo(0, hY * 2.6, wX * 1.25, hY * 2.35); ctx.bezierCurveTo(wX * 1.4, hY * 1.6, wX * 1.5, hY * 0.2, wX * 1.05, -hY * 0.5); ctx.closePath(); ctx.fill(); ctx.strokeStyle = shade(hair, 0.45, 0.7); ctx.lineWidth = Math.max(1, R * 0.035); ctx.stroke();
    if (!lod) strands(ctx, hair, wX * 1.3, hY, 6, hY * 0.2, hY * 2.3, R);
  };
  const ponyTail = (back) => {
    const sw = sway * R * 0.35, top = back ? -hY * 0.2 : hY * 0.05; hairFill(ctx, hair, wX, hY); ctx.beginPath();
    if (back) { ctx.moveTo(-R * 0.16, top); ctx.bezierCurveTo(-R * 0.42 + sw * 0.3, hY * 0.6, -R * 0.3 + sw, hY * 1.7, sw * 1.3, hY * 2.5); ctx.bezierCurveTo(R * 0.3 + sw, hY * 1.7, R * 0.42 + sw * 0.3, hY * 0.6, R * 0.16, top); } else { ctx.ellipse(wX * 0.95 + sw * 0.2, hY * 0.45, R * 0.15, R * 0.55, 0.22, 0, TAU); }
    ctx.closePath(); ctx.fill(); ctx.strokeStyle = shade(hair, 0.45, 0.7); ctx.lineWidth = Math.max(1, R * 0.03); ctx.stroke();
    if (back) { ctx.fillStyle = "#c43a3a"; ctx.fillRect(-R * 0.17, top - R * 0.04, R * 0.34, R * 0.12); }
  };
  // --- لایه‌ی پشت سر (نمای جلو) ---
  if (front && hairOn) { if (style === "long") hairDrape(0); else if (style === "pony") ponyTail(false); }
  // گوش‌ها
  ctx.fillStyle = shade(skin, 0.9); ctx.strokeStyle = shade(skin, 0.5, 0.7); ctx.lineWidth = Math.max(1, R * 0.035);
  for (const sg of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sg * wX * 0.98, hY * 0.08, R * 0.13, R * 0.2, 0, 0, TAU); ctx.fill(); ctx.stroke(); }
  // جمجمه
  headPath(ctx, wX, hY, cw, jw, cy); { const g = ctx.createRadialGradient(-wX * 0.3, -hY * 0.35, R * 0.1, 0, 0, hY * 1.25); g.addColorStop(0, shade(skin, 1.14)); g.addColorStop(0.7, shade(skin, 0.95)); g.addColorStop(1, shade(skin, 0.74)); ctx.fillStyle = g; ctx.fill(); }
  ctx.strokeStyle = shade(skin, 0.45, 0.65); ctx.lineWidth = Math.max(1, R * 0.045); ctx.stroke();
  if (front) {
    ctx.save(); headPath(ctx, wX, hY, cw, jw, cy); ctx.clip(); const fade = clamp((c + 0.08) / 0.5, 0, 1);
    // سایه‌ی چانه و گونه
    ctx.globalAlpha = fade; ctx.fillStyle = "rgba(120,50,40,.1)"; for (const sg of [-1, 1]) { ctx.beginPath(); ctx.ellipse(fo + sg * wX * 0.52, hY * 0.36, wX * 0.22, hY * 0.12, 0, 0, TAU); ctx.fill(); }
    ctx.translate(fo, 0); const ex = wX * 0.46, ey = hY * 0.05;
    if (f.beard !== "none") beardClipped(ctx, f, wX, hY, bc);
    ctx.translate(-fo, 0); ctx.translate(fo, 0);
    // خط‌های چهره
    if (!lod) { for (const sg of [-1, 1]) { ctx.strokeStyle = shade(skin, 0.6, 0.25); ctx.lineWidth = Math.max(1, R * 0.03); ctx.beginPath(); ctx.arc(sg * ex, ey + R * 0.08, R * 0.2, sg < 0 ? 0.15 : 0.5, sg < 0 ? 2.6 : 3.0); ctx.stroke(); } }
    const ecol = L.eyeCol || f.eyeCol || "#3a2a1a";
    drawEye(ctx, -1, ex, ey, R, f.eye, ecol, lod); drawEye(ctx, 1, ex, ey, R, f.eye, ecol, lod);
    drawBrow(ctx, -1, ex, ey, R, f, hair); drawBrow(ctx, 1, ex, ey, R, f, hair);
    if (!lod) drawNose(ctx, R, f, skin, hY);
    drawMouth(ctx, R, f, skin, hY);
    if (f.beard !== "none" && f.beard !== "stubble" && !lod) { ctx.strokeStyle = shade(hair, 0.5, 0.4); ctx.lineWidth = 1; }
    if (f.scar) { ctx.strokeStyle = "rgba(90,30,30,.7)"; ctx.lineWidth = Math.max(1.5, R * 0.07); ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(-wX * 0.62, -hY * 0.18); ctx.lineTo(-wX * 0.28, hY * 0.42); ctx.stroke(); ctx.strokeStyle = "rgba(235,150,150,.85)"; ctx.lineWidth = Math.max(1, R * 0.035); ctx.stroke(); if (!lod) { ctx.strokeStyle = "rgba(235,150,150,.75)"; ctx.beginPath(); for (const t of [0.3, 0.55, 0.8]) { const px = -wX * 0.62 + wX * 0.34 * t, py = -hY * 0.18 + hY * 0.6 * t; ctx.moveTo(px - R * 0.07, py + R * 0.02); ctx.lineTo(px + R * 0.07, py - R * 0.02); } ctx.stroke(); } }
    ctx.restore();
  } else if (f.beard !== "none") { /* ریش از پشت دیده نمی‌شود */ }
  if (f.beard === "long" && front) { ctx.fillStyle = bc; ctx.strokeStyle = shade(hair, 0.45, 0.7); ctx.lineWidth = Math.max(1, R * 0.03); ctx.beginPath(); ctx.moveTo(-wX * 0.85 + fo * 0.5, hY * 0.55); ctx.quadraticCurveTo(-wX * 0.9 + fo * 0.5, hY * 1.2, fo * 0.5, hY * 2.0); ctx.quadraticCurveTo(wX * 0.9 + fo * 0.5, hY * 1.2, wX * 0.85 + fo * 0.5, hY * 0.55); ctx.quadraticCurveTo(fo * 0.5, hY * 1.0, -wX * 0.85 + fo * 0.5, hY * 0.55); ctx.fill(); ctx.stroke(); }
  // --- مو ---
  if (hairOn) {
    hairFill(ctx, hair, wX, hY); ctx.strokeStyle = shade(hair, 0.45, 0.7); ctx.lineWidth = Math.max(1, R * 0.035);
    if (front) {
      const sd = clamp((0.55 - c) / 0.7, 0, 1);
      if (style === "mohawk") { ctx.globalAlpha = 0.3; capPath(ctx, wX, hY, 1.01, -hY * 0.05); ctx.quadraticCurveTo(0, -hY * 0.4, -wX, -hY * 0.05); ctx.fill(); ctx.globalAlpha = 1; ctx.beginPath(); ctx.moveTo(-R * 0.17 + fo, -hY * 0.5); for (let i = 0; i < 5; i++) ctx.lineTo(-R * 0.17 + fo + i * R * 0.085, -hY * (1.15 + (i % 2 ? 0.28 : 0.5))); ctx.lineTo(R * 0.17 + fo, -hY * 0.5); ctx.closePath(); ctx.fill(); ctx.stroke(); }
      else {
        capPath(ctx, wX, hY, 1.07, hY * 0.06); ctx.bezierCurveTo(wX * 0.9 + fo * 0.2, -hY * 0.3, wX * 0.5 + fo, -hY * 0.44, fo, -hY * 0.36); ctx.bezierCurveTo(-wX * 0.5 + fo, -hY * 0.44, -wX * 0.9 + fo * 0.2, -hY * 0.3, -wX * 1.07, hY * 0.06); ctx.closePath(); ctx.fill(); ctx.stroke();
        if (!lod) strands(ctx, hair, wX * 0.9, hY, 5, -hY * 0.95, -hY * 0.4, R);
        if (style === "bun") { ctx.beginPath(); ctx.arc(0, -hY * 1.22, R * 0.38, 0, TAU); ctx.fill(); ctx.stroke(); ctx.fillStyle = shade(hair, 1.25, 0.5); ctx.beginPath(); ctx.arc(-R * 0.1, -hY * 1.3, R * 0.12, 0, TAU); ctx.fill(); }
        if (sd > 0.02) { ctx.save(); headPath(ctx, wX, hY, cw, jw, cy); ctx.clip(); hairFill(ctx, hair, wX, hY); const sg2 = s >= 0 ? -1 : 1; ctx.fillRect(sg2 > 0 ? wX - 2 * wX * sd : -wX, -hY, 2 * wX * sd, hY * 1.4); ctx.restore(); }
      }
    } else {
      // نمای پشت
      const nape = style === "short" || style === "mohawk" ? hY * 0.32 : hY * 0.55;
      if (style === "mohawk") { ctx.globalAlpha = 0.3; capPath(ctx, wX, hY, 1.0, hY * 0.3); ctx.closePath(); ctx.fill(); ctx.globalAlpha = 1; ctx.beginPath(); ctx.moveTo(-R * 0.17, hY * 0.4); for (let i = 0; i < 6; i++) ctx.lineTo(-R * 0.17 + (i % 2) * R * 0.04, -hY * (0.3 + i * 0.2)); ctx.lineTo(0, -hY * 1.55); ctx.lineTo(R * 0.17, -hY * 0.9); ctx.lineTo(R * 0.17, hY * 0.4); ctx.closePath(); ctx.fill(); ctx.stroke(); }
      else {
        if (style === "long") hairDrape(0);
        capPath(ctx, wX, hY, 1.08, nape); ctx.quadraticCurveTo(0, nape + hY * 0.25, -wX * 1.08, nape); ctx.closePath(); ctx.fill(); ctx.stroke(); if (!lod) strands(ctx, hair, wX, hY, 6, -hY * 0.9, nape, R);
        if (style === "pony") ponyTail(true);
        if (style === "bun") { hairFill(ctx, hair, wX, hY); ctx.beginPath(); ctx.arc(0, -hY * 1.15, R * 0.4, 0, TAU); ctx.fill(); ctx.stroke(); ctx.strokeStyle = shade(hair, 0.5, 0.6); ctx.beginPath(); ctx.arc(0, -hY * 1.15, R * 0.22, 0.3, 4.2); ctx.stroke(); }
      }
    }
  } else if (style === "bald" && !covers && !lod) { ctx.fillStyle = "rgba(255,255,255,.28)"; ctx.beginPath(); ctx.ellipse(-wX * 0.3, -hY * 0.62, wX * 0.2, hY * 0.12, -0.5, 0, TAU); ctx.fill(); }
  if (hm && hm.kind !== "none") helm2d(ctx, hm, wX, hY, R, front, c, sway, hair);
  ctx.restore();
}

// ---------- آیکون‌های SVG تجهیزات ----------
let uid = 0;
export function gearSVG(slot, g) {
  const id = "gq" + (++uid), r = RARITY[g.r || "c"].col; let b = "";
  const grad = (a, c1, c2) => `<linearGradient id="${id}${a}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient>`;
  const dk = (h, k = 0.5) => shade(h, k), lt = (h, k = 1.35) => shade(h, k);
  if (slot === "sword") {
    const k = g.kind, bl = g.blade, hl = g.hilt, L = 34 + (g.len - 1) * 12, top = 46 - L;
    b = `<defs>${grad("b", lt(bl, 1.3), dk(bl, 0.78))}${grad("h", lt(hl, 1.2), dk(hl, 0.6))}</defs><g transform="rotate(38 32 32)">`;
    if (g.glow) b += `<ellipse cx="32" cy="${top + L / 2}" rx="9" ry="${L / 2 + 2}" fill="${g.glow}" opacity=".28"/>`;
    if (k === "axe") b += `<rect x="30" y="8" width="4" height="52" rx="2" fill="url(#${id}h)" stroke="${dk(hl)}" stroke-width="1"/><path d="M34 10 C52 6 58 22 54 36 C48 28 42 26 34 28 Z" fill="url(#${id}b)" stroke="${dk(bl, 0.4)}" stroke-width="1.5"/><path d="M30 12 C22 12 20 18 22 24 L30 22 Z" fill="url(#${id}b)" stroke="${dk(bl, 0.4)}" stroke-width="1.2"/><path d="M52 14 C55 22 54 30 51 34" stroke="#fff" stroke-opacity=".7" stroke-width="1.5" fill="none"/>`;
    else if (k === "mace") { b += `<rect x="30" y="20" width="4" height="40" rx="2" fill="url(#${id}h)" stroke="${dk(hl)}"/><circle cx="32" cy="14" r="11" fill="url(#${id}b)" stroke="${dk(bl, 0.4)}" stroke-width="1.5"/>`; for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; b += `<path d="M${(32 + Math.cos(a) * 9).toFixed(1)} ${(14 + Math.sin(a) * 9).toFixed(1)} L${(32 + Math.cos(a) * 15).toFixed(1)} ${(14 + Math.sin(a) * 15).toFixed(1)} L${(32 + Math.cos(a + 0.4) * 9).toFixed(1)} ${(14 + Math.sin(a + 0.4) * 9).toFixed(1)}Z" fill="${dk(bl, 0.7)}"/>`; } b += `<path d="M26 10 a8 8 0 0 1 8 -3" stroke="#fff" stroke-opacity=".6" stroke-width="2" fill="none"/>`; }
    else {
      if (k === "curve") b += `<path d="M30 47 C20 38 22 18 38 3 C38 16 37 32 36 47 Z" fill="url(#${id}b)" stroke="${dk(bl, 0.4)}" stroke-width="1.5"/><path d="M36 6 C35 20 35 32 34 44" stroke="#fff" stroke-opacity=".6" stroke-width="1.2" fill="none"/>`;
      else { b += `<path d="M32 ${top - 3} L36.5 ${top + 4} L36.5 46 L27.5 46 L27.5 ${top + 4} Z" fill="url(#${id}b)" stroke="${dk(bl, 0.4)}" stroke-width="1.5" stroke-linejoin="round"/><path d="M32 ${top + 2} V45" stroke="${dk(bl, 0.7)}" stroke-width="1.4"/><path d="M29.5 ${top + 6} V44" stroke="#fff" stroke-opacity=".55" stroke-width="1.2"/>`; if (k === "twin") b += `<path d="M36.5 ${top + 8} L47 ${top - 6} L44 ${top + 14} L36.5 ${top + 18} Z M27.5 ${top + 8} L17 ${top - 6} L20 ${top + 14} L27.5 ${top + 18} Z" fill="url(#${id}b)" stroke="${dk(bl, 0.4)}" stroke-width="1.2"/>`; }
      b += `<rect x="21" y="46" width="22" height="5" rx="2.5" fill="url(#${id}h)" stroke="${dk(hl)}" stroke-width="1.2"/><rect x="29.5" y="51" width="5" height="9" rx="2" fill="${dk(hl, 0.8)}" stroke="${dk(hl)}"/><circle cx="32" cy="61" r="3.2" fill="url(#${id}h)" stroke="${dk(hl)}"/>`;
    }
    b += `</g>`;
  } else if (slot === "shield") {
    if (g.id === "d0") b = `<circle cx="32" cy="32" r="18" fill="none" stroke="#7a859e" stroke-width="3" stroke-dasharray="5 5"/><path d="M22 22l20 20M42 22L22 42" stroke="#7a859e" stroke-width="3" stroke-linecap="round"/>`;
    else {
      const c = g.color, rim = g.rim; b = `<defs>${grad("s", lt(c, 1.3), dk(c, 0.7))}</defs>`;
      if (g.glow) b += `<circle cx="32" cy="32" r="28" fill="${g.glow}" opacity=".25"/>`;
      const emb = g.emblem === 1 ? `<path d="M32 18 l4 9 10 1 -8 6 3 10 -9 -6 -9 6 3 -10 -8 -6 10 -1z" fill="#d8453a" stroke="#6a120a" stroke-width="1"/>` : g.emblem === 2 ? `<path d="M32 16 L40 32 L32 48 L24 32Z" fill="${rim}" opacity=".9"/><circle cx="32" cy="32" r="5" fill="${dk(c, .6)}"/>` : g.emblem === 3 ? `<path d="M10 28 q10 -14 22 -4 q12 -10 22 4 q-12 -2 -22 6 q-10 -8 -22 -6z" fill="#c8862a"/><circle cx="32" cy="30" r="6" fill="#fff4c0" stroke="#c8862a" stroke-width="1.5"/><path d="M26 42 h12 l-3 8 h-6z" fill="#c8862a"/>` : "";
      if (g.shape === "kite") b += `<path d="M32 5 L55 13 C55 38 46 51 32 60 C18 51 9 38 9 13 Z" fill="url(#${id}s)" stroke="${rim}" stroke-width="3.5" stroke-linejoin="round"/><path d="M32 8 V57" stroke="${dk(c, .55)}" stroke-width="1.4"/><path d="M13 22 H51" stroke="${dk(c, .55)}" stroke-width="1.4"/>` + emb + `<circle cx="32" cy="30" r="4.5" fill="${lt(rim, 1.2)}" stroke="${dk(rim)}"/>`;
      else b += `<circle cx="32" cy="32" r="25" fill="url(#${id}s)" stroke="${rim}" stroke-width="4"/><circle cx="32" cy="32" r="19" fill="none" stroke="${dk(c, .6)}" stroke-width="1.4"/>` + (g.emblem ? emb : `<path d="M32 8V56M8 32H56M15 15L49 49M49 15L15 49" stroke="${dk(c, .6)}" stroke-width="1.2"/>`) + `<circle cx="32" cy="32" r="${g.emblem ? 4 : 7}" fill="${lt(rim, 1.2)}" stroke="${dk(rim)}" stroke-width="1.2"/>`;
      b += `<path d="M16 14 q8 -7 18 -7" stroke="#fff" stroke-opacity=".5" stroke-width="2.5" fill="none" stroke-linecap="round"/>`;
    }
  } else if (slot === "helm") {
    const c = g.color, k = g.kind; b = `<defs>${grad("m", lt(c, 1.35), dk(c, 0.62))}</defs>`;
    if (g.glow) b += `<circle cx="32" cy="30" r="27" fill="${g.glow}" opacity=".22"/>`;
    const st = `stroke="${dk(c, 0.4)}" stroke-width="1.8" stroke-linejoin="round"`;
    if (k === "cap") b += `<path d="M12 40 C10 16 54 16 52 40 C44 34 20 34 12 40Z" fill="url(#${id}m)" ${st}/><path d="M32 17 V35" stroke="${dk(c, .6)}" stroke-dasharray="3 2.5" stroke-width="1.5"/>`;
    else if (k === "crown") b += `<path d="M10 44 L10 20 L20 32 L26 14 L32 30 L38 14 L44 32 L54 20 L54 44 Z" fill="url(#${id}m)" ${st}/><rect x="10" y="40" width="44" height="7" rx="2" fill="${dk(c, .85)}" ${st}/><circle cx="32" cy="43.5" r="3.3" fill="${g.gem || "#d84a3a"}" stroke="#fff" stroke-opacity=".7"/>` + [18, 46].map((x) => `<circle cx="${x}" cy="43.5" r="2" fill="#7bd8ff"/>`).join("");
    else if (k === "coif") b += `<path d="M10 52 C6 20 20 8 32 8 C44 8 58 20 54 52 C48 46 44 44 42 36 C40 24 24 24 22 36 C20 44 16 46 10 52Z" fill="url(#${id}m)" ${st}/>` + Array.from({ length: 9 }, (_, i) => `<path d="M${8 + i * 6} 12 L${14 + i * 6} 50" stroke="${dk(c, .5)}" stroke-opacity=".5"/>`).join("");
    else {
      if (k === "winged") b += [-1, 1].map((sg) => `<path d="M${32 + sg * 20} 30 Q${32 + sg * 40} 18 ${32 + sg * 30} 4 Q${32 + sg * 34} 20 ${32 + sg * 18} 24Z M${32 + sg * 20} 34 Q${32 + sg * 44} 28 ${32 + sg * 38} 12 Q${32 + sg * 36} 28 ${32 + sg * 18} 30Z" fill="${g.plume}" stroke="${dk(g.plume, .5)}" stroke-width="1.2"/>`).join("");
      if (k === "horned") b += [-1, 1].map((sg) => `<path d="M${32 + sg * 16} 24 C${32 + sg * 36} 24 ${32 + sg * 40} 8 ${32 + sg * 28} 2 C${32 + sg * 30} 14 ${32 + sg * 24} 16 ${32 + sg * 14} 16Z" fill="#efe6cc" stroke="#6a5a3a" stroke-width="1.4"/>`).join("");
      if (k === "crest") b += `<path d="M30 20 C28 2 52 -2 50 14 C44 10 38 14 34 22Z" fill="${g.plume}" stroke="${dk(g.plume, .5)}" stroke-width="1.2"/>`;
      b += `<path d="M12 42 C10 14 54 14 52 42 L52 50 L42 50 L42 42 L38 42 L38 54 L26 54 L26 42 L22 42 L22 50 L12 50Z" fill="url(#${id}m)" ${st}/><path d="M12 38 H52" stroke="${dk(c, .5)}" stroke-width="2.5"/><path d="M20 22 q4 -6 12 -6" stroke="#fff" stroke-opacity=".55" stroke-width="2.5" fill="none" stroke-linecap="round"/><circle cx="18" cy="38" r="1.5" fill="${dk(c, .4)}"/><circle cx="46" cy="38" r="1.5" fill="${dk(c, .4)}"/>`;
    }
  } else if (slot === "armor") {
    const c = g.color; b = `<defs>${grad("a", lt(c, 1.3), dk(c, 0.62))}${g.mail ? `<pattern id="${id}p" width="5" height="5" patternUnits="userSpaceOnUse"><circle cx="2.5" cy="2.5" r="2" fill="none" stroke="${dk(c, .45)}" stroke-width=".9"/></pattern>` : ""}</defs>`;
    if (g.glow) b += `<ellipse cx="32" cy="32" rx="26" ry="28" fill="${g.glow}" opacity=".22"/>`;
    b += `<path d="M8 18 L22 8 Q32 14 42 8 L56 18 L50 30 L46 28 L48 56 L16 56 L18 28 L14 30Z" fill="url(#${id}a)" stroke="${dk(c, .4)}" stroke-width="1.8" stroke-linejoin="round"/>`;
    if (g.mail) b += `<path d="M16 20 L22 12 Q32 18 42 12 L48 20 L46 54 L18 54Z" fill="url(#${id}p)"/>`;
    if (g.plate) b += `<path d="M20 22 Q32 28 44 22 M20 34 Q32 40 44 34 M22 46 Q32 51 42 46" stroke="${dk(c, .5)}" stroke-width="1.6" fill="none"/><path d="M32 16 V54" stroke="${dk(c, .5)}" stroke-width="1.2"/>`;
    if (g.trim) b += `<path d="M22 8 Q32 14 42 8" stroke="${g.trim}" stroke-width="2.5" fill="none"/><path d="M16 56 H48" stroke="${g.trim}" stroke-width="3"/><circle cx="32" cy="30" r="4" fill="${g.trim}" stroke="${dk(g.trim, .5)}"/>`;
    b += `<path d="M16 54 H48 V58 H16Z" fill="#5a3a1a" stroke="#2a1a0a" stroke-width="1.2"/><path d="M22 16 q6 -4 12 -2" stroke="#fff" stroke-opacity=".4" stroke-width="2.5" fill="none" stroke-linecap="round"/>`;
  } else if (slot === "cape") {
    if (g.id === "c0") b = `<path d="M18 10 H46 L56 56 C44 50 20 50 8 56Z" fill="none" stroke="#7a859e" stroke-width="3" stroke-dasharray="5 5"/>`;
    else { const c = g.color, c2 = g.color2 || lt(c, 1.4); b = `<defs><linearGradient id="${id}c" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${lt(c, 1.2)}"/><stop offset="1" stop-color="${dk(c, 0.6)}"/></linearGradient></defs>${g.glow ? `<ellipse cx="32" cy="34" rx="28" ry="28" fill="${g.glow}" opacity=".22"/>` : ""}<path d="M18 8 H46 L58 58 C46 52 40 56 32 52 C24 56 18 52 6 58Z" fill="url(#${id}c)" stroke="${dk(c, .4)}" stroke-width="1.8" stroke-linejoin="round"/><path d="M26 12 L22 54 M32 12 V52 M38 12 L42 54" stroke="${dk(c, .5)}" stroke-width="1.3" opacity=".7"/><path d="M12 56 C22 52 26 56 32 52 C38 56 44 52 54 56" stroke="${c2}" stroke-width="2.5" fill="none"/><rect x="14" y="6" width="36" height="6" rx="3" fill="${c2}" stroke="${dk(c, .4)}"/><circle cx="32" cy="9" r="3" fill="#ffd24a" stroke="#8a5a08"/>`; }
  } else if (slot === "aura") {
    if (g.id === "x0") b = `<circle cx="32" cy="32" r="18" fill="none" stroke="#7a859e" stroke-width="3" stroke-dasharray="5 5"/>`;
    else {
      const c = g.col; b = `<defs><radialGradient id="${id}r"><stop offset="0" stop-color="${c}" stop-opacity=".1"/><stop offset=".7" stop-color="${c}" stop-opacity=".45"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></radialGradient></defs><circle cx="32" cy="32" r="29" fill="url(#${id}r)"/>`;
      if (g.kind === "flame") b += `<path d="M32 6 C36 18 50 22 48 38 C46 50 38 56 32 56 C24 56 16 50 16 38 C16 28 24 26 26 16 C28 22 30 22 32 6Z" fill="${c}" stroke="${dk(c, .4)}" stroke-width="1.6"/><path d="M32 26 C35 32 42 34 40 42 C39 48 35 50 32 50 C28 50 24 46 24 42 C24 36 30 34 32 26Z" fill="#ffd86a"/><path d="M32 38 C34 42 36 44 34 48 H30 C28 44 31 42 32 38Z" fill="#fff6c8"/>`;
      else if (g.kind === "frost") { for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; b += `<path d="M32 32 L${(32 + Math.cos(a) * 22).toFixed(1)} ${(32 + Math.sin(a) * 22).toFixed(1)}" stroke="${c}" stroke-width="3" stroke-linecap="round"/><path d="M${(32 + Math.cos(a) * 14).toFixed(1)} ${(32 + Math.sin(a) * 14).toFixed(1)} l${(Math.cos(a + 1.2) * 6).toFixed(1)} ${(Math.sin(a + 1.2) * 6).toFixed(1)} M${(32 + Math.cos(a) * 14).toFixed(1)} ${(32 + Math.sin(a) * 14).toFixed(1)} l${(Math.cos(a - 1.2) * 6).toFixed(1)} ${(Math.sin(a - 1.2) * 6).toFixed(1)}" stroke="#fff" stroke-width="2" stroke-linecap="round"/>`; } b += `<circle cx="32" cy="32" r="4" fill="#fff"/>`; }
      else if (g.kind === "banner") b += `<rect x="14" y="4" width="3.5" height="56" rx="1.5" fill="#8a6a3a" stroke="#4a3418"/><path d="M17.500 8 H52 L46 18 L52 28 L46 38 L52 48 H17.500Z" fill="${c}" stroke="${dk(c, .4)}" stroke-width="1.6"/><path d="M17.500 14 H46 M17.500 42 H46" stroke="${g.col2}" stroke-width="2.5"/><circle cx="33" cy="28" r="7" fill="${g.col2}" stroke="${dk(g.col2, .5)}"/><circle cx="33" cy="28" r="3" fill="${c}"/>`;
      else b += `<path d="M32 18 C20 18 10 22 4 34 C14 32 22 34 32 40 C42 34 50 32 60 34 C54 22 44 18 32 18Z" fill="${c}" stroke="${dk(c, .45)}" stroke-width="1.5"/><path d="M12 32 C20 30 26 32 32 36 M52 32 C44 30 38 32 32 36" stroke="#fff6c8" stroke-width="1.5" fill="none"/><circle cx="32" cy="26" r="6" fill="#fff6c8" stroke="${dk(c, .5)}"/><path d="M32 32 V52 M26 46 H38" stroke="${c}" stroke-width="3" stroke-linecap="round"/>`;
    }
  }
  return `<svg class="gi" viewBox="0 0 64 64" aria-hidden="true">${b}</svg>`;
}
