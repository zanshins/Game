// تجهیزات و شخصی‌سازی قهرمان سه‌بعدی
export const SLOTS = { sword: "شمشیر", shield: "سپر", helm: "کلاه‌خود", armor: "زره", cape: "شنل" };
export const GEAR = {
  sword: [
    { id: "s0", name: "شمشیر آهنی", dmg: 14, cost: 0, blade: "#cfd6df", hilt: "#8a6a3a", len: 1.0 },
    { id: "s1", name: "شمشیر فولادی", dmg: 22, cost: 600, blade: "#e8f1ff", hilt: "#b0b8c8", len: 1.1 },
    { id: "s2", name: "قمه‌ی پارسی", dmg: 30, cost: 1800, blade: "#f0e6c8", hilt: "#c8923a", len: 1.15, curve: 1 },
    { id: "s3", name: "تیغ آتشین", dmg: 42, cost: 4200, blade: "#ff9a4a", hilt: "#7a2a1a", len: 1.25, glow: "#ff6a2a" },
    { id: "s4", name: "ذوالفقار", dmg: 58, cost: 0, gems: 120, blade: "#9fe8ff", hilt: "#ffd24a", len: 1.35, glow: "#5ad0ff", twin: 1 },
  ],
  shield: [
    { id: "d0", name: "بدون سپر", def: 0, cost: 0 },
    { id: "d1", name: "سپر چوبی", def: 0.1, cost: 400, color: "#9a7248", rim: "#5a4028" },
    { id: "d2", name: "سپر فولادی", def: 0.18, cost: 1500, color: "#aab4c4", rim: "#6a7486" },
    { id: "d3", name: "سپر شاهی", def: 0.28, cost: 3800, color: "#e0b840", rim: "#8a6a1a", emblem: 1 },
  ],
  helm: [
    { id: "h0", name: "کلاه چرمی", hp: 10, cost: 0, color: "#8a6a4a", kind: "cap" },
    { id: "h1", name: "کلاه‌خود آهنی", hp: 28, cost: 500, color: "#aab4c4", kind: "helm" },
    { id: "h2", name: "کلاه‌خود پرچم‌دار", hp: 50, cost: 1600, color: "#c8d0e0", kind: "crest", plume: "#d84a3a" },
    { id: "h3", name: "تاج شاهی", hp: 80, cost: 4000, color: "#ffd24a", kind: "crown" },
  ],
  armor: [
    { id: "a0", name: "جامه‌ی ساده", hp: 20, cost: 0, color: "#6a8fb8" },
    { id: "a1", name: "زره‌ی زنجیری", hp: 60, cost: 700, color: "#8a94a6" },
    { id: "a2", name: "زره‌ی فولادی", hp: 110, cost: 2000, color: "#aab6c8" },
    { id: "a3", name: "زره‌ی زرین", hp: 180, cost: 4600, color: "#e6bb3c" },
  ],
  cape: [
    { id: "c0", name: "بدون شنل", cost: 0 },
    { id: "c1", name: "شنل سرخ", cost: 300, color: "#c43a3a" },
    { id: "c2", name: "شنل شاهی", cost: 900, color: "#7a3aa8" },
    { id: "c3", name: "شنل زرین", cost: 2200, color: "#e0a82a" },
  ],
};
export const SKINS = ["#f2d0a8", "#e0b184", "#c68e5e", "#8d5a38", "#5a3a26"];
export const HAIRS = ["#2a1a10", "#5a3a1a", "#b8782a", "#d8d0c0", "#a02a2a", "#1a1a2a"];
export const TUNICS = ["#6a8fb8", "#4aa86a", "#c4503a", "#8a5ac8", "#d8a83a", "#2a2f3a"];
export const find = (slot, id) => GEAR[slot].find((g) => g.id === id) || GEAR[slot][0];
export function defaultAvatar() { return { skin: SKINS[0], hair: HAIRS[1], tunic: TUNICS[0], sword: "s0", shield: "d0", helm: "h0", armor: "a0", cape: "c0" }; }
export function defaultOwned() { return { s0: 1, d0: 1, h0: 1, a0: 1, c0: 1 }; }
export function stats(av) {
  const s = find("sword", av.sword), sh = find("shield", av.shield), h = find("helm", av.helm), a = find("armor", av.armor);
  return { dmg: s.dmg, hp: 120 + h.hp + a.hp, def: sh.def || 0 };
}
