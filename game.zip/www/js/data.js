// داده‌های ثابت بازی «بستیون: حماسه‌ی ایران‌زمین»
export const COLS = 14, ROWS = 8;
export const fa = (n) => {
  n = Math.round(n);
  const s = Math.abs(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, "٬");
  return (n < 0 ? "-" : "") + s.replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);
};
export const faTime = (sec) => { sec = Math.max(0, Math.floor(sec)); const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60; return (h ? fa(h) + ":" : "") + fa(m).padStart(1, "۰") + ":" + (s < 10 ? "۰" : "") + fa(s); };

export function rng(seed) { let s = seed >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }

// ---------- برج‌ها ----------
export const TOWER_ORDER = ["bow", "spear", "catapult", "frost", "lightning", "flame", "arcane", "bank"];
export const TOWERS = {
  bow: { name: "کمان", icon: "🏹", color: "#7bd88f", cost: 60, range: 2.7, dmg: 9, rate: 1.9, speed: 12, desc: "سریع و ارزان؛ ستون دفاع", unlock: 0,
    evo: { a: { name: "کمان رعد", color: "#9be7ff", desc: "سه تیر هم‌زمان", multi: 3, dmgMul: 0.75 }, b: { name: "شکارچی", color: "#ffd36b", desc: "برد بلند و ضربه‌ی مهلک", rangeMul: 1.5, crit: 0.3, critMul: 3.2, rateMul: 0.8, dmgMul: 1.3 } } },
  spear: { name: "بالیستا", icon: "🗡️", color: "#e8c27a", cost: 100, range: 2.3, dmg: 24, rate: 0.95, speed: 15, pierce: 3, desc: "نیزه‌ی سوراخ‌کننده‌ی صف", unlock: 0,
    evo: { a: { name: "بالیستای غول", color: "#ff9d5c", desc: "نیزه‌ی عظیم با نفوذ ۷", dmgMul: 2.1, pierce: 7, rateMul: 0.85 }, b: { name: "نیزه‌ی زنجیری", color: "#b8c6ff", desc: "پرتاب‌ها به دشمنان بعدی می‌پرند", chain: 4, dmgMul: 1.3, rateMul: 1.2 } } },
  catapult: { name: "منجنیق", icon: "💥", color: "#ff9a62", cost: 140, range: 3.5, dmg: 34, rate: 0.5, speed: 4, splash: 1.1, ground: true, desc: "انفجار گروهی؛ فقط زمینی", unlock: 0,
    evo: { a: { name: "توپ آتشین", color: "#ff5a3c", desc: "زمین را می‌سوزاند", burnZone: 4, dmgMul: 1.3 }, b: { name: "ترابوشه", color: "#d7a3ff", desc: "برد و انفجار بزرگ + بی‌حرکتی", splashMul: 1.5, rangeMul: 1.3, stun: 0.9 } } },
  frost: { name: "یخ", icon: "❄️", color: "#8fe3ff", cost: 110, range: 2.5, dmg: 5, rate: 1.2, speed: 8, slow: 0.5, slowDur: 1.8, desc: "کندکننده‌ی دشمن", unlock: 1,
    evo: { a: { name: "یخچال", color: "#c9f3ff", desc: "هر ۴ ثانیه همه را منجمد می‌کند", freezeEvery: 4, freezeDur: 1.3 }, b: { name: "کولاک", color: "#6ab7ff", desc: "آسیب بالا و کندی شدید", dmgMul: 5, slow: 0.68, rangeMul: 1.2 } } },
  lightning: { name: "صاعقه", icon: "⚡", color: "#ffe45c", cost: 150, range: 2.5, dmg: 15, rate: 0.95, chain: 3, magic: true, desc: "رعد زنجیره‌ای؛ زره را دور می‌زند", unlock: 2,
    evo: { a: { name: "طوفان", color: "#fff39a", desc: "زنجیره‌ی ۷ هدفه", chain: 7, dmgMul: 1.1 }, b: { name: "تسلا", color: "#9ff0ff", desc: "ضربه‌ی قوی + شوک", dmgMul: 1.7, stun: 0.55, rateMul: 1.1 } } },
  flame: { name: "آتش", icon: "🔥", color: "#ff7a3c", cost: 130, range: 1.95, dmg: 5, rate: 5, burn: 6, burnDur: 2.4, desc: "شعله‌ی پیوسته و سوزاندن", unlock: 3,
    evo: { a: { name: "اژدها", color: "#ff3d6a", desc: "برد بلندتر و سوختن شدید", rangeMul: 1.45, burn: 16, dmgMul: 1.4 }, b: { name: "آتشفشان", color: "#ff9d2f", desc: "هر ثانیه انفجار گرد برج", pulse: 1, pulseDmg: 38, dmgMul: 0.8 } } },
  arcane: { name: "جادو", icon: "🔮", color: "#c58bff", cost: 170, range: 3, dmg: 30, rate: 0.85, speed: 9, magic: true, desc: "گوی جادویی هدایت‌شونده", unlock: 4,
    evo: { a: { name: "کهکشان", color: "#8f7bff", desc: "دو گوی و ستاره‌ی همراه", multi: 2, dmgMul: 0.95 }, b: { name: "مرگ‌آور", color: "#ff4fa0", desc: "اعدام دشمن زیر ۲۵٪ جان", execute: 0.25, dmgMul: 1.6 } } },
  bank: { name: "گنجینه", icon: "💰", color: "#ffd24a", cost: 150, range: 2.2, desc: "هر موج طلا می‌دهد", income: 22, unlock: 1,
    evo: { a: { name: "خزانه", color: "#fff0a0", desc: "درآمد دو برابر", incomeMul: 2.2 }, b: { name: "ضرابخانه", color: "#ffb347", desc: "درآمد + تقویت برج‌های اطراف", incomeMul: 1.5, aura: 0.18 } } },
};
export const LEVEL_COST = [0, 0.8, 1.3]; // هزینه‌ی سطح ۲ و ۳ نسبت به هزینه‌ی پایه
export const LEVEL_MUL = { dmg: [1, 1.55, 2.4], range: [1, 1.08, 1.16], rate: [1, 1.1, 1.2] };
export const EVO_COST = 2.3;
export const SELL_RATIO = 0.65;

// ---------- دشمنان ----------
export const ENEMIES = {
  scout: { name: "پیشاهنگ", hp: 30, speed: 1.75, gold: 5, r: 0.22, armor: 0 },
  raider: { name: "مهاجم", hp: 62, speed: 0.95, gold: 7, r: 0.28, armor: 0 },
  shield: { name: "سپردار", hp: 130, speed: 0.75, gold: 10, r: 0.3, armor: 0.35 },
  brute: { name: "غول", hp: 320, speed: 0.5, gold: 15, r: 0.4, armor: 0.1 },
  flyer: { name: "عقاب تاریکی", hp: 52, speed: 1.3, gold: 8, r: 0.26, armor: 0, flying: true },
  healer: { name: "شفادهنده", hp: 95, speed: 0.8, gold: 12, r: 0.28, armor: 0, heals: true },
  splitter: { name: "ژله‌ی تکثیری", hp: 170, speed: 0.7, gold: 11, r: 0.33, armor: 0, splits: true },
  mini: { name: "ژله‌ی کوچک", hp: 38, speed: 1.15, gold: 2, r: 0.18, armor: 0 },
  boss: { name: "سالار", hp: 1900, speed: 0.42, gold: 90, r: 0.55, armor: 0.2, boss: true },
};

// ---------- مپ‌ها ----------
// مسیرها با مختصات خانه (ستون، ردیف)؛ -1 و ۱۴ یعنی بیرون صفحه
export const MAPS = [
  { id: "meadow", name: "دشت سبز", sub: "آغاز سفر", emoji: "🌾", music: "map1", waves: 10, weather: "petals", seed: 11,
    col: { g1: "#4f9d4a", g2: "#5cae54", path: "#cfae72", edge: "#8a6a3a", acc: "#9be88a", deco: "tree" }, enemyTint: "#d9534f",
    paths: [[[-1, 1], [3, 1], [3, 5], [7, 5], [7, 2], [10, 2], [10, 6], [14, 6]]],
    boss: { name: "سالار دشت", ability: "summon" }, gold: 240, lives: 20, sky: ["#2d6a4f", "#9ad37a"] },
  { id: "forest", name: "جنگل افسون‌شده", sub: "درختان زمزمه می‌کنند", emoji: "🌲", music: "map2", waves: 12, weather: "fireflies", seed: 22,
    col: { g1: "#1f5a43", g2: "#256b4e", path: "#6d5a8e", edge: "#3b2d58", acc: "#7cf0c8", deco: "mushroom" }, enemyTint: "#8e5be0",
    paths: [[[-1, 6], [2, 6], [2, 2], [5, 2], [5, 5], [8, 5], [8, 1], [11, 1], [11, 4], [14, 4]]],
    boss: { name: "پیر جنگل", ability: "regen" }, gold: 300, lives: 20, sky: ["#0d3b2e", "#3fb58b"] },
  { id: "desert", name: "صحرای سوزان", sub: "خورشید بی‌رحم", emoji: "🏜️", music: "map3", waves: 12, weather: "sand", seed: 33,
    col: { g1: "#d8a24a", g2: "#e0ad57", path: "#a8703a", edge: "#6e4421", acc: "#ffd27a", deco: "cactus" }, enemyTint: "#7a4a2a",
    paths: [[[-1, 3], [4, 3], [4, 6], [7, 6], [7, 1], [10, 1], [10, 5], [14, 5]], [[-1, 7], [2, 7], [2, 5], [4, 5], [4, 6], [7, 6], [7, 1], [10, 1], [10, 5], [14, 5]]],
    boss: { name: "عقرب سرخ", ability: "charge" }, gold: 340, lives: 20, sky: ["#8c4a1d", "#ffcf7a"] },
  { id: "ice", name: "قله‌ی یخی", sub: "سرمای استخوان‌سوز", emoji: "🏔️", music: "map4", waves: 14, weather: "snow", seed: 44,
    col: { g1: "#b9dcf2", g2: "#c8e6f7", path: "#6fa3cc", edge: "#3e6c94", acc: "#e9fbff", deco: "crystal" }, enemyTint: "#2f6fb5",
    paths: [[[-1, 1], [12, 1], [12, 3], [2, 3], [2, 5], [12, 5], [12, 7], [14, 7]]],
    boss: { name: "غول یخی", ability: "frostimmune" }, gold: 540, lives: 20, sky: ["#1f4b78", "#d6f1ff"] },
  { id: "swamp", name: "مرداب سمی", sub: "دو دروازه، یک سرنوشت", emoji: "🐊", music: "map5", waves: 14, weather: "spores", seed: 55,
    col: { g1: "#4a5a2c", g2: "#566a31", path: "#7a6a3c", edge: "#3a3017", acc: "#b6ff5c", deco: "mushroom2" }, enemyTint: "#6f9a2a",
    paths: [[[-1, 1], [5, 1], [5, 4], [8, 4], [8, 2], [11, 2], [11, 5], [14, 5]], [[-1, 6], [5, 6], [5, 4], [8, 4], [8, 2], [11, 2], [11, 5], [14, 5]]],
    boss: { name: "اژدهای مرداب", ability: "aura" }, gold: 420, lives: 20, sky: ["#27320f", "#9bc24a"] },
  { id: "volcano", name: "آتشفشان", sub: "رود گدازه", emoji: "🌋", music: "map6", waves: 16, weather: "embers", seed: 66,
    col: { g1: "#4a2a26", g2: "#573029", path: "#ff7a2e", edge: "#8a2a10", acc: "#ffb347", deco: "lavarock" }, enemyTint: "#ff4d2e",
    paths: [[[-1, 2], [2, 2], [2, 6], [5, 6], [5, 1], [8, 1], [8, 6], [11, 6], [11, 3], [14, 3]]],
    boss: { name: "ضحاک آتشین", ability: "enrage" }, gold: 460, lives: 18, sky: ["#2a0d0a", "#ff6a2e"] },
  { id: "sky", name: "قلعه‌ی ابر", sub: "بر فراز آسمان", emoji: "🏰", music: "map7", waves: 16, weather: "clouds", seed: 77,
    col: { g1: "#8aa8e6", g2: "#97b4ee", path: "#f0e6c8", edge: "#a89868", acc: "#ffffff", deco: "cloud" }, enemyTint: "#e0b84a",
    paths: [[[-1, 4], [3, 4], [3, 1], [6, 1], [6, 6], [9, 6], [9, 3], [12, 3], [12, 0], [14, 0]]],
    boss: { name: "فرمانده ابر", ability: "shieldphase" }, gold: 500, lives: 18, sky: ["#3a58a8", "#d8e6ff"] },
  { id: "void", name: "اعماق ظلمت", sub: "نبرد پایانی با اهریمن", emoji: "🌌", music: "map8", waves: 20, weather: "stars", seed: 88,
    col: { g1: "#1d1535", g2: "#251a45", path: "#5b3a9a", edge: "#2a1a55", acc: "#d68cff", deco: "voidshard" }, enemyTint: "#c13fb0",
    paths: [[[-1, 1], [10, 1], [10, 4], [3, 4], [3, 6], [14, 6]], [[14, 1], [10, 1], [10, 4], [3, 4], [3, 6], [14, 6]]],
    boss: { name: "اهریمن", ability: "all" }, gold: 380, lives: 18, sky: ["#07030f", "#5a2a9a"] },
];

// ---------- مسیر و مپ ----------
export function buildMapRuntime(map) {
  const paths = map.paths.map((wp) => {
    const pts = wp.map(([x, y]) => ({ x: x + 0.5, y: y + 0.5 }));
    // دو سر مسیر را به بیرون صفحه ببریم تا دشمن از لبه وارد/خارج شود
    const segs = []; let total = 0;
    for (let i = 0; i < pts.length - 1; i++) {
      const a = pts[i], b = pts[i + 1], len = Math.hypot(b.x - a.x, b.y - a.y);
      segs.push({ a, b, len, start: total }); total += len;
    }
    return { pts, segs, total };
  });
  const cells = new Set();
  for (const wp of map.paths) {
    for (let i = 0; i < wp.length - 1; i++) {
      let [x0, y0] = wp[i]; const [x1, y1] = wp[i + 1];
      const dx = Math.sign(x1 - x0), dy = Math.sign(y1 - y0);
      for (;;) { cells.add(x0 + "," + y0); if (x0 === x1 && y0 === y1) break; x0 += dx; y0 += dy; }
    }
  }
  // دکورهای مسدودکننده
  const r = rng(map.seed * 977), deco = [], blocked = new Set();
  for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) {
    const k = x + "," + y; if (cells.has(k)) continue;
    const roll = r();
    if (roll < 0.1) { deco.push({ x, y, kind: map.col.deco, s: 0.7 + r() * 0.5, blocks: true, v: r() }); blocked.add(k); }
    else if (roll < 0.3) deco.push({ x, y, kind: "tuft", s: 0.5 + r() * 0.6, blocks: false, v: r(), ox: r(), oy: r() });
  }
  return { paths, cells, blocked, deco };
}
export function posAt(path, d) {
  const segs = path.segs;
  if (d <= 0) { const s = segs[0], ux = (s.b.x - s.a.x) / s.len, uy = (s.b.y - s.a.y) / s.len; return { x: s.a.x + ux * d, y: s.a.y + uy * d, dx: ux, dy: uy }; }
  for (let i = 0; i < segs.length; i++) {
    const s = segs[i];
    if (d <= s.start + s.len || i === segs.length - 1) { const t = (d - s.start) / s.len; return { x: s.a.x + (s.b.x - s.a.x) * t, y: s.a.y + (s.b.y - s.a.y) * t, dx: (s.b.x - s.a.x) / s.len, dy: (s.b.y - s.a.y) / s.len }; }
  }
}

// ---------- موج‌ها ----------
export function genWaves(mi, hard = false) {
  const map = MAPS[mi], n = map.waves, out = [], r = rng(map.seed * 31 + 7);
  for (let w = 0; w < n; w++) {
    const groups = []; const diff = 1 + w * 0.17 + mi * 0.5;
    const pool = ["scout", "raider"];
    if (w >= 2) pool.push("shield"); if (w >= 3 || mi >= 2) pool.push("brute");
    if (w >= 4 && mi >= 1) pool.push("flyer"); if (w >= 4 && mi >= 2) pool.push("healer"); if (w >= 5 && mi >= 3) pool.push("splitter");
    const nb = w === n - 1 ? 1 : w === Math.floor(n / 2) - 1 && n >= 12 ? 1 : 0;
    const gcount = 2 + (w > 5 ? 1 : 0);
    for (let g = 0; g < gcount; g++) {
      const kind = pool[Math.floor(r() * pool.length)];
      const base = { scout: 9, raider: 7, shield: 5, brute: 3, flyer: 6, healer: 3, splitter: 4 }[kind];
      const count = Math.max(2, Math.round(base * (0.55 + w * 0.1 + mi * 0.05) * (0.85 + r() * 0.3)));
      const interval = Math.max(0.26, ({ scout: 0.4, raider: 0.7, shield: 0.8, brute: 1.3, flyer: 0.55, healer: 1.1, splitter: 1 }[kind]) * (1 - Math.min(0.35, w * 0.015)));
      groups.push({ kind, count, interval, delay: g * 1.4, path: -1 });
    }
    if (nb) groups.push({ kind: "boss", count: w === n - 1 ? 1 + (mi >= 5 ? 1 : 0) : 1, interval: 3, delay: 2.5, path: 0, last: w === n - 1 });
    const hp = (1 + w * 0.16 + w * w * 0.004) * (1 + mi * 0.27) * (hard ? 1.7 : 1);
    out.push({ groups, hpMul: hp, goldMul: (1 + mi * 0.2) * (hard ? 1.4 : 1) });
  }
  return out;
}
export function genRaidWaves(power, kLevel) {
  const out = [], r = rng(power * 13 + 5), n = 6;
  for (let w = 0; w < n; w++) {
    const groups = [{ kind: "raider", count: 6 + w * 2, interval: 0.6, delay: 0, path: 0 }, { kind: "shield", count: 3 + w, interval: 0.9, delay: 1.2, path: 0 }];
    if (w >= 2) groups.push({ kind: "flyer", count: 4 + w, interval: 0.5, delay: 2, path: 0 });
    if (w >= 3) groups.push({ kind: "brute", count: 2 + w - 2, interval: 1.2, delay: 1, path: 0 });
    if (w === n - 1) groups.push({ kind: "boss", count: 1, interval: 2, delay: 3, path: 0 });
    out.push({ groups, hpMul: (1 + w * 0.22) * (0.6 + power / 90) * (1 + kLevel * 0.02), goldMul: 1.1 });
  }
  return out;
}

// ---------- قهرمانان ----------
export const HERO_ORDER = ["arash", "rostam", "gordafarid", "zal", "kaveh"];
export const HEROES = {
  arash: { name: "آرش کمانگیر", title: "تیر آسمان‌شکن", color: "#ffd36b", emoji: "🏹", cost: { coins: 0 }, range: 3.6, dmg: 22, rate: 1.4, ranged: true,
    skill: { name: "تیر آرش", cd: 24, desc: "نیرومندترین دشمن را با تیری عظیم و پرنفوذ می‌زند" }, lore: "کسی که تیرش مرز ایران را کشید." },
  rostam: { name: "رستم دستان", title: "پهلوان جهان", color: "#ff8a5c", emoji: "⚔️", cost: { coins: 3500 }, range: 1.5, dmg: 52, rate: 0.95,
    skill: { name: "گرز رستم", cd: 28, desc: "ضربه‌ی زمین‌لرزه‌ای: آسیب سنگین و بی‌حرکتی دشمنان اطراف" }, lore: "تنومند، شکست‌ناپذیر و باوفا." },
  gordafarid: { name: "گردآفرید", title: "بانوی دژ سپید", color: "#7be0ff", emoji: "🗡️", cost: { gems: 120 }, range: 1.4, dmg: 34, rate: 2.2,
    skill: { name: "رقص شمشیر", cd: 22, desc: "گردبادی از ضربات سریع به دشمنان اطراف" }, lore: "دلیرزنی که سهراب را به چالش کشید." },
  zal: { name: "زال زر", title: "یار سیمرغ", color: "#d9f0ff", emoji: "🦅", cost: { gems: 220 }, range: 3, dmg: 30, rate: 1, magic: true,
    skill: { name: "فرود سیمرغ", cd: 38, desc: "سیمرغ بر همه‌ی دشمنان می‌تازد و جان‌ها را ترمیم می‌کند" }, lore: "موی سپید، دلی روشن." },
  kaveh: { name: "کاوه‌ی آهنگر", title: "درفش کاویانی", color: "#ff5a5a", emoji: "🔨", cost: { coins: 9000 }, range: 1.6, dmg: 40, rate: 1.1,
    skill: { name: "درفش کاویانی", cd: 34, desc: "همه‌ی برج‌ها ۱۰ ثانیه سریع‌تر و قوی‌تر می‌شوند" }, lore: "پیش‌قراول رستاخیز مردم." },
};
export const HERO_MAX = 15;
export const heroUpCost = (key, lvl) => Math.round((HEROES[key].cost.gems ? 700 : 400) * Math.pow(1.5, lvl - 1));
export const heroMul = (lvl) => 1 + 0.2 * (lvl - 1);

// ---------- سربازان (حمله) ----------
export const TROOP_ORDER = ["sword", "shield", "archer", "horse", "ram"];
export const TROOPS = {
  sword: { name: "شمشیرزن", emoji: "⚔️", energy: 2, hp: 95, speed: 1.0, gate: 10, melee: 9, barracks: 1, color: "#ffd9a0", upBase: 300, desc: "سرباز پایه؛ برج‌های کنار مسیر را می‌زند" },
  shield: { name: "سپردار", emoji: "🛡️", energy: 3, hp: 320, speed: 0.8, gate: 6, melee: 5, barracks: 2, color: "#9fc0ff", upBase: 500, desc: "جان زیاد؛ آتش برج‌ها را به خود می‌کشد", tank: true },
  archer: { name: "کماندار", emoji: "🏹", energy: 2, hp: 55, speed: 0.95, gate: 5, ranged: 9, range: 2.3, barracks: 3, color: "#a9f0b4", upBase: 650, desc: "از دور برج‌ها را سوراخ می‌کند" },
  horse: { name: "سوارکار", emoji: "🐎", energy: 3, hp: 130, speed: 1.9, gate: 20, melee: 7, barracks: 4, color: "#ffb86b", upBase: 900, desc: "سریع؛ تا برج‌ها نرسیده به دروازه می‌رسد" },
  ram: { name: "دروازه‌شکن", emoji: "🐏", energy: 5, hp: 230, speed: 0.6, gate: 90, melee: 4, barracks: 5, color: "#d9a066", upBase: 1300, desc: "آسیب عظیم به دروازه" },
};
export const TROOP_MAX = 10;
export const troopUpCost = (key, lvl) => Math.round(TROOPS[key].upBase * Math.pow(1.55, lvl - 1));
export const troopMul = (lvl) => 1 + 0.22 * (lvl - 1);

// ---------- همسایه‌ها ----------
export const NEIGHBORS = [
  { id: "n1", name: "دهکده‌ی سبزپوش", ruler: "کدخدا بهمن", emoji: "🏡", color: "#7bd88f", power: 12, map: 0, gate: 380, loot: 1200, gems: 8, need: 1, towers: 4, tlvl: 1, perk: 0.05 },
  { id: "n2", name: "قلعه‌ی سنگی", ruler: "سردار آرمان", emoji: "🏯", color: "#c9b28a", power: 26, map: 1, gate: 650, loot: 2600, gems: 14, need: 3, towers: 5, tlvl: 1, perk: 0.06 },
  { id: "n3", name: "شهر کاروانی", ruler: "بانو مهتاب", emoji: "🐪", color: "#ffd27a", power: 42, map: 2, gate: 900, loot: 4800, gems: 20, need: 5, towers: 6, tlvl: 2, perk: 0.07 },
  { id: "n4", name: "دژ زمستانی", ruler: "شاه فریدون", emoji: "🧊", color: "#8fe3ff", power: 62, map: 3, gate: 1300, loot: 8000, gems: 28, need: 7, towers: 8, tlvl: 2, perk: 0.08 },
  { id: "n5", name: "امپراتوری آتش", ruler: "خاقان تیمور", emoji: "🔥", color: "#ff7a3c", power: 88, map: 5, gate: 1900, loot: 13000, gems: 40, need: 10, towers: 9, tlvl: 3, perk: 0.1 },
  { id: "n6", name: "کاخ ابرها", ruler: "ملکه‌ی پریسا", emoji: "☁️", color: "#d8e6ff", power: 120, map: 6, gate: 2600, loot: 22000, gems: 60, need: 14, towers: 10, tlvl: 3, perk: 0.12 },
];
export const MAX_ENERGY = 10, ENERGY_REGEN = 1.3, ATTACK_TIME = 100;

// ---------- ساختمان‌های کشور ----------
export const BUILDINGS = {
  mine: { name: "معدن طلا", emoji: "⛏️", color: "#ffd24a", base: 250, grow: 1.55, max: 12, desc: (l) => `${fa(70 * l)} سکه در ساعت`, need: 0 },
  gem: { name: "معدن جواهر", emoji: "💎", color: "#7be0ff", base: 600, grow: 1.7, max: 10, desc: (l) => `${(0.35 * l).toFixed(2).replace(".", "٫").replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d])} جواهر در ساعت`, need: 2 },
  barracks: { name: "پادگان", emoji: "🛖", color: "#ff8a5c", base: 400, grow: 1.6, max: 8, desc: (l) => `باز شدن سربازان تا سطح ${fa(l)}`, need: 0 },
  walls: { name: "دیوار و برج‌دیده‌بان", emoji: "🧱", color: "#c9b28a", base: 350, grow: 1.6, max: 10, desc: (l) => `+${fa(l * 2)} جان در دفاع از کشور`, need: 0 },
  market: { name: "بازار بزرگ", emoji: "🏪", color: "#ffb86b", base: 500, grow: 1.65, max: 8, desc: (l) => `${fa(l * 3)}٪ تخفیف صندوق‌ها`, need: 1 },
  academy: { name: "آکادمی پهلوانان", emoji: "🎓", color: "#c58bff", base: 700, grow: 1.65, max: 8, desc: (l) => `${fa(l * 4)}٪ تخفیف ارتقای قهرمان و سرباز`, need: 2 },
  forge: { name: "کارگاه آهنگری", emoji: "🛠️", color: "#9fc0ff", base: 800, grow: 1.7, max: 8, desc: (l) => `${fa(l * 4)}٪ تخفیف تحقیقات`, need: 3 },
  hall: { name: "تالار اتحاد", emoji: "🏛️", color: "#7bd88f", base: 900, grow: 1.7, max: 6, desc: (l) => `ظرفیت اتحاد و امتیاز هدیه سطح ${fa(l)}`, need: 4 },
};
export const BUILDING_ORDER = ["mine", "gem", "barracks", "walls", "market", "academy", "forge", "hall"];
export const bCost = (key, lvl) => Math.round(BUILDINGS[key].base * Math.pow(BUILDINGS[key].grow, lvl));
export const KINGDOM_TIERS = [[0, "روستا"], [6, "دهکده"], [14, "شهرک"], [26, "شهر"], [40, "قلمرو"], [56, "امپراتوری"]];

// ---------- تحقیقات ----------
export const RESEARCH = {
  dmg: { name: "تیزی سلاح‌ها", emoji: "🗡️", per: "+۴٪ آسیب برج‌ها", max: 12, base: 400, grow: 1.5 },
  rate: { name: "دست‌های چابک", emoji: "⏱️", per: "+۳٪ سرعت شلیک", max: 10, base: 450, grow: 1.5 },
  range: { name: "دیده‌بانی", emoji: "🔭", per: "+۲٪ برد", max: 8, base: 400, grow: 1.5 },
  gold: { name: "تجارت جنگی", emoji: "🪙", per: "+۴٪ طلای نبرد", max: 12, base: 350, grow: 1.5 },
  start: { name: "ذخیره‌ی اولیه", emoji: "🎒", per: "+۲۵ طلای شروع", max: 10, base: 300, grow: 1.45 },
  life: { name: "استحکام دژ", emoji: "❤️", per: "+۱ جان", max: 6, base: 600, grow: 1.7 },
  sell: { name: "معامله‌ی بهتر", emoji: "♻️", per: "+۳٪ بازگشت فروش", max: 6, base: 350, grow: 1.5 },
};
export const rCost = (k, l) => Math.round(RESEARCH[k].base * Math.pow(RESEARCH[k].grow, l));

// ---------- مغازه ----------
export const CHESTS = {
  wood: { name: "صندوق چوبی", emoji: "📦", price: { coins: 700 }, color: "#c9a06a", desc: "سکه‌ی خوب، شاید جواهر" },
  silver: { name: "صندوق نقره‌ای", emoji: "🎁", price: { gems: 45 }, color: "#c9d6e8", desc: "سکه‌ی فراوان و جواهر" },
  gold: { name: "صندوق طلایی", emoji: "👑", price: { gems: 130 }, color: "#ffd24a", desc: "شانس باز کردن قهرمان جدید" },
};
export const BOOSTERS = {
  gold: { name: "کیف طلا", emoji: "💰", desc: "+۱۵۰ طلا در شروع نبرد بعدی", price: { coins: 450 } },
  life: { name: "سپر جان", emoji: "🛡️", desc: "+۵ جان در نبرد بعدی", price: { coins: 600 } },
  power: { name: "ساغر نیرو", emoji: "🧪", desc: "+۲۰٪ آسیب برج‌ها در نبرد بعدی", price: { gems: 12 } },
};
export const GEM_EXCHANGE = [{ gems: 10, coins: 1200 }, { gems: 50, coins: 7000 }, { gems: 200, coins: 32000 }];

// ---------- ماموریت‌ها و پاداش روزانه ----------
export const DAILY_REWARDS = [{ coins: 500 }, { coins: 900 }, { gems: 10 }, { coins: 1800 }, { gems: 18 }, { coins: 3500 }, { gems: 45, chest: "silver" }];
export const MISSION_POOL = [
  { id: "win", text: "در ۲ نبرد پیروز شو", target: 2, reward: { coins: 700 } },
  { id: "kills", text: "۱۵۰ دشمن را نابود کن", target: 150, reward: { coins: 900 } },
  { id: "build", text: "۱۵ برج بساز", target: 15, reward: { coins: 600 } },
  { id: "skill", text: "۴ بار مهارت قهرمان را به‌کار ببر", target: 4, reward: { gems: 6 } },
  { id: "collect", text: "یک‌بار درآمد معدن را جمع کن", target: 1, reward: { coins: 500 } },
  { id: "attack", text: "به یک همسایه حمله کن", target: 1, reward: { gems: 8 } },
  { id: "evolve", text: "یک برج را به شکل نهایی برسان", target: 1, reward: { gems: 10 } },
  { id: "donate", text: "به اتحاد کمک کن", target: 1, reward: { coins: 600 } },
];
export const BOT_NAMES = ["پیمان", "سارا", "کیان", "مهسا", "بردیا", "نیلوفر", "آریا", "ستاره", "داریوش", "یلدا", "ماهان", "رها", "سیروس", "الهام", "بابک", "نگار"];
export const BOT_MSGS = ["کسی برای جنگ هفتگی آماده‌ست؟", "مرحله‌ی ۷ رو با رستم زدم، عالی بود!", "برج کولاک تو مرداب فوق‌العاده‌ست", "امروز کمک مالی کردم 💪", "درفش کاویانی + صاعقه = ترکیب مرگبار", "همسایه‌ی شمالی رو فتح کردیم!", "سلام به همه‌ی پهلوانان 🌟", "کی میاد دفاع از کشور؟", "گنجینه رو کنار فروشگاه بذارید سودش بالاست", "امشب ماموریت اتحاد رو تموم می‌کنیم"];
export const ALLIANCE_PERK = (lvl) => ({ coin: 0.02 * lvl, dmg: 0.015 * lvl });
export const PLAYER_XP = (lvl) => 120 + lvl * 90;
