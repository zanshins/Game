// ساختمان‌های کشور: تصویر SVG اختصاصی هر ساختمان که با سطح بزرگ‌تر و باشکوه‌تر می‌شود
const P = (d, f, s = "#1a1224", w = 1.6) => `<path d="${d}" fill="${f}" stroke="${s}" stroke-width="${w}" stroke-linejoin="round"/>`;
const R = (x, y, w, h, f, rx = 1.5, s = "#1a1224", sw = 1.4) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${f}" stroke="${s}" stroke-width="${sw}"/>`;
const C = (x, y, r, f, s = "#1a1224", sw = 1.2) => `<circle cx="${x}" cy="${y}" r="${r}" fill="${f}" stroke="${s}" stroke-width="${sw}"/>`;
const flag = (x, y, c) => `<path d="M${x} ${y}v-12" stroke="#3a2410" stroke-width="1.6"/>${P(`M${x} ${y - 12}l8 3-8 3z`, c, "#1a1224", 1)}`;
const win = (x, y, lit) => R(x, y, 4, 5, lit ? "#ffe08a" : "#3a3a5a", 1, "#1a1224", 1);
export function bldSVG(key, L = 1) {
  const t = Math.min(3, Math.floor((L - 1) / 3)), fl = 1 + t;
  const ground = `<ellipse cx="32" cy="57" rx="27" ry="5" fill="#000" opacity=".28"/><path d="M4 56c8-4 48-4 56 0v3H4z" fill="#4a7a3a" stroke="#1a3a1a" stroke-width="1.2"/>`;
  let b = "";
  if (key === "mine") {
    b = P("M6 56L20 22l10-6 14 8 14 32z", "#7a7a88") + P("M20 22l10-6 4 4-8 6z", "#a8a8b8", "#1a1224", 1) + P("M22 56V40q10-12 20 0v16z", "#1a1220") + R(20, 38, 3, 18, "#8a5a2a", 1) + R(41, 38, 3, 18, "#8a5a2a", 1) + R(20, 36, 24, 3.500, "#a0703a", 1);
    b += C(28, 52, 2.500, "#ffd24a", "#7a4a08") + C(35, 53, 2, "#ffe58a", "#7a4a08") + (L > 3 ? R(46, 47, 12, 7, "#6a4a2a", 1.5) + C(49, 56, 2.500, "#3a3a44") + C(55, 56, 2.500, "#3a3a44") + C(52, 46, 3, "#ffd24a", "#7a4a08") : "") + (L > 6 ? flag(10, 46, "#ffd24a") : "") + (L > 9 ? P("M30 14l3-8 3 8z", "#ffd24a", "#7a4a08", 1) : "");
  } else if (key === "gem") {
    b = P("M4 56L14 34l12 6 12-10 14 12 8 14z", "#5a5a72") + P("M20 54L26 24l8 30z", "#5fd8ff", "#14506a") + P("M30 54l8-34 8 34z", "#9be8ff", "#14506a") + P("M42 54l6-18 8 18z", "#3aa8e0", "#14506a") + P("M26 24l3 12-3 18", "none", "#e8fbff", 1) + P("M38 20l3 16", "none", "#fff", 1);
    b += (L > 3 ? P("M10 54l4-12 4 12z", "#c58bff", "#3a1a6a") : "") + (L > 6 ? P("M52 54l3-10 3 10z", "#ff7aa8", "#6a1a3a") : "") + (L > 8 ? `<path d="M32 8l2 4 4 1-4 2-2 4-2-4-4-1 4-2z" fill="#fff" opacity=".9"/>` : "");
  } else if (key === "barracks") {
    b = R(10, 32, 44, 24, "#a8794a", 2) + P("M6 34L32 14l26 20z", "#a83a2a") + P("M6 34L32 14l8 6-30 16z", "#c8503a", "#1a1224", 0) + R(26, 40, 12, 16, "#3a2410", 2) + win(14, 40, 1) + win(46, 40, 1) + R(12, 52, 6, 4, "#d8d8e8", 1);
    b += flag(32, 14, "#3f7bff") + (L > 2 ? flag(10, 34, "#ffd24a") : "") + (L > 5 ? flag(54, 34, "#ffd24a") : "") + (L > 3 ? `<path d="M44 56l4-16M48 56l4-16" stroke="#cfd6e6" stroke-width="2"/>` : "") + (L > 6 ? R(2, 44, 6, 12, "#8a8a96", 1) + R(56, 44, 6, 12, "#8a8a96", 1) : "");
  } else if (key === "walls") {
    b = R(4, 34, 56, 22, "#a8a8b8", 1.5);
    for (let i = 0; i < 6; i++) b += R(4 + i * 10, 29, 6, 6, "#a8a8b8", 1);
    b += R(24, 14, 16, 42, "#b8b8c8", 1.5); for (let i = 0; i < 3; i++) b += R(23 + i * 6, 9, 4, 6, "#b8b8c8", 1); b += P("M28 56V44q4-6 8 0v12z", "#2a2030") + R(30, 22, 4, 7, "#1a1220", 1) + R(30, 34, 4, 5, "#1a1220", 1);
    b += flag(32, 9, "#e8453a") + (L > 3 ? flag(8, 29, "#e8453a") : "") + (L > 6 ? flag(56, 29, "#e8453a") : "") + (L > 8 ? `<path d="M4 44h56" stroke="#7a7a8a" stroke-width="1.200"/>` : "");
  } else if (key === "market") {
    b = R(8, 34, 48, 22, "#c8964a", 2);
    for (let i = 0; i < 6; i++) b += P(`M${6 + i * 8.7} 22h8.700l1.500 14h-11.700z`, i % 2 ? "#fff3d8" : "#e8453a", "#1a1224", 1);
    b += R(12, 44, 10, 8, "#8a5a2a", 1) + R(24, 46, 8, 6, "#a8703a", 1) + C(40, 48, 4, "#ffb347", "#7a4a08") + C(47, 49, 3, "#7bd88f", "#1a5a2a") + (L > 3 ? flag(56, 24, "#ffd24a") : "") + (L > 5 ? C(10, 28, 3, "#ffd24a", "#7a4a08") : "") + (L > 7 ? P("M4 22h56", "none", "#ffd24a", 1.5) : "");
  } else if (key === "academy") {
    b = R(8, 34, 48, 22, "#e8dcc0", 1.5) + P("M8 34L32 20l24 14z", "#d8c8a0");
    for (let i = 0; i < 4; i++) b += R(11 + i * 11, 36, 4.500, 20, "#f4ecd8", 1);
    b += `<path d="M20 20q12-18 24 0z" fill="#7a6ae8" stroke="#1a1224" stroke-width="1.500"/>` + C(32, 10, 2, "#ffd24a", "#7a4a08") + R(28, 44, 8, 12, "#3a2a64", 2) + (L > 2 ? C(32, 26, 3, "#ffd24a", "#7a4a08") : "") + (L > 5 ? flag(8, 34, "#c58bff") + flag(56, 34, "#c58bff") : "");
  } else if (key === "forge") {
    b = R(8, 32, 38, 24, "#8a6a4a", 2) + P("M4 34L27 18l23 16z", "#4a4a5c") + R(38, 12, 7, 20, "#6a6a7a", 1.5) + R(26, 40, 10, 16, "#1a1220", 2) + `<ellipse cx="31" cy="48" rx="4" ry="5" fill="#ff8a1a"/><ellipse cx="31" cy="49" rx="2" ry="3" fill="#ffe58a"/>`;
    b += R(48, 46, 12, 4, "#3a3a46", 1) + R(52, 50, 4, 6, "#3a3a46", 1) + `<circle cx="41" cy="8" r="3.500" fill="#cfd6e6" opacity=".7"/><circle cx="45" cy="3" r="2.500" fill="#cfd6e6" opacity=".5"/>` + (L > 3 ? win(12, 38, 1) : "") + (L > 6 ? flag(8, 32, "#ff8a1a") : "");
  } else {
    b = R(6, 38, 52, 18, "#e8dcc0", 1.5) + P("M2 38L32 14l30 24z", "#ffd24a", "#7a4a08") + P("M2 38L32 14l10 8-34 16z", "#fff0a0", "#7a4a08", 0);
    for (let i = 0; i < 5; i++) b += R(9 + i * 10, 40, 4, 16, "#f4ecd8", 1);
    b += R(26, 44, 12, 12, "#3a8a4a", 2) + flag(32, 14, "#7bd88f") + (L > 2 ? flag(6, 38, "#ffd24a") + flag(58, 38, "#ffd24a") : "") + (L > 4 ? C(32, 28, 4, "#7bd88f", "#14602e") : "");
  }
  return `<svg class="bld" viewBox="0 0 64 64" aria-hidden="true">${ground}${b}</svg>`;
}
export const citySkyline = (levels, order) => `<div class="city">${order.map((k, i) => `<div class="cb" style="--d:${i}">${bldSVG(k, levels[k] || 0 || 1)}<span>${levels[k] || 0}</span></div>`).join("")}</div>`;
