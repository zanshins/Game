// موتور صدا: موسیقی مولّد برای هر مپ + جلوه‌های صوتی — همه با Web Audio و بدون فایل صوتی
const AC = typeof window !== "undefined" ? window.AudioContext || window.webkitAudioContext : null;
const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);
const rnd = (seed) => { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; };

// ---------- زیرساخت ----------
function makeIR(c, dur, decay) {
  const len = Math.floor(c.sampleRate * dur), b = c.createBuffer(2, len, c.sampleRate), r = rnd(7);
  for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (r() * 2 - 1) * Math.pow(1 - i / len, decay); }
  return b;
}
function makeRig(ctx, dest) {
  const comp = ctx.createDynamicsCompressor();
  comp.threshold.value = -18; comp.knee.value = 20; comp.ratio.value = 6; comp.attack.value = 0.004; comp.release.value = 0.22;
  const master = ctx.createGain(); master.gain.value = 0.62; master.connect(comp);
  const sat = ctx.createWaveShaper(), cv = new Float32Array(2048); for (let i = 0; i < 2048; i++) { const x = (i / 1023.5) - 1; cv[i] = Math.tanh(x * 1.2) / Math.tanh(1.2) * 0.97; } sat.curve = cv; comp.connect(sat); sat.connect(dest || ctx.destination);
  const music = ctx.createGain(), sfx = ctx.createGain(); music.connect(master); sfx.connect(master);
  const conv = ctx.createConvolver(); conv.buffer = makeIR(ctx, 1.3, 2.8);
  const rev = ctx.createGain(); rev.connect(conv); const revRet = ctx.createGain(); revRet.gain.value = 0.5; conv.connect(revRet); revRet.connect(master);
  const dIn = ctx.createGain(), dly = ctx.createDelay(1.5), fb = ctx.createGain(), dlp = ctx.createBiquadFilter(), dOut = ctx.createGain();
  dly.delayTime.value = 0.33; fb.gain.value = 0.3; dlp.type = "lowpass"; dlp.frequency.value = 2400; dOut.gain.value = 0.45;
  dIn.connect(dly); dly.connect(dlp); dlp.connect(fb); fb.connect(dly); dlp.connect(dOut); dOut.connect(music);
  const nb = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate), nd = nb.getChannelData(0), r = rnd(99);
  for (let i = 0; i < nd.length; i++) nd[i] = r() * 2 - 1;
  return { ctx, master, music, sfx, rev, dIn, dly, noise: nb, live: 0, voices: 0, q: null };
}
function outChain(R, g, o) {
  let n = g;
  if (o.pan && R.ctx.createStereoPanner) { const p = R.ctx.createStereoPanner(); p.pan.value = Math.max(-1, Math.min(1, o.pan)); n.connect(p); n = p; }
  n.connect(o.dest || R.music);
  if (o.send) { const s = R.ctx.createGain(); s.gain.value = o.send; n.connect(s); s.connect(R.rev); }
  if (o.dsend) { const s = R.ctx.createGain(); s.gain.value = o.dsend; n.connect(s); s.connect(R.dIn); }
  return n;
}
function envelope(g, t, o, dur) {
  const v = o.vol, a = o.a ?? 0.01, rel = o.rel ?? 0.1;
  g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + a);
  if (o.d) g.gain.exponentialRampToValueAtTime(Math.max(0.0001, v * (o.s ?? 0.0001)), t + a + o.d);
  g.gain.setValueAtTime(Math.max(0.0001, o.d ? v * (o.s ?? 0.0001) : v), Math.max(t + a + (o.d || 0), t + dur));
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur + rel);
  return t + dur + rel + 0.05;
}
function tone(R, o) {
  if (R.q) { R.q.push({ t: o.t, f: () => tone(R, o) }); return; }
  if (R.voices > 40 && (o.vol || 0) < 0.12) return;
  const c = R.ctx, t = Math.max(0.0001, o.t), dur = o.dur, g = c.createGain(), end = envelope(g, t, o, dur);
  let head = g;
  if (o.lp) { const f = c.createBiquadFilter(); f.type = "lowpass"; f.Q.value = o.lq ?? 0.7; f.frequency.setValueAtTime(o.lp[0], t); if (o.lp[1] !== o.lp[0]) f.frequency.exponentialRampToValueAtTime(o.lp[1], t + (o.lp[2] ?? dur)); f.connect(g); head = f; }
  if (o.bp) { const f = c.createBiquadFilter(); f.type = "bandpass"; f.frequency.value = o.bp; f.Q.value = o.bq ?? 3; f.connect(head); head = f; }
  const parts = o.parts || [{ r: 1, v: 1, type: o.type || "sine" }], oscs = [];
  for (const p of parts) {
    const layers = o.det ? [-o.det, o.det] : [0];
    for (const dt of layers) {
      const os = c.createOscillator(), pg = c.createGain(); os.type = p.type || o.type || "sine";
      const f1 = o.f * p.r; os.detune.value = dt;
      if (o.f2) { os.frequency.setValueAtTime(f1, t); os.frequency.exponentialRampToValueAtTime(Math.max(10, o.f2 * p.r), t + (o.sw ?? dur)); } else os.frequency.value = f1;
      if (o.bend) { os.detune.setValueAtTime(dt + o.bend, t); os.detune.linearRampToValueAtTime(dt, t + (o.bendT ?? 0.08)); }
      pg.gain.value = (p.v ?? 1) / layers.length; os.connect(pg); pg.connect(head);
      if (p.dec) { pg.gain.setValueAtTime(p.v / layers.length, t); pg.gain.exponentialRampToValueAtTime(0.0001, t + p.dec); }
      os.start(t); os.stop(end); oscs.push(os); R.voices++; os.onended = () => { R.voices--; };
    }
  }
  if (o.vib && oscs.length) {
    const l = c.createOscillator(), lg = c.createGain(); l.frequency.value = o.vib[0]; lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(o.vib[1], t + (o.vib[2] ?? 0.2)); l.connect(lg);
    for (const os of oscs) lg.connect(os.detune); l.start(t); l.stop(end);
  }
  const out = outChain(R, g, o); const last = oscs[oscs.length - 1];
  if (last) { const prev = last.onended; last.onended = () => { if (prev) prev(); try { out.disconnect(); g.disconnect(); } catch (e) { /* */ } }; }
}
function noiseHit(R, o) {
  if (R.q) { R.q.push({ t: o.t, f: () => noiseHit(R, o) }); return; }
  if (R.voices > 40 && o.vol < 0.2) return;
  const c = R.ctx, t = Math.max(0.0001, o.t), g = c.createGain(), dur = o.dur, end = envelope(g, t, { vol: o.vol, a: o.a ?? 0.003, rel: o.rel ?? 0.03, d: o.d, s: o.s }, dur);
  const s = c.createBufferSource(); s.buffer = R.noise; s.loop = true; const f = c.createBiquadFilter(); f.type = o.ft || "bandpass"; f.Q.value = o.q ?? 1;
  f.frequency.setValueAtTime(o.f || 2000, t); if (o.f2) f.frequency.exponentialRampToValueAtTime(o.f2, t + dur);
  s.connect(f); f.connect(g); s.start(t, Math.random() * 1.5); s.stop(end); R.voices++;
  const out = outChain(R, g, o); s.onended = () => { R.voices--; try { out.disconnect(); g.disconnect(); } catch (e) { /* */ } };
}

// ---------- ابزارهای طبل ----------
const D = {
  kick: (R, t, v, o) => { tone(R, { ...o, t, f: 150, f2: 42, sw: 0.12, dur: 0.18, vol: 0.9 * v, a: 0.002, rel: 0.12, type: "sine" }); noiseHit(R, { ...o, t, dur: 0.02, vol: 0.18 * v, f: 1800, q: 0.7 }); },
  snare: (R, t, v, o) => { noiseHit(R, { ...o, t, dur: 0.16, vol: 0.4 * v, f: 2200, f2: 1400, q: 0.8, rel: 0.08 }); tone(R, { ...o, t, f: 220, f2: 150, sw: 0.08, dur: 0.1, vol: 0.28 * v, type: "triangle" }); },
  hat: (R, t, v, o) => noiseHit(R, { ...o, t, dur: 0.035, vol: 0.14 * v, ft: "highpass", f: 7500, q: 0.5 }),
  ohat: (R, t, v, o) => noiseHit(R, { ...o, t, dur: 0.18, vol: 0.12 * v, ft: "highpass", f: 6500, q: 0.5, rel: 0.1 }),
  taiko: (R, t, v, o) => { tone(R, { ...o, t, f: 110, f2: 52, sw: 0.25, dur: 0.35, vol: 1 * v, a: 0.003, rel: 0.4, type: "sine", send: 0.25 }); noiseHit(R, { ...o, t, dur: 0.05, vol: 0.22 * v, f: 900, q: 0.6 }); },
  tom: (R, t, v, o) => tone(R, { ...o, t, f: 190, f2: 100, sw: 0.14, dur: 0.14, vol: 0.55 * v, rel: 0.12, type: "sine", send: 0.15 }),
  dum: (R, t, v, o) => { tone(R, { ...o, t, f: 140, f2: 85, sw: 0.1, dur: 0.14, vol: 0.8 * v, rel: 0.18, type: "sine", send: 0.2 }); noiseHit(R, { ...o, t, dur: 0.03, vol: 0.12 * v, f: 700 }); },
  tak: (R, t, v, o) => { noiseHit(R, { ...o, t, dur: 0.05, vol: 0.28 * v, f: 3200, q: 2, rel: 0.04 }); tone(R, { ...o, t, f: 520, f2: 420, sw: 0.04, dur: 0.05, vol: 0.12 * v, type: "triangle" }); },
  jing: (R, t, v, o) => noiseHit(R, { ...o, t, dur: 0.12, vol: 0.1 * v, ft: "highpass", f: 5200, q: 6, rel: 0.12 }),
  clap: (R, t, v, o) => { for (let i = 0; i < 3; i++) noiseHit(R, { ...o, t: t + i * 0.011, dur: 0.03, vol: 0.2 * v, f: 1500, q: 1.2 }); noiseHit(R, { ...o, t: t + 0.033, dur: 0.12, vol: 0.14 * v, f: 1300, q: 1, rel: 0.1 }); },
  clank: (R, t, v, o) => tone(R, { ...o, t, f: 640, dur: 0.1, vol: 0.12 * v, rel: 0.15, parts: [{ r: 1, v: 1, type: "square" }, { r: 1.48, v: 0.7, type: "square" }, { r: 2.17, v: 0.5, type: "sine" }], lp: [5000, 1200, 0.2] }),
  impact: (R, t, v, o) => { noiseHit(R, { ...o, t, dur: 0.9, vol: 0.5 * v, ft: "lowpass", f: 1800, f2: 80, q: 0.5, rel: 0.4, send: 0.5 }); tone(R, { ...o, t, f: 80, f2: 30, sw: 0.6, dur: 0.8, vol: 0.8 * v, rel: 0.4 }); },
};

// ---------- سازها ----------
const I = {
  pluck: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: Math.min(d, 0.5), vol: 0.2 * v, a: 0.004, d: 0.35, s: 0.0001, rel: 0.1, type: "sawtooth", det: 6, lp: [3200, 500, 0.3], send: 0.18, dsend: 0.12 }),
  flute: (R, t, m, d, v, o) => { tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.2 * v, a: 0.07, rel: 0.18, parts: [{ r: 1, v: 1, type: "sine" }, { r: 2, v: 0.18, type: "triangle" }], vib: [5.2, 9, 0.25], send: 0.3, dsend: 0.15 }); noiseHit(R, { ...o, t, dur: Math.min(d, 0.18), vol: 0.035 * v, f: mtof(m) * 2, q: 4, a: 0.04 }); },
  marimba: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: 0.3, vol: 0.28 * v, a: 0.002, d: 0.25, s: 0.0001, rel: 0.08, parts: [{ r: 1, v: 1, type: "sine" }, { r: 4, v: 0.35, type: "sine", dec: 0.07 }, { r: 10, v: 0.08, type: "sine", dec: 0.03 }], send: 0.2, dsend: 0.12 }),
  bell: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: 0.5, vol: 0.17 * v, a: 0.003, d: 1.2, s: 0.0001, rel: 0.7, parts: [{ r: 1, v: 1, type: "sine" }, { r: 2.76, v: 0.35, type: "sine", dec: 0.5 }, { r: 5.4, v: 0.15, type: "sine", dec: 0.25 }], send: 0.5, dsend: 0.25 }),
  pad: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.075 * v, a: Math.min(0.9, d * 0.35), rel: 0.9, type: "sawtooth", det: 9, lp: [500, 1500, d], send: 0.45 }),
  glass: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.085 * v, a: Math.min(1, d * 0.4), rel: 1, parts: [{ r: 1, v: 1, type: "sine" }, { r: 2, v: 0.4, type: "triangle" }, { r: 3.01, v: 0.12, type: "sine" }], det: 5, vib: [0.4, 6, 0.5], send: 0.6, dsend: 0.1 }),
  choir: (R, t, m, d, v, o) => { for (const fq of [650, 1100]) tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.06 * v, a: Math.min(0.8, d * 0.4), rel: 0.9, type: "sawtooth", det: 7, bp: fq, bq: 5, vib: [5, 7, 0.6], send: 0.55 }); },
  strings: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.085 * v, a: Math.min(0.5, d * 0.3), rel: 0.5, type: "sawtooth", det: 11, lp: [1500, 2800, d], vib: [5, 7, 0.4], send: 0.4 }),
  brass: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.14 * v, a: 0.07, rel: 0.2, type: "sawtooth", det: 5, lp: [500, 2400, 0.14], lq: 1.2, vib: [5, 6, 0.3], send: 0.3, dsend: 0.1 }),
  oud: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: Math.min(d, 0.6), vol: 0.25 * v, a: 0.003, d: 0.45, s: 0.0001, rel: 0.1, parts: [{ r: 1, v: 1, type: "triangle" }, { r: 2, v: 0.25, type: "sawtooth" }], lp: [2600, 600, 0.35], bend: 35, bendT: 0.05, send: 0.22, dsend: 0.14 }),
  ney: (R, t, m, d, v, o) => { tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.2 * v, a: 0.09, rel: 0.2, parts: [{ r: 1, v: 1, type: "sine" }, { r: 3, v: 0.12, type: "sine" }], vib: [4.6, 14, 0.3], send: 0.35, dsend: 0.2 }); noiseHit(R, { ...o, t, dur: Math.min(d, 0.3), vol: 0.06 * v, f: mtof(m) * 1.5, q: 3, a: 0.06 }); },
  santur: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: 0.35, vol: 0.2 * v, a: 0.002, d: 0.6, s: 0.0001, rel: 0.2, parts: [{ r: 1, v: 1, type: "triangle" }, { r: 1.003, v: 0.7, type: "triangle" }, { r: 3, v: 0.15, type: "sine", dec: 0.1 }], send: 0.45, dsend: 0.2 }),
  slead: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.13 * v, a: 0.03, rel: 0.15, parts: [{ r: 1, v: 1, type: "sawtooth" }, { r: 1.005, v: 0.6, type: "square" }], lp: [1200, 3200, 0.2], vib: [5.5, 8, 0.3], send: 0.3, dsend: 0.2 }),
  theremin: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.14 * v, a: 0.15, rel: 0.3, type: "sine", bend: -90, bendT: 0.25, vib: [6.2, 20, 0.4], send: 0.5, dsend: 0.3 }),
  metal: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: 0.4, vol: 0.14 * v, a: 0.002, d: 0.9, s: 0.0001, rel: 0.5, parts: [{ r: 1, v: 1, type: "sine" }, { r: 1.41, v: 0.6, type: "sine", dec: 0.7 }, { r: 3.14, v: 0.3, type: "sine", dec: 0.3 }, { r: 4.07, v: 0.15, type: "square", dec: 0.12 }], send: 0.5, dsend: 0.3 }),
  bsaw: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.3 * v, a: 0.008, d: d * 0.8, s: 0.45, rel: 0.06, type: "sawtooth", lp: [900, 220, 0.2], lq: 2 }),
  bsine: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.4 * v, a: 0.01, rel: 0.12, parts: [{ r: 1, v: 1, type: "sine" }, { r: 2, v: 0.2, type: "triangle" }] }),
  bsq: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.2 * v, a: 0.004, d: 0.12, s: 0.35, rel: 0.05, type: "square", lp: [1800, 250, 0.12], lq: 4 }),
  pulse: (R, t, m, d, v, o) => tone(R, { ...o, t, f: mtof(m), dur: d, vol: 0.14 * v, a: 0.003, d: 0.12, s: 0.3, rel: 0.04, type: "sawtooth", lp: [2400, 300, 0.14], lq: 6, dsend: 0.2 }),
};

// ---------- تعریف قطعه‌ها ----------
const KICKS = ["x...x...x...x...", "x.....x...x.....", "x..x..x...x..x..", "x.......x.x....."];
const TRACKS = {
  menu: { root: 48, scale: [0, 2, 3, 5, 7, 8, 10], mask: [0, 1, 2, 4, 5], bpm: 96, prog: [0, 5, 2, 6, 0, 5, 3, 6], seed: 101, pad: "strings", bass: "bsaw", bassPat: [[0, 0, 3], [4, 0, 3], [8, 0, 3], [12, 2, 3]], arp: "pluck", arpPat: [0, 1, 2, 3, 2, 1, 2, 3], lead: "brass", rhy: "calm", drone: true,
    dr: { kick: KICKS[0], snare: "....x.......x...", hat: "x.x.x.x.x.x.x.x.", perc: "x.......x.......", pk: "taiko" }, tpl: "swell" },
  kingdom: { root: 53, scale: [0, 2, 4, 5, 7, 9, 11], mask: [0, 1, 2, 4, 5], bpm: 84, prog: [0, 3, 4, 0, 5, 3, 1, 4], seed: 202, pad: "glass", bass: "bsine", bassPat: [[0, 0, 6], [8, 2, 6]], arp: "santur", arpPat: [0, 2, 1, 3, 2, 1, 3, 2], lead: "flute", rhy: "calm", drone: false,
    dr: { kick: "x.......x.......", snare: "................", hat: "..x...x...x...x.", perc: "x..x..x.x..x..x.", pk: "daf" }, tpl: "soft" },
  attack: { root: 41, scale: [0, 1, 3, 5, 7, 8, 10], mask: [0, 1, 2, 3, 4], bpm: 120, prog: [0, 0, 1, 0, 5, 0, 1, 4], seed: 303, pad: "strings", bass: "bsaw", bassPat: [[0, 0, 1.5], [2, 0, 1.5], [4, 0, 1.5], [6, 0, 1.5], [8, 0, 1.5], [10, 0, 1.5], [12, 2, 1.5], [14, 0, 1.5]], arp: "pulse", arpPat: [0, 0, 2, 0, 3, 0, 2, 0], lead: "brass", rhy: "drive", drone: true,
    dr: { kick: "x...x...x...x...", snare: "x.x.x.x.xxxxxxxx", hat: "x.x.x.x.x.x.x.x.", perc: "x.......x.......", pk: "taiko" }, tpl: "war" },
  raid: { root: 45, scale: [0, 2, 3, 5, 7, 8, 10], mask: [0, 2, 3, 4, 6], bpm: 132, prog: [0, 0, 5, 0, 6, 0, 3, 4], seed: 404, pad: "choir", bass: "bsq", bassPat: [[0, 0, 1], [1, 0, 1], [2, 0, 1], [3, 0, 1], [4, 0, 1], [5, 0, 1], [6, 0, 1], [7, 0, 1], [8, 0, 1], [9, 0, 1], [10, 0, 1], [11, 0, 1], [12, 2, 1], [13, 2, 1], [14, 0, 1], [15, 0, 1]], arp: "pulse", arpPat: [0, 2, 3, 2], lead: "slead", rhy: "drive", drone: true,
    dr: { kick: "x..x..x.x..x..x.", snare: "....x.......x...", hat: "xxxxxxxxxxxxxxxx", perc: "x.......x.......", pk: "tom" }, tpl: "tense" },
  map1: { root: 50, scale: [0, 2, 4, 5, 7, 9, 11], mask: [0, 1, 2, 4, 5], bpm: 104, prog: [0, 4, 5, 3, 0, 4, 3, 4], seed: 11, pad: "pad", bass: "bsine", bassPat: [[0, 0, 3], [4, 2, 3], [8, 0, 3], [12, 2, 3]], arp: "pluck", arpPat: [0, 1, 2, 1, 3, 2, 1, 2], lead: "flute", rhy: "calm", drone: false,
    dr: { kick: KICKS[0], snare: "................", hat: "x.x.x.x.x.x.x.x.", perc: "....x.......x...", pk: "clap" }, tpl: "soft" },
  map2: { root: 45, scale: [0, 2, 3, 5, 7, 9, 10], mask: [0, 1, 2, 4, 6], bpm: 88, prog: [0, 3, 6, 4, 0, 3, 1, 4], seed: 22, pad: "glass", bass: "bsine", bassPat: [[0, 0, 5], [8, 4, 3], [12, 2, 3]], arp: "marimba", arpPat: [0, 2, 1, 3, 1, 2, 3, 1], lead: "bell", rhy: "sparse", drone: false,
    dr: { kick: "x.......x...x...", snare: "................", hat: "..x...x...x...x.", perc: "...x.....x.x....", pk: "tom" }, tpl: "mystic" },
  map3: { root: 50, scale: [0, 1, 4, 5, 7, 8, 10], mask: [0, 1, 2, 3, 4, 5], bpm: 112, prog: [0, 0, 1, 0, 0, 3, 1, 0], seed: 33, pad: "strings", bass: "bsaw", bassPat: [[0, 0, 2], [3, 0, 1], [6, 0, 2], [8, 0, 2], [11, 2, 1], [14, 0, 2]], arp: "oud", arpPat: [0, 1, 2, 1, 0, 2, 1, 3], lead: "ney", rhy: "calm", drone: true, orn: true,
    dr: { kick: "x.......x.x.....", snare: "................", hat: "x.x.x.x.x.x.x.x.", perc: "D..t.tD.t.D.tt..", pk: "daf" }, tpl: "desert" },
  map4: { root: 52, scale: [0, 2, 4, 6, 7, 9, 11], mask: [0, 1, 2, 4, 6], bpm: 76, prog: [0, 1, 0, 4, 5, 1, 0, 4], seed: 44, pad: "choir", bass: "bsine", bassPat: [[0, 0, 8], [8, 4, 8]], arp: "bell", arpPat: [0, 2, 3, 2, 1, 3, 2, 1], lead: "bell", rhy: "sparse", drone: false,
    dr: { kick: "x...............", snare: "................", hat: "......x.......x.", perc: "........x.......", pk: "tom" }, tpl: "ice" },
  map5: { root: 43, scale: [0, 1, 3, 6, 7, 8, 11], mask: [0, 1, 3, 4, 6], bpm: 92, prog: [0, 1, 0, 3, 0, 5, 3, 1], seed: 55, pad: "glass", bass: "bsq", bassPat: [[0, 0, 1], [3, 1, 1], [6, 0, 1], [7, 3, 1], [10, 0, 1], [12, 4, 1], [14, 3, 1]], arp: "pulse", arpPat: [0, 3, 1, 2, 3, 0, 2, 1], lead: "theremin", rhy: "sparse", drone: true,
    dr: { kick: "x..x....x.....x.", snare: "....x.......x..x", hat: "..x..x..x..x..x.", perc: ".x...x.x...x....", pk: "clank" }, tpl: "swamp" },
  map6: { root: 40, scale: [0, 2, 3, 5, 7, 8, 11], mask: [0, 2, 3, 4, 6], bpm: 128, prog: [0, 5, 3, 4, 0, 5, 6, 4], seed: 66, pad: "strings", bass: "bsaw", bassPat: [[0, 0, 1], [2, 0, 1], [3, 0, 1], [4, 0, 1], [6, 0, 1], [8, 0, 1], [10, 0, 1], [11, 0, 1], [12, 2, 1], [14, 0, 1]], arp: "pulse", arpPat: [0, 0, 2, 0, 3, 2, 0, 2], lead: "brass", rhy: "drive", drone: true,
    dr: { kick: "x..x..x.x..x..x.", snare: "....x.......x...", hat: "x.x.x.x.x.x.x.xx", perc: "x...x..x..x.x...", pk: "taiko" }, tpl: "volcano" },
  map7: { root: 55, scale: [0, 2, 4, 6, 7, 9, 11], mask: [0, 1, 2, 4, 5], bpm: 118, prog: [0, 4, 5, 3, 0, 4, 1, 4], seed: 77, pad: "strings", bass: "bsine", bassPat: [[0, 0, 3], [4, 0, 3], [8, 2, 3], [12, 2, 3]], arp: "marimba", arpPat: [0, 1, 2, 3, 2, 3, 1, 2], lead: "slead", rhy: "drive", drone: false,
    dr: { kick: "x...x...x...x...", snare: "....x.......x...", hat: "x.xxx.xxx.xxx.xx", perc: "......x.......x.", pk: "clap" }, tpl: "sky" },
  map8: { root: 38, scale: [0, 2, 4, 6, 8, 10], mask: [0, 1, 2, 3, 4], bpm: 100, prog: [0, 2, 4, 1, 3, 5, 2, 4], seed: 88, pad: "choir", bass: "bsaw", bassPat: [[0, 0, 2], [4, 0, 2], [8, 0, 2], [12, 3, 2]], arp: "pulse", arpPat: [0, 2, 1, 3, 0, 3, 2, 1], lead: "metal", rhy: "sparse", drone: true,
    dr: { kick: "x...x...x..x....", snare: "........x.......", hat: "x.x.x.x.x.x.xxxx", perc: "x.....x...x.....", pk: "clank" }, tpl: "void" },
};
const RHY = {
  calm: ["x.......x.x.....", "x...x.x.x.......", "x.x.x...x.......", "x.....x.x.x....."],
  drive: ["x.x.x.x.x.x.x.xx", "x.xx.x.xx.x.x...", "x..x..x.x..x.x.x", "x.x...x.x.x.xx.."],
  sparse: ["x...............", "x.......x.......", "....x.......x...", "x.......x.x....."],
};

// ---------- مولد ملودی و میزان ----------
const nd = (T, d) => { const L = T.scale.length, o = Math.floor(d / L), i = ((d % L) + L) % L; return T.root + T.scale[i] + 12 * o; };
const chordOf = (T, r) => [nd(T, r), nd(T, r + 2), nd(T, r + 4), nd(T, r + 7)];
function melBar(T, seed, b, croot, reg) {
  const r = rnd(seed * 131 + b * 17), tpl = RHY[T.rhy][Math.floor(r() * 4)], notes = [], L = T.mask.length;
  let pos = Math.floor(r() * L) + (b % 2 ? 1 : 0);
  const onsets = []; for (let s = 0; s < 16; s++) if (tpl[s] === "x") onsets.push(s);
  onsets.forEach((s, k) => {
    const strong = s % 4 === 0;
    if (strong && r() < 0.65) { const tgt = (croot + (r() < 0.5 ? 2 : 0)) % T.scale.length; let best = pos, bd = 99; for (let q = pos - 3; q <= pos + 3; q++) { const idx = ((q % L) + L) % L; const d = Math.abs(T.mask[idx] - tgt) % T.scale.length; if (d < bd) { bd = d; best = q; } } pos = best; }
    else pos += Math.floor(r() * 5) - 2;
    pos = Math.max(-2, Math.min(L + 2, pos));
    const o = Math.floor(pos / L), idx = ((pos % L) + L) % L;
    const next = onsets[k + 1] ?? 16;
    notes.push({ s, m: nd(T, T.mask[idx] + o * T.scale.length) + 12 + reg, len: Math.min(next - s, 8) });
  });
  return notes;
}
function scheduleBar(R, dest, T, bar, t0, inten) {
  const stepD = 60 / T.bpm / 4, barD = stepD * 16, ph = Math.floor(bar / 8), bi = bar % 8, variant = ph % 4;
  const root = T.prog[bi % T.prog.length], ch = chordOf(T, root), o = { dest };
  const swing = T.swing || 0, st = (s) => t0 + s * stepD + (s % 2 ? swing * stepD : 0);
  // لایه‌ی پایه: پد و درون
  const padI = I[T.pad]; for (const n of ch.slice(0, 3)) padI(R, t0, n + (T.pad === "choir" || T.pad === "glass" ? 12 : 0), barD * 1.02, 0.8 + 0.3 * inten, o);
  if (T.drone) { I.bsine(R, t0, T.root - 12, barD, 0.5, o); I.pad(R, t0, T.root, barD, 0.4, o); I.pad(R, t0, T.root + 7, barD, 0.3, o); }
  // بیس
  if (inten >= 0.15) for (const [s, tn, len] of T.bassPat) I[T.bass](R, st(s), ch[Math.min(tn, 3)] - 12, len * stepD * 0.95, 0.8 + 0.3 * inten, o);
  // آرپژ
  if (inten >= 0.3) { const dens = inten > 0.6 ? 1 : 2, sw = T.arp === "oud" || T.arp === "santur" ? 1 : 1; for (let s = 0; s < 16; s += dens) { const idx = T.arpPat[(s / dens) % T.arpPat.length | 0], n = ch[idx % 4] + (idx > 3 ? 12 : 0) + 12; I[T.arp](R, st(s), n + (T.arp === "pulse" ? 0 : 0), stepD * 1.4, 0.5 + 0.4 * inten, { dest, pan: ((s % 4) - 1.5) * 0.18 }); } void sw; }
  // طبل
  const dr = T.dr, pat = (p, f, thr, v = 1) => { if (inten < thr) return; for (let s = 0; s < 16; s++) { const c = p[s]; if (c && c !== ".") f(st(s), c === "x" || c === "D" ? v : 0.6 * v, c); } };
  pat(dr.kick, (t, v) => D.kick(R, t, v, o), 0.4); pat(dr.hat, (t, v) => D.hat(R, t, v * (0.5 + 0.5 * inten), { dest, pan: 0.3 }), 0.35, 0.8);
  pat(dr.snare, (t, v) => D.snare(R, t, v, o), 0.55);
  const pk = D[dr.pk] || D.tom;
  pat(dr.perc, (t, v, c) => { if (dr.pk === "daf") (c === "D" ? D.dum : D.tak)(R, t, v, o); else pk(R, t, v, o); }, dr.pk === "daf" ? 0.2 : 0.5);
  if (dr.pk === "daf" && inten >= 0.2) for (let s = 2; s < 16; s += 4) D.jing(R, st(s), 0.8, { dest, pan: -0.3 });
  if (inten >= 0.85 && bi % 4 === 3) for (let s = 12; s < 16; s++) D.tom(R, st(s), 0.5 + (s - 12) * 0.12, o);
  if (bi === 0 && ph > 0 && inten >= 0.5) D.impact(R, t0, 0.5, o);
  // ملودی
  if (inten >= 0.25) {
    const reg = variant === 2 ? 5 : 0, seedA = T.seed + (variant === 2 ? 77 : 0) + (variant === 1 && bi >= 6 ? 31 : 0), cr = root;
    if (!(bi === 3 && variant !== 2) || inten > 0.8) {
      const notes = melBar(T, seedA, bi, cr, reg + (variant === 3 && bi >= 4 ? 7 : 0)), L = I[T.lead];
      notes.forEach((n, k) => {
        if (T.orn && k % 2 === 0 && n.len >= 2) { const gm = n.m + 1; I.oud(R, st(n.s) - 0.07, gm, 0.06, 0.4, { dest, pan: 0.15 }); }
        L(R, st(n.s), n.m, Math.max(0.12, n.len * stepD * 0.95), 0.8 + 0.3 * inten, { dest, pan: 0.1 });
        if (inten > 0.7 && (T.lead === "bell" || T.lead === "metal") && k % 2 === 0) I.bell(R, st(n.s), n.m + 12, 0.3, 0.4, { dest, pan: -0.25 });
      });
    }
  }
  if (inten >= 0.85) for (const n of ch.slice(0, 2)) I.brass(R, t0, n + 12, barD * 0.9, 0.35, { dest });
}
const barDur = (T) => (60 / T.bpm) * 4;

// ---------- موتور زنده ----------
let ctx = null, R = null, cur = null, want = null, wantOpts = null, musicVol = 0.7, sfxVol = 0.85, inten = 0.5, tick = null, duckT = 0;
const lastSfx = {};
const applyVol = () => { if (!R) return; const t = ctx.currentTime; R.music.gain.setTargetAtTime(musicVol * 0.6, t, 0.05); R.sfx.gain.setTargetAtTime(sfxVol, t, 0.05); };
function loop() {
  if (!cur || !ctx) return;
  if (ctx.state !== "running") return;
  const now = ctx.currentTime;
  if (cur.nextT < now - 0.4) { cur.nextT = now + 0.1; cur.q.length = 0; }
  // تولید بار بعدی فقط به‌صورت لیست رویداد (بدون ساخت نود)؛ اجرای رویدادها تدریجی و جلوتر از زمان
  let added = false;
  while (cur.nextT < now + 2.4) { R.q = cur.q; try { scheduleBar(R, cur.dest, cur.trk, cur.bar, cur.nextT, inten); } finally { R.q = null; } cur.nextT += barDur(cur.trk); cur.bar++; added = true; }
  if (added) cur.q.sort((a, b) => a.t - b.t);
  let n = 0; const q = cur.q;
  while (q.length && q[0].t < now + 1.1 && n < 22) { const ev = q.shift(); n++; if (ev.t < now - 0.3) continue; ev.f(); }
}
export const Sound = {
  init() {
    if (!AC) return; if (!ctx) { try { ctx = new AC({ latencyHint: "playback" }); } catch (e) { ctx = new AC(); } R = makeRig(ctx); applyVol(); tick = setInterval(loop, 50); if (want) this.playMusic(want, wantOpts); }
    if (ctx.state === "suspended") ctx.resume();
  },
  unlock() { this.init(); },
  setMusicVolume(v) { musicVol = v; applyVol(); }, setSfxVolume(v) { sfxVol = v; applyVol(); },
  setIntensity(x) { inten = Math.max(0, Math.min(1, x)); },
  playMusic(id, opts = {}) {
    wantOpts = opts; if (opts.intensity != null) inten = opts.intensity;
    if (cur && cur.id === id && want === id) return; want = id;
    if (!R) return; const T = TRACKS[id]; if (!T) return; const now = ctx.currentTime;
    if (cur) { const old = cur; old.dest.gain.cancelScheduledValues(now); old.dest.gain.setValueAtTime(old.dest.gain.value, now); old.dest.gain.linearRampToValueAtTime(0, now + 1.2); setTimeout(() => { try { old.dest.disconnect(); } catch (e) { /* */ } }, 1800); }
    const dest = ctx.createGain(); dest.gain.setValueAtTime(0, now); dest.gain.linearRampToValueAtTime(1, now + 1.2); dest.connect(R.music);
    R.dly.delayTime.setTargetAtTime((60 / T.bpm) * 0.75, now, 0.2);
    cur = { id, trk: T, dest, bar: 0, nextT: now + 0.12, q: [] }; loop();
  },
  stopMusic(fade = 1) { want = null; if (!cur) return; const old = cur, now = ctx.currentTime; cur = null; old.dest.gain.cancelScheduledValues(now); old.dest.gain.setValueAtTime(old.dest.gain.value, now); old.dest.gain.linearRampToValueAtTime(0, now + fade); setTimeout(() => { try { old.dest.disconnect(); } catch (e) { /* */ } }, fade * 1000 + 600); },
  pause() { if (ctx && ctx.state === "running") ctx.suspend(); }, resume() { if (ctx && ctx.state === "suspended") ctx.resume(); },
  jingle(name) {
    if (!R) return; const t = ctx.currentTime + 0.05, J = JINGLES[name]; if (!J) return;
    const now = ctx.currentTime; R.music.gain.cancelScheduledValues(now); R.music.gain.setTargetAtTime(musicVol * 0.15, now, 0.05); R.music.gain.setTargetAtTime(musicVol * 0.6, now + J.len + 0.4, 0.4);
    const o = { dest: R.sfx }; for (const [m, b, l, ins] of J.n) I[ins || J.ins](R, t + b * J.beat, m, l * J.beat, 1, o);
  },
  sfx(name, opts = {}) {
    if (!R || ctx.state !== "running") return; const f = SFX[name]; if (!f) return; const now = ctx.currentTime, cd = (CD[name] ?? 0.05);
    if (lastSfx[name] && now - lastSfx[name] < cd) return; if (R.live > 16) return; lastSfx[name] = now; R.live++; setTimeout(() => { R.live--; }, 350);
    f(R, now + 0.005, { dest: R.sfx, pan: opts.pan || 0, v: opts.vol ?? 1, r: opts.rate ?? 1 });
  },
  async renderOffline(id, seconds = 20, intensity = 0.5) {
    const sr = 44100, oc = new OfflineAudioContext(2, sr * seconds, sr), rig = makeRig(oc), T = TRACKS[id], dest = oc.createGain(); dest.connect(rig.music);
    rig.dly.delayTime.value = (60 / T.bpm) * 0.75; for (let b = 0, t = 0; t < seconds; b++, t += barDur(T)) scheduleBar(rig, dest, T, b, t, intensity);
    return oc.startRendering();
  },
  async renderSfxOffline(name, seconds = 2) { const sr = 44100, oc = new OfflineAudioContext(2, sr * seconds, sr), rig = makeRig(oc); SFX[name](rig, 0.01, { dest: rig.sfx, pan: 0, v: 1, r: 1 }); return oc.startRendering(); },
  tracks: Object.keys(TRACKS), sfxNames: () => Object.keys(SFX),
};

// ---------- ژینگل‌ها ----------
const JINGLES = {
  victory: { beat: 0.16, len: 2.6, ins: "brass", n: [[60, 0, 1.5], [64, 1.5, 1.5], [67, 3, 1.5], [72, 4.5, 4], [76, 4.5, 4, "bell"], [67, 9, 2], [72, 11, 2], [76, 13, 2], [79, 15, 6], [84, 15, 6, "bell"], [48, 0, 6, "bsine"], [55, 9, 10, "bsine"]] },
  defeat: { beat: 0.28, len: 2.8, ins: "strings", n: [[67, 0, 2], [63, 2, 2], [60, 4, 2], [55, 6, 6], [43, 0, 12, "bsine"], [58, 6, 6, "strings"]] },
  levelup: { beat: 0.12, len: 1.4, ins: "bell", n: [[72, 0, 2], [76, 1.5, 2], [79, 3, 2], [84, 4.5, 6], [91, 6, 5]] },
  chest: { beat: 0.1, len: 1.6, ins: "bell", n: [[67, 0, 2], [72, 1, 2], [76, 2, 2], [79, 3, 2], [84, 4, 8], [88, 5.5, 6], [96, 7, 6]] },
};

// ---------- جلوه‌های صوتی ----------
const ping = (R, t, f, v, o, d = 0.15) => tone(R, { ...o, t, f, dur: 0.02, vol: v * o.v, a: 0.002, d, s: 0.0001, rel: 0.1, parts: [{ r: 1, v: 1, type: "sine" }, { r: 2, v: 0.3, type: "triangle" }], send: 0.15 });
const arp = (R, t, o, notes, step, v, ins = "bell") => notes.forEach((m, i) => I[ins](R, t + i * step, m, step, v * o.v, { dest: o.dest, pan: o.pan }));
const CD = { hit: 0.05, shot_bow: 0.06, shot_spear: 0.08, shot_catapult: 0.1, shot_frost: 0.08, shot_lightning: 0.08, shot_flame: 0.14, shot_arcane: 0.08, enemy_die: 0.05, burn: 0.2, click: 0.02, coin: 0.05, hit_heavy: 0.07, zap: 0.06, explode: 0.06, freeze: 0.15, tick: 0.05, gate_hit: 0.06 };
const SFX = {
  click: (R, t, o) => tone(R, { ...o, t, f: 1300, f2: 900, sw: 0.04, dur: 0.03, vol: 0.2 * o.v, rel: 0.05, type: "triangle" }),
  back: (R, t, o) => tone(R, { ...o, t, f: 800, f2: 520, sw: 0.06, dur: 0.05, vol: 0.2 * o.v, rel: 0.06, type: "triangle" }),
  tick: (R, t, o) => tone(R, { ...o, t, f: 2200, dur: 0.01, vol: 0.08 * o.v, rel: 0.03, type: "square", lp: [3000, 800, 0.03] }),
  coin: (R, t, o) => { ping(R, t, 1568 * o.r, 0.25, o, 0.1); ping(R, t + 0.07, 2093 * o.r, 0.25, o, 0.25); },
  collect: (R, t, o) => arp(R, t, o, [84, 88, 91, 96], 0.07, 0.8),
  build: (R, t, o) => { noiseHit(R, { ...o, t, dur: 0.07, vol: 0.35 * o.v, f: 600, q: 0.8 }); tone(R, { ...o, t, f: 200, f2: 90, sw: 0.1, dur: 0.12, vol: 0.5 * o.v, type: "triangle" }); ping(R, t + 0.1, 880, 0.2, o, 0.2); },
  sell: (R, t, o) => { ping(R, t, 1568, 0.22, o, 0.1); ping(R, t + 0.07, 1175, 0.22, o, 0.1); ping(R, t + 0.14, 784, 0.22, o, 0.2); },
  upgrade: (R, t, o) => arp(R, t, o, [72, 76, 79, 84], 0.06, 0.8, "marimba"),
  evolve: (R, t, o) => { noiseHit(R, { ...o, t, dur: 0.9, vol: 0.25 * o.v, f: 300, f2: 6000, q: 1.5, a: 0.5, rel: 0.2 }); [60, 64, 67, 72].forEach((m) => I.strings(R, t + 0.5, m, 1, 1.2 * o.v, o)); arp(R, t + 0.8, o, [84, 88, 91, 96, 100], 0.07, 1); D.taiko(R, t + 0.55, 1, o); },
  error: (R, t, o) => { tone(R, { ...o, t, f: 170, dur: 0.1, vol: 0.2 * o.v, type: "sawtooth", lp: [800, 400, 0.1] }); tone(R, { ...o, t: t + 0.12, f: 140, dur: 0.14, vol: 0.2 * o.v, type: "sawtooth", lp: [800, 300, 0.1] }); },
  wave_start: (R, t, o) => { I.brass(R, t, 55, 0.5, 1.1 * o.v, o); I.brass(R, t + 0.45, 62, 0.9, 1.2 * o.v, o); D.taiko(R, t, 0.8, o); D.taiko(R, t + 0.45, 0.9, o); },
  wave_clear: (R, t, o) => { [67, 71, 74, 79].forEach((m, i) => I.bell(R, t + i * 0.06, m, 0.4, 1 * o.v, o)); },
  life_lost: (R, t, o) => { tone(R, { ...o, t, f: 220, f2: 70, sw: 0.4, dur: 0.4, vol: 0.5 * o.v, type: "sawtooth", lp: [1200, 150, 0.4], rel: 0.2 }); noiseHit(R, { ...o, t, dur: 0.25, vol: 0.3 * o.v, f: 400, q: 0.6 }); },
  hero_spawn: (R, t, o) => { noiseHit(R, { ...o, t, dur: 0.4, vol: 0.2 * o.v, f: 500, f2: 5000, q: 1.2, a: 0.25 }); arp(R, t + 0.2, o, [72, 79, 84], 0.08, 0.9); },
  skill_arash: (R, t, o) => { tone(R, { ...o, t, f: 3200, f2: 380, sw: 0.5, dur: 0.5, vol: 0.2 * o.v, type: "sine", send: 0.3 }); noiseHit(R, { ...o, t, dur: 0.5, vol: 0.2 * o.v, f: 4000, f2: 600, q: 2 }); D.impact(R, t + 0.45, 0.6 * o.v, o); },
  skill_rostam: (R, t, o) => { D.impact(R, t, 1.1 * o.v, o); tone(R, { ...o, t, f: 55, dur: 0.9, vol: 0.5 * o.v, rel: 0.4 }); noiseHit(R, { ...o, t: t + 0.05, dur: 0.6, vol: 0.4 * o.v, ft: "lowpass", f: 500, f2: 60, q: 0.5 }); },
  skill_gordafarid: (R, t, o) => { for (let i = 0; i < 7; i++) noiseHit(R, { ...o, t: t + i * 0.07, dur: 0.1, vol: 0.28 * o.v, ft: "highpass", f: 2500 + i * 500, q: 0.7, rel: 0.06 }); arp(R, t, o, [88, 91, 95, 100], 0.1, 0.6, "metal"); },
  skill_zal: (R, t, o) => { noiseHit(R, { ...o, t, dur: 0.7, vol: 0.2 * o.v, f: 800, f2: 3000, q: 1, a: 0.3 }); [72, 76, 79, 84].forEach((m) => I.glass(R, t, m, 1.4, 1.5 * o.v, o)); arp(R, t + 0.3, o, [91, 96, 100], 0.12, 0.9); },
  skill_sohrab: (R, t, o) => { I.metal(R, t, 52, 0.6, 1.3 * o.v, o); D.taiko(R, t, 1.1, o); I.brass(R, t + 0.1, 57, 0.5, 1 * o.v, o); },
  skill_tahmineh: (R, t, o) => { [76, 79, 83, 88].forEach((m, k) => I.glass(R, t + k * 0.1, m, 0.6, 0.8 * o.v, o)); },
  skill_kaveh: (R, t, o) => { I.metal(R, t, 55, 0.6, 1.4 * o.v, o); D.clank(R, t, 1.5, o); I.brass(R, t + 0.15, 60, 0.4, 1 * o.v, o); I.brass(R, t + 0.5, 67, 0.7, 1.1 * o.v, o); D.taiko(R, t + 0.1, 0.9, o); },
  shot_bow: (R, t, o) => { noiseHit(R, { ...o, t, dur: 0.07, vol: 0.12 * o.v, ft: "highpass", f: 2500, q: 0.6 }); tone(R, { ...o, t, f: 700 * o.r, f2: 280, sw: 0.08, dur: 0.06, vol: 0.14 * o.v, type: "triangle" }); },
  shot_spear: (R, t, o) => { noiseHit(R, { ...o, t, dur: 0.2, vol: 0.14 * o.v, f: 600, f2: 3000, q: 1.2 }); tone(R, { ...o, t, f: 140, f2: 90, sw: 0.1, dur: 0.1, vol: 0.3 * o.v, type: "triangle" }); },
  shot_catapult: (R, t, o) => { tone(R, { ...o, t, f: 130, f2: 55, sw: 0.18, dur: 0.2, vol: 0.5 * o.v, rel: 0.1 }); noiseHit(R, { ...o, t, dur: 0.25, vol: 0.14 * o.v, f: 300, f2: 120, q: 3 }); },
  shot_frost: (R, t, o) => { ping(R, t, 2000 * o.r, 0.2, o, 0.15); noiseHit(R, { ...o, t, dur: 0.08, vol: 0.08 * o.v, ft: "highpass", f: 6000 }); },
  shot_lightning: (R, t, o) => { tone(R, { ...o, t, f: 2400, f2: 180, sw: 0.14, dur: 0.15, vol: 0.14 * o.v, type: "sawtooth", lp: [4000, 600, 0.15] }); noiseHit(R, { ...o, t, dur: 0.1, vol: 0.2 * o.v, f: 3500, q: 0.8 }); },
  shot_flame: (R, t, o) => noiseHit(R, { ...o, t, dur: 0.2, vol: 0.1 * o.v, f: 900, f2: 500, q: 0.8, a: 0.04, rel: 0.1 }),
  shot_arcane: (R, t, o) => { tone(R, { ...o, t, f: 500, f2: 1000, sw: 0.12, dur: 0.14, vol: 0.14 * o.v, parts: [{ r: 1, v: 1, type: "sine" }, { r: 1.5, v: 0.5, type: "sine" }], send: 0.4 }); },
  hit: (R, t, o) => noiseHit(R, { ...o, t, dur: 0.03, vol: 0.12 * o.v, f: 1800, q: 1.5 }),
  hit_heavy: (R, t, o) => { tone(R, { ...o, t, f: 120, f2: 60, sw: 0.08, dur: 0.1, vol: 0.4 * o.v }); noiseHit(R, { ...o, t, dur: 0.06, vol: 0.2 * o.v, f: 800 }); },
  explode: (R, t, o) => { noiseHit(R, { ...o, t, dur: 0.5, vol: 0.4 * o.v, ft: "lowpass", f: 2500, f2: 120, q: 0.6, rel: 0.2, send: 0.2 }); tone(R, { ...o, t, f: 90, f2: 35, sw: 0.4, dur: 0.4, vol: 0.55 * o.v }); },
  freeze: (R, t, o) => { arp(R, t, o, [96, 100, 103, 108], 0.04, 0.6); noiseHit(R, { ...o, t, dur: 0.25, vol: 0.1 * o.v, ft: "highpass", f: 5000 }); },
  zap: (R, t, o) => { tone(R, { ...o, t, f: 1800, f2: 300, sw: 0.1, dur: 0.1, vol: 0.12 * o.v, type: "square", lp: [3000, 800, 0.1] }); noiseHit(R, { ...o, t, dur: 0.08, vol: 0.14 * o.v, f: 4000, q: 1 }); },
  burn: (R, t, o) => { for (let i = 0; i < 4; i++) noiseHit(R, { ...o, t: t + i * 0.05 + Math.random() * 0.03, dur: 0.02, vol: 0.1 * o.v, f: 1500 + Math.random() * 3000, q: 2 }); },
  enemy_die: (R, t, o) => { tone(R, { ...o, t, f: 520 * o.r, f2: 130, sw: 0.12, dur: 0.1, vol: 0.2 * o.v, type: "triangle" }); noiseHit(R, { ...o, t, dur: 0.06, vol: 0.1 * o.v, f: 1500 }); },
  enemy_big_die: (R, t, o) => { tone(R, { ...o, t, f: 260, f2: 55, sw: 0.3, dur: 0.3, vol: 0.4 * o.v, type: "sawtooth", lp: [1800, 150, 0.3] }); noiseHit(R, { ...o, t, dur: 0.25, vol: 0.25 * o.v, f: 600, f2: 150, q: 0.7 }); },
  boss_roar: (R, t, o) => { tone(R, { ...o, t, f: 95, f2: 48, sw: 1.2, dur: 1.4, vol: 0.4 * o.v, type: "sawtooth", lp: [900, 150, 1.2], lq: 3, vib: [14, 40, 0.1], rel: 0.5, send: 0.3 }); noiseHit(R, { ...o, t, dur: 1.2, vol: 0.18 * o.v, f: 300, f2: 120, q: 1.5, a: 0.2 }); },
  boss_die: (R, t, o) => { D.impact(R, t, 1.2 * o.v, o); tone(R, { ...o, t, f: 300, f2: 40, sw: 1.4, dur: 1.5, vol: 0.4 * o.v, type: "sawtooth", lp: [2000, 100, 1.4], rel: 0.5 }); arp(R, t + 0.9, o, [72, 76, 79, 84], 0.12, 0.8); },
  chest_open: (R, t, o) => { tone(R, { ...o, t, f: 150, f2: 260, sw: 0.3, dur: 0.3, vol: 0.18 * o.v, type: "sawtooth", lp: [700, 700, 0.3] }); noiseHit(R, { ...o, t, dur: 0.25, vol: 0.1 * o.v, f: 1200, q: 2 }); arp(R, t + 0.3, o, [79, 84, 88, 91, 96, 100], 0.06, 0.8); },
  levelup: (R, t, o) => { arp(R, t, o, [72, 76, 79, 84, 88, 91], 0.07, 0.9, "marimba"); I.brass(R, t + 0.3, 72, 0.8, 0.9 * o.v, o); },
  victory: (R, t, o) => Sound.jingle("victory"), defeat: (R, t, o) => Sound.jingle("defeat"),
  troop_spawn: (R, t, o) => { I.brass(R, t, 60 + Math.floor(Math.random() * 3) * 2, 0.15, 0.7 * o.v, o); D.tom(R, t, 0.7, o); },
  gate_hit: (R, t, o) => { tone(R, { ...o, t, f: 110, f2: 50, sw: 0.12, dur: 0.12, vol: 0.5 * o.v }); noiseHit(R, { ...o, t, dur: 0.1, vol: 0.3 * o.v, f: 500, f2: 200, q: 1 }); D.clank(R, t + 0.02, 0.8, o); },
  tower_destroyed: (R, t, o) => { noiseHit(R, { ...o, t, dur: 0.7, vol: 0.4 * o.v, ft: "lowpass", f: 1500, f2: 100, q: 0.6, rel: 0.3 }); tone(R, { ...o, t, f: 100, f2: 35, sw: 0.5, dur: 0.5, vol: 0.5 * o.v }); },
  heal: (R, t, o) => arp(R, t, o, [79, 84, 88], 0.08, 0.7, "glass"),
  daily: (R, t, o) => { arp(R, t, o, [76, 79, 83, 88], 0.09, 0.9); ping(R, t + 0.4, 1760, 0.3, o, 0.6); },
  star: (R, t, o) => { ping(R, t, 1046 * o.r, 0.35, o, 0.5); ping(R, t + 0.02, 2093 * o.r, 0.2, o, 0.6); },
};
