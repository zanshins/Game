// منوهای حالت سه‌بعدی: تجهیزات، چهره، مهارت‌ها، سپاه
import { S, save, saveSoon, pay, canPay } from "./save.js";
import { Sound } from "./audio.js";
import { GEAR, SLOTS, RARITY, SKINS, HAIRS, TUNICS, EYECOLS, FACE_OPTS, SLIDERS, DEF_FACE, find, stats, STAT_MAX, lookOf, randomLook, drawHead, gearSVG, faceOf, buildW } from "./gear.js";
import { A, UNITS, UNIT_ORDER, UNIT_MAX, MAX_BRING, SKILLS, SKILL_ORDER, skillLv, skillCost, buySkill, unitCount, unitLv, packPrice, buyPack, upCost, upUnit, totalUnits, mulLv } from "./army3d.js";

let H = {}; export function initUI3D(h) { H = h; }
const fa = (n) => (H.fa ? H.fa(n) : String(n));
const st3 = { tab: "look", slot: "sword", zoom: false, stop: null };
const price = (p) => (p.gems ? `💎 ${fa(p.gems)}` : `🪙 ${fa(p.coins || 0)}`);
const afford = (p) => canPay({ coins: p.coins || 0, gems: p.gems || 0 });
const TAU = Math.PI * 2;
const hex = (h) => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const col = (h, k, a = 1) => { const c = hex(h); return `rgba(${Math.min(255, c[0] * k) | 0},${Math.min(255, c[1] * k) | 0},${Math.min(255, c[2] * k) | 0},${a})`; };

// ---------- پیکره‌ی پیش‌نمایش ----------
function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
function grad(ctx, x0, y0, x1, y1, c, k1 = 1.25, k2 = 0.7) { const g = ctx.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, col(c, k1)); g.addColorStop(1, col(c, k2)); return g; }
export function drawFigure(ctx, W, H2, L, t, zoom) {
  const f = L.face, bw = buildW(f.build), ht = f.height || 1, u = H2 / 4.1 * ht * (zoom ? 2.4 : 1), cx = W / 2, gy = zoom ? H2 * 1.55 : H2 * 0.95, sway = Math.sin(t * 1.4) * 0.02;
  ctx.save(); ctx.translate(cx, gy); ctx.scale(1, 1);
  // سایه و هاله
  ctx.fillStyle = "rgba(0,0,0,.4)"; ctx.beginPath(); ctx.ellipse(0, 0, u * 0.9, u * 0.17, 0, 0, TAU); ctx.fill();
  if (L.aura) { const c = L.aura.col || "#ffd24a", g = ctx.createRadialGradient(0, -u * 1.2, u * 0.2, 0, -u * 1.2, u * 1.7); g.addColorStop(0, c + "99"); g.addColorStop(1, c + "00"); ctx.fillStyle = g; ctx.fillRect(-u * 2, -u * 3.4, u * 4, u * 3.6); }
  const sk = L.skin, tun = L.tunic, bodyC = L.armor || tun, sleeve = tun;
  // شنل
  if (L.cape) { const cc = L.cape.color; ctx.fillStyle = grad(ctx, 0, -u * 1.9, 0, -u * 0.2, cc, 1.2, 0.6); ctx.beginPath(); ctx.moveTo(-u * 0.38 * bw, -u * 1.85); ctx.lineTo(u * 0.38 * bw, -u * 1.85); ctx.quadraticCurveTo(u * 0.8 * bw, -u * 0.9, u * 0.72 * bw, -u * 0.12 + Math.sin(t * 2) * u * 0.03); ctx.quadraticCurveTo(0, -u * 0.04, -u * 0.72 * bw, -u * 0.12); ctx.quadraticCurveTo(-u * 0.8 * bw, -u * 0.9, -u * 0.38 * bw, -u * 1.85); ctx.fill(); ctx.strokeStyle = col(cc, 0.45); ctx.lineWidth = 1.5; ctx.stroke(); if (L.cape.color2) { ctx.strokeStyle = L.cape.color2; ctx.lineWidth = u * 0.05; ctx.beginPath(); ctx.moveTo(-u * 0.7 * bw, -u * 0.16); ctx.quadraticCurveTo(0, -u * 0.06, u * 0.7 * bw, -u * 0.16); ctx.stroke(); } }
  // پاها
  for (const sg of [-1, 1]) { ctx.fillStyle = grad(ctx, 0, -u * 1.0, 0, 0, L.legs || "#3a3f4a", 1.2, 0.7); rr(ctx, sg * u * 0.19 * bw - u * 0.13, -u * 1.0, u * 0.26 * bw, u * 0.92, u * 0.08); ctx.fill(); ctx.fillStyle = "#2a2420"; rr(ctx, sg * u * 0.19 * bw - u * 0.16, -u * 0.12, u * 0.33 * bw, u * 0.14, u * 0.06); ctx.fill(); }
  // بازوها
  const arm = (sg, ang) => { ctx.save(); ctx.translate(sg * u * 0.46 * bw, -u * 1.72); ctx.rotate(ang); ctx.fillStyle = grad(ctx, 0, 0, 0, u * 0.5, sleeve, 1.2, 0.75); rr(ctx, -u * 0.11, -u * 0.06, u * 0.22, u * 0.46, u * 0.08); ctx.fill(); ctx.fillStyle = grad(ctx, 0, u * 0.4, 0, u * 0.8, sk, 1.15, 0.8); rr(ctx, -u * 0.09, u * 0.38, u * 0.18, u * 0.4, u * 0.08); ctx.fill(); ctx.restore(); };
  arm(1, 0.18 + sway); 
  // تنه
  ctx.fillStyle = grad(ctx, -u * 0.4, -u * 1.9, u * 0.4, -u * 0.8, bodyC, 1.3, 0.72); rr(ctx, -u * 0.37 * bw, -u * 1.86, u * 0.74 * bw, u * 0.98, u * 0.12); ctx.fill(); ctx.strokeStyle = col(bodyC, 0.4); ctx.lineWidth = 1.4; ctx.stroke();
  if (L.armorItem) { ctx.strokeStyle = col(bodyC, 0.5); ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(0, -u * 1.84); ctx.lineTo(0, -u * 0.9); ctx.moveTo(-u * 0.3 * bw, -u * 1.5); ctx.quadraticCurveTo(0, -u * 1.4, u * 0.3 * bw, -u * 1.5); ctx.moveTo(-u * 0.3 * bw, -u * 1.2); ctx.quadraticCurveTo(0, -u * 1.1, u * 0.3 * bw, -u * 1.2); ctx.stroke(); if (L.armorItem.trim) { ctx.strokeStyle = L.armorItem.trim; ctx.lineWidth = u * 0.04; ctx.beginPath(); ctx.moveTo(-u * 0.3 * bw, -u * 1.84); ctx.quadraticCurveTo(0, -u * 1.7, u * 0.3 * bw, -u * 1.84); ctx.stroke(); } for (const sg of [-1, 1]) { ctx.fillStyle = grad(ctx, 0, -u * 1.95, 0, -u * 1.7, bodyC, 1.3, 0.8); ctx.beginPath(); ctx.ellipse(sg * u * 0.45 * bw, -u * 1.76, u * 0.2, u * 0.12, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = col(bodyC, 0.4); ctx.stroke(); } }
  else { ctx.strokeStyle = col(tun, 0.55); ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(-u * 0.14, -u * 1.85); ctx.lineTo(0, -u * 1.65); ctx.lineTo(u * 0.14, -u * 1.85); ctx.stroke(); }
  ctx.fillStyle = "#5a3a1a"; rr(ctx, -u * 0.39 * bw, -u * 1.0, u * 0.78 * bw, u * 0.12, u * 0.04); ctx.fill(); ctx.fillStyle = "#e0be5a"; rr(ctx, -u * 0.07, -u * 1.0, u * 0.14, u * 0.12, u * 0.03); ctx.fill();
  // گردن + سر
  ctx.fillStyle = grad(ctx, 0, -u * 2.0, 0, -u * 1.8, sk, 1.1, 0.75); rr(ctx, -u * 0.1, -u * 2.02, u * 0.2, u * 0.22, u * 0.05); ctx.fill();
  drawHead(ctx, 0, -u * 2.32, u * 0.33, L, Math.sin(t * 0.7) * 0.16, { sway: Math.sin(t * 2) });
  // سپر (چپ) و سلاح (راست)
  arm(-1, -0.12 - sway);
  if (L.shield) { const d = L.shield, c = d.color, r = d.rim; ctx.save(); ctx.translate(-u * 0.78 * bw, -u * 1.15); if (d.glow) { const g = ctx.createRadialGradient(0, 0, 0, 0, 0, u * 0.8); g.addColorStop(0, d.glow + "88"); g.addColorStop(1, d.glow + "00"); ctx.fillStyle = g; ctx.fillRect(-u, -u, u * 2, u * 2); } ctx.fillStyle = grad(ctx, -u * 0.4, -u * 0.5, u * 0.4, u * 0.5, c, 1.35, 0.65); ctx.strokeStyle = r; ctx.lineWidth = u * 0.07; ctx.beginPath(); if (d.shape === "kite") { ctx.moveTo(0, -u * 0.5); ctx.lineTo(u * 0.4, -u * 0.38); ctx.quadraticCurveTo(u * 0.38, u * 0.2, 0, u * 0.58); ctx.quadraticCurveTo(-u * 0.38, u * 0.2, -u * 0.4, -u * 0.38); ctx.closePath(); } else ctx.arc(0, 0, u * 0.44, 0, TAU); ctx.fill(); ctx.stroke(); ctx.fillStyle = r; ctx.beginPath(); ctx.arc(0, 0, u * 0.09, 0, TAU); ctx.fill(); if (d.emblem === 1) { ctx.fillStyle = "#d8453a"; ctx.beginPath(); ctx.arc(0, -u * 0.18, u * 0.08, 0, TAU); ctx.fill(); } ctx.restore(); }
  if (L.weapon) { const w = L.weapon, len = u * 1.5 * w.len, kd = w.kind || "sword"; ctx.save(); ctx.translate(u * 0.78 * bw, -u * 1.0); ctx.rotate(0.12 + sway * 2); if (w.glow) { const g = ctx.createRadialGradient(0, -len * 0.5, 0, 0, -len * 0.5, len * 0.7); g.addColorStop(0, w.glow + "99"); g.addColorStop(1, w.glow + "00"); ctx.fillStyle = g; ctx.fillRect(-len, -len * 1.4, len * 2, len * 1.6); }
    ctx.lineJoin = "round"; if (kd === "axe") { ctx.fillStyle = w.hilt; ctx.fillRect(-u * 0.04, -len, u * 0.08, len * 1.05); ctx.fillStyle = grad(ctx, 0, -len, u * 0.5, -len * 0.6, w.blade, 1.3, 0.7); ctx.beginPath(); ctx.moveTo(u * 0.04, -len * 0.98); ctx.quadraticCurveTo(u * 0.7, -len * 1.05, u * 0.62, -len * 0.62); ctx.quadraticCurveTo(u * 0.3, -len * 0.7, u * 0.04, -len * 0.62); ctx.fill(); ctx.strokeStyle = col(w.blade, 0.4); ctx.stroke(); }
    else if (kd === "mace") { ctx.fillStyle = w.hilt; ctx.fillRect(-u * 0.04, -len * 0.9, u * 0.08, len); ctx.fillStyle = grad(ctx, -u * 0.2, -len, u * 0.2, -len * 0.7, w.blade, 1.3, 0.7); ctx.beginPath(); ctx.arc(0, -len * 0.95, u * 0.22, 0, TAU); ctx.fill(); ctx.strokeStyle = col(w.blade, 0.4); ctx.stroke(); for (let i = 0; i < 8; i++) { const a = i / 8 * TAU; ctx.fillStyle = w.hilt; ctx.beginPath(); ctx.arc(Math.cos(a) * u * 0.24, -len * 0.95 + Math.sin(a) * u * 0.24, u * 0.04, 0, TAU); ctx.fill(); } }
    else { ctx.fillStyle = grad(ctx, -u * 0.05, 0, u * 0.05, -len, w.blade, 1.35, 0.8); ctx.beginPath(); ctx.moveTo(-u * 0.06, -u * 0.1); ctx.lineTo(-u * 0.06, -len); ctx.lineTo(0, -len - u * 0.14); ctx.lineTo(u * 0.06, -len); ctx.lineTo(u * 0.06, -u * 0.1); ctx.fill(); ctx.strokeStyle = col(w.blade, 0.45); ctx.stroke(); ctx.fillStyle = w.hilt; rr(ctx, -u * 0.2, -u * 0.14, u * 0.4, u * 0.08, u * 0.03); ctx.fill(); ctx.fillRect(-u * 0.045, -u * 0.08, u * 0.09, u * 0.3); if (w.twin) { ctx.fillStyle = w.blade; ctx.fillRect(-u * 0.17, -len * 0.82, u * 0.34, u * 0.07); } }
    ctx.restore(); }
  ctx.restore();
}
export function avatarPreview(canvas, av, getAv) {
  const ctx = canvas.getContext("2d"); let t = 0, alive = true, raf = 0;
  const fr = () => { if (!alive || !canvas.isConnected) return; raf = requestAnimationFrame(fr); t += 0.016; const a = getAv ? getAv() : av, W = canvas.width, Hh = canvas.height; ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, W, Hh); const g = ctx.createRadialGradient(W / 2, Hh * 0.55, 10, W / 2, Hh * 0.55, Hh * 0.75); g.addColorStop(0, "#52407a"); g.addColorStop(1, "#150f26"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, Hh); ctx.strokeStyle = "rgba(255,210,120,.07)"; ctx.lineWidth = 1; for (let i = -6; i < 8; i++) { ctx.beginPath(); ctx.moveTo(W / 2 + i * 34, Hh); ctx.lineTo(W / 2 + i * 120, Hh * 0.6); ctx.stroke(); } drawFigure(ctx, W, Hh, lookOf(a), t, st3.zoom); };
  fr(); return () => { alive = false; cancelAnimationFrame(raf); };
}
// پرتره‌ی کوچک سرباز
const PORT = { sword: { helm: { kind: "cap", color: "#7a8ab0" } }, shield: { helm: { kind: "helm", color: "#9aa8c0" } }, archer: { helm: { kind: "cap", color: "#6a4a2a" } }, horse: { helm: { kind: "crest", color: "#c8d0e0", plume: "#ffb347" } }, guard: { helm: { kind: "crest", color: "#e8d890", plume: "#c8302a" } } };
function portrait(c, k) { const ctx = c.getContext("2d"), W = c.width, g = ctx.createRadialGradient(W / 2, W / 2, 2, W / 2, W / 2, W * 0.7); g.addColorStop(0, "#4a3a70"); g.addColorStop(1, "#150f26"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, W); const lk = randomLook(900 + k.length * 13, {}); drawHead(ctx, W / 2, W * 0.56, W * 0.3, { skin: lk.skin, hair: lk.hair, face: lk.face, helm: PORT[k].helm }, 0, {}); }

// ---------- پنجره‌ی اصلی ----------
const bar = (v, m, c) => `<i class="sb"><b style="width:${Math.min(100, v / m * 100)}%;background:${c}"></b></i>`;
function tabsHTML() { return `<div class="sub g3tabs">${[["look", "چهره و ظاهر"], ["gear", "تجهیزات"], ["skill", "مهارت‌ها"], ["army", "سپاه"]].map(([k, n]) => `<button class="${st3.tab === k ? "on" : ""}" data-act="g3tab" data-k="${k}">${n}</button>`).join("")}</div>`; }
function head() { const s = stats(S.avatar); return `<div class="g3cur"><span class="chip">🪙 ${fa(S.coins)}</span><span class="chip">💎 ${fa(S.gems)}</span><span class="chip">⚔️ ${fa(s.dmg)}</span><span class="chip">❤️ ${fa(s.hp)}</span><span class="chip">🛡️ ${fa(Math.round(s.def * 100))}٪</span><span class="chip">👥 ${fa(totalUnits())}</span></div>`; }
export function openGear3D(tab) {
  if (tab) st3.tab = tab; if (st3.stop) { st3.stop(); st3.stop = null; }
  H.modal(`${H.closeBtn}<h2>🗡️ قهرمان من</h2><div id="g3head">${head()}</div><div class="g3wrap"><div class="g3prev"><canvas id="g3c" width="340" height="440"></canvas><div class="g3pbtn"><button class="btn s d" data-act="g3zoom">🔍 چهره</button><button class="btn s d" data-act="g3rand">🎲 چهره‌ی تصادفی</button></div></div><div class="g3main"><div id="g3tabs">${tabsHTML()}</div><div class="g3body" id="g3body"></div></div></div>`, "wide");
  const c = document.getElementById("g3c"); if (c) st3.stop = avatarPreview(c, S.avatar, () => S.avatar); body();
}
function refreshHead() { const e = document.getElementById("g3head"); if (e) e.innerHTML = head(); const t = document.getElementById("g3tabs"); if (t) t.innerHTML = tabsHTML(); }
function body(keepScroll) { const b = document.getElementById("g3body"); if (!b) return; const sc = keepScroll ? b.scrollTop : 0; b.innerHTML = st3.tab === "look" ? lookHTML() : st3.tab === "gear" ? gearHTML() : st3.tab === "skill" ? skillHTML() : armyHTML(); b.scrollTop = sc; if (st3.tab === "look") bindSliders(); if (st3.tab === "army") b.querySelectorAll("canvas[data-pk]").forEach((c) => portrait(c, c.dataset.pk)); }
const sw = (arr, k, cur) => `<div class="row wrap" style="gap:6px;margin:4px 0">${arr.map((c) => `<button class="swatch ${cur === c ? "on" : ""}" style="background:${c}" data-act="g3col" data-k="${k}" data-v="${c}"></button>`).join("")}</div>`;
function chips(k) { const f = faceOf(S.avatar); return `<div class="g3chips">${FACE_OPTS[k].map(([v, n]) => `<button class="gchip ${f[k] === v ? "on" : ""}" data-act="g3face" data-k="${k}" data-v="${v}">${n}</button>`).join("")}</div>`; }
function lookHTML() {
  const f = faceOf(S.avatar), av = S.avatar, T = { shape: "شکل صورت", eye: "شکل چشم", brow: "ابرو", nose: "بینی", mouth: "دهان", hairStyle: "مدل مو", beard: "ریش و سبیل", build: "اندام" };
  return `<div class="g3sec"><b>رنگ‌ها</b><div class="xs mut">پوست</div>${sw(SKINS, "skin", av.skin)}<div class="xs mut">مو</div>${sw(HAIRS, "hair", av.hair)}<div class="xs mut">لباس</div>${sw(TUNICS, "tunic", av.tunic)}<div class="xs mut">رنگ چشم</div>${sw(EYECOLS, "eyeCol", f.eyeCol)}</div>`
    + Object.keys(T).map((k) => `<div class="g3sec"><b>${T[k]}</b>${chips(k)}</div>`).join("")
    + `<div class="g3sec"><b>تنظیم دقیق</b>${SLIDERS.map(([k, n, a, b, s]) => `<label class="g3sl"><span>${n}</span><input type="range" min="${a}" max="${b}" step="${s}" value="${f[k]}" data-sl="${k}"></label>`).join("")}<button class="gchip ${f.scar ? "on" : ""}" data-act="g3scar">زخم روی صورت</button></div>`;
}
function bindSliders() { document.querySelectorAll("#g3body input[data-sl]").forEach((i) => i.addEventListener("input", () => { S.avatar.face = Object.assign({}, faceOf(S.avatar), { [i.dataset.sl]: +i.value }); saveSoon(); })); }
function gearHTML() {
  const slot = st3.slot, cur = GEAR[slot], eq = find(slot, S.avatar[slot]);
  const nav = `<div class="g3slots">${Object.keys(SLOTS).map((k) => `<button class="${slot === k ? "on" : ""}" data-act="g3slot" data-k="${k}">${gearSVG(k, find(k, S.avatar[k]))}<em>${SLOTS[k]}</em></button>`).join("")}</div>`;
  const val = (g) => g.dmg || g.hp || (g.def ? Math.round(g.def * 100) : 0), mx = slot === "sword" ? STAT_MAX.dmg : slot === "shield" ? 40 : STAT_MAX.hp / 2;
  const cards = cur.map((g) => { const own = S.gear[g.id], on = S.avatar[slot] === g.id, R = RARITY[g.r || "c"], diff = val(g) - val(eq);
    return `<div class="gcard r_${g.r || "c"} ${on ? "eq" : ""} ${own ? "" : "lock"}" style="--rc:${R.col}"><div class="gi-wrap">${gearSVG(slot, g)}<span class="rtag">${R.n}</span></div><div class="gname">${g.name}</div>${g.id === cur[0].id && slot !== "sword" && slot !== "helm" && slot !== "armor" ? '<div class="xs mut">—</div>' : `<div class="gst"><span>${g.dmg ? "⚔️" : g.def != null ? "🛡️" : g.hp ? "❤️" : "✨"} ${fa(val(g))}${g.def != null && !g.dmg ? "٪" : ""}</span>${bar(val(g), mx, R.col)}${own || on || !diff ? "" : `<span class="df ${diff > 0 ? "up" : "dn"}">${diff > 0 ? "▲" : "▼"}${fa(Math.abs(diff))}</span>`}</div>`}
      ${on ? '<div class="gbtn ok">✔ پوشیده</div>' : own ? `<button class="btn s g" data-act="g3eq" data-s="${slot}" data-id="${g.id}">بپوش</button>` : `<button class="btn s ${afford({ coins: g.cost, gems: g.gems }) ? "r" : "d"}" data-act="g3buy" data-s="${slot}" data-id="${g.id}">${price({ coins: g.cost, gems: g.gems })}</button>`}</div>`; }).join("");
  return nav + `<div class="gcards">${cards}</div>`;
}
function skillHTML() {
  return `<div class="xs mut" style="margin:2px 0 8px">در ابتدا فقط ضربه‌ی شمشیر و جاخالی را داری. مهارت‌ها را بخر و ارتقا بده؛ در نبرد از دکمه‌های گوشه‌ی صفحه فعال می‌شوند.</div>` + SKILL_ORDER.map((k) => { const s = SKILLS[k], l = skillLv(k), c = skillCost(k), key = k === "oil" ? "bolt" : k;
    return `<div class="card item skl ${l ? "own" : ""}"><div class="skic">${s.icon}${l ? "" : '<b class="lk2">🔒</b>'}</div><div class="grow"><b>${s.name}</b> <span class="chip">${l ? "سطح " + fa(l) + " از ۳" : "قفل"}</span><div class="xs mut">${s.desc}</div><div class="xs">⏱ ${fa(s.cd[Math.max(0, l - 1)])} ثانیه • کلید ${{ spec: "R", rally: "F", ram: "G", oil: "H" }[k]}</div></div>${c ? `<button class="btn s ${afford(c) ? "r" : "d"}" data-act="g3skill" data-k="${k}">${l ? "ارتقا " : "خرید "}${price(c)}</button>` : '<span class="chip" style="color:#7bff9a">کامل</span>'}</div>`; void key; }).join("");
}
function armyHTML() {
  const A_ = A();
  return `<div class="xs mut" style="margin:2px 0 8px">سپاه تو: ${fa(totalUnits())} نفر. هر نبرد حداکثر ${fa(MAX_BRING)} نفر همراهت می‌آیند؛ ۷۰٪ افتادگان پس از نبرد برمی‌گردند. با فتح کشورها سرباز غنیمت می‌گیری.</div>` + UNIT_ORDER.map((k) => { const u = UNITS[k], n = unitCount(k), l = unitLv(k), pp = packPrice(k), uc = upCost(k), m = mulLv(l);
    return `<div class="card item ucard"><canvas data-pk="${k}" width="64" height="64" class="uport"></canvas><div class="grow"><b>${u.name}</b> <span class="chip">${fa(n)} نفر</span> <span class="chip">سطح ${fa(l)}</span><div class="xs mut">${u.note}</div><div class="xs">❤️ ${fa(Math.round(u.hp * m))} &nbsp; ⚔️ ${fa(Math.round(u.dmg * m))}</div></div><div class="col" style="gap:5px"><button class="btn s ${afford(pp) ? "r" : "d"}" data-act="g3pack" data-k="${k}">خرید ×${fa(u.pack)} ${price(pp)}</button>${uc ? `<button class="btn s ${afford(uc) && n ? "g" : "d"}" data-act="g3up" data-k="${k}">ارتقا ${price(uc)}</button>` : '<span class="chip">حداکثر</span>'}</div></div>`; }).join("") + (void A_, "");
}
const done = (ok, t) => { if (ok) { Sound.sfx("upgrade"); } else { Sound.sfx("error"); H.toast("موجودی کافی نیست"); } refreshHead(); body(true); void t; };
export const ACTS3D = {
  g3tab(d) { st3.tab = d.k; refreshHead(); body(); },
  g3slot(d) { st3.slot = d.k; body(true); },
  g3zoom() { st3.zoom = !st3.zoom; },
  g3rand() { const r = randomLook(Math.floor(Math.random() * 1e5), {}); S.avatar.skin = r.skin; S.avatar.hair = r.hair; S.avatar.face = Object.assign({}, faceOf(S.avatar), r.face, { eyeCol: r.face.eyeCol }); save(); body(true); },
  g3col(d) { if (d.k === "eyeCol") S.avatar.face = Object.assign({}, faceOf(S.avatar), { eyeCol: d.v }); else S.avatar[d.k] = d.v; saveSoon(); body(true); },
  g3face(d) { S.avatar.face = Object.assign({}, faceOf(S.avatar), { [d.k]: d.v }); saveSoon(); body(true); },
  g3scar() { const f = faceOf(S.avatar); S.avatar.face = Object.assign({}, f, { scar: !f.scar }); saveSoon(); body(true); },
  g3buy(d) { const g = GEAR[d.s].find((x) => x.id === d.id); if (S.gear[g.id]) return; const ok = pay({ coins: g.cost || 0, gems: g.gems || 0 }); if (ok) { S.gear[g.id] = 1; S.avatar[d.s] = g.id; save(); } done(ok); },
  g3eq(d) { S.avatar[d.s] = d.id; Sound.sfx("click"); saveSoon(); refreshHead(); body(true); },
  g3skill(d) { done(buySkill(d.k)); },
  g3pack(d) { done(buyPack(d.k)); },
  g3up(d) { done(upUnit(d.k)); },
};
export { st3 };
