// طرح‌ریزی میدان نبرد: زمین (ارتفاع/رنگ)، دیوارها، ساختمان‌ها و دکور با مدل‌های واقعی. مختصات منطقی: x جانبی، z جلو (به‌سمت قلعه)، y بالا
const clamp = (v, a, b) => Math.max(a, Math.min(b, v)), lerp = (a, b, t) => a + (b - a) * t;
const ss = (a, b, v) => { const t = clamp((v - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const hex = (h) => { const n = parseInt(h.slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; };
const h2 = (a, b) => { let h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263)) | 0; h = Math.imul(h ^ (h >> 13), 1274126177); return ((h ^ (h >> 16)) >>> 0) / 4294967295; };
function vnoise(x, z) { const i = Math.floor(x), j = Math.floor(z), fx = x - i, fz = z - j, u = fx * fx * (3 - 2 * fx), v = fz * fz * (3 - 2 * fz); return lerp(lerp(h2(i, j), h2(i + 1, j), u), lerp(h2(i, j + 1), h2(i + 1, j + 1), u), v); }
const fbm = (x, z) => vnoise(x, z) * 0.55 + vnoise(x * 2.1 + 5, z * 2.1 + 9) * 0.3 + vnoise(x * 4.3 + 11, z * 4.3 + 3) * 0.15;

// پالت و پوشش‌گیاهی هر قوم
export const BIOME = {
  n1: { g0: "#5f9a3c", g1: "#4a8434", rock: "#8a8c86", env: [["tree", 5], ["pine", 1], ["bush", 3], ["flower", 5], ["rock", 2], ["grass", 4]], sky: [[0.26, 0.5, 0.88], [0.78, 0.88, 0.97]], fog: [0.72, 0.84, 0.94], sun: [1, 0.92, 0.78] },
  n2: { g0: "#7a8c5a", g1: "#657a4a", rock: "#7e8088", env: [["pine", 5], ["tree", 2], ["dead", 1], ["rock", 3], ["bush", 2], ["grass", 2]], sky: [[0.36, 0.5, 0.72], [0.78, 0.82, 0.88]], fog: [0.78, 0.82, 0.88], sun: [0.96, 0.94, 0.9] },
  n3: { g0: "#c9aa66", g1: "#b8955a", rock: "#a8845a", env: [["palm", 3], ["rock", 4], ["dead", 2], ["bush", 2], ["grass", 1]], sky: [[0.36, 0.58, 0.9], [0.98, 0.9, 0.72]], fog: [0.96, 0.88, 0.72], sun: [1, 0.86, 0.6] },
  n4: { g0: "#dfe8ee", g1: "#c6d4e0", rock: "#8c96a4", env: [["pine", 6], ["rock", 3], ["dead", 1]], sky: [[0.4, 0.55, 0.78], [0.88, 0.93, 0.98]], fog: [0.88, 0.93, 0.98], sun: [0.95, 0.95, 1] },
  n5: { g0: "#4a3228", g1: "#3a261f", rock: "#2e2220", env: [["dead", 5], ["rock", 5], ["bush", 1]], sky: [[0.16, 0.08, 0.1], [0.78, 0.36, 0.22]], fog: [0.5, 0.26, 0.2], sun: [1, 0.6, 0.35] },
  n6: { g0: "#8fb0d8", g1: "#7a9ac8", rock: "#a8a0d0", env: [["tree", 3], ["flower", 5], ["bush", 3], ["rock", 1], ["grass", 2]], sky: [[0.42, 0.38, 0.8], [0.94, 0.88, 0.98]], fog: [0.88, 0.84, 0.97], sun: [1, 0.9, 0.95] },
};
const ENVK = { tree: ["NormalTree_5", "BirchTree_4", "MapleTree_4", "NormalTree_5", "BirchTree_1"], pine: ["PineTree_5", "PineTree_1", "PineTree_3"], palm: ["PalmTree_1", "PalmTree_5"], dead: ["DeadTree_9", "DeadTree_5"], bush: ["Bush", "Bush_Small", "Bush_Large_Flowers", "Bush_Flowers"], flower: ["Flower_1_Clump", "Flower_2_Clump", "Flower_3_Clump", "Flower_4_Clump", "Flower_5_Clump"], rock: ["Rock_1", "Rock_2", "Rock_3", "Rock_4", "Rock_5"], grass: ["Grass_Small", "Grass_Large_Extruded"] };
const HT = { tree: [6.5, 9.5], pine: [7, 11], palm: [6, 8.5], dead: [4.5, 7], bush: [1.3, 2.0], flower: [0.7, 1.1], rock: [1.0, 2.2], grass: [0.6, 1.0] };

export const GEO = { castle: { ZG: 46, ZI: 94, ZK: 116, HZ: 188, HW: 58 }, town: { ZG: 46, ZI: 100, ZK: 0, HZ: 0, HW: 58 }, village: { ZG: 44, ZI: 80, ZK: 0, HZ: 0, HW: 40 }, field: { ZG: 0, ZI: 0, ZK: 0, HZ: 0, HW: 0 } };

// models: W3.models (برای ابعاد). o: {kind,id,seed,power,tlvl,color}
export function buildSite(o, models) {
  const kind = o.kind, G = GEO[kind], bio = BIOME[o.id] || BIOME.n1, g0 = hex(bio.g0), g1 = hex(bio.g1), rockC = hex(bio.rock), FIELD = kind === "field";
  let sd = (o.seed | 0) || 7; const rnd = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
  const W = (n) => (models[n] ? models[n].w : 1), Hh = (n) => (models[n] ? models[n].h : 1);
  const statics = [], cols = [], fires = [], S = { kind, G, bio, statics, cols, fires, flat: [] };
  const zEnd = kind === "castle" ? G.HZ + 36 : kind === "town" ? G.ZI + 30 : kind === "village" ? G.ZI + 30 : 64;
  S.zEnd = zEnd; S.x0 = -120; S.x1 = 120; S.z0 = -64; S.z1 = zEnd + 46;
  // ----- ارتفاع زمین: مسطح در محوطه‌ی نبرد، تپه‌های دور -----
  const flatRects = []; // [x0,x1,z0,z1,margin]
  if (FIELD) flatRects.push([-20, 20, -36, 46, 12]);
  else { flatRects.push([-34, 34, -30, G.ZG - 4, 10]); flatRects.push([-G.HW - 6, G.HW + 6, G.ZG - 6, G.ZI + 8, 8]); if (kind === "castle") { flatRects.push([-30, 30, G.ZI, G.ZK + 26, 8]); flatRects.push([-24, 24, G.HZ - 28, G.HZ + 28, 6]); } }
  const flatMask = (x, z) => { let m = 0; for (const r of flatRects) { const dx = Math.max(r[0] - x, 0, x - r[1]), dz = Math.max(r[2] - z, 0, z - r[3]); m = Math.max(m, 1 - ss(0, r[4], Math.hypot(dx, dz))); } return m; };
  S.H = (x, z) => {
    const ax = Math.abs(x), edge = ss(FIELD ? 24 : 30, FIELD ? 62 : 74, ax) + ss(zEnd - 6, zEnd + 40, z) * 0.9 + ss(-34, -60, z) * 0.85;
    const roll = (fbm(x * 0.045, z * 0.045) - 0.4) * 5.2 * (0.25 + edge) + (fbm(x * 0.11 + 30, z * 0.11) - 0.5) * 1.1;
    const hills = edge * (7 + 17 * fbm(x * 0.03 + 7, z * 0.03 + 3));
    const m = flatMask(x, z); if (FIELD) { const ar = (fbm(x * 0.05 + 40, z * 0.05 + 13) - 0.5) * 3.4 + (fbm(x * 0.13, z * 0.13 + 60) - 0.5) * 0.9; return (roll + hills) * (1 - m * 0.85) + ar * m * (0.5 + 0.5 * ss(-8, 14, z)); } return (roll + hills) * (1 - m) + (fbm(x * 0.2, z * 0.2) - 0.5) * 0.16 * m;
  };
  const pathX = (z) => Math.sin(z * 0.045) * 2.2 * (1 - ss(G.ZG - 22, G.ZG, z));
  S.color = (x, z, y, slope) => {
    const n = fbm(x * 0.09, z * 0.09), pn = vnoise(x * 0.8, z * 0.8);
    let c = [lerp(g0[0], g1[0], n) * (0.92 + pn * 0.14), lerp(g0[1], g1[1], n) * (0.92 + pn * 0.14), lerp(g0[2], g1[2], n) * (0.94 + pn * 0.1)];
    const ax = Math.abs(x); const forest = ss(30, 52, ax) * 0.35; c = c.map((v) => v * (1 - forest));
    if (!FIELD) { // جاده‌ی خاکی تا دروازه و پیاده‌روی داخل
      const dpx = Math.abs(x - pathX(z)), road = z < G.ZG + 2 && z > -34 ? 1 - ss(2.0, 3.6, dpx) : 0, edgeR = z < G.ZG + 2 && z > -34 ? 1 - ss(3.4, 5.4, dpx) : 0;
      const dirt = [0.55 + pn * 0.06, 0.45 + pn * 0.05, 0.31 + pn * 0.04]; c = c.map((v, i) => lerp(v, dirt[i], edgeR * 0.4)); c = c.map((v, i) => lerp(v, dirt[i], road));
      if (z > G.ZG && z < G.ZI + 30 && Math.abs(x) < G.HW + 4) { const st = [0.5 + pn * 0.08, 0.47 + pn * 0.08, 0.42 + pn * 0.07], pm = 0.55 + 0.45 * (1 - ss(G.ZG, G.ZG + 6, z) * 0 ); const stone = 1 - ss(0, 7, Math.abs(x - pathX(z))), plaza = 1 - ss(10, 16, Math.hypot(x, z - (G.ZG + 26))); c = c.map((v, i) => lerp(v, st[i], Math.max(stone, plaza) * 0.85 * pm)); }
      if (kind === "castle" && z > G.HZ - 26 && z < G.HZ + 26 && Math.abs(x) < 20) { const tile = [0.38 + pn * 0.05, 0.36 + pn * 0.05, 0.34 + pn * 0.05]; c = tile; }
    } else { const dt = 1 - ss(0, 10, Math.hypot(x * 0.8, z + 8)); c = c.map((v, i) => lerp(v, [0.5, 0.42, 0.3][i], dt * 0.18)); }
    if (slope > 0.34) c = c.map((v, i) => lerp(v, rockC[i] * (0.8 + pn * 0.3), clamp((slope - 0.34) * 4, 0, 1)));
    if (y > 11 && (o.id === "n4" || o.id === "n6" || y > 18)) c = c.map((v, i) => lerp(v, [0.95, 0.96, 0.98][i], clamp((y - 11) / 4, 0, 1)));
    return c;
  };
  const gy = (x, z) => S.H(x, z);
  const add = (n, x, z, yaw, s, opt) => { if (!opt || !opt.tint) { const RK = /^(Rock_|c_rock|d_|mtn)/.test(n) ? (n[0] === "m" ? [1.9, 1.9, 2.0] : /^d_/.test(n) ? [1.7, 1.65, 1.6] : rockC.map((v) => 0.8 + v * 1.3)) : null; if (RK) opt = Object.assign({}, opt, { tint: RK }); } if (!models[n]) return; statics.push({ n, x, z, y: opt && opt.y !== undefined ? opt.y : gy(x, z), yaw, s, o: opt || null, big: !!(opt && opt.big), d: opt && opt.d }); };
  const col = (x, z, r) => cols.push([x, z, r]);
  const team = o.color || [0.7, 0.15, 0.15];
  // ----- محیط: درخت/بوته/گل/سنگ -----
  { const tab = bio.env, tot = tab.reduce((a, b) => a + b[1], 0);
    for (let i = 0; i < (FIELD ? 1100 : 760); i++) {
      let r = rnd() * tot, ty = tab[0][0]; for (const [t, w] of tab) { if ((r -= w) <= 0) { ty = t; break; } }
      const x = (rnd() * 2 - 1) * 112, z = S.z0 + 6 + rnd() * (zEnd + 40 - S.z0), big = ty === "tree" || ty === "pine" || ty === "palm" || ty === "dead";
      const fm = flatMask(x, z); if (fm > 0.5 && (big || ty === "bush")) continue; if (fm > 0.92 && ty === "rock" && rnd() < 0.8) continue;
      if (!FIELD && (Math.abs(x - pathX(z)) < (big ? 8 : 4)) && z < G.ZG + 4) continue; if (FIELD && big && ((x * x) / 150 + ((z - 8) * (z - 8)) / 900 < 1)) continue;
      if (!FIELD && z > G.ZG - 2 && z < G.ZI + 10 && Math.abs(x) < G.HW + 8) continue; if (kind === "castle" && z > G.ZI - 2 && z < G.ZK + 30 && Math.abs(x) < 34) continue; if (kind === "castle" && z > G.HZ - 40 && z < G.HZ + 40 && Math.abs(x) < 34) continue;
      const nm = ENVK[ty][Math.floor(rnd() * ENVK[ty].length)], hgt = HT[ty][0] + rnd() * (HT[ty][1] - HT[ty][0]), s = hgt / (Hh(nm) || 3), cl = ty === "flower" || ty === "grass" ? 3 + Math.floor(rnd() * 3) : 1;
      const rad = big ? 2.2 : ty === "rock" ? W(nm) * s * 0.35 : 0;
      for (let j = 0; j < cl; j++) { const px = x + (j ? (rnd() - 0.5) * 3.5 : 0), pz = z + (j ? (rnd() - 0.5) * 3.5 : 0); add(nm, px, pz, rnd() * 6.28, s * (0.85 + rnd() * 0.3), { cls: ty, big, d: ty === "grass" ? 40 : ty === "flower" ? 55 : ty === "bush" ? 80 : 190, tint: ty === "tree" || ty === "bush" ? [0.9 + rnd() * 0.25, 0.9 + rnd() * 0.25, 0.85 + rnd() * 0.2] : null }); }
      if (rad && fm < 0.9) col(x, z, rad * 0.8 + 0.4);
    } }
  // پس‌زمینه‌ی کوهستان
  for (let i = 0; i < 16; i++) { const x = -118 + i * 15.5 + rnd() * 6, z = zEnd + 34 + rnd() * 16, nm = ["mtn1", "mtn2", "mtn3"][i % 3], s = 26 + rnd() * 18; add(nm, x, z, rnd() * 6, s, { y: gy(x, z) - 1, d: 400, big: 1, cls: "mtn" }); }
  for (let i = 0; i < 8; i++) { const x = (i < 4 ? -1 : 1) * (78 + rnd() * 22), z = -20 + rnd() * 130, nm = ["mtn1", "mtn2", "mtn3"][i % 3], s = 20 + rnd() * 14; add(nm, x, z, rnd() * 6, s, { y: gy(x, z) - 1, d: 400, big: 1, cls: "mtn" }); }
  // ----- اردوگاه خودی (شروع) -----
  if (!FIELD) { const cz = -22; add("c_tent", -20, cz, 0.6, 5.2, { d: 110 }); add("c_tent", 21, cz - 4, -0.5, 5.6, { d: 110 }); add("c_campfire", -15, cz + 4, 0, 3.4, { d: 90 }); fires.push([-15, gy(-15, cz + 4) + 0.5, cz + 4, 2.6]); add("c_log", -12.5, cz + 5, 1.1, 3.2); add("c_log", -17.5, cz + 3, 0.3, 3.2); add("c_rock", 25, cz + 6, 0, 3); }
  else { add("c_tent", -22, -26, 0.5, 5.2, { d: 110 }); add("c_campfire", -16, -22, 0, 3.4, { d: 90 }); fires.push([-16, gy(-16, -22) + 0.5, -22, 2.6]); add("c_log", -13, -21, 1.0, 3.2); add("c_tent", 24, -30, -0.6, 5.4, { d: 110 }); add("c_rock", 8, 14, 0, 3); add("d_column", -14, 28, 0.2, 1.1, { big: 1 }); add("d_column", 15, 33, 0, 0.8); }
  if (FIELD) return S;
  // ----- دیوارها -----
  const SW = kind === "village" ? 11 : 13, M = kind === "village" ? { wall: "wwall", tw: "wwalltower", gate: "wgateclosed", open: "wgate" } : { wall: "swall", tw: "swalltower", gate: "sgateclosed", open: "sgate" };
  S.M = M; S.SW = SW; S.WALLH = (Hh(M.wall) || 0.45) * SW * 0.97; const Lg = W(M.gate) * SW, Lw = W(M.wall) * SW, Lt = W(M.tw) * SW;
  S.gateX = 0; S.gateZ = G.ZG; S.gateL = Lg;
  const ring = (z, withGate) => { // خط افقی دیوار در z
    const half = G.HW, pieces = []; let xr = Lg / 2; const sides = [];
    for (const sx of [-1, 1]) { let x = xr, k = 0; while (x < half + 4) { const n = k % 2 === 0 ? M.wall : M.tw, L = n === M.wall ? Lw : Lt; add(n, sx * (x + L / 2), z, 0, SW, { big: 1, d: 360, cls: "wall" }); x += L; k++; } sides.push(x); }
    if (withGate) { S.gateObj = { z, M }; } else { add(M.wall, 0, z, 0, SW, { big: 1, d: 360 }); const L = Lw; for (let x = Lg / 2; x < xr + 1; x += L) { add(M.wall, x + L / 2 - Lg / 2, z, 0, SW, { big: 1, d: 360 }); add(M.wall, -(x + L / 2 - Lg / 2), z, 0, SW, { big: 1, d: 360 }); } }
    return half;
  };
  ring(G.ZG, true); // دیوار بیرونی + دروازه
  // دیوارهای جانبی (چرخیده 90 درجه)
  const sideWall = (x, z0, z1) => { let z = z0, k = 0; while (z < z1) { const n = k % 2 === 0 ? M.tw : M.wall, L = n === M.wall ? Lw : Lt; add(n, x, z + L / 2, Math.PI / 2, SW, { big: 1, d: 360 }); z += L; k++; } };
  sideWall(-G.HW - 2, G.ZG + Lg / 2, G.ZI); sideWall(G.HW + 2, G.ZG + Lg / 2, G.ZI);
  // دیوار داخلی/پشتی
  if (kind === "castle" || kind === "town") { const z = G.ZI; for (const sx of [-1, 1]) { let x = kind === "castle" ? Lg * 0.9 / 2 * 0.8 : 0; if (kind === "castle") x = 6.5; else x = 0; let k = 0; const start = kind === "castle" ? 9.8 : -1; if (kind === "castle") { let xx = start; while (xx < G.HW + 6) { const n = k % 2 ? M.tw : M.wall, L = n === M.wall ? Lw : Lt; add(n, sx * (xx + L / 2), z, 0, SW, { big: 1, d: 360 }); xx += L; k++; } } }
    if (kind === "town") { let xx = -G.HW - 4; let k = 0; while (xx < G.HW + 6) { const n = k % 2 ? M.tw : M.wall, L = n === M.wall ? Lw : Lt; add(n, xx + L / 2, z, 0, SW, { big: 1, d: 360 }); xx += L; k++; } } }
  if (kind === "village") { let xx = -G.HW - 4, k = 0; while (xx < G.HW + 6) { const n = k % 2 ? M.tw : M.wall; const L = n === M.wall ? Lw : Lt; add(n, xx + L / 2, G.ZI, 0, SW, { big: 1, d: 360 }); xx += L; k++; } }
  S.WALLH = Math.max(5.6, S.WALLH);
  // ----- ساختمان‌ها داخل -----
  const bld = (n, x, z, yaw, s, extra) => { if (!models[n]) return; const r = Math.max(models[n].w, 0.6) * s * 0.5; add(n, x, z, yaw, s, Object.assign({ d: 220, cls: "bld", team: extra && extra.noTeam ? null : team, big: 1 }, extra || {})); col(x, z, r * 0.82); S.bl = S.bl || []; S.bl.push(statics[statics.length - 1]); return statics[statics.length - 1]; };
  const plazaZ = G.ZG + 26;
  if (kind === "village") {
    const huts = ["hut1", "hut2", "hut3", "hut4"], zA = G.ZG + 8;
    for (let r = 0; r < 4; r++) for (const sx of [-1, 1]) { const x = sx * (11 + (r % 2) * 7 + rnd() * 4), z = zA + r * 7.5 + rnd() * 3; bld(huts[Math.floor(rnd() * 4)], x, z, sx > 0 ? Math.PI * 0.5 + (rnd() - 0.5) * 0.4 : -Math.PI * 0.5 + (rnd() - 0.5) * 0.4, 7 + rnd() * 1.4); }
    bld("tc1", 0, plazaZ + 6, 0, 8, { noTeam: 1 }); bld("farm", -26, G.ZI - 10, 0.4, 7, { noTeam: 1 }); bld("windmill", 28, G.ZI - 12, 0, 7, { noTeam: 1 });
  } else {
    const hs = ["house1", "house2", "house3", "house4"];
    for (let r = 0; r < 4; r++) for (const sx of [-1, 1]) { if (kind === "castle" && r === 3 && sx > 0) continue; const x = sx * (15 + (r % 2) * 12 + rnd() * 4), z = G.ZG + 9 + r * 9.2 + rnd() * 2; bld(hs[Math.floor(rnd() * 4)], x, z, sx > 0 ? -Math.PI * 0.5 + (rnd() - 0.5) * 0.3 : Math.PI * 0.5 + (rnd() - 0.5) * 0.3, 7.4); }
    bld("tc2", 0, plazaZ, 0, 9, { noTeam: 1 }); bld("market", -32, G.ZG + 30, 0.3, 7); bld("market", 32, G.ZG + 34, -0.3, 7); bld("barracks", -42, G.ZG + 12, Math.PI / 2, 9); if (kind === "castle") { bld("barracks", 42, G.ZG + 14, -Math.PI / 2, 9); bld("temple", 38, G.ZG + 24, 0, 3.4, { noTeam: 1 }); }
    if (kind === "town") { bld("temple", 38, G.ZG + 52, 0, 3.4, { noTeam: 1 }); bld("windmill", -40, G.ZI - 14, 0, 6.2, { noTeam: 1 }); bld("house1", 36, G.ZI - 10, 3.1, 7.4); bld("house2", -22, G.ZI - 10, 3.1, 7.4); }
  }
  // دکور حیاط: بشکه، جعبه، سبد
  for (let i = 0; i < 24; i++) { const x = (rnd() * 2 - 1) * (G.HW - 6), z = G.ZG + 6 + rnd() * (G.ZI - G.ZG - 12); if (Math.abs(x) < 6 || statics.length > 4000) continue; let ok = true; for (const c of cols) if (Math.hypot(c[0] - x, c[1] - z) < c[2] + 1.4) { ok = false; break; } if (!ok) continue; const nm = ["d_barrel", "d_barrel", "c_log", "d_bucket", "c_rock"][i % 5]; add(nm, x, z, rnd() * 6, nm === "d_barrel" ? 1.3 : 1.8, { d: 70 }); col(x, z, 0.8); }
  S.plazaZ = plazaZ;
  // مشعل‌ها کنار جاده
  for (let z = 6; z < G.ZG - 2; z += 9) for (const sx of [-1, 1]) { const x = sx * 5.2 + pathX(z); add("d_torch", x, z, 0, 1.6, { d: 90, y: gy(x, z) }); fires.push([x, gy(x, z) + 1.9, z, 1.4]); }
  // ----- قلعه: دروازه‌ی داخلی، کیپ، تالار -----
  if (kind === "castle") {
    S.innerGate = { z: G.ZI, x: 0 };
    const k = bld("keep2", 0, G.ZK, 0, 11.5, { d: 260 }); S.keepW = W("keep2") * 11.5; S.keepH = Hh("keep2") * 11.5;
    S.keepDoor = { x: 0, z: G.ZK - S.keepW * 0.38 };
    // تالار داخلی (جدا از نقشه؛ با تلپورت)
    const HZ = G.HZ, FW = 6, hx0 = -4, rows = 8, cs = 5; const tile = (x, z) => add("d_floor", x, z, 0, cs / 2 * 1.0, { y: 0.02, d: 160, tint: [0.9, 0.88, 0.86] });
    for (let i = -3; i <= 2; i++) for (let j = 0; j < rows; j++) tile(i * cs + cs / 2, HZ - 20 + j * cs + cs / 2);
    for (let j = 0; j < rows; j++) for (const sx of [-1, 1]) { add("d_wall", sx * 15.2, HZ - 20 + j * 5 + 2.5, Math.PI / 2, 2.5, { d: 160, big: 1 }); }
    for (let i = -3; i <= 2; i++) { add("d_wall", i * 5 + 2.5, HZ + 20.2, 0, 2.5, { d: 160, big: 1 }); }
    for (let i = -3; i <= 2; i++) { if (i === -1 || i === 0) continue; add("d_wall", i * 5 + 2.5, HZ - 20.2, 0, 2.5, { d: 160, big: 1 }); }
    for (const sx of [-1, 1]) for (let j = 0; j < 4; j++) { add("d_column", sx * 9, HZ - 14 + j * 10, 0, 1.45, { d: 160, big: 1 }); col(sx * 9, HZ - 14 + j * 10, 1); fires.push([sx * 12.8, 3.2, HZ - 14 + j * 10, 1.4]); add("d_torch", sx * 14.6, HZ - 14 + j * 10, sx > 0 ? Math.PI / 2 : -Math.PI / 2, 1.8, { y: 2.6, d: 120 }); }
    for (const sx of [-1, 1]) add("d_banner", sx * 14.4, HZ + 6, sx > 0 ? -Math.PI / 2 : Math.PI / 2, 1.5, { d: 160, y: 0.3, team }); add("d_banner", 0, HZ + 19.6, Math.PI, 1.7, { d: 160, y: 0.2, team });
    add("d_ped", 0, HZ + 15, 0, 1.4, { d: 160 }); add("d_statue", 0, HZ + 15, 0, 0.0001 + 1.2, { d: 160, y: 1.2 }); col(0, HZ + 15, 2);
    add("d_table", -10, HZ + 12, 0.3, 1.5, { d: 160 }); col(-10, HZ + 12, 3); add("d_chest", 11, HZ + 16, -0.4, 1.8, { d: 160 }); add("d_barrel", -12, HZ - 17, 0, 1.6, { d: 140 }); add("d_barrel", -10.5, HZ - 16, 0, 1.4, { d: 140 }); add("d_chest", 12, HZ - 17, 0.5, 1.6, { d: 140 }); add("d_bag", 10, HZ + 17, 0, 1.4, { d: 140 }); add("d_web", -14.5, HZ + 19, 0, 2.2, { d: 100, y: 3 });
    S.hall = { x: 0, z: HZ - 16, bx: 0, bz: HZ + 11, x0: -13.5, x1: 13.5, z0: HZ - 19, z1: HZ + 19 };
  }
  // پرچم‌ها روی برج‌ها
  S.team = team; return S;
}
