// رابط کاربری مرکز بازی: کمپین، کشور، قهرمانان، مغازه، اتحاد، ماموریت‌ها
import { MAPS, TOWERS, TOWER_ORDER, HEROES, HERO_ORDER, HERO_MAX, heroUpCost, heroMul, TROOPS, TROOP_ORDER, TROOP_MAX, troopUpCost, troopMul, NEIGHBORS, BUILDINGS, BUILDING_ORDER, bCost, RESEARCH, rCost, CHESTS, BOOSTERS, GEM_EXCHANGE, DAILY_REWARDS, MISSION_POOL, PLAYER_XP, ALLIANCE_PERK, genWaves, genRaidWaves, fa, faTime, ATTACK_TIME } from "./data.js";
import * as SV from "./save.js";
import { S } from "./save.js";
import { Sound } from "./audio.js";
import { startBattle } from "./battleui.js";

export const $ = (s, r = document) => r.querySelector(s);
const ui = { tab: "battle", ksub: "build", pre: null, greeted: false, chatInput: "" };
const cleared = () => S.stars.filter((x) => x > 0).length;
const stars = (n, max = 3) => "★".repeat(n) + "☆".repeat(max - n);
const cost = (p) => (p.coins ? `🪙 ${fa(p.coins)}` : "") + (p.gems ? `💎 ${fa(p.gems)}` : "");
const bar = (v, m, cls = "") => `<div class="bar ${cls}"><i style="width:${Math.max(0, Math.min(100, (v / m) * 100))}%"></i></div>`;
const disc = (b, per) => SV.discount(b, per);

export function toast(msg) { const t = document.createElement("div"); t.className = "toast"; t.innerHTML = msg; $("#toasts").appendChild(t); setTimeout(() => t.remove(), 2700); }
export function modal(html, cls = "") { const m = $("#modal"); m.innerHTML = `<div class="dlg ${cls}" style="position:relative">${html}</div>`; m.classList.add("on"); }
export function closeModal() { const m = $("#modal"); m.classList.remove("on"); m.innerHTML = ""; }
const closeBtn = `<button class="ibtn x" data-act="close">✕</button>`;

// ---------- هاب ----------
export function renderHub() {
  document.body.classList.remove("inbattle"); const old = $("#content"), sc = old ? old.scrollTop : 0;
  SV.dailyCheck(); SV.allianceTick(); const raid = SV.raidTick(); void raid;
  const p = SV.minePending(), claimable = S.missions.list.some((m) => !m.claimed && m.p >= MISSION_POOL.find((d) => d.id === m.id).target) || !S.daily.claimed;
  const dots = { kingdom: S.raid.pending || p.coins > 400, shop: false, alliance: S.buildings.hall > 0 && S.alliance && S.alliance.goal.progress >= S.alliance.goal.target && !S.alliance.goal.claimed };
  $("#app").innerHTML = `<div id="hub"><div class="top">
    <div class="badge"><div class="lv">${fa(S.level)}</div><div style="min-width:90px"><div class="xs mut">${SV.kingdomTier()} • قدرت ${fa(SV.kingdomPower())}</div>${bar(S.xp, PLAYER_XP(S.level), "xp")}</div></div>
    <div class="grow"></div>
    <div class="res">🪙 <span id="rc">${fa(S.coins)}</span></div><div class="res">💎 <span>${fa(S.gems)}</span></div>
    <button class="ibtn" data-act="missions">🎯${claimable ? '<span class="dot"></span>' : ""}</button><button class="ibtn" data-act="settings">⚙️</button></div>
    <div class="content" id="content">${tabContent()}</div>
    <div class="nav">${[["battle", "⚔️", "نبرد"], ["kingdom", "🏰", "کشور"], ["heroes", "🦸", "قهرمانان"], ["shop", "🛒", "مغازه"], ["alliance", "🤝", "اتحاد"]].map(([k, i, n]) => `<button class="${ui.tab === k ? "on" : ""}" data-act="tab" data-t="${k}"><i>${i}</i>${n}${dots[k] ? '<span class="dot"></span>' : ""}</button>`).join("")}</div></div>`;
  const c = $("#content"); if (c) c.scrollTop = sc;
  Sound.playMusic(ui.tab === "kingdom" ? "kingdom" : "menu", { intensity: 0.55 });
  if (!ui.greeted) { ui.greeted = true; if (!S.daily.claimed) setTimeout(openMissions, 500); }
}
const refresh = () => { renderHub(); };
function tabContent() { return { battle: tabBattle, kingdom: tabKingdom, heroes: tabHeroes, shop: tabShop, alliance: tabAlliance }[ui.tab](); }

// ---------- نبرد ----------
function tabBattle() {
  const first = MAPS.findIndex((_, i) => S.stars[i] === 0);
  return `<div class="row" style="margin-bottom:8px"><div class="title">ماجراجویی ایران‌زمین</div><div class="grow"></div><span class="chip">⭐ ${fa(S.stars.reduce((a, b) => a + b, 0))} / ${fa(24)}</span></div>
  <div class="grid g4">${MAPS.map((m, i) => { const lock = i > 0 && S.stars[i - 1] === 0; return `<div class="mapcard ${lock ? "lock" : ""} ${i === first ? "cur" : ""}" style="background:linear-gradient(135deg,${m.sky[0]},${m.sky[1]})" data-act="map" data-i="${i}"><div class="em">${m.emoji}</div><div class="nm">${m.name}</div><div class="xs" style="opacity:.85">${m.sub} • ${fa(m.waves)} موج</div><div class="st">${stars(S.stars[i])}${S.hard[i] ? ` <span class="xs">🔥${fa(S.hard[i])}</span>` : ""}</div></div>`; }).join("")}</div>`;
}
function openMap(i) {
  const m = MAPS[i], hardOK = S.stars[i] === 3; ui.pre = ui.pre && ui.pre.i === i ? ui.pre : { i, hard: false };
  const owned = HERO_ORDER.filter((k) => S.heroes[k]);
  const boosters = Object.keys(BOOSTERS).map((k) => `<div class="tb ${S.picked[k] && S.boosters[k] > 0 ? "sel" : ""} ${S.boosters[k] <= 0 ? "no" : ""}" style="min-width:86px" data-act="booster" data-k="${k}"><div class="i">${BOOSTERS[k].emoji}</div><div class="n">${BOOSTERS[k].name}</div><div class="p">×${fa(S.boosters[k])}</div></div>`).join("");
  modal(`${closeBtn}<h2>${m.emoji} ${m.name}</h2><div class="c mut sm">${m.sub} • ${fa(m.waves)} موج • سالار: ${m.boss.name}</div>
  <div class="row c" style="margin:8px 0">${[0, 1, 2].map((k) => `<span class="big" style="color:${k < S.stars[i] ? "#ffd24a" : "#3a4466"}">★</span>`).join("")}</div>
  ${hardOK ? `<div class="row c" style="margin-bottom:8px"><button class="btn s ${ui.pre.hard ? "d" : ""}" data-act="hard" data-v="0">عادی</button><button class="btn s r ${ui.pre.hard ? "" : "d"}" data-act="hard" data-v="1">🔥 سخت (پاداش ۱٫۸×)</button></div>` : `<div class="c xs mut" style="margin-bottom:6px">با ۳ ستاره، حالت سخت باز می‌شود</div>`}
  <div class="sm mut">قهرمانان همراه (حداکثر ۲):</div><div class="row wrap" style="margin:6px 0">${owned.map((k) => `<div class="tb ${S.loadout.includes(k) ? "sel" : ""}" style="min-width:86px" data-act="loadout" data-k="${k}"><div class="i">${HEROES[k].emoji}</div><div class="n">${HEROES[k].name.split(" ")[0]}</div><div class="p">سطح ${fa(S.heroes[k].lvl)}</div></div>`).join("")}</div>
  <div class="sm mut">تقویت‌کننده‌ها:</div><div class="row wrap" style="margin:6px 0 12px">${boosters}</div>
  <button class="btn l g" style="width:100%" data-act="play">شروع نبرد ⚔️</button>`);
}
function startMap() {
  const { i, hard } = ui.pre, m = MAPS[i], mods = SV.mods(), unlocked = TOWER_ORDER.filter((k) => TOWERS[k].unlock === 0 || S.stars[TOWERS[k].unlock - 1] > 0);
  const heroLv = {}; for (const k in S.heroes) heroLv[k] = S.heroes[k].lvl;
  closeModal(); const used = { ...S.picked }; SV.consumeBoosters();
  runBattle({ mode: "td", mapIndex: i, hard, waves: genWaves(i, hard), mods, unlocked, heroes: S.loadout.filter(Boolean), heroLv, title: m.name, music: m.music, usedBoosters: used });
}
function runBattle(cfg) { startBattle(cfg, (res) => onResult(cfg, res)); }

// ---------- نتیجه ----------
function onResult(cfg, res) {
  const out = { coins: 0, gems: 0, xp: 0, lines: [], won: res.won }; const mi = cfg.mapIndex;
  SV.mission("kills", res.kills); SV.mission("build", res.built); SV.mission("skill", res.skills); if (res.evolves) SV.mission("evolve", res.evolves);
  S.stats.kills += res.kills; S.stats.towers += res.built; S.stats.evolves += res.evolves || 0;
  if (cfg.mode === "attack") {
    const nb = cfg.neighbor; SV.mission("attack", 1); S.stats.attacks++;
    if (res.won) { const firstTime = !S.conquered[nb.id]; out.coins = Math.round(nb.loot * (firstTime ? 1 : 0.3) * (0.6 + res.stars * 0.2) * SV.coinBonus()); out.gems = firstTime ? nb.gems : 0; out.xp = 60 + nb.power; if (firstTime) { S.conquered[nb.id] = true; out.lines.push(`🏴 ${nb.name} فتح شد! (+${fa(nb.perk * 100)}٪ سکه برای همیشه)`); } SV.mission("win", 1); S.stats.wins++; }
    else { out.coins = Math.round(nb.loot * 0.03); out.xp = 12; }
  } else if (cfg.raid) {
    const r = SV.resolveRaid(!res.won, res.won, false); if (res.won) { out.coins = 0; out.gems = 0; out.lines.push(`🛡️ غارتگران ${r.nb.name} را عقب راندی! غنیمت: ${fa(r.loot)} سکه و ${fa(r.gems)} جواهر`); out.xp = 50; SV.mission("win", 1); } else { out.lines.push(`😔 غارتگران ${fa(r.lost)} سکه از گنجینه بردند`); out.xp = 10; }
  } else if (res.won) {
    const hard = cfg.hard, prev = hard ? S.hard[mi] : S.stars[mi], base = (mi + 1) * 140;
    out.coins = Math.round((base * res.stars + res.kills * 1.5) * (hard ? 1.8 : 1) * SV.coinBonus()); const gain = Math.max(0, res.stars - prev); out.gems = gain * 4 * (hard ? 2 : 1) + (res.stars === 3 && prev < 3 ? 6 : 0); out.xp = 40 + mi * 18 + res.stars * 12;
    if (hard) S.hard[mi] = Math.max(S.hard[mi], res.stars); else S.stars[mi] = Math.max(S.stars[mi], res.stars);
    if (res.stars === 3 && prev < 3 && !hard) out.lines.push("🔥 حالت سخت باز شد!"); if (!hard && prev === 0 && mi < 7) out.lines.push(`🗺️ مرحله‌ی «${MAPS[mi + 1].name}» باز شد!`);
    SV.mission("win", 1); S.stats.wins++; SV.allianceWin(res.stars);
    const unl = TOWER_ORDER.find((k) => TOWERS[k].unlock === mi + 1 && prev === 0); if (unl) out.lines.push(`🆕 برج «${TOWERS[unl].name}» باز شد!`);
  } else { out.coins = Math.round(res.wave * (mi + 1) * 14 * SV.coinBonus()); out.xp = 10 + res.wave * 2; }
  SV.give({ coins: out.coins, gems: out.gems }); const up = SV.addXp(out.xp); if (up) out.lines.push(`⬆️ سطح بازیکن ${fa(S.level)} شد! (+${fa(up * 5)} جواهر)`);
  SV.save(); const again = cfg.mode === "td" && !cfg.raid;
  Sound.playMusic("menu", { intensity: 0.5 }); document.body.classList.remove("inbattle"); renderHub();
  const stx = cfg.mode === "attack" ? 3 : 3;
  modal(`<h2>${res.won ? "پیروزی! 🏆" : "شکست 💔"}</h2><div class="c stars">${res.won ? [0, 1, 2].map((k) => `<span class="star-in ${k < res.stars ? "" : "o"}" style="animation-delay:${0.25 + k * 0.3}s">★</span>`).join("") : ""}</div>
  <div class="row wrap c" style="justify-content:center;margin:10px 0"><span class="chip">☠️ ${fa(res.kills)} دشمن</span>${cfg.mode === "td" ? `<span class="chip">❤️ ${fa(res.lives)}/${fa(res.maxLives)}</span><span class="chip">🌊 موج ${fa(res.wave)}</span>` : `<span class="chip">⏱️ ${faTime(res.timeLeft || 0)}</span>`}<span class="chip">🗼 ${fa(res.built)} ساخته</span></div>
  <div class="row c" style="justify-content:center;gap:14px;margin:8px 0"><div class="res">🪙 ${fa(out.coins)}</div>${out.gems ? `<div class="res">💎 ${fa(out.gems)}</div>` : ""}<div class="res">✨ ${fa(out.xp)} تجربه</div></div>
  ${out.lines.map((l) => `<div class="card c sm" style="margin:5px 0">${l}</div>`).join("")}
  <div class="row" style="margin-top:12px"><button class="btn d grow" data-act="close">بازگشت</button>${again ? `<button class="btn g grow" data-act="again" data-i="${mi}">دوباره 🔁</button>` : ""}${again && res.won && mi < 7 ? `<button class="btn grow" data-act="again" data-i="${mi + 1}">مرحله‌ی بعد ▶</button>` : ""}</div>`);
  if (res.won) { Sound.jingle("victory"); setTimeout(() => [0, 1, 2].slice(0, res.stars).forEach((k) => setTimeout(() => Sound.sfx("star", { rate: 1 + k * 0.25 }), 250 + k * 300)), 0); } else Sound.jingle("defeat"); void stx;
}

// ---------- کشور ----------
function tabKingdom() {
  const p = SV.minePending(), raid = S.raid.pending, nb = raid && NEIGHBORS.find((n) => n.id === raid.id);
  let h = `<div class="row wrap" style="margin-bottom:8px"><div class="title">کشور من — ${SV.kingdomTier()}</div><div class="grow"></div><span class="chip">🏛️ سطح ${fa(SV.kingdomLevel())}</span><span class="chip">💪 قدرت ${fa(SV.kingdomPower())}</span></div>`;
  if (raid) h += `<div class="banner row" style="margin-bottom:10px"><div style="font-size:34px">🚨</div><div class="grow"><b>غارت! ${nb.emoji} ${nb.name}</b><div class="sm">سپاه ${nb.ruler} (قدرت ${fa(raid.power)}) به مرزها رسید</div></div><div class="col"><button class="btn s g" data-act="defend">⚔️ دفاع</button><button class="btn s d" data-act="autodef">🛡️ نگهبانان (${fa(Math.round(SV.raidAutoChance() * 100))}٪)</button></div></div>`;
  h += `<div class="card row" style="margin-bottom:10px"><div style="font-size:30px">⛏️</div><div class="grow"><div>معدن‌ها: <b class="gold">🪙 ${fa(p.coins)}</b> ${S.buildings.gem ? `&nbsp; <b style="color:#7be0ff">💎 ${fa(p.gems)}</b>` : ""}</div>${bar(p.coins, Math.max(1, p.capCoins), "y")}<div class="xs mut">${p.fullH ? "انبار پر است!" : "با گذشت زمان (حتی وقتی بازی بسته است) پر می‌شود"}</div></div><button class="btn g ${p.coins + p.gems <= 0 ? "off" : ""}" data-act="collect">جمع‌آوری</button></div>`;
  h += `<div class="sub">${[["build", "🏗️ ساختمان‌ها"], ["nb", "🗺️ همسایگان"], ["army", "🛖 پادگان"], ["res", "🔬 تحقیقات"]].map(([k, n]) => `<button class="${ui.ksub === k ? "on" : ""}" data-act="ksub" data-k="${k}">${n}</button>`).join("")}</div>`;
  if (ui.ksub === "build") h += `<div class="grid g2">${BUILDING_ORDER.map((k) => { const b = BUILDINGS[k], l = S.buildings[k], lock = cleared() < b.need, max = l >= b.max, c = bCost(k, l); return `<div class="card item ${lock ? "lock-o" : ""}"><div class="ic" style="border-color:${b.color}">${b.emoji}</div><div class="grow"><b>${b.name}</b> <span class="chip">سطح ${fa(l)}</span><div class="xs mut">${l ? b.desc(l) : b.desc(1)}${l && !max ? ` ← ${b.desc(l + 1)}` : ""}</div></div>${lock ? `<span class="xs mut">با پیروزی در ${fa(b.need)} مرحله</span>` : max ? `<span class="chip">حداکثر</span>` : `<button class="btn s ${S.coins < c ? "off" : ""}" data-act="build" data-k="${k}">${l ? "ارتقا" : "ساخت"}<br>🪙 ${fa(c)}</button>`}</div>`; }).join("")}</div>`;
  else if (ui.ksub === "nb") h += `<div class="mut sm" style="margin-bottom:6px">با سربازان پادگان به همسایه‌ها حمله کن، دروازه‌شان را بشکن و کشورشان را فتح کن. هر فتح، درآمد دائمی می‌دهد. همسایه‌های فتح‌نشده گاهی به تو غارت می‌برند!</div><div class="grid g2">${NEIGHBORS.map((n) => { const lock = SV.kingdomLevel() < n.need, conq = S.conquered[n.id]; return `<div class="card item ${lock ? "lock-o" : ""}" style="border-color:${n.color}55"><div class="ic" style="border-color:${n.color}">${n.emoji}</div><div class="grow"><b>${n.name}</b> ${conq ? '<span class="chip" style="color:#7bff9a">🏴 فتح‌شده</span>' : ""}<div class="xs mut">${n.ruler} • قدرت ${fa(n.power)} • ${fa(n.towers)} برج</div><div class="xs">غنیمت: 🪙${fa(n.loot)} 💎${fa(n.gems)} • +${fa(n.perk * 100)}٪ سکه</div></div>${lock ? `<span class="xs mut">کشور سطح ${fa(n.need)}</span>` : `<button class="btn s r" data-act="atk" data-id="${n.id}">⚔️ ${conq ? "غارت" : "حمله"}</button>`}</div>`; }).join("")}</div>`;
  else if (ui.ksub === "army") h += `<div class="mut sm" style="margin-bottom:6px">سطح پادگان: ${fa(S.buildings.barracks)} — سربازان تا سطح ${fa(S.buildings.barracks * 2 + 1)} ارتقا می‌یابند.</div><div class="grid g2">${TROOP_ORDER.map((k) => { const t = TROOPS[k], l = S.troops[k], lock = S.buildings.barracks < t.barracks, c = Math.round(troopUpCost(k, l) * disc("academy", 0.04)), cap = Math.min(TROOP_MAX, S.buildings.barracks * 2 + 1); return `<div class="card item ${lock ? "lock-o" : ""}"><div class="ic" style="border-color:${t.color}">${t.emoji}</div><div class="grow"><b>${t.name}</b> <span class="chip">سطح ${fa(l)}</span><div class="xs mut">${t.desc}</div><div class="xs">❤️ ${fa(t.hp * troopMul(l))} • ⚡ ${fa(t.energy)} انرژی</div></div>${lock ? `<span class="xs mut">پادگان ${fa(t.barracks)}</span>` : l >= cap ? `<span class="chip">سقف</span>` : `<button class="btn s ${S.coins < c ? "off" : ""}" data-act="troopup" data-k="${k}">ارتقا<br>🪙 ${fa(c)}</button>`}</div>`; }).join("")}</div>`;
  else h += `<div class="grid g2">${Object.keys(RESEARCH).map((k) => { const r = RESEARCH[k], l = SV.rLvl(k), c = Math.round(rCost(k, l) * disc("forge", 0.04)); return `<div class="card item"><div class="ic">${r.emoji}</div><div class="grow"><b>${r.name}</b> <span class="chip">${fa(l)}/${fa(r.max)}</span><div class="xs mut">${r.per}</div></div>${l >= r.max ? `<span class="chip">کامل</span>` : `<button class="btn s ${S.coins < c ? "off" : ""}" data-act="research" data-k="${k}">ارتقا<br>🪙 ${fa(c)}</button>`}</div>`; }).join("")}</div>`;
  return h;
}
function openAttack(id) {
  const nb = NEIGHBORS.find((n) => n.id === id), ready = TROOP_ORDER.filter((k) => S.buildings.barracks >= TROOPS[k].barracks);
  modal(`${closeBtn}<h2>${nb.emoji} ${nb.name}</h2><div class="c mut sm">${nb.ruler} • قدرت ${fa(nb.power)} • دروازه ❤️ ${fa(nb.gate)} • ${fa(nb.towers)} برج دفاعی</div>
  <div class="card sm" style="margin:10px 0">سربازان را با انرژی (⚡) به مسیر بفرست. برج‌های دشمن به آن‌ها شلیک می‌کنند؛ کماندارها برج‌ها را سوراخ می‌کنند، دروازه‌شکن‌ها دروازه را می‌شکنند. <b>${fa(ATTACK_TIME)} ثانیه</b> وقت داری!</div>
  <div class="row wrap c" style="justify-content:center">${ready.map((k) => `<span class="chip">${TROOPS[k].emoji} ${TROOPS[k].name} سطح ${fa(S.troops[k])}</span>`).join("")}</div>
  <div class="row c" style="justify-content:center;margin:10px 0"><span class="chip">🪙 ${fa(nb.loot)}</span><span class="chip">💎 ${fa(nb.gems)}</span></div>
  <button class="btn l r" style="width:100%" data-act="goattack" data-id="${id}">حمله! ⚔️</button>`);
}
function startAttack(id) {
  const nb = NEIGHBORS.find((n) => n.id === id), troopLv = {}; for (const k of TROOP_ORDER) troopLv[k] = S.troops[k];
  closeModal(); runBattle({ mode: "attack", mapIndex: nb.map, neighbor: nb, troopLv, troops: TROOP_ORDER.filter((k) => S.buildings.barracks >= TROOPS[k].barracks), title: nb.name, music: "attack", gold: 0, lives: 1 });
}
function startDefense() {
  const r = S.raid.pending, nb = NEIGHBORS.find((n) => n.id === r.id), mods = SV.mods(), unlocked = TOWER_ORDER.filter((k) => TOWERS[k].unlock === 0 || S.stars[TOWERS[k].unlock - 1] > 0), heroLv = {}; for (const k in S.heroes) heroLv[k] = S.heroes[k].lvl;
  const map = Object.assign({}, MAPS[0], { name: "دفاع از کشور", boss: { name: "سردار " + nb.ruler.split(" ").pop(), ability: "summon" }, gold: 320 + SV.kingdomLevel() * 4, lives: 10 + S.buildings.walls * 2, music: "raid" });
  runBattle({ mode: "td", mapIndex: 0, map, raid: true, waves: genRaidWaves(r.power, SV.kingdomLevel()), mods, unlocked, heroes: S.loadout.filter(Boolean), heroLv, title: "دفاع از کشور", music: "raid" });
}

// ---------- قهرمانان ----------
function tabHeroes() {
  return `<div class="row" style="margin-bottom:8px"><div class="title">قهرمانان</div><div class="grow"></div><span class="chip">در تیم: ${S.loadout.filter(Boolean).map((k) => HEROES[k].emoji).join(" ") || "—"}</span></div><div class="grid g2">${HERO_ORDER.map((k) => {
    const d = HEROES[k], o = S.heroes[k], l = o ? o.lvl : 1, c = Math.round(heroUpCost(k, l) * disc("academy", 0.04));
    return `<div class="card col" style="border-color:${d.color}66"><div class="row"><div class="hero-art" style="border-color:${d.color}">${d.emoji}</div><div class="grow"><b style="font-size:16px">${d.name}</b><div class="xs" style="color:${d.color}">${d.title}</div><div class="xs mut">${d.lore}</div></div>${o ? `<span class="chip">سطح ${fa(l)}</span>` : ""}</div>
    <div class="row wrap xs"><span class="chip">⚔️ ${fa(d.dmg * heroMul(l))}</span><span class="chip">🎯 ${d.range}</span><span class="chip">⏱️ ${fa(d.skill.cd)}ث</span></div>
    <div class="card xs" style="padding:6px"><b style="color:${d.color}">✨ ${d.skill.name}:</b> ${d.skill.desc}</div>
    ${o ? `<div class="row"><button class="btn s ${S.loadout.includes(k) ? "g" : "d"} grow" data-act="loadout2" data-k="${k}">${S.loadout.includes(k) ? "✔ در تیم" : "افزودن به تیم"}</button>${l >= HERO_MAX ? '<span class="chip">سقف</span>' : `<button class="btn s grow ${S.coins < c ? "off" : ""}" data-act="heroup" data-k="${k}">ارتقا 🪙 ${fa(c)}</button>`}</div>` : `<button class="btn ${SV.canPay(d.cost) ? "" : "off"}" data-act="herobuy" data-k="${k}">خرید ${cost(d.cost)}</button>`}</div>`; }).join("")}</div>`;
}

// ---------- مغازه ----------
function tabShop() {
  const m = disc("market", 0.03);
  return `<div class="title" style="margin-bottom:6px">مغازه</div><div class="sm mut" style="margin-bottom:6px">صندوق‌ها — تخفیف بازار: <span dir="ltr">${fa(Math.round((1 - m) * 100))}٪</span></div>
  <div class="grid g3">${Object.keys(CHESTS).map((k) => { const c = CHESTS[k], pr = c.price.coins ? { coins: Math.round(c.price.coins * m) } : { gems: Math.round(c.price.gems * m) }; return `<div class="card c col" style="border-color:${c.color}88"><div class="chest">${c.emoji}</div><b>${c.name}</b><div class="xs mut">${c.desc}</div><button class="btn ${SV.canPay(pr) ? "" : "off"}" data-act="chest" data-k="${k}">${cost(pr)}</button></div>`; }).join("")}</div>
  <div class="sm mut" style="margin:12px 0 6px">تقویت‌کننده‌ها (یک‌بار مصرف)</div><div class="grid g3">${Object.keys(BOOSTERS).map((k) => { const b = BOOSTERS[k]; return `<div class="card item"><div class="ic">${b.emoji}</div><div class="grow"><b>${b.name}</b> <span class="chip">×${fa(S.boosters[k])}</span><div class="xs mut">${b.desc}</div></div><button class="btn s ${SV.canPay(b.price) ? "" : "off"}" data-act="boost" data-k="${k}">${cost(b.price)}</button></div>`; }).join("")}</div>
  <div class="sm mut" style="margin:12px 0 6px">تبدیل جواهر به سکه</div><div class="grid g3">${GEM_EXCHANGE.map((g, i) => `<div class="card c col"><div class="big">🪙 ${fa(g.coins)}</div><button class="btn b s ${S.gems >= g.gems ? "" : "off"}" data-act="exch" data-i="${i}">💎 ${fa(g.gems)}</button></div>`).join("")}</div>`;
}
function openChest(kind) {
  const c = CHESTS[kind], m = disc("market", 0.03), pr = c.price.coins ? { coins: Math.round(c.price.coins * m) } : { gems: Math.round(c.price.gems * m) };
  if (!SV.pay(pr)) { toast("موجودی کافی نیست"); Sound.sfx("error"); return; }
  const got = SV.openChest(kind); SV.save();
  modal(`<div class="c" id="chestbox"><div class="chest" style="font-size:96px;animation:pulse .25s infinite">${c.emoji}</div><div class="mut">در حال باز شدن…</div></div>`); Sound.sfx("chest_open");
  setTimeout(() => { Sound.jingle("chest"); $("#modal .dlg").innerHTML = `<h2>${c.emoji} ${c.name}</h2><div class="col c" style="align-items:center;gap:10px"><div class="res big">🪙 ${fa(got.coins)}</div>${got.gems ? `<div class="res big">💎 ${fa(got.gems)}</div>` : ""}${got.extra.map((e) => `<div class="res">${BOOSTERS[e].emoji} ${BOOSTERS[e].name}</div>`).join("")}${got.hero ? `<div class="card c" style="border-color:${HEROES[got.hero].color}"><div class="hero-art" style="border-color:${HEROES[got.hero].color};margin:auto">${HEROES[got.hero].emoji}</div><b>قهرمان جدید: ${HEROES[got.hero].name}!</b></div>` : ""}</div><button class="btn l g" style="width:100%;margin-top:14px" data-act="close">عالی!</button>`; }, 1100);
}

// ---------- اتحاد ----------
function tabAlliance() {
  if (S.buildings.hall < 1) return `<div class="title">اتحاد</div><div class="card c" style="padding:30px"><div style="font-size:50px">🏛️</div><p>برای پیوستن یا ساختن اتحاد، ابتدا <b>تالار اتحاد</b> را در بخش کشور بساز.</p><button class="btn" data-act="gokingdom">رفتن به کشور</button></div>`;
  const a = S.alliance;
  if (!a) return `<div class="title">اتحاد</div><div class="mut sm" style="margin-bottom:8px">با هم‌پیمانان سکه جمع کن، ماموریت هفتگی را کامل کن و از جایزه‌های اتحاد بهره ببر. (اعضا شبیه‌سازی شده‌اند)</div>
  <div class="grid g2">${SV.allianceOffers().map((o, i) => `<div class="card item"><div class="ic">${o.emoji}</div><div class="grow"><b>${o.name}</b><div class="xs mut">سطح ${fa(o.level)} • ${fa(o.members)} عضو</div></div><button class="btn s g" data-act="join" data-i="${i}">پیوستن</button></div>`).join("")}</div>
  <div class="card col" style="margin-top:10px"><b>ساخت اتحاد جدید — 🪙 ${fa(1000)}</b><input type="text" id="aname" maxlength="18" placeholder="نام اتحاد"><div class="row">${["🦁", "🦅", "🐉", "⚔️", "🔥", "🌟"].map((e, i) => `<button class="ibtn" data-act="aemo" data-e="${e}" id="ae${i}" style="${i === 0 ? "background:var(--gold)" : ""}">${e}</button>`).join("")}<div class="grow"></div><button class="btn ${S.coins >= 1000 ? "" : "off"}" data-act="acreate">ساخت</button></div></div>`;
  const perk = ALLIANCE_PERK(a.level), need = SV.allyNeed(a.level), g = a.goal;
  return `<div class="row" style="margin-bottom:8px"><div class="title">${a.emoji} ${a.name}</div><div class="grow"></div><span class="chip">سطح ${fa(a.level)}</span><span class="chip">👥 ${fa(a.members.length)}/${fa(SV.allyCap())}</span></div>
  <div class="grid g2"><div class="card col"><div class="row"><b>پیشرفت اتحاد</b><div class="grow"></div><span class="xs mut">${fa(a.xp)} / ${fa(need)}</span></div>${bar(a.xp, need, "xp")}<div class="xs">🎁 امتیاز: +${fa(perk.coin * 100)}٪ سکه و +${fa(perk.dmg * 100)}٪ آسیب برج‌ها</div><div class="row">${[500, 2000, 10000].map((v) => `<button class="btn s grow ${S.coins >= v ? "" : "off"}" data-act="donate" data-v="${v}">🪙 ${fa(v)}</button>`).join("")}</div></div>
  <div class="card col"><div class="row"><b>ماموریت هفتگی: ستاره جمع کنید</b><div class="grow"></div><span class="xs mut">${fa(g.progress)}/${fa(g.target)}</span></div>${bar(g.progress, g.target, "y")}<div class="xs mut">با پیروزی در نبردها ستاره به اتحاد کمک می‌کنی</div>${g.claimed ? '<span class="chip">دریافت شد ✔</span>' : `<button class="btn g ${g.progress >= g.target ? "" : "off"}" data-act="aclaim">🎁 دریافت جایزه</button>`}</div></div>
  <div class="grid g2" style="margin-top:10px"><div class="card"><b>اعضا</b><div class="col" style="margin-top:6px;max-height:190px;overflow:auto">${a.members.slice().sort((x, y) => y.don - x.don).map((m, i) => `<div class="row sm"><span class="chip">${fa(i + 1)}</span><span class="grow" style="${m.me ? "color:var(--gold)" : ""}">${m.name}</span><span class="mut">💪${fa(m.power)}</span><span class="gold">🪙${fa(m.don)}</span></div>`).join("")}</div></div>
  <div class="card"><b>گفتگو</b><div class="chat" style="margin-top:6px">${a.feed.slice(-12).map((f) => `<div><b>${f.who}:</b> ${f.msg}</div>`).join("") || '<span class="mut">هنوز پیامی نیست</span>'}</div></div></div>
  <div style="margin-top:10px"><button class="btn d s" data-act="aleave">ترک اتحاد</button></div>`;
}

// ---------- ماموریت و تنظیمات ----------
function openMissions() {
  modal(`${closeBtn}<h2>🎯 ماموریت‌ها</h2><div class="sm mut c">پاداش ورود روزانه</div><div class="grid" style="grid-template-columns:repeat(7,1fr);gap:5px;margin:6px 0">${DAILY_REWARDS.map((r, i) => `<div class="card c xs" style="padding:5px;${i === S.daily.idx ? "border-color:var(--gold);background:rgba(255,210,74,.15)" : ""}${i < S.daily.idx || (i === S.daily.idx && S.daily.claimed) ? ";opacity:.5" : ""}"><div>روز ${fa(i + 1)}</div><div class="big">${r.gems ? "💎" : "🪙"}</div><b>${fa(r.gems || r.coins)}</b>${r.chest ? "<div>+📦</div>" : ""}</div>`).join("")}</div>
  <button class="btn g ${S.daily.claimed ? "off" : ""}" style="width:100%" data-act="daily">${S.daily.claimed ? "امروز دریافت شد ✔" : "🎁 دریافت هدیه‌ی امروز"}</button>
  <div class="sm mut c" style="margin:12px 0 6px">ماموریت‌های امروز</div><div class="col">${S.missions.list.map((m, i) => { const d = MISSION_POOL.find((x) => x.id === m.id), ok = m.p >= d.target; return `<div class="card row"><div class="grow"><div>${d.text}</div>${bar(m.p, d.target, "y")}<div class="xs mut">${fa(m.p)} / ${fa(d.target)} • ${cost(d.reward)}</div></div>${m.claimed ? '<span class="chip">✔</span>' : `<button class="btn s ${ok ? "g" : "off"}" data-act="mclaim" data-i="${i}">دریافت</button>`}</div>`; }).join("")}</div>`);
}
function openSettings() {
  modal(`${closeBtn}<h2>⚙️ تنظیمات</h2><div class="col" style="gap:12px"><div><div class="sm">🎵 صدای موسیقی</div><input type="range" min="0" max="100" value="${Math.round(S.settings.music * 100)}" data-rng="music"></div><div><div class="sm">🔊 جلوه‌های صوتی</div><input type="range" min="0" max="100" value="${Math.round(S.settings.sfx * 100)}" data-rng="sfx"></div>
  <div class="row"><span class="grow">📳 لرزش</span><button class="btn s ${S.settings.vibrate ? "g" : "d"}" data-act="vib">${S.settings.vibrate ? "روشن" : "خاموش"}</button></div>
  <div class="card xs mut">پیشرفت شما به‌صورت خودکار روی همین دستگاه ذخیره می‌شود و با بستن بازی از بین نمی‌رود.<br>بازی: بستیون — حماسه‌ی ایران‌زمین</div><button class="btn r s" data-act="reset">پاک کردن کل پیشرفت</button></div>`);
}

// ---------- کنش‌ها ----------
const A = {
  close() { closeModal(); refresh(); },
  tab(d) { ui.tab = d.t; refresh(); }, ksub(d) { ui.ksub = d.k; refresh(); }, gokingdom() { ui.tab = "kingdom"; refresh(); },
  map(d) { openMap(+d.i); }, hard(d) { ui.pre.hard = d.v === "1"; openMap(ui.pre.i); }, play: startMap,
  booster(d) { if (S.boosters[d.k] <= 0) { toast("ابتدا از مغازه بخر"); return; } S.picked[d.k] = !S.picked[d.k]; openMap(ui.pre.i); },
  loadout(d) { toggleLoadout(d.k); openMap(ui.pre.i); }, loadout2(d) { toggleLoadout(d.k); refresh(); },
  again(d) { const i = +d.i; ui.pre = null; ui.tab = "battle"; openMap(i); },
  missions: openMissions, settings: openSettings,
  daily() { const r = SV.claimDaily(); if (r) { Sound.sfx("daily"); if (r.chest) { S.boosters.power++; } toast("🎁 هدیه دریافت شد!"); } openMissions(); refresh(); },
  mclaim(d) { const r = SV.claimMission(+d.i); if (r) { Sound.sfx("collect"); toast("✔ پاداش دریافت شد"); } openMissions(); refresh(); },
  vib() { S.settings.vibrate = !S.settings.vibrate; SV.save(); openSettings(); },
  reset() { if (confirm("همه‌ی پیشرفت پاک شود؟")) { SV.resetAll(); closeModal(); refresh(); } },
  collect() { const p = SV.collectMine(); if (p.coins + p.gems > 0) { Sound.sfx("collect"); toast(`+${fa(p.coins)} 🪙 ${p.gems ? "+" + fa(p.gems) + " 💎" : ""}`); } refresh(); },
  build(d) { const k = d.k, l = S.buildings[k], c = bCost(k, l); if (!SV.pay({ coins: c })) { toast("سکه کافی نیست"); Sound.sfx("error"); return; } if (k === "mine" || k === "gem") SV.collectMine(); if (k === "gem" && l === 0) S.gemT = Date.now(); S.buildings[k]++; Sound.sfx("build"); Sound.sfx("upgrade"); SV.save(); refresh(); },
  troopup(d) { const k = d.k, l = S.troops[k], c = Math.round(troopUpCost(k, l) * disc("academy", 0.04)); if (l >= Math.min(TROOP_MAX, S.buildings.barracks * 2 + 1)) { toast("ابتدا پادگان را ارتقا بده"); return; } if (!SV.pay({ coins: c })) { Sound.sfx("error"); return; } S.troops[k]++; Sound.sfx("upgrade"); SV.save(); refresh(); },
  research(d) { const k = d.k, l = SV.rLvl(k), c = Math.round(rCost(k, l) * disc("forge", 0.04)); if (l >= RESEARCH[k].max || !SV.pay({ coins: c })) { Sound.sfx("error"); return; } S.research[k] = l + 1; Sound.sfx("upgrade"); SV.save(); refresh(); },
  atk(d) { openAttack(d.id); }, goattack(d) { startAttack(d.id); }, defend() { startDefense(); },
  autodef() { const r = SV.resolveRaid(false, false, true); SV.save(); refresh(); modal(`${closeBtn}<h2>${r.won ? "🛡️ نگهبانان پیروز شدند" : "😔 نگهبانان شکست خوردند"}</h2><div class="c">${r.won ? `غنیمت: 🪙 ${fa(r.loot)}` : `غارتگران ${fa(r.lost)} سکه بردند`}</div>`); Sound.jingle(r.won ? "levelup" : "defeat"); },
  heroup(d) { const k = d.k, l = S.heroes[k].lvl, c = Math.round(heroUpCost(k, l) * disc("academy", 0.04)); if (!SV.pay({ coins: c })) { Sound.sfx("error"); return; } S.heroes[k].lvl++; Sound.sfx("upgrade"); SV.save(); refresh(); },
  herobuy(d) { const k = d.k; if (!SV.pay(HEROES[k].cost)) { toast("موجودی کافی نیست"); Sound.sfx("error"); return; } S.heroes[k] = { lvl: 1 }; Sound.jingle("levelup"); toast(`${HEROES[k].name} به تو پیوست!`); const e = S.loadout.indexOf(null); if (e >= 0) S.loadout[e] = k; SV.save(); refresh(); },
  chest(d) { openChest(d.k); }, boost(d) { if (!SV.pay(BOOSTERS[d.k].price)) { Sound.sfx("error"); toast("موجودی کافی نیست"); return; } S.boosters[d.k]++; Sound.sfx("coin"); SV.save(); refresh(); },
  exch(d) { const g = GEM_EXCHANGE[+d.i]; if (!SV.pay({ gems: g.gems })) { Sound.sfx("error"); return; } SV.give({ coins: g.coins }); Sound.sfx("coin"); SV.save(); refresh(); },
  join(d) { SV.joinAlliance(SV.allianceOffers()[+d.i]); Sound.sfx("daily"); refresh(); },
  aemo(d, el) { ui.aemo = d.e; document.querySelectorAll("[data-act=aemo]").forEach((b) => (b.style.background = "")); el.style.background = "var(--gold)"; },
  acreate() { const n = ($("#aname").value || "").trim(); if (n.length < 2) { toast("نام اتحاد را وارد کن"); return; } if (!SV.pay({ coins: 1000 })) return; SV.createAlliance(n, ui.aemo || "🦁"); Sound.sfx("daily"); refresh(); },
  donate(d) { if (SV.donate(+d.v)) { Sound.sfx("coin"); toast("به اتحاد کمک شد 🙏"); } refresh(); },
  aclaim() { const r = SV.claimAllianceGoal(); if (r) { Sound.jingle("chest"); toast(`🎁 ${fa(r.coins)} سکه و ${fa(r.gems)} جواهر`); } refresh(); },
  aleave() { if (confirm("اتحاد را ترک می‌کنی؟")) { SV.leaveAlliance(); refresh(); } },
};
function toggleLoadout(k) { const i = S.loadout.indexOf(k); if (i >= 0) S.loadout[i] = null; else { const e = S.loadout.indexOf(null); if (e >= 0) S.loadout[e] = k; else S.loadout[1] = k; } SV.saveSoon(); }

export function initUI() {
  document.addEventListener("click", (e) => { const el = e.target.closest("[data-act]"); if (!el || el.classList.contains("off")) return; Sound.init(); Sound.sfx(el.dataset.act === "close" ? "back" : "click"); const f = A[el.dataset.act]; if (f) f(el.dataset, el); });
  document.addEventListener("input", (e) => { const r = e.target.dataset && e.target.dataset.rng; if (!r) return; S.settings[r] = e.target.value / 100; r === "music" ? Sound.setMusicVolume(S.settings.music) : Sound.setSfxVolume(S.settings.sfx); SV.saveSoon(); if (r === "sfx") Sound.sfx("coin"); });
  document.addEventListener("pointerdown", () => Sound.init(), { once: true });
  $("#modal").addEventListener("click", (e) => { if (e.target.id === "modal") A.close(); });
  setInterval(() => { if (!document.hidden && $("#hub") && !$("#modal").classList.contains("on") && ui.tab === "kingdom") refresh(); }, 15000);
}
export { runBattle };
