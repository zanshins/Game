// هنر رویه‌ای نقشه‌ی بزرگ: جانوران، قایق، روستا/شهر/قلعه، پرچم، دود، آتش
const TAU = Math.PI * 2;
export const rgb = (h) => { if (h[0] === "#") { const n = parseInt(h.length === 4 ? h.replace(/./g, (c, i) => (i ? c + c : c)).slice(1) : h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; } return h; };
export const sh = (h, k) => { const [r, g, b] = rgb(h); const f = (v) => Math.max(0, Math.min(255, Math.round(v * k))); return `rgb(${f(r)},${f(g)},${f(b)})`; };
export const mix = (a, b, t) => { const A = rgb(a), B = rgb(b); return `rgb(${Math.round(A[0] + (B[0] - A[0]) * t)},${Math.round(A[1] + (B[1] - A[1]) * t)},${Math.round(A[2] + (B[2] - A[2]) * t)})`; };
const rnd = (s) => () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
// ---------------- جانوران ----------------
const BP = {
  wolf: { L: 30, H: 11, leg: 12, lw: 3.2, col: "#7d7f86", dark: "#4c4e56", belly: "#c4c6cc", head: 6.5, snout: 7, ear: 1, tail: "bushy", sc: 1.15 },
  bear: { L: 38, H: 19, leg: 12, lw: 6.5, col: "#5b3a24", dark: "#35200f", belly: "#704a30", head: 9.5, snout: 5, ear: 0, tail: "stub", hump: 7, sc: 1.25 },
  boar: { L: 34, H: 15, leg: 8, lw: 3.8, col: "#5e4c40", dark: "#2f261d", belly: "#76624f", head: 8, snout: 8.5, ear: 1, tail: "curl", tusk: 1, mane: 1, sc: 1.05 },
  lion: { L: 38, H: 13.5, leg: 12.5, lw: 4.4, col: "#c9984c", dark: "#8a5a24", belly: "#e2bd7e", head: 8.5, snout: 5.5, ear: 0, tail: "tuft", mane: 1, sc: 1.2 },
};
export function drawBeast(g, type, x, y, dir, ph, mv, s = 1, atk = 0) {
  const P = BP[type] || BP.wolf; s *= P.sc;
  g.save(); g.translate(x, y); g.scale(dir * s, s); g.lineCap = "round"; g.lineJoin = "round";
  g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(0, 1, P.L * 0.62, 4.2, 0, 0, TAU); g.fill();
  const sw = mv ? Math.sin(ph * 1.6) : 0, bob = mv ? -Math.abs(Math.sin(ph * 1.6)) * 1.6 : Math.sin(ph * 0.5) * 0.5, lunge = atk * 7;
  g.translate(lunge, bob);
  const by = -P.leg - P.H * 0.5, L = P.L, hipX = -L * 0.3, shX = L * 0.28;
  const leg = (hx, ph2, col) => { const a = Math.sin(ph2) * (mv ? 0.8 : 0.05), u = P.leg * 0.55, lo = P.leg * 0.55, kx = hx + Math.sin(a) * u, ky = -P.leg + P.H * 0.1 + Math.cos(a) * u, lift = mv && Math.cos(ph2) > 0 ? -2.6 : 0, fx = kx + Math.sin(-a * 0.6) * lo, fy = Math.min(0, ky + Math.cos(-a * 0.6) * lo + lift);
    g.strokeStyle = col; g.lineWidth = P.lw; g.beginPath(); g.moveTo(hx, -P.leg + P.H * 0.15); g.lineTo(kx, ky); g.lineTo(fx, fy); g.stroke(); g.fillStyle = col; g.beginPath(); g.ellipse(fx + 1, fy, P.lw * 0.75, P.lw * 0.45, 0, 0, TAU); g.fill(); };
  const p0 = ph * 1.6;
  // دم
  g.strokeStyle = P.dark; g.fillStyle = P.dark; const tw = mv ? Math.sin(ph * 2) * 3 : Math.sin(ph) * 1.5;
  if (P.tail === "bushy") { g.lineWidth = 4.5; g.beginPath(); g.moveTo(-L * 0.46, by - 1); g.quadraticCurveTo(-L * 0.78, by + 4 + tw, -L * 0.7, by + 12 + tw); g.stroke(); g.strokeStyle = P.col; g.lineWidth = 2; g.stroke(); }
  else if (P.tail === "tuft") { g.lineWidth = 2; g.beginPath(); g.moveTo(-L * 0.46, by); g.quadraticCurveTo(-L * 0.8, by - 3 + tw, -L * 0.7, by + 10); g.stroke(); g.fillStyle = "#6a3a14"; g.beginPath(); g.ellipse(-L * 0.7, by + 11, 3, 4.5, 0, 0, TAU); g.fill(); }
  else if (P.tail === "curl") { g.lineWidth = 1.8; g.beginPath(); g.arc(-L * 0.52, by - 2, 3.5, 0.5, 5.2); g.stroke(); }
  else { g.beginPath(); g.ellipse(-L * 0.5, by, 3, 2.4, 0, 0, TAU); g.fill(); }
  // پاهای دورتر
  leg(hipX + 3, p0 + Math.PI * 0.9, P.dark); leg(shX + 3, p0 + 0.2 + Math.PI, P.dark);
  // بدن
  const gr = g.createLinearGradient(0, by - P.H * 0.6, 0, by + P.H * 0.6); gr.addColorStop(0, sh(P.col, 1.15)); gr.addColorStop(0.55, P.col); gr.addColorStop(1, P.belly);
  g.fillStyle = gr; g.strokeStyle = "rgba(0,0,0,0.55)"; g.lineWidth = 1;
  g.beginPath(); g.ellipse(0, by, L * 0.52, P.H * 0.55, 0, 0, TAU); g.fill(); g.stroke();
  g.beginPath(); g.ellipse(shX * 0.9, by - P.H * 0.05, L * 0.26, P.H * 0.6, 0, 0, TAU); g.fill();   // سینه
  if (P.hump) { g.fillStyle = P.col; g.beginPath(); g.ellipse(L * 0.12, by - P.H * 0.45, L * 0.22, P.H * 0.35, 0, 0, TAU); g.fill(); }
  g.strokeStyle = "rgba(0,0,0,0.2)"; g.lineWidth = 0.8; for (let i = -3; i <= 3; i++) { g.beginPath(); g.moveTo(i * 4, by - P.H * 0.5); g.lineTo(i * 4 - 1.5, by - P.H * 0.15); g.stroke(); }
  if (P.mane) { g.fillStyle = type === "lion" ? "#7a4416" : "#2a2018"; if (type === "lion") { g.beginPath(); g.ellipse(L * 0.4, by - 1, P.head * 1.45, P.head * 1.45, 0, 0, TAU); g.fill(); } else { g.beginPath(); g.moveTo(-L * 0.28, by - P.H * 0.5); for (let i = 0; i < 9; i++) g.lineTo(-L * 0.28 + i * 3.6 + 1.5, by - P.H * 0.78 - (i % 2) * 2.2); g.lineTo(L * 0.3, by - P.H * 0.4); g.closePath(); g.fill(); } }
  // گردن و سر
  const hx = L * 0.5 + (type === "bear" ? 1 : 3), hy = by - P.H * (type === "wolf" ? 0.2 : 0.1) + (atk ? 1.5 : 0) - (type === "wolf" ? 2 : 0);
  g.fillStyle = P.col; g.strokeStyle = "rgba(0,0,0,0.55)"; g.lineWidth = 1; g.beginPath(); g.moveTo(L * 0.3, by - P.H * 0.5); g.lineTo(hx, hy - P.head * 0.6); g.lineTo(hx, hy + P.head * 0.6); g.lineTo(L * 0.28, by + P.H * 0.4); g.closePath(); g.fill();
  const jaw = atk > 0.2 ? 0.5 + atk * 4 : (mv ? 0.2 : 0);
  g.beginPath(); g.ellipse(hx, hy, P.head, P.head * 0.82, 0, 0, TAU); g.fill(); g.stroke();
  g.fillStyle = type === "lion" ? "#d8ae6a" : sh(P.col, 0.92); g.beginPath(); g.ellipse(hx + P.head * 0.8 + P.snout * 0.35, hy + P.head * 0.22, P.snout * 0.8, P.head * 0.42, 0, 0, TAU); g.fill(); g.stroke();
  g.fillStyle = "#1a1210"; g.beginPath(); g.arc(hx + P.head * 0.8 + P.snout * 1.0, hy + P.head * 0.06, 1.8, 0, TAU); g.fill();
  if (jaw > 0.4) { g.fillStyle = "#8a1a1a"; g.beginPath(); g.ellipse(hx + P.head * 0.8 + P.snout * 0.3, hy + P.head * 0.55 + jaw * 0.4, P.snout * 0.6, jaw, 0, 0, TAU); g.fill(); g.fillStyle = "#fff"; for (let i = 0; i < 3; i++) g.fillRect(hx + P.head * 0.8 + i * 2.2, hy + P.head * 0.4, 1.2, 2.4); }
  g.fillStyle = P.dark; if (P.ear) { g.beginPath(); g.moveTo(hx - P.head * 0.55, hy - P.head * 0.6); g.lineTo(hx - P.head * 0.2, hy - P.head * 1.55); g.lineTo(hx + P.head * 0.25, hy - P.head * 0.65); g.closePath(); g.fill(); g.stroke(); } else { g.beginPath(); g.arc(hx - P.head * 0.3, hy - P.head * 0.8, P.head * 0.36, 0, TAU); g.fill(); g.stroke(); }
  g.fillStyle = atk > 0.1 || type === "wolf" ? "#ffd24a" : "#fff"; g.beginPath(); g.ellipse(hx + P.head * 0.42, hy - P.head * 0.22, 1.8, 1.3, 0.3, 0, TAU); g.fill(); g.fillStyle = "#111"; g.fillRect(hx + P.head * 0.46, hy - P.head * 0.28, 1, 1.4);
  if (P.tusk) { g.fillStyle = "#f2ecd8"; g.beginPath(); g.moveTo(hx + P.head * 0.9 + P.snout * 0.5, hy + P.head * 0.4); g.quadraticCurveTo(hx + P.head * 1.3 + P.snout * 0.7, hy + P.head * 0.3, hx + P.head * 1.2 + P.snout * 0.7, hy - P.head * 0.35); g.lineTo(hx + P.head * 1.0 + P.snout * 0.6, hy + P.head * 0.2); g.fill(); }
  // پاهای نزدیک‌تر
  leg(hipX, p0, P.col); leg(shX, p0 + 0.2, P.col);
  g.restore();
}
// ---------------- قایق ----------------
export function drawBoat(g, x, y, t, dir, s = 1, moving = false) {
  g.save(); g.translate(x, y); const bob = Math.sin(t * 2.4 + x * 0.01) * 1.6;
  // موج و کف
  for (let i = 0; i < 3; i++) { const r = ((t * 0.6 + i / 3) % 1); g.strokeStyle = `rgba(255,255,255,${0.35 * (1 - r)})`; g.lineWidth = 1.5; g.beginPath(); g.ellipse(0, 4, (22 + r * 26) * s, (6 + r * 9) * s, 0, 0, TAU); g.stroke(); }
  if (moving) { g.strokeStyle = "rgba(255,255,255,0.45)"; g.lineWidth = 2; g.beginPath(); g.moveTo(-dir * 20 * s, 4); g.lineTo(-dir * 52 * s, -4 * s); g.moveTo(-dir * 20 * s, 6); g.lineTo(-dir * 52 * s, 14 * s); g.stroke(); }
  g.translate(0, bob); g.scale(dir * s, s);
  g.fillStyle = "rgba(0,0,0,0.28)"; g.beginPath(); g.ellipse(0, 6, 24, 5, 0, 0, TAU); g.fill();
  g.fillStyle = "#6a4222"; g.strokeStyle = "#2a1608"; g.lineWidth = 1.4; g.beginPath(); g.moveTo(-24, -4); g.quadraticCurveTo(-18, 7, 0, 8); g.quadraticCurveTo(18, 7, 28, -8); g.lineTo(24, -4); g.closePath(); g.fill(); g.stroke();
  g.fillStyle = "#8a5a30"; g.beginPath(); g.moveTo(-24, -4); g.lineTo(24, -4); g.lineTo(28, -8); g.lineTo(-22, -8); g.closePath(); g.fill(); g.stroke();
  g.strokeStyle = "#3a2010"; g.lineWidth = 1; for (let i = -16; i <= 16; i += 8) { g.beginPath(); g.moveTo(i, -3); g.lineTo(i * 0.9, 4); g.stroke(); }
  g.fillStyle = "#c8a24a"; g.beginPath(); g.arc(27, -9, 2, 0, TAU); g.fill();
  g.strokeStyle = "#4a2c14"; g.lineWidth = 2.4; g.beginPath(); g.moveTo(0, -6); g.lineTo(0, -44); g.stroke();
  const w = Math.sin(t * 2 + 1) * 2;
  g.fillStyle = "#f2ead2"; g.beginPath(); g.moveTo(1, -42); g.quadraticCurveTo(22 + w, -30, 17, -10 + w * 0.3); g.lineTo(1, -10); g.closePath(); g.fill(); g.strokeStyle = "rgba(60,40,20,0.7)"; g.lineWidth = 1; g.stroke();
  g.fillStyle = "rgba(180,150,100,0.35)"; g.beginPath(); g.moveTo(1, -42); g.quadraticCurveTo(8 + w * 0.4, -30, 6, -10); g.lineTo(1, -10); g.closePath(); g.fill();
  g.fillStyle = "#c83a2a"; g.beginPath(); g.moveTo(0, -44); g.lineTo(-11 - w, -41); g.lineTo(0, -38); g.closePath(); g.fill();
  g.restore();
}
// ---------------- پرچم / دود / آتش ----------------
export function drawFlag(g, x, y, t, col, s = 1, h = 18) {
  g.save(); g.translate(x, y); g.scale(s, s); g.strokeStyle = "#3a2a1a"; g.lineWidth = 1.6; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -h - 4); g.stroke();
  const w = Math.sin(t * 4 + x * 0.1) * 2.2; g.fillStyle = col; g.beginPath(); g.moveTo(0, -h - 3); g.quadraticCurveTo(7, -h - 6 + w, 15 + w, -h - 1); g.quadraticCurveTo(8, -h + 1 - w, 15 + w, -h + 5); g.quadraticCurveTo(7, -h + 4 + w, 0, -h + 7); g.closePath(); g.fill(); g.strokeStyle = "rgba(0,0,0,0.5)"; g.lineWidth = 0.8; g.stroke();
  g.fillStyle = "#ffd24a"; g.beginPath(); g.arc(0, -h - 4, 1.8, 0, TAU); g.fill(); g.restore();
}
export function drawSmoke(g, x, y, t, n = 5) {
  for (let i = 0; i < n; i++) { const p = ((t * 0.28 + i / n) % 1), a = (1 - p) * 0.38; g.fillStyle = `rgba(230,230,235,${a})`; g.beginPath(); g.arc(x + Math.sin(t + i * 2) * 3 * p + p * 5, y - p * 26, 2 + p * 5, 0, TAU); g.fill(); }
}
export function drawFire(g, x, y, t, s = 1) {
  g.save(); g.translate(x, y); g.scale(s, s);
  const gl = g.createRadialGradient(0, -6, 2, 0, -6, 46); gl.addColorStop(0, "rgba(255,170,60,0.45)"); gl.addColorStop(1, "rgba(255,120,20,0)"); g.fillStyle = gl; g.beginPath(); g.arc(0, -6, 46, 0, TAU); g.fill();
  g.fillStyle = "#3a2a1a"; for (let i = 0; i < 5; i++) { g.save(); g.rotate(i * 1.26); g.fillRect(-9, -1.8, 18, 3.6); g.restore(); }
  for (let i = 0; i < 3; i++) { const f = 1 - i * 0.28, w = Math.sin(t * 9 + i * 2) * 1.8; g.fillStyle = ["#ff5a1a", "#ff9a2a", "#ffe46a"][i]; g.beginPath(); g.moveTo(-6 * f, 0); g.quadraticCurveTo(-5 * f + w, -12 * f, w, -22 * f - Math.sin(t * 11 + i) * 2); g.quadraticCurveTo(5 * f + w, -12 * f, 6 * f, 0); g.closePath(); g.fill(); }
  for (let i = 0; i < 4; i++) { const p = (t * 0.9 + i * 0.25) % 1; g.fillStyle = `rgba(255,${180 + i * 20},80,${1 - p})`; g.fillRect(Math.sin(i * 3 + t * 3) * 8, -14 - p * 30, 1.5, 1.5); }
  g.restore();
}
// ---------------- ساخت اسپرایت ایستا ----------------
function spr(w, h, ax, ay, fn) { const S2 = 2, c = document.createElement("canvas"); c.width = w * S2; c.height = h * S2; const g = c.getContext("2d"); g.scale(S2, S2); g.translate(ax, ay); g.lineJoin = "round"; fn(g); return { c, w, h, ax, ay }; }
const brick = (g, x, y, w, h, col, seed = 1) => { const r = rnd(seed); g.strokeStyle = "rgba(0,0,0,0.16)"; g.lineWidth = 0.7; const rows = Math.max(1, Math.floor(h / 6)); for (let j = 1; j < rows; j++) { const yy = y + j * 6; g.beginPath(); g.moveTo(x, yy); g.lineTo(x + w, yy); g.stroke(); for (let xx = x + ((j & 1) ? 4 : 0) + r() * 2; xx < x + w; xx += 8) { g.beginPath(); g.moveTo(xx, yy); g.lineTo(xx, yy + 6); g.stroke(); } } };
function tower(g, x, y, r, h, col, roof, seed) { // y: پایین برج
  const gr = g.createLinearGradient(x - r, 0, x + r, 0); gr.addColorStop(0, sh(col, 1.12)); gr.addColorStop(0.55, col); gr.addColorStop(1, sh(col, 0.6));
  g.fillStyle = gr; g.strokeStyle = "rgba(20,14,30,0.8)"; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x - r, y); g.lineTo(x - r, y - h); g.ellipse(x, y - h, r, r * 0.38, 0, Math.PI, 0, true); g.lineTo(x + r, y); g.ellipse(x, y, r, r * 0.38, 0, 0, Math.PI); g.closePath(); g.fill(); g.stroke();
  brick(g, x - r, y - h, r * 2, h, col, seed);
  g.fillStyle = "#1c1420"; g.fillRect(x - 1.6, y - h * 0.55, 3.2, 8); g.fillRect(x - 1.6, y - h * 0.82, 3.2, 7);
  if (roof) { const rg = g.createLinearGradient(x - r, 0, x + r, 0); rg.addColorStop(0, sh(roof, 1.25)); rg.addColorStop(0.5, roof); rg.addColorStop(1, sh(roof, 0.55)); g.fillStyle = rg; g.beginPath(); g.moveTo(x - r - 3, y - h + 1); g.lineTo(x, y - h - r * 2.1); g.lineTo(x + r + 3, y - h + 1); g.quadraticCurveTo(x, y - h + r * 0.6, x - r - 3, y - h + 1); g.fill(); g.stroke(); }
}
function crenel(g, x0, x1, y, col, n = 8) { const w = (x1 - x0) / (n * 2 - 1); g.fillStyle = col; g.strokeStyle = "rgba(20,14,30,0.7)"; g.lineWidth = 0.8; for (let i = 0; i < n; i++) { g.fillRect(x0 + i * 2 * w, y - 5, w, 5); g.strokeRect(x0 + i * 2 * w, y - 5, w, 5); } }
export function house(g, x, y, w, d, h, wall, roof, o = {}) { // مرکز-پایین جلوی خانه
  const dx = d * 0.6, dy = d * 0.34, rh = o.rh || h * 0.62;
  g.strokeStyle = "rgba(25,15,10,0.8)"; g.lineWidth = 1;
  g.fillStyle = "rgba(0,0,0,0.25)"; g.beginPath(); g.ellipse(x + dx * 0.4, y + 1, w * 0.62 + dx * 0.5, 4 + dy * 0.4, 0, 0, TAU); g.fill();
  g.fillStyle = sh(wall, 0.62); g.beginPath(); g.moveTo(x + w / 2, y); g.lineTo(x + w / 2 + dx, y - dy); g.lineTo(x + w / 2 + dx, y - dy - h); g.lineTo(x + w / 2, y - h); g.closePath(); g.fill(); g.stroke();
  g.fillStyle = wall; g.fillRect(x - w / 2, y - h, w, h); g.strokeRect(x - w / 2, y - h, w, h);
  g.fillStyle = sh(wall, 1.1); g.beginPath(); g.moveTo(x - w / 2, y - h); g.lineTo(x, y - h - rh); g.lineTo(x + w / 2, y - h); g.closePath(); g.fill(); g.stroke();
  const rg = g.createLinearGradient(x, y - h - rh, x + dx, y - h); rg.addColorStop(0, sh(roof, 1.2)); rg.addColorStop(1, sh(roof, 0.8));
  g.fillStyle = rg; g.beginPath(); g.moveTo(x - 2, y - h - rh - 1); g.lineTo(x + w / 2 + 3, y - h + 1); g.lineTo(x + w / 2 + dx + 3, y - h - dy + 1); g.lineTo(x + dx - 2, y - h - rh - dy - 1); g.closePath(); g.fill(); g.stroke();
  g.strokeStyle = "rgba(0,0,0,0.18)"; for (let i = 1; i < 4; i++) { const t = i / 4; g.beginPath(); g.moveTo(x + (w / 2 + 3) * t, y - h - rh + (rh + 1) * t); g.lineTo(x + (w / 2 + dx + 3) * t + dx * (1 - t), y - h - rh - dy + (rh + 1) * t + 0); g.stroke(); }
  g.fillStyle = "#3a2410"; g.fillRect(x - w * 0.12, y - h * 0.5, w * 0.24, h * 0.5); g.fillStyle = "#f6d98a"; g.fillRect(x + w * 0.22, y - h * 0.72, w * 0.16, h * 0.22); g.strokeRect(x + w * 0.22, y - h * 0.72, w * 0.16, h * 0.22);
  if (o.chim) { g.fillStyle = "#6a5a50"; g.fillRect(x + w * 0.18, y - h - rh * 0.9, 5, 10); if (o.out) o.out.push([x + w * 0.18 + 2.5, y - h - rh * 0.9]); }
}
function tree(g, x, y, s, col = "#2e7a3a") { g.fillStyle = "#4a2e18"; g.fillRect(x - 1.5 * s, y - 6 * s, 3 * s, 6 * s); g.fillStyle = col; g.beginPath(); g.arc(x, y - 11 * s, 6.5 * s, 0, TAU); g.arc(x - 4 * s, y - 8 * s, 4.5 * s, 0, TAU); g.arc(x + 4 * s, y - 8 * s, 4.5 * s, 0, TAU); g.fill(); }
export function makeVillage(seed, dev) {
  const r = rnd(seed * 7 + 3), N = 5 + (dev >= 2 ? 2 : 0) + (dev >= 3 ? 2 : 0);
  const out = [], sp = spr(190, 120, 95, 92, (g) => {
    g.fillStyle = "rgba(60,40,20,0.22)"; g.beginPath(); g.ellipse(0, -6, 88, 28, 0, 0, TAU); g.fill();
    const hs = []; for (let i = 0; i < N; i++) { const a = i / N * TAU + r() * 0.5, rx = 36 + r() * 36, ry = rx * 0.38; hs.push({ x: Math.cos(a) * rx, y: Math.sin(a) * ry, w: 20 + r() * 8, h: 13 + r() * 6, d: 12 + r() * 6, wall: ["#d9c49a", "#cdb48a", "#e4d3a8", "#c8a87a"][i % 4], roof: ["#b04a2e", "#a8402a", "#8a5a2a", "#a65a2a", "#7a3a2a"][(i + (r() * 5 | 0)) % 5] }); }
    hs.sort((a, b) => a.y - b.y);
    g.fillStyle = "#6e4a24"; g.beginPath(); g.ellipse(0, 0, 8, 3, 0, 0, TAU); g.fill(); g.fillStyle = "#4a90c0"; g.beginPath(); g.ellipse(0, -0.5, 5.5, 2, 0, 0, TAU); g.fill();
    for (const h of hs) house(g, h.x, h.y, h.w, h.d, h.h, h.wall, h.roof, { chim: true, out });
    for (let i = 0; i < 4; i++) tree(g, (r() - 0.5) * 170, 18 + r() * 12, 0.85, i % 2 ? "#2e7a3a" : "#3a8a44");
    if (dev >= 3) { g.fillStyle = "#c8a24a"; g.fillRect(-2, -38, 4, 20); }
  }); sp.chims = out; return sp;
}
export function makeHome() {
  return spr(170, 130, 85, 98, (g) => {
    g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(0, 0, 78, 16, 0, 0, TAU); g.fill();
    const wall = "#e4dac0", roof = "#3a6ad8";
    g.fillStyle = "#b8b4a6"; g.strokeStyle = "rgba(20,14,30,0.75)"; g.lineWidth = 1.1; g.fillRect(-64, -16, 128, 16); g.strokeRect(-64, -16, 128, 16); crenel(g, -64, 64, -16, "#b8b4a6", 14); brick(g, -64, -16, 128, 16, "#b8b4a6", 5);
    tower(g, -62, 0, 9, 38, "#c4c0b4", roof, 2); tower(g, 62, 0, 9, 38, "#c4c0b4", roof, 3);
    house(g, 0, -4, 52, 26, 30, wall, roof, { rh: 24 });
    g.fillStyle = "#2a1a10"; g.beginPath(); g.moveTo(-7, 0); g.lineTo(-7, -9); g.quadraticCurveTo(0, -17, 7, -9); g.lineTo(7, 0); g.fill();
    g.fillStyle = "#3f6ad8"; g.fillRect(-3, -64, 6, 10);
  });
}
export function makeTown() {
  const out = [], sp = spr(280, 190, 140, 146, (g) => {
    g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(0, 4, 128, 28, 0, 0, TAU); g.fill();
    const stone = "#aa9f88"; g.strokeStyle = "rgba(20,14,30,0.8)"; g.lineWidth = 1.2;
    g.fillStyle = stone; g.fillRect(-118, -20, 236, 20); g.strokeRect(-118, -20, 236, 20); brick(g, -118, -20, 236, 20, stone, 8); crenel(g, -118, 118, -20, stone, 22);
    const r = rnd(41), rows = [[-98, -46, 9], [-62, -52, 6], [-26, -44, 8], [14, -52, 7], [52, -44, 6], [90, -50, 8]];
    for (let i = 0; i < 12; i++) { const x = -96 + (i % 6) * 38 + r() * 10, row = (i / 6 | 0), y = -30 + row * 30 + r() * 4; house(g, x, y, 22 + r() * 10, 14, 17 + r() * 14, ["#e2d4b0", "#d4c196", "#c9b284", "#e8dcc0"][i % 4], ["#b0402e", "#3f6ab0", "#8a4a2a", "#a8402a", "#4a7a5a"][(i * 3) % 5], { chim: i % 3 === 0, out }); }
    for (let i = 0; i < 4; i++) { const x = -60 + i * 40; g.fillStyle = ["#d84a3a", "#e8c24a", "#3a8ad8", "#48a85a"][i]; g.beginPath(); g.moveTo(x - 9, 0); g.lineTo(x - 9, -9); g.lineTo(x, -14); g.lineTo(x + 9, -9); g.lineTo(x + 9, 0); g.closePath(); g.fill(); g.stroke(); g.fillStyle = "#8a5a2a"; g.fillRect(x - 8, -1, 16, 5); }
    tower(g, 0, -20, 14, 80, "#c8bfa6", "#8a3a2a", 6);
    tower(g, -118, 4, 11, 52, "#bdb39c", "#4a6aa8", 4); tower(g, 118, 4, 11, 52, "#bdb39c", "#4a6aa8", 7);
    g.fillStyle = "#2a1a10"; g.beginPath(); g.moveTo(-12, 4); g.lineTo(-12, -14); g.quadraticCurveTo(0, -30, 12, -14); g.lineTo(12, 4); g.fill(); g.strokeStyle = "#5a3a1a"; g.lineWidth = 1; for (let i = -8; i <= 8; i += 4) { g.beginPath(); g.moveTo(i, 4); g.lineTo(i, -16); g.stroke(); }
  }); sp.chims = out; return sp;
}
export function makeCastle(state, seed = 1) {
  const locked = state === "locked", conq = state === "conq", stone = locked ? "#6a6a78" : conq ? "#bcc2d2" : "#b0aeb8", roof = locked ? "#4a4a56" : conq ? "#2f5fc8" : "#b8301f";
  return spr(210, 190, 105, 150, (g) => {
    g.fillStyle = "rgba(0,0,0,0.34)"; g.beginPath(); g.ellipse(0, 4, 96, 20, 0, 0, TAU); g.fill();
    g.strokeStyle = "rgba(20,14,30,0.85)"; g.lineWidth = 1.3;
    // برج‌ بلند پشت
    tower(g, 0, -34, 17, 66, sh(stone, 0.95), roof, seed);
    // دیوار پشتی
    g.fillStyle = sh(stone, 0.88); g.fillRect(-72, -48, 144, 22); g.strokeRect(-72, -48, 144, 22); brick(g, -72, -48, 144, 22, stone, 4); crenel(g, -72, 72, -48, sh(stone, 0.88), 14);
    tower(g, -74, -24, 13, 62, stone, roof, seed + 1); tower(g, 74, -24, 13, 62, stone, roof, seed + 2);
    // دیوار جلو
    const gr = g.createLinearGradient(0, -34, 0, 0); gr.addColorStop(0, sh(stone, 1.1)); gr.addColorStop(1, sh(stone, 0.82));
    g.fillStyle = gr; g.fillRect(-72, -34, 144, 34); g.strokeRect(-72, -34, 144, 34); brick(g, -72, -34, 144, 34, stone, 9); crenel(g, -72, 72, -34, sh(stone, 1.05), 15);
    tower(g, -76, 4, 15, 58, stone, roof, seed + 3); tower(g, 76, 4, 15, 58, stone, roof, seed + 4);
    // دروازه
    g.fillStyle = "#1a1018"; g.beginPath(); g.moveTo(-13, 0); g.lineTo(-13, -17); g.quadraticCurveTo(0, -34, 13, -17); g.lineTo(13, 0); g.closePath(); g.fill(); g.stroke();
    g.strokeStyle = locked ? "#8a8a96" : "#6a4a28"; g.lineWidth = 1.6; for (let i = -9; i <= 9; i += 4.5) { g.beginPath(); g.moveTo(i, 0); g.lineTo(i, -20 + Math.abs(i) * 0.5); g.stroke(); } if (!locked) { g.beginPath(); g.moveTo(-12, -8); g.lineTo(12, -8); g.stroke(); }
    if (locked) { g.strokeStyle = "#9a9aa6"; g.lineWidth = 2; g.beginPath(); g.moveTo(-14, -6); g.lineTo(14, -14); g.moveTo(-14, -14); g.lineTo(14, -6); g.stroke(); g.fillStyle = "#c8a24a"; g.fillRect(-4, -14, 8, 7); }
    g.fillStyle = conq ? "#3f7bff" : locked ? "#555" : "#d8a02a"; g.beginPath(); g.arc(0, -42, 3, 0, TAU); g.fill();
  });
}
export const CASTLE_FLAGS = [[0, -136], [-74, -113], [74, -113], [-76, -85], [76, -85]];
export function villageSprite() { return null; }
