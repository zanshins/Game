// نقشه‌ی جهان: قلمروها، مرزها، مه جنگ، فتح‌ها، مسیر لشکرکشی و هشدار غارت
import { NEIGHBORS, fa } from "./data.js";
import { S } from "./save.js";
import * as SV from "./save.js";
import { rng } from "./data.js";

const TAU = Math.PI * 2, FONT = "Vazirmatn, sans-serif";
const W = 760, H = 380, CELL = 5, GW = W / CELL, GH = H / CELL;
// مختصات نسبی مراکز قلمروها
const SEEDS = { home: [0.16, 0.6], n1: [0.33, 0.3], n2: [0.37, 0.79], n3: [0.56, 0.52], n4: [0.6, 0.15], n5: [0.8, 0.77], n6: [0.87, 0.32] };
const BIOME = { home: "#6fbf5a", n1: "#7bd88f", n2: "#9aa6a0", n3: "#e0b86a", n4: "#bfe3f5", n5: "#c8553a", n6: "#dbe6ff" };
const ids = Object.keys(SEEDS);
const wm = { sel: null, base: null, key: "", cv: null, t: 0, raf: 0, grid: null };

const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const mixc = (a, b, t) => { const A = hex(a), B = hex(b); return "#" + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, "0")).join(""); };

// شبکه‌ی ناحیه‌ها: وورونوی تاب‌خورده (یک‌بار ساخته می‌شود)
function buildGrid() {
  if (wm.grid) return wm.grid; const r = rng(4242), ph = Array.from({ length: 6 }, () => r() * 6.28), g = new Int8Array(GW * GH).fill(-1);
  for (let j = 0; j < GH; j++) for (let i = 0; i < GW; i++) {
    const x = i / GW, y = j / GH, wx = x + Math.sin(y * 13 + ph[0]) * 0.018 + Math.sin(y * 31 + ph[1]) * 0.008, wy = y + Math.sin(x * 11 + ph[2]) * 0.03 + Math.sin(x * 29 + ph[3]) * 0.012;
    let best = -1, bd = 9, second = 9;
    for (let k = 0; k < ids.length; k++) { const [sx, sy] = SEEDS[ids[k]], d = Math.hypot((wx - sx) * 2, wy - sy); if (d < bd) { second = bd; bd = d; best = k; } else if (d < second) second = d; }
    const edge = 0.255 + Math.sin(x * 17 + ph[4]) * 0.025 + Math.sin(y * 23 + ph[5]) * 0.02; // ضخامت خشکی
    if (bd < edge) g[j * GW + i] = best;
  }
  wm.grid = g; return g;
}
const state = (id) => {
  if (id === "home") return "home"; const nb = NEIGHBORS.find((n) => n.id === id);
  if (S.conquered[id]) return "conq"; if (SV.kingdomLevel() < nb.need) return "locked"; return "open";
};
function regionColor(id) { const st = state(id); const base = id === "home" ? "#4f86ff" : id in BIOME ? BIOME[id] : "#888"; if (st === "home" || st === "conq") return mixc("#3f7bff", BIOME[id], st === "home" ? 0.28 : 0.4); if (st === "locked") return "#4b4f60"; return mixc(base, "#555a48", 0.28); }

function buildBase() {
  const g = buildGrid(), c = document.createElement("canvas"); c.width = W * 2; c.height = H * 2; const x = c.getContext("2d"); x.scale(2, 2); const r = rng(99);
  // اقیانوس
  const og = x.createLinearGradient(0, 0, 0, H); og.addColorStop(0, "#143a6a"); og.addColorStop(1, "#0b2548"); x.fillStyle = og; x.fillRect(0, 0, W, H);
  x.strokeStyle = "rgba(120,190,255,0.10)"; x.lineWidth = 1.2; for (let i = 0; i < 90; i++) { const px = r() * W, py = r() * H; x.beginPath(); x.moveTo(px, py); x.quadraticCurveTo(px + 8, py - 4, px + 16, py); x.stroke(); }
  // خشکی: سایه‌ی ساحل
  x.fillStyle = "rgba(0,0,0,0.25)"; for (let j = 0; j < GH; j++) for (let i = 0; i < GW; i++) if (g[j * GW + i] >= 0) x.fillRect(i * CELL + 2, j * CELL + 3, CELL, CELL);
  for (let j = 0; j < GH; j++) for (let i = 0; i < GW; i++) {
    const k = g[j * GW + i]; if (k < 0) continue; const id = ids[k]; let col = regionColor(id); const n = (Math.sin(i * 1.7 + j * 2.3) + Math.sin(i * 0.6 - j * 0.9)) * 0.04; col = mixc(col, n > 0 ? "#ffffff" : "#000000", Math.abs(n)); x.fillStyle = col; x.fillRect(i * CELL, j * CELL, CELL + 0.6, CELL + 0.6);
  }
  // دکور بیوم
  for (let k = 0; k < ids.length; k++) {
    const id = ids[k], st = state(id), [sx, sy] = SEEDS[id], rr = rng(k * 71 + 5); if (st === "locked") continue;
    for (let q = 0; q < 46; q++) { const px = sx * W + (rr() - 0.5) * 190, py = sy * H + (rr() - 0.5) * 120, gi = Math.floor(px / CELL), gj = Math.floor(py / CELL); if (gi < 0 || gj < 0 || gi >= GW || gj >= GH || g[gj * GW + gi] !== k) continue;
      if (id === "n4") { x.fillStyle = "#fff"; x.beginPath(); x.moveTo(px - 6, py + 4); x.lineTo(px, py - 8); x.lineTo(px + 6, py + 4); x.fill(); x.fillStyle = "rgba(60,100,150,0.4)"; x.beginPath(); x.moveTo(px, py - 8); x.lineTo(px + 6, py + 4); x.lineTo(px + 1, py + 4); x.fill(); }
      else if (id === "n5") { x.fillStyle = "#3a1a14"; x.beginPath(); x.moveTo(px - 7, py + 4); x.lineTo(px - 1, py - 8); x.lineTo(px + 7, py + 4); x.fill(); x.fillStyle = "#ff8a2e"; x.fillRect(px - 1, py - 7, 2, 4); }
      else if (id === "n3") { x.fillStyle = "rgba(160,110,40,0.5)"; x.beginPath(); x.ellipse(px, py, 7, 2.5, 0, 0, TAU); x.fill(); }
      else if (id === "n6") { x.fillStyle = "rgba(255,255,255,0.8)"; x.beginPath(); x.arc(px, py, 5, 0, TAU); x.arc(px + 5, py + 1, 4, 0, TAU); x.fill(); }
      else if (id === "n2") { x.fillStyle = "#6a7068"; x.beginPath(); x.moveTo(px - 6, py + 4); x.lineTo(px - 1, py - 7); x.lineTo(px + 6, py + 4); x.fill(); }
      else { x.fillStyle = "rgba(30,100,40,0.8)"; x.beginPath(); x.arc(px, py, 3.2, 0, TAU); x.fill(); x.fillStyle = "rgba(90,200,90,0.7)"; x.beginPath(); x.arc(px - 1, py - 1, 1.8, 0, TAU); x.fill(); }
    }
  }
  // مرزها و ساحل
  x.lineCap = "round";
  for (let j = 0; j < GH; j++) for (let i = 0; i < GW; i++) {
    const a = g[j * GW + i]; for (const [di, dj] of [[1, 0], [0, 1]]) { const ni = i + di, nj = j + dj; if (ni >= GW || nj >= GH) continue; const b = g[nj * GW + ni]; if (a === b) continue;
      const px = (i + di) * CELL, py = (j + dj) * CELL; x.beginPath(); if (di) { x.moveTo(px, j * CELL); x.lineTo(px, j * CELL + CELL); } else { x.moveTo(i * CELL, py); x.lineTo(i * CELL + CELL, py); }
      if (a < 0 || b < 0) { x.strokeStyle = "rgba(255,255,255,0.55)"; x.lineWidth = 2; } else { const sa = state(ids[a]), sb = state(ids[b]), mine = (s) => s === "home" || s === "conq"; if (mine(sa) !== mine(sb)) { x.strokeStyle = "#ffd24a"; x.lineWidth = 2.6; } else if (mine(sa) && mine(sb)) { x.strokeStyle = "rgba(160,200,255,0.9)"; x.lineWidth = 1.6; } else { x.strokeStyle = "rgba(20,20,30,0.7)"; x.lineWidth = 1.8; } }
      x.stroke(); }
  }
  // مه‌ی قلمروهای قفل
  for (let k = 0; k < ids.length; k++) if (state(ids[k]) === "locked") { const [sx, sy] = SEEDS[ids[k]]; for (let q = 0; q < 14; q++) { const px = sx * W + (rng(q * 13 + k)() - 0.5) * 170, py = sy * H + (rng(q * 7 + k * 3)() - 0.5) * 100; const gi = Math.floor(px / CELL), gj = Math.floor(py / CELL); if (gi < 0 || gj < 0 || gi >= GW || gj >= GH || g[gj * GW + gi] !== k) continue; x.fillStyle = "rgba(210,218,235,0.18)"; x.beginPath(); x.arc(px, py, 14 + (q % 4) * 4, 0, TAU); x.fill(); } }
  // قاب
  x.strokeStyle = "rgba(255,210,120,0.55)"; x.lineWidth = 4; x.strokeRect(2, 2, W - 4, H - 4);
  return c;
}
const keyOf = () => ids.map((i) => state(i)).join("|") + (SV.kingdomLevel());

function castle(x, px, py, col, size, locked) {
  x.save(); x.translate(px, py); x.scale(size, size); x.fillStyle = "rgba(0,0,0,0.3)"; x.beginPath(); x.ellipse(0, 4, 14, 4, 0, 0, TAU); x.fill();
  x.fillStyle = locked ? "#7a7f90" : "#e6dcc4"; x.strokeStyle = "rgba(20,15,30,0.8)"; x.lineWidth = 1.2; x.beginPath(); x.rect(-11, -10, 22, 14); x.fill(); x.stroke();
  for (const dx of [-12, 7]) { x.beginPath(); x.rect(dx, -17, 5, 21); x.fill(); x.stroke(); x.fillStyle = locked ? "#555a6a" : col; x.beginPath(); x.moveTo(dx - 1.5, -17); x.lineTo(dx + 2.5, -23); x.lineTo(dx + 6.5, -17); x.closePath(); x.fill(); x.stroke(); x.fillStyle = locked ? "#7a7f90" : "#e6dcc4"; }
  x.fillStyle = "#3a2414"; x.beginPath(); x.arc(0, 4, 4.2, Math.PI, 0); x.lineTo(4.2, 4); x.lineTo(-4.2, 4); x.fill();
  x.restore();
}
function flag(x, px, py, col, t) { x.strokeStyle = "#4a3220"; x.lineWidth = 1.6; x.beginPath(); x.moveTo(px, py); x.lineTo(px, py - 17); x.stroke(); x.fillStyle = col; x.strokeStyle = "rgba(0,0,0,0.6)"; x.lineWidth = 1; x.beginPath(); x.moveTo(px, py - 17); x.quadraticCurveTo(px + 6, py - 18 + Math.sin(t * 4) * 1.5, px + 12, py - 14); x.quadraticCurveTo(px + 6, py - 12 + Math.sin(t * 4 + 1) * 1.5, px, py - 10); x.closePath(); x.fill(); x.stroke(); }
function label(x, txt, px, py, col = "#fff", size = 12) { x.font = `bold ${size}px ${FONT}`; x.textAlign = "center"; x.lineWidth = 3.5; x.strokeStyle = "rgba(10,10,25,0.85)"; x.strokeText(txt, px, py); x.fillStyle = col; x.fillText(txt, px, py); }

function frame(dt) {
  const cv = wm.cv; if (!cv || !document.body.contains(cv)) { wm.raf = 0; return; }
  wm.t += dt; const k = keyOf(); if (k !== wm.key || !wm.base) { wm.base = buildBase(); wm.key = k; }
  const x = cv.getContext("2d"); x.setTransform(cv.width / W, 0, 0, cv.height / H, 0, 0); x.drawImage(wm.base, 0, 0, W, H);
  const t = wm.t, raid = S.raid && S.raid.pending;
  // مسیر لشکرکشی به قلمرو انتخاب‌شده
  const sel = wm.sel; if (sel && sel !== "home") { const [hx, hy] = SEEDS.home, [sx, sy] = SEEDS[sel], ax = hx * W, ay = hy * H, bx = sx * W, by = sy * H, mx = (ax + bx) / 2, my = Math.min(ay, by) - 50;
    x.strokeStyle = "rgba(255,230,140,0.85)"; x.lineWidth = 2.5; x.setLineDash([7, 7]); x.lineDashOffset = -t * 20; x.beginPath(); x.moveTo(ax, ay); x.quadraticCurveTo(mx, my, bx, by); x.stroke(); x.setLineDash([]);
    for (let i = 0; i < 4; i++) { const u = ((t * 0.18 + i / 4) % 1), px = (1 - u) * (1 - u) * ax + 2 * u * (1 - u) * mx + u * u * bx, py = (1 - u) * (1 - u) * ay + 2 * u * (1 - u) * my + u * u * by; x.fillStyle = "#3f7bff"; x.strokeStyle = "#fff"; x.lineWidth = 1.5; x.beginPath(); x.arc(px, py, 4, 0, TAU); x.fill(); x.stroke(); } }
  // حمله‌ی در راه
  if (raid) { const nb = NEIGHBORS.find((n) => n.id === raid.id), [sx, sy] = SEEDS[nb.id], [hx, hy] = SEEDS.home; const u = (t * 0.25) % 1, px = sx * W + (hx * W - sx * W) * u, py = sy * H + (hy * H - sy * H) * u; x.strokeStyle = "rgba(255,70,70,0.7)"; x.lineWidth = 3; x.setLineDash([6, 5]); x.lineDashOffset = -t * 30; x.beginPath(); x.moveTo(sx * W, sy * H); x.lineTo(hx * W, hy * H); x.stroke(); x.setLineDash([]); x.fillStyle = "#ff4d4d"; x.beginPath(); x.arc(px, py, 5, 0, TAU); x.fill(); }
  for (const id of ids) {
    const [sx, sy] = SEEDS[id], px = sx * W, py = sy * H, st = state(id), nb = id === "home" ? null : NEIGHBORS.find((n) => n.id === id), sc = id === "home" ? 1.25 : 1;
    if (wm.sel === id) { x.strokeStyle = "rgba(255,229,138," + (0.6 + 0.4 * Math.sin(t * 5)) + ")"; x.lineWidth = 3; x.beginPath(); x.ellipse(px, py + 2, 36, 22, 0, 0, TAU); x.stroke(); }
    castle(x, px, py, id === "home" || st === "conq" ? "#3f7bff" : nb.color, sc, st === "locked");
    if (st === "home" || st === "conq") flag(x, px + 1, py - 22 * sc, "#3f7bff", t); else if (st === "open") flag(x, px + 1, py - 22 * sc, "#e8453a", t);
    label(x, id === "home" ? "کشور من" : nb.name, px, py + 22, st === "locked" ? "#aab" : "#fff", 12);
    if (st === "open") { const a = 0.6 + 0.4 * Math.sin(t * 4 + sx * 9); x.fillStyle = `rgba(255,90,70,${a})`; x.strokeStyle = "#fff"; x.lineWidth = 1.5; x.beginPath(); x.arc(px + 24, py - 16, 8, 0, TAU); x.fill(); x.stroke(); x.strokeStyle = "#fff"; x.lineWidth = 1.6; x.beginPath(); x.moveTo(px + 20, py - 12); x.lineTo(px + 28, py - 20); x.moveTo(px + 28, py - 12); x.lineTo(px + 20, py - 20); x.stroke(); }
    if (st === "locked") { label(x, "سطح " + fa(nb.need), px, py + 37, "#ffd27a", 11); x.fillStyle = "#ffd24a"; x.beginPath(); x.roundRect(px - 5, py - 14, 10, 8, 2); x.fill(); x.strokeStyle = "#ffd24a"; x.lineWidth = 2; x.beginPath(); x.arc(px, py - 14, 4, Math.PI, 0); x.stroke(); }
    if (st === "conq") label(x, "+" + fa(Math.round(nb.loot * 0.012)) + "/س", px, py + 37, "#ffe58a", 10.5);
  }
  // عنوان و بادگرد
  x.font = `bold 11px ${FONT}`; x.fillStyle = "rgba(255,255,255,0.7)"; x.textAlign = "left"; x.fillText("N", 22, 24); x.strokeStyle = "rgba(255,255,255,0.7)"; x.lineWidth = 1.5; x.beginPath(); x.moveTo(26, 48); x.lineTo(26, 28); x.lineTo(22, 34); x.moveTo(26, 28); x.lineTo(30, 34); x.stroke();
}
function loop(now) {
  if (!wm.cv || !document.body.contains(wm.cv)) { wm.raf = 0; return; }
  const dt = Math.min(0.1, (now - (wm.last || now)) / 1000); wm.last = now; if (!wm.acc) wm.acc = 0; wm.acc += dt; if (wm.acc >= 1 / 24) { frame(wm.acc); wm.acc = 0; }
  wm.raf = requestAnimationFrame(loop);
}
function pick(ev) {
  const r = wm.cv.getBoundingClientRect(), x = (ev.clientX - r.left) / r.width, y = (ev.clientY - r.top) / r.height, g = buildGrid(), gi = Math.floor(x * GW), gj = Math.floor(y * GH);
  let k = g[gj * GW + gi]; if (k < 0) { let bd = 9; for (let q = 0; q < ids.length; q++) { const d = Math.hypot((x - SEEDS[ids[q]][0]) * 2, y - SEEDS[ids[q]][1]); if (d < bd && d < 0.12) { bd = d; k = q; } } }
  return k >= 0 ? ids[k] : null;
}
export function infoHTML(id) {
  if (!id) return `<div class="mut sm c">یک قلمرو را لمس کن تا جزئیات و مسیر لشکرکشی را ببینی.</div>`;
  if (id === "home") { const n = NEIGHBORS.filter((q) => S.conquered[q.id]).length; return `<div class="row"><div class="grow"><b>کشور من</b><div class="xs mut">${SV.kingdomTier()} • قدرت ${fa(SV.kingdomPower())} • ${fa(n)} از ${fa(NEIGHBORS.length)} قلمرو فتح شده</div><div class="xs">درآمد استان‌ها: 🪙 ${fa(SV.provinceRate())} در ساعت</div></div></div>`; }
  const nb = NEIGHBORS.find((n) => n.id === id), st = state(id);
  const head = `<div class="row"><div class="ic" style="border-color:${nb.color}">${nb.emoji}</div><div class="grow"><b>${nb.name}</b> ${st === "conq" ? '<span class="chip" style="color:#7bff9a">🏴 فتح‌شده</span>' : ""}<div class="xs mut">${nb.ruler} • قدرت ${fa(nb.power)} • ${fa(nb.towers)} برج • دروازه ${fa(nb.gate)}</div><div class="xs">غنیمت: 🪙${fa(nb.loot)} 💎${fa(nb.gems)} • +${fa(nb.perk * 100)}٪ سکه • 🪙 ${fa(Math.round(nb.loot * 0.012))}/ساعت</div></div>`;
  if (st === "locked") return head + `<span class="xs mut">با رسیدن کشورت به سطح ${fa(nb.need)} مه کنار می‌رود</span></div>`;
  return head + `<button class="btn s r" data-act="atk" data-id="${nb.id}">⚔️ ${st === "conq" ? "غارت" : "حمله"}</button></div>`;
}
export function worldMapHTML() {
  const n = NEIGHBORS.filter((q) => S.conquered[q.id]).length, all = n === NEIGHBORS.length;
  const bar = `<div class="row wrap" style="margin-bottom:6px;gap:6px"><span class="chip">🗺️ فتح‌شده: ${fa(n)}/${fa(NEIGHBORS.length)}</span><span class="chip">🪙 درآمد استان‌ها: ${fa(SV.provinceRate())}/ساعت</span><span class="chip" style="color:#7bff9a">+${fa(Math.round(SV.conqPerk() * 100))}٪ سکه</span>${all && !S.empire ? '<button class="btn s g" data-act="empire">👑 جایزه‌ی امپراتوری</button>' : S.empire ? '<span class="chip">👑 امپراتور</span>' : ""}</div>`;
  const legend = `<div class="xs mut" style="margin:4px 0">آبی = قلمرو تو • مرز طلایی = جبهه‌ی نبرد • مه = هنوز نامعلوم • ⚔️ قرمز = قابل‌حمله</div>`;
  return `${bar}<div class="wmwrap"><canvas id="wm" width="${W * 2}" height="${H * 2}"></canvas></div>${legend}<div class="card" id="wminfo" style="margin-bottom:8px">${infoHTML(wm.sel)}</div>`;
}
export function mountWorldMap() {
  const cv = document.getElementById("wm"); if (!cv) return; wm.cv = cv; wm.key = ""; wm.last = 0;
  cv.addEventListener("pointerup", (e) => { wm.sel = pick(e); const el = document.getElementById("wminfo"); if (el) el.innerHTML = infoHTML(wm.sel); });
  if (!wm.raf) wm.raf = requestAnimationFrame(loop); frame(0.016);
}
