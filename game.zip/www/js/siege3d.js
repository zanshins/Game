// حالت سه‌بعدی (آزمایشی): محاصره‌ی قلعه از پشت شخصیت — موتور سبک با تصویرسازی پرسپکتیو روی canvas
import { S, heroInit, heroXp, heroNeed, heroBuy, HERO_UP, HERO_MAXUP } from "./save.js";
import { loadEnv, envFrame, envSprite, envBlit, envInfo, ENVK, EV } from "./env3d.js";
import { Sound } from "./audio.js";
import { find, stats, lookOf, randomLook, drawHead, buildW } from "./gear.js";
import * as SQ from "./squad.js";
import { frameBegin, renderInst, blit } from "./char3d.js";
import { A as ARMY, UNITS, SKILLS, mulLv, unitLv, skillLv, pickArmy, applyLosses } from "./army3d.js";

const TAU = Math.PI * 2, clamp = (v, a, b) => Math.max(a, Math.min(b, v)), lerp = (a, b, t) => a + (b - a) * t;
const hex = (h) => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const rgb = (c, k = 1, fog = 0, fc = [190, 215, 235]) => { const r = lerp(clamp(c[0] * k, 0, 255), fc[0], fog), g = lerp(clamp(c[1] * k, 0, 255), fc[1], fog), b = lerp(clamp(c[2] * k, 0, 255), fc[2], fog); return `rgb(${r | 0},${g | 0},${b | 0})`; };
const angDiff = (a, b) => { let d = (b - a) % TAU; if (d > Math.PI) d -= TAU; if (d < -Math.PI) d += TAU; return d; };
const LIGHT = (() => { const l = [0.45, 0.8, -0.4], n = Math.hypot(...l); return l.map((v) => v / n); })();

// ---------- پالت هر کشور ----------
const THEMES = {
  n1: { sky: ["#8fd0ff", "#e6f6ff"], ground: ["#5fae56", "#4c9a48"], wall: "#b9a27a", roof: "#a8482e", fog: [200, 228, 245], mount: "#7aa88a" },
  n2: { sky: ["#9ab8d8", "#dfe8f2"], ground: ["#8a9a72", "#788a64"], wall: "#9a9a9a", roof: "#5a6a8a", fog: [205, 215, 228], mount: "#7a8696" },
  n3: { sky: ["#ffcf8a", "#ffeccb"], ground: ["#d8b872", "#c8a862"], wall: "#d6b27a", roof: "#2f8a8a", fog: [250, 226, 190], mount: "#c4966a" },
  n4: { sky: ["#a8c8e8", "#eef6ff"], ground: ["#e8f0f8", "#d4e0ee"], wall: "#a8bcd2", roof: "#4a6a9a", fog: [226, 238, 250], mount: "#b8cce0" },
  n5: { sky: ["#5a2a2a", "#ff9a5a"], ground: ["#5a3a30", "#4a2e28"], wall: "#6a4a42", roof: "#c4401a", fog: [150, 80, 60], mount: "#3a2420" },
  n6: { sky: ["#8a7ad8", "#f6e0ff"], ground: ["#c8d0f0", "#b4bee6"], wall: "#e8e0f4", roof: "#7a5ac8", fog: [232, 224, 250], mount: "#a8a0d8" },
};

export function startSiege3D(nb, onEnd) {
  const FIELD = !!nb.keep, KEEP = nb.keep || null;
  const th = THEMES[nb.id] || THEMES.n1, WALL = hex(th.wall), ROOF = hex(th.roof), FOG = th.fog;
  const root = document.createElement("div"); root.id = "s3d";
  root.innerHTML = `<canvas id="s3c"></canvas>
  <div class="s3top"><div class="s3col"><div class="s3bar"><i id="s3php"></i><span id="s3pt"></span></div><div class="s3lv"><b id="s3lvn">1</b><div class="s3xp"><i id="s3xp"></i></div></div></div><div class="s3mid"><b>${nb.emoji} ${nb.name}</b><div class="s3bar g"><i id="s3ghp"></i><span id="s3gt"></span></div></div><div class="s3r"><span id="s3time"></span><button class="s3b sm" data-s="cam" id="s3cam">🎥</button><button class="s3b sm" data-s="upg">⬆️<i class="s3dot" id="s3dot"></i></button><button class="s3b sm" data-s="pause">⏸</button></div></div>
  <div id="s3lvup"></div>
  <div id="s3msg"></div>
  <div class="s3joy" id="s3joy"><i id="s3knob"></i></div>
  <div class="s3side"><button class="s3b" data-s="heavy"><span>⚒️</span><em>ضربه‌ی سنگین</em></button><button class="s3b" data-s="block"><span>🛡️</span><em>سپر</em></button></div>
  <div class="s3btns"><button class="s3b big" data-s="atk">⚔️</button><button class="s3b" data-s="roll"><span>🌀</span><em>جاخالی</em></button><button class="s3b" data-s="spec"><span>💥</span><em>ضربه شاهانه</em><u id="s3c1"></u><b class="lk">🔒</b></button><button class="s3b" data-s="rally"><span>📣</span><em>فریاد جنگ</em><u id="s3c2"></u><b class="lk">🔒</b></button><button class="s3b" data-s="ram"><span>🐏</span><em>دروازه‌شکن</em><u id="s3c3"></u><b class="lk">🔒</b></button><button class="s3b" data-s="bolt"><span>⚡</span><em>سپر آذرخش</em><u id="s3c4"></u><b class="lk">🔒</b></button></div>
  <div class="s3cmd" id="s3cmd"><button class="s3tab" data-s="cmdtoggle" id="s3tab"><span>☰</span></button><div class="s3cin"><button data-s="o_attack"><span>⚔️</span>حمله</button><button data-s="o_gate"><span>🚪</span>دروازه</button><button data-s="o_guard"><span>🛡️</span>دفاع</button><button data-s="o_regroup"><span>📯</span>جمع شو</button></div><div class="s3ord" id="s3ord"></div></div>
  <div id="s3up" class="s3pause"></div>
  <div id="s3pause" class="s3pause"><div class="s3card"><h2>توقف</h2><button class="btn l g" data-s="resume">ادامه ▶</button><button class="btn l d" data-s="quit">خروج از نبرد</button></div></div>`;
  document.body.appendChild(root); document.body.classList.add("inbattle");
  const cv = root.querySelector("#s3c"), ctx = cv.getContext("2d", { alpha: false });
  const $ = (id) => root.querySelector("#" + id);
  let W = 0, H = 0, DPR = 1, F = 600;
  function resize() { DPR = Math.min(window.devicePixelRatio || 1, 2); W = innerWidth; H = innerHeight; const px = W * H * DPR * DPR, cap = 2.3e6; if (px > cap) DPR *= Math.sqrt(cap / px); cv.width = W * DPR | 0; cv.height = H * DPR | 0; cv.style.width = W + "px"; cv.style.height = H + "px"; F = Math.min(H * 1.15, W * 0.62); }
  resize(); addEventListener("resize", resize);

  // ---------- جهان ----------
  const ZG = 46, WALLH = 8, GATEW = 5.2, GATEH = 6.2, FRONT = ZG - 1.6, LIMX = FIELD ? 34 : 26, ZMAX = FIELD ? 34 : FRONT - 0.9;
  const st = stats(S.avatar), AV = S.avatar, SW = find("sword", AV.sword), SH = find("shield", AV.shield), HM = find("helm", AV.helm), AR = find("armor", AV.armor), CP = find("cape", AV.cape);
  const HX = heroInit(), up = HX.up, hpK = () => (1 + 0.08 * up.hp) * (1 + 0.03 * (HX.lv - 1)), pd = () => st.dmg * (1 + 0.06 * up.pow) * (1 + 0.02 * (HX.lv - 1)), cdK = () => 1 - 0.05 * up.sta, spK = () => 1 + 0.05 * up.spd;
  const P = { x: 0, z: 0, yaw: 0, hp: st.hp * hpK(), maxhp: st.hp * hpK(), atkT: 0, hitDone: true, combo: 0, comboT: 0, roll: 0, inv: 0, walk: 0, hurt: 0, vx: 0, vz: 0, dead: false, bob: 0 };
  const gateMax = FIELD ? 0 : Math.round(nb.gate * 0.85), G = { hp: gateMax, max: Math.max(1, gateMax), hit: 0, fall: 0, shake: 0 };
  const allies = [], corpses = [], foes = [], arrows = [], parts = [], texts = [], rams = [];
  const CAMM = [{ dist: 4.8, h: 2.9, pitch: 0.22, n: "پشت کاراکتر" }, { dist: 7.6, h: 5.0, pitch: 0.34, n: "تاکتیکی" }, { dist: 13.5, h: 10, pitch: 0.52, n: "بالا و دور" }];
  let camMode = 1; try { const v = parseInt(localStorage.getItem("bs_cam")); if (v >= 0 && v < 3) camMode = v; } catch (e) { /* */ }
  const cam = { yaw: 0, x: 0, y: 0, z: -7, pitch: 0.34, dist: CAMM[camMode].dist, h: CAMM[camMode].h, shake: 0, pb: CAMM[camMode].pitch, modeT: 0, dragT: 0 };
  const power = nb.power;
  const SL = (k) => skillLv(k === "bolt" ? "oil" : k);
  let winT = 0, enemyTotal = 1, upCb = null, time = 0, kills = 0, lost = 0, over = false, paused = false, cd = { spec: 0, rally: 0, ram: 0, bolt: 0, heavy: 0 }, boltT = 0, ordT = 0, rallyT = 0, spawnT = 4, captain = 0, msgT = 0, ended = false, raf = 0, last = performance.now(), endT = 0, endWon = false, deadT = 0, hitStop = 0;
  const LIMIT = FIELD ? 200 : 150, K = FIELD ? KEEP.k || {} : {};
  // یاران: از سپاه خریداری‌شده/غنیمت (در شروع فقط یک سرباز)
  const army = pickArmy(), nAll = army.length, armyIn = {}; let order = FIELD ? "attack" : "guard"; const orderName = { attack: FIELD ? "حمله‌ی همه‌جانبه" : "حمله به نگهبانان", gate: "کوبیدن دروازه", guard: "دفاع و همراهی", regroup: "جمع شدن" };
  for (let i = 0; i < nAll; i++) {
    const k = army[i], d = UNITS[k], m = mulLv(unitLv(k)); armyIn[k] = (armyIn[k] || 0) + 1;
    const lk = randomLook(900 + i * 7 + k.length, {});
    allies.push({ id: "a" + i, kind: k, look: lk, x: (i % 2 ? 1 : -1) * (2.2 + Math.floor(i / 2) * 1.5), z: 1.5 - Math.floor(i / 2) * 1.2, yaw: 0, hp: d.hp * m, maxhp: d.hp * m, dmg: d.dmg * 1.5 * m, speed: 5.8 * d.speed, cdT: Math.random(), walk: Math.random() * 6, hurt: 0, atkA: 0, ranged: k === "archer", off: i, tgt: null, sc: 0.9 + (lk.face.height - 1) * 1.2, bw: buildW(lk.face.build) });
  }
  const deadOw = {};
  if (nb.keep && S.ow && S.ow.allies) S.ow.allies.forEach((g, gi) => { const kinds = g.k === "turan" ? ["horse", "archer", "archer"] : g.k === "merc" ? ["sword", "shield", "sword"] : ["sword", "sword", "archer"]; const cnt = Math.min(4, Math.max(2, g.n)); for (let j = 0; j < cnt; j++) { const k = kinds[j % 3], d = UNITS[k], m = 0.8 + g.pow / Math.max(1, cnt) / 40, lk = randomLook(300 + gi * 31 + j * 7, {}); lk.skin = g.look[j % g.look.length].s || lk.skin; allies.push({ id: "o" + gi + "_" + j, ow: gi, kind: k, look: lk, x: (j % 2 ? 1 : -1) * (3.4 + j * 0.6), z: 2.8 - gi * 1.0, yaw: 0, hp: d.hp * m, maxhp: d.hp * m, dmg: d.dmg * 1.3 * m, speed: 5.6 * d.speed, cdT: Math.random(), walk: Math.random() * 6, hurt: 0, atkA: 0, ranged: k === "archer", off: 30 + j, tgt: null, sc: 0.9 + (lk.face.height - 1) * 1.2, bw: buildW(lk.face.build) }); } });
  const props = []; { let q = nb.power * 7 + 3; const rnd = () => { q = (q * 16807) % 2147483647; return q / 2147483647; }; for (let i = 0; i < 46; i++) { const side = rnd() < 0.5 ? -1 : 1, x = side * (5 + rnd() * 22), z = -12 + rnd() * 52; const kind = rnd() < 0.62 ? "tree" : rnd() < 0.5 || FIELD ? "rock" : "tent"; props.push({ x, z, kind, s: 0.8 + rnd() * 0.7, r: rnd() * 6 }); } if (!FIELD) for (const sx of [-1, 1]) for (let z = 4; z < 40; z += 9) props.push({ x: sx * 3.6, z, kind: "torch", s: 1, r: 0 }); }
  const envProps = [];
  { let q = (nb.power * 13 + 5) | 0 || 7; const rnd = () => { q = (q * 16807) % 2147483647; return q / 2147483647; };
    const TB = { n1: [["tree", 5], ["pine", 1], ["bush", 3], ["flower", 4], ["rock", 2], ["grass", 4]], n2: [["pine", 5], ["tree", 2], ["dead", 1], ["rock", 3], ["bush", 2], ["grass", 2]], n3: [["palm", 3], ["rock", 4], ["dead", 2], ["bush", 2], ["grass", 1]], n4: [["pine", 6], ["rock", 3], ["dead", 1]], n5: [["dead", 5], ["rock", 5], ["bush", 1]], n6: [["tree", 3], ["flower", 5], ["bush", 3], ["rock", 1], ["grass", 2]] };
    const tab = TB[nb.id] || TB.n1, tot = tab.reduce((a, b) => a + b[1], 0), HT = { tree: [5.5, 8], pine: [6, 9], palm: [5, 7], dead: [4, 6], bush: [1.1, 1.7], flower: [0.55, 0.95], rock: [0.9, 1.7], grass: [0.5, 0.9] };
    const zlo = FIELD ? -34 : -20, zhi = FIELD ? 46 : ZG - 4.5;
    for (let i = 0; i < 300 && envProps.length < 420; i++) {
      let r = rnd() * tot, ty = tab[0][0]; for (const [t, w] of tab) { if ((r -= w) <= 0) { ty = t; break; } }
      const x = (rnd() * 2 - 1) * 46, z = zlo + rnd() * (zhi - zlo), big = ty === "tree" || ty === "pine" || ty === "palm" || ty === "dead";
      if (!FIELD && Math.abs(x) < (big ? 7 : 5) && z > -16) continue;
      if (FIELD && big && ((x * x) / 144 + ((z - 6) * (z - 6)) / 484 < 1 || (x * x + (z + 12) * (z + 12)) < 100)) continue;
      const cl = ty === "flower" || ty === "grass" ? 3 : 1;
      for (let j = 0; j < cl; j++) { const nm = ENVK[ty][Math.floor(rnd() * ENVK[ty].length)], h = HT[ty][0] + rnd() * (HT[ty][1] - HT[ty][0]); envProps.push({ n: nm, ty, x: x + (j ? (rnd() - 0.5) * 3 : 0), z: z + (j ? (rnd() - 0.5) * 3 : 0), th: h, flip: rnd() < 0.5 }); }
    } }
  const oils = []; let oilT = 12;
  const archerPos = []; const nArch = 3 + nb.tlvl * 2; for (let i = 0; i < nArch; i++) archerPos.push(-LIMX + 6 + (i + 0.5) * ((LIMX * 2 - 12) / nArch));
  const wallArchers = archerPos.map((x, i) => ({ id: 0.137 * (i + 3), x, z: ZG - 0.4, y: WALLH, yaw: Math.PI, hp: 36 + power * 0.8, maxhp: 36 + power * 0.8, cdT: 1 + i * 0.5, kind: "warcher", walk: 0, hurt: 0, wall: true }));
  if (!FIELD) for (const a of wallArchers) foes.push(a);

  // ---------- ورودی ----------
  const key = {}, joy = { on: false, id: null, x: 0, y: 0, ox: 0, oy: 0 }; let camTouch = null;
  const mv = () => { let x = (key.d || key.arrowright ? 1 : 0) - (key.a || key.arrowleft ? 1 : 0), y = (key.w || key.arrowup ? 1 : 0) - (key.s || key.arrowdown ? 1 : 0); x += joy.x; y += joy.y; const l = Math.hypot(x, y); return l > 1 ? [x / l, y / l] : [x, y]; };
  const onKD = (e) => { const k = e.key.toLowerCase(); key[k] = true; if (k === " ") { act("atk"); e.preventDefault(); } if (k === "shift") act("roll"); if (k === "r") act("spec"); if (k === "f") act("rally"); if (k === "g") act("ram"); if (k === "h") act("bolt"); if (k === "1") act("o_attack"); if (k === "2") act("o_gate"); if (k === "3") act("o_guard"); if (k === "4") act("o_regroup"); if (k === "c") act("cam"); if (k === "u") act("upg"); if (k === "escape") act(paused ? "resume" : "pause"); };
  const onKU = (e) => { key[e.key.toLowerCase()] = false; };
  addEventListener("keydown", onKD); addEventListener("keyup", onKU);
  const joyEl = $("s3joy"), knob = $("s3knob");
  joyEl.addEventListener("pointerdown", (e) => { joy.on = true; joy.id = e.pointerId; joyEl.setPointerCapture(e.pointerId); joyMove(e); e.preventDefault(); });
  joyEl.addEventListener("pointermove", (e) => { if (joy.on && e.pointerId === joy.id) joyMove(e); });
  const joyEnd = (e) => { if (e.pointerId === joy.id) { joy.on = false; joy.x = joy.y = 0; knob.style.transform = "translate(0,0)"; } };
  joyEl.addEventListener("pointerup", joyEnd); joyEl.addEventListener("pointercancel", joyEnd);
  function joyMove(e) { const r = joyEl.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2, R = r.width / 2; let dx = (e.clientX - cx) / R, dy = (e.clientY - cy) / R; const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; } joy.x = Math.abs(dx) < 0.1 ? 0 : dx; joy.y = Math.abs(dy) < 0.1 ? 0 : -dy; knob.style.transform = `translate(${dx * R * 0.55}px,${dy * R * 0.55}px)`; }
  cv.addEventListener("pointerdown", (e) => { if (camTouch === null) { camTouch = { id: e.pointerId, x: e.clientX, y: e.clientY }; cv.setPointerCapture(e.pointerId); } });
  cv.addEventListener("pointermove", (e) => { if (camTouch && camTouch.id === e.pointerId) { cam.yaw += (e.clientX - camTouch.x) * 0.0065; cam.dragT = 1.4; cam.modeT = 0; cam.pb = clamp((cam.pb || 0.34) + (e.clientY - (camTouch.y || e.clientY)) * 0.003, 0.08, 0.62); camTouch.x = e.clientX; camTouch.y = e.clientY; } });
  const camEnd = (e) => { if (camTouch && camTouch.id === e.pointerId) camTouch = null; };
  cv.addEventListener("pointerup", camEnd); cv.addEventListener("pointercancel", camEnd);
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-s]"); if (b) act(b.dataset.s); });
  root.querySelectorAll(".s3b,.s3cmd button").forEach((b) => b.addEventListener("pointerdown", (e) => { const a = b.dataset.s; if (a === "atk" || a === "roll" || a === "heavy" || a === "spec" || a === "rally" || a === "ram" || a === "bolt" || a[1] === "_") { e.preventDefault(); e.stopPropagation(); act(a); b.classList.add("p"); setTimeout(() => b.classList.remove("p"), 120); } }));
  root.querySelectorAll(".s3b,.s3cmd button").forEach((b) => b.addEventListener("click", (e) => { const a = b.dataset.s; if (a === "atk" || a === "roll" || a === "heavy" || a === "spec" || a === "rally" || a === "ram" || a === "bolt" || a[1] === "_") e.stopPropagation(); }, true));

  { const bb = root.querySelector('[data-s=block]'), setB = (v) => { if (paused || over || P.dead) v = false; P.block = v; bb.classList.toggle("p", v); };
    bb.addEventListener("pointerdown", (e) => { e.preventDefault(); e.stopPropagation(); bb.setPointerCapture(e.pointerId); setB(true); });
    const rel = (e) => { e.stopPropagation(); setB(false); }; bb.addEventListener("pointerup", rel); bb.addEventListener("pointercancel", rel); bb.addEventListener("lostpointercapture", () => setB(false));
    addEventListener("keydown", (e) => { if (e.key.toLowerCase() === "q") setB(true); }); addEventListener("keyup", (e) => { if (e.key.toLowerCase() === "q") setB(false); }); }
  function updCmd() { root.querySelectorAll(".s3cmd button").forEach((b) => b.classList.toggle("on", b.dataset.s === "o_" + order)); }
  ['spec', 'rally', 'ram', 'bolt'].forEach((k) => { const b = root.querySelector(`[data-s=${k}]`); b.classList.toggle("locked", !SL(k)); });
  function say(t, d = 2.2) { const m = $("s3msg"); m.textContent = t; m.classList.add("on"); msgT = d; }
  function act(a) {
    if (a === "pause") { paused = true; $("s3pause").classList.add("on"); return; }
    if (a === "resume") { paused = false; $("s3pause").classList.remove("on"); last = performance.now(); return; }
    if (a === "quit") { finish(false, true); return; }
    if (a === "cam") { camMode = (camMode + 1) % 3; try { localStorage.setItem("bs_cam", camMode); } catch (e) { /* */ } cam.modeT = 0.9; say("دوربین: " + CAMM[camMode].n, 1.2); return; }
    if (a === "upg") { openUp(false); return; }
    if (a === "upclose") { closeUp(); return; }
    if (a.startsWith("up_")) { if (heroBuy(a.slice(3))) { Sound.sfx("click"); applyHero(); } else Sound.sfx("error"); renderUp(); return; }
    if (a === "cmdtoggle") { $("s3cmd").classList.toggle("open"); return; }
    if (paused || over || P.dead) return;
    if (a === "atk") { if (P.atkT <= (P.am || 0.3) * 0.5 && P.roll <= 0 && !P.block) { P.atkT = P.am = 0.3; P.heavy = false; P.hitDone = false; P.combo = P.comboT > 0 ? (P.combo + 1) % 3 : 0; P.comboT = 0.8; autoAim(); Sound.sfx("shot_spear", { vol: 0.5 }); } }
    else if (a === "heavy") { if (cd.heavy <= 0 && P.atkT <= 0.1 && P.roll <= 0 && !P.block) { cd.heavy = 1.8 * cdK(); P.atkT = P.am = 0.46; P.heavy = true; P.hitDone = false; P.combo = 1; P.comboT = 0; autoAim(); Sound.sfx("shot_spear", { vol: 0.7 }); } }
    else if (a === "block") { /* با نگه‌داشتن */ }
    else if (a === "roll") { if (P.roll <= 0) { const [mx, my] = mv(); let d = P.yaw; if (mx || my) d = camAng(mx, my); P.rd = d; P.roll = 0.34; P.inv = 0.45; P.atkT = 0; Sound.sfx("tick"); } }
    else if (a[1] === "_") { $("s3cmd").classList.remove("open"); order = a.slice(2); if (order === "gate" && FIELD) order = "attack"; if (order === "regroup") { for (const al of allies) { al.x = P.x + (Math.random() - 0.5) * 4; al.z = P.z - 1 - Math.random() * 2; } ring(P.x, P.z, 4, "#7bd8ff"); order = "guard"; } $("s3ord").textContent = "فرمان: " + orderName[order]; $("s3ord").classList.add("on"); clearTimeout(ordT); ordT = setTimeout(() => $("s3ord").classList.remove("on"), 2500); Sound.sfx("click"); updCmd(); $("s3cmd").classList.remove("open"); }
    else if ((a === "spec" || a === "rally" || a === "ram" || a === "bolt") && !SL(a)) { say("🔒 این مهارت را از «تجهیزات ← مهارت‌ها» بخر", 2.2); Sound.sfx("error"); }
    else if (a === "spec") { if (cd.spec <= 0) { cd.spec = SKILLS.spec.cd[SL("spec") - 1] * cdK(); slam(); } }
    else if (a === "bolt") { if (cd.bolt <= 0) { cd.bolt = SKILLS.oil.cd[SL("bolt") - 1] * cdK(); boltT = 4 + SL("bolt") * 1.5; P.inv = boltT; say("سپر آذرخش! ⚡", 1.6); Sound.sfx("skill_kaveh"); } }
    else if (a === "rally") { if (cd.rally <= 0) { cd.rally = SKILLS.rally.cd[SL("rally") - 1] * cdK(); rallyT = 6 + SL("rally") * 2; for (const al of allies) { al.hp = Math.min(al.maxhp, al.hp + al.maxhp * 0.2); burst(al.x, 1, al.z, 8, "#ffd36b", 3); } ring(P.x, P.z, 7, "#ffd36b"); Sound.sfx("skill_kaveh"); say("یاران، به پیش! ⚔️", 1.6); } }
    else if (a === "ram") { if (cd.ram <= 0 && !FIELD) { cd.ram = SKILLS.ram.cd[SL("ram") - 1]; const lv = SL("ram"); rams.push({ x: clamp(P.x, -5, 5), z: P.z - 6, hp: 220 * (1 + lv * 0.5), maxhp: 220 * (1 + lv * 0.5), dmg: 110 * (1 + lv * 0.55), roll: 0, hits: 0, cdT: 0 }); Sound.sfx("troop_spawn"); say("دروازه‌شکن فرستاده شد! 🐏", 1.8); } }
  }
  const camAng = (mx, my) => { const f = cam.yaw, fx = Math.sin(f), fz = Math.cos(f), rx = Math.cos(f), rz = -Math.sin(f); return Math.atan2(rx * mx + fx * my, rz * mx + fz * my); };
  function autoAim() { let b = null, bd = 4.2; for (const f of foes) { if (f.wall || f.dead) continue; const d = Math.hypot(f.x - P.x, f.z - P.z); if (d < bd) { bd = d; b = f; } } if (b) P.yaw = Math.atan2(b.x - P.x, b.z - P.z); else if (Math.abs(P.z - (FRONT - 0.6)) < 4.5) P.yaw = Math.atan2(-P.x * 0.5, 1); }

  // ---------- افکت‌ها ----------
  function burst(x, y, z, n, color, sp = 3) { if (parts.length > 260) return; for (let i = 0; i < n; i++) { const a = Math.random() * TAU; parts.push({ x, y, z, vx: Math.cos(a) * sp * Math.random(), vy: Math.random() * sp * 1.1, vz: Math.sin(a) * sp * Math.random(), life: 0.5 + Math.random() * 0.4, max: 0.9, c: color, s: 0.09 + Math.random() * 0.1 }); } }
  function ring(x, z, r, color) { parts.push({ ring: true, x, y: 0.08, z, r, life: 0.5, max: 0.5, c: color }); }
  function text(x, y, z, t, color) { texts.push({ x, y, z, t, c: color, life: 0.9 }); }
  function hurtP(dmg, from) {
    if (P.inv > 0 || P.dead) return; dmg = dmg * (1 - st.def); if (P.block) { dmg *= 0.2 - 0.012 * up.sta; ring(P.x, P.z, 1.8, "#9fe8ff"); Sound.sfx("hit", { vol: 0.5 }); } P.hp -= dmg; P.hurt = 0.25; cam.shake = Math.max(cam.shake, 0.18); text(P.x, 2.4, P.z, "-" + Math.round(dmg), "#ff6a6a"); Sound.sfx("hit_heavy", { vol: 0.6 }); burst(P.x, 1.2, P.z, 6, "#ff8a8a", 2.5);
    if (P.hp <= 0) { P.hp = 0; P.dead = true; deadT = 1.4; say("افتادی… 💔", 2); }
  }
  function slam() {
    P.critNow = false; const dmg = pd() * (2 + SL("spec") * 0.6); ring(P.x, P.z, 5, "#ffd24a"); ring(P.x, P.z, 3, "#fff"); burst(P.x, 0.5, P.z, 30, "#ffd24a", 6); cam.shake = 0.5; Sound.sfx("explode", { vol: 0.7 }); hitStop = 0.08;
    for (const f of foes) { if (f.wall) continue; const d = Math.hypot(f.x - P.x, f.z - P.z); if (d < 5) { dmgFoe(f, dmg, P); f.stun = 1.3; const a = Math.atan2(f.x - P.x, f.z - P.z); f.x += Math.sin(a) * 2; f.z += Math.cos(a) * 2; } }
    if (P.z > FRONT - 5.5 && Math.abs(P.x) < 6) hitGate(dmg * 1.6, P.x, P.z + 1);
  }
  function dmgFoe(f, d, src) {
    if (f.dead) return; f.hp -= d; f.hurt = 0.2; if (src === P) gainXp(1 + d / 40); text(f.x, (f.y || 0) + 2.4 * (f.sc || 1), f.z, Math.round(d) + (src === P && P.critNow ? "!" : ""), src === P ? (P.critNow ? "#ff9a3a" : "#fff2b0") : "#ffd0a0"); burst(f.x, (f.y || 0) + 1.2, f.z, 4, "#ffe0b0", 2.5);
    if (f.hp <= 0) { f.dead = true; f.deadT = 0.7; kills++; gainXp(6 + f.maxhp / 18); burst(f.x, (f.y || 0) + 1, f.z, 14, "#d8c0a0", 4); Sound.sfx("enemy_die"); }
  }
  function hitGate(d, x, z) {
    if (G.hp <= 0 || FIELD) return; gainXp(d / 45); G.hp = Math.max(0, G.hp - d); G.hit = 0.18; G.shake = 0.25; cam.shake = Math.max(cam.shake, 0.12); text(x, 3.5, FRONT - 0.5, Math.round(d), "#ffb347"); burst(x, 2.5, FRONT - 0.3, 8, "#caa070", 3); Sound.sfx("gate_hit");
    if (G.hp <= 0) { G.fall = 0.001; Sound.sfx("explode"); cam.shake = 0.9; burst(0, 3, FRONT, 60, "#caa070", 8); say("دروازه شکست! 🏰", 3); }
  }

  // ---------- پیشرفت قهرمان ----------
  function applyHero() { const r = P.hp / P.maxhp; P.maxhp = st.hp * hpK(); P.hp = clamp(r * P.maxhp, 0, P.maxhp); }
  function gainXp(x) {
    const n = heroXp(x); if (!n) return; const el = $("s3lvup"); el.innerHTML = `<b>سطح ${HX.lv}</b><span>+${n} امتیاز ارتقا ⬆️</span>`; el.classList.remove("on"); void el.offsetWidth; el.classList.add("on");
    Sound.sfx("skill_kaveh"); ring(P.x, P.z, 3.5, "#ffd24a"); burst(P.x, 1, P.z, 24, "#ffd24a", 5); applyHero(); if (!P.dead) P.hp = Math.min(P.maxhp, P.hp + P.maxhp * 0.25);
  }
  function renderUp() {
    const el = $("s3up"), pips = (v) => Array.from({ length: HERO_MAXUP }, (_, i) => `<i class="${i < v ? "on" : ""}"></i>`).join("");
    el.innerHTML = `<div class="s3card s3upc"><h2>⬆️ ارتقای قهرمان</h2><div class="s3upsum"><b>سطح ${HX.lv}</b> • امتیاز: <b class="${HX.pts ? "hot" : ""}">${HX.pts}</b></div><div class="s3xp big"><i style="width:${HX.xp / heroNeed(HX.lv) * 100}%"></i><span>${Math.round(HX.xp)} / ${heroNeed(HX.lv)}</span></div>` +
      HERO_UP.map((u) => `<div class="s3urow"><span class="ui">${u.i}</span><div class="ut"><b>${u.n}</b><small>${u.d}</small><div class="pips">${pips(up[u.k])}</div></div><button class="s3ubtn" data-s="up_${u.k}" ${HX.pts < 1 || up[u.k] >= HERO_MAXUP ? "disabled" : ""}>＋</button></div>`).join("") +
      `<div class="s3uhint">با کشتن دشمنان و زدن ضربه تجربه می‌گیری؛ هر سطح یک امتیاز می‌دهد.</div><button class="btn l g" data-s="upclose">ادامه ▶</button></div>`;
  }
  function openUp(final, cb) { upCb = cb || null; paused = true; renderUp(); $("s3up").classList.add("on"); }
  function closeUp() { $("s3up").classList.remove("on"); const cb = upCb; upCb = null; if (cb) { cb(); return; } paused = false; last = performance.now(); }
  const BEASTS = { wolf: { hpK: 1, dmgK: 1, spd: 6.8, sc: 1 }, bear: { hpK: 3.6, dmgK: 2.3, spd: 4.4, sc: 1.55 }, boar: { hpK: 1.8, dmgK: 1.4, spd: 5.8, sc: 1.0 }, lion: { hpK: 2.2, dmgK: 1.8, spd: 6.6, sc: 1.2 } };
  const beastOf = () => { if (!FIELD || !K.beast) return null; const id = (K.id || "") + " " + (K.name || ""); if (/bear|خرس/i.test(id)) return "bear"; if (/boar|گراز/.test(id)) return "boar"; if (/lion|شیر|panther|پلنگ/i.test(id)) return "lion"; return "wolf"; };
  if (FIELD) {
    P.z = -12; for (const a of allies) a.z -= 12; cam.z = P.z - cam.dist; cam.x = 0;
    const bt = beastOf(), En = clamp(Math.round(KEEP.n * 1.7 + 1), 4, 40), upow = Math.max(2, KEEP.pow / Math.max(1, KEEP.n)); let sd = 11; const rr = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
    for (let i = 0; i < En; i++) {
      const col = i % 8, row = Math.floor(i / 8), x = (col - 3.5) * 2.0 + (rr() - 0.5) * 1.2, z = 22 + row * 2.2 + (rr() - 0.5) * 1.5;
      if (bt) { const B = BEASTS[bt], hp = (30 + upow * 4) * B.hpK; foes.push({ id: 0.01 + rr(), kind: "beast", beast: bt, x, z, yaw: Math.PI, hp, maxhp: hp, dmg: (5 + upow * 0.6) * B.dmgK, speed: B.spd * (0.9 + rr() * 0.2), sc: B.sc * (0.92 + rr() * 0.16), walk: rr() * 6, cdT: 0.6 + rr(), hurt: 0, atkA: 0, stun: rr() * 1.6 }); }
      else { const boss = i === 0 && En >= 10, heavy = !boss && upow > 6 && rr() < 0.22, kind = boss ? "captain" : heavy ? "heavy" : "guard", hp = boss ? 260 + upow * 18 : (heavy ? 2.1 : 1) * (50 + upow * 6), spawnX = boss ? 0 : x; foes.push({ id: 0.01 + rr(), kind, dark: K.id === "div", x: spawnX, z: boss ? 27 : z, yaw: Math.PI, hp, maxhp: hp, dmg: boss ? 13 + upow * 0.8 : (heavy ? 1.4 : 1) * (5 + upow * 0.5), speed: boss ? 4.6 : heavy ? 3.8 : 5.0 * (0.9 + rr() * 0.2), sc: boss ? 1.4 : heavy ? 1.12 : 1, walk: rr() * 6, cdT: 0.6 + rr(), hurt: 0, atkA: 0, stun: rr() * 1.6 }); }
    }
    enemyTotal = foes.reduce((n, f) => n + f.maxhp, 0);
  }
  // ---------- دشمنان ----------
  function spawnGuard(captainMode) {
    const side = Math.random() < 0.5 ? -1 : 1, x = side * (LIMX - 3.5), z = FRONT - 1;
    const heavy = !captainMode && power > 55 && Math.random() < 0.4;
    const hp = captainMode ? 380 + power * 9 : (heavy ? 2.1 : 1) * (60 + power * 1.8);
    foes.push({ id: Math.random(), kind: captainMode ? "captain" : heavy ? "heavy" : "guard", x, z, yaw: Math.PI, hp, maxhp: hp, dmg: (captainMode ? 22 : heavy ? 10 : 7) + power * (captainMode ? 0.35 : 0.1), speed: captainMode ? 4.6 : heavy ? 3.8 : 5.0, sc: captainMode ? 1.45 : heavy ? 1.12 : 1, walk: Math.random() * 6, cdT: 0.6, hurt: 0, atkA: 0, stun: 0 });
    burst(x, 1, z, 8, "#8a7a6a", 2);
  }

  // ---------- به‌روزرسانی ----------
  function update(dt) {
    time += dt; if (msgT > 0) { msgT -= dt; if (msgT <= 0) $("s3msg").classList.remove("on"); }
    for (const k in cd) cd[k] = Math.max(0, cd[k] - dt); rallyT = Math.max(0, rallyT - dt);
    if (boltT > 0) { boltT -= dt; if (Math.random() < dt * 14) burst(P.x + (Math.random() - 0.5) * 2, 0.5 + Math.random() * 2, P.z + (Math.random() - 0.5) * 2, 2, "#9fe8ff", 3); for (const f of foes) { if (f.wall || f.dead) continue; if (Math.hypot(f.x - P.x, f.z - P.z) < 3.2 && Math.random() < dt * 3) dmgFoe(f, pd() * 0.8, P); } }
    P.atkT = Math.max(0, P.atkT - dt); P.comboT = Math.max(0, P.comboT - dt); P.hurt = Math.max(0, P.hurt - dt); P.inv = Math.max(0, P.inv - dt);
    G.hit = Math.max(0, G.hit - dt); G.shake = Math.max(0, G.shake - dt); cam.shake = Math.max(0, cam.shake - dt * 1.6);
    if (G.fall > 0) { G.fall += dt; if (G.fall > 1.8 && !over) finish(true); }
    // بازیکن
    if (!P.dead) {
      const [mx, my] = mv(); let sp = 0;
      if (P.roll > 0) { P.roll -= dt; sp = 17 * spK(); P.x += Math.sin(P.rd) * sp * dt; P.z += Math.cos(P.rd) * sp * dt; P.yaw = P.rd; }
      else if (mx || my) { const d = camAng(mx, my), m = Math.hypot(mx, my); sp = (P.atkT > 0 ? 4.6 : P.block ? 4.2 : 10.6 * spK()) * m; P.yaw += angDiff(P.yaw, d) * Math.min(1, dt * 14); P.x += Math.sin(d) * sp * dt; P.z += Math.cos(d) * sp * dt; }
      P.walk += sp * dt * 1.8; P.moving = sp;
      if (P.atkT > 0 && !P.hitDone && P.atkT < (P.am || 0.3) - (P.heavy ? 0.2 : 0.11)) {
        P.hitDone = true; const crit = Math.random() < 0.04 * up.crit; P.critNow = crit; const dm = pd() * (crit ? 1.9 : 1) * (P.heavy ? 2.6 : (1 + P.combo * 0.18) * (P.combo === 2 ? 1.2 : 1)), HV = P.heavy ? 1 : 0; let hit = 0; hitStop = 0.03; if (crit) text(P.x, 3.0, P.z, "✦", "#ffcf5a");
        for (const f of foes) { if (f.wall || f.dead) continue; const dx = f.x - P.x, dz = f.z - P.z, d = Math.hypot(dx, dz); if (d < 2.9 * (SW.len * 0.9 + 0.2) * (HV ? 1.25 : 1) && Math.abs(angDiff(P.yaw, Math.atan2(dx, dz))) < (HV ? 1.9 : 1.25)) { dmgFoe(f, dm, P); const kb = HV ? 1.9 : 0.7; f.x += dx / (d || 1) * kb; f.z += dz / (d || 1) * kb; f.stun = Math.max(f.stun || 0, HV ? 0.7 : 0.25); hit++; } }
        if (P.z > FRONT - 3.4 && Math.abs(P.x) < GATEW / 2 + 1.6 && Math.abs(angDiff(P.yaw, 0)) < 1.1) { hitGate(dm * 1.5, P.x, P.z); hit++; }
        if (hit) { Sound.sfx("hit", { vol: 0.7 }); cam.shake = Math.max(cam.shake, HV ? 0.3 : 0.1); if (HV) ring(P.x + Math.sin(P.yaw) * 1.5, P.z + Math.cos(P.yaw) * 1.5, 2.6, "#ff9a5a"); } else Sound.sfx("shot_spear", { vol: 0.3 });
        burst(P.x + Math.sin(P.yaw) * 1.8, 1.3, P.z + Math.cos(P.yaw) * 1.8, 5, SW.glow || "#fff", 3); P.critNow = false;
      }
    } else { deadT -= dt; if (deadT <= 0 && !over && (!FIELD || allies.length === 0)) finish(false); }
    P.x = clamp(P.x, -LIMX + 1, LIMX - 1); P.z = clamp(P.z, FIELD ? -34 : -14, ZMAX);
    // نگهبانان
    spawnT -= dt; const aliveG = foes.filter((f) => !f.wall && !f.dead).length;
    if (spawnT <= 0 && G.hp > 0) { spawnT = Math.max(3.4, 9.5 - power / 22) * (0.8 + Math.random() * 0.4); const n = 1 + (power > 40 ? 1 : 0) + (power > 85 ? 1 : 0); if (aliveG < 6 + (power > 60 ? 3 : 0)) for (let i = 0; i < n; i++) spawnGuard(false); }
    oilT -= dt; if (oilT <= 0 && G.hp > 0) { oilT = Math.max(7, 16 - power / 12); const px = P.z > FRONT - 8 ? P.x : (Math.random() - 0.5) * 8; oils.push({ x: clamp(px, -6, 6), z: FRONT - 2.4, t: 1.9 }); say("روغن داغ از دیوار! جاخالی بده 🔥", 1.8); }
    for (let i = oils.length - 1; i >= 0; i--) { const h = oils[i]; h.t -= dt; if (h.t <= 0) { burst(h.x, 0.5, h.z, 26, "#ff8a3a", 5); ring(h.x, h.z, 2.6, "#ff6a2a"); cam.shake = Math.max(cam.shake, 0.2); if (!P.dead && Math.hypot(P.x - h.x, P.z - h.z) < 2.6) hurtP(14 + power * 0.18); for (const a of allies) if (Math.hypot(a.x - h.x, a.z - h.z) < 2.6) { a.hp -= 12 + power * 0.15; a.hurt = 0.2; } oils.splice(i, 1); } }
    const frac = G.hp / G.max;
    if (!FIELD && captain === 0 && frac < 0.62) { captain = 1; spawnGuard(true); say("سردار نگهبانان آمد! ⚠️", 2.5); Sound.sfx("boss_roar"); cam.shake = 0.4; }
    if (!FIELD && captain === 1 && frac < 0.25) { captain = 2; spawnGuard(true); for (let i = 0; i < 3; i++) spawnGuard(false); say("آخرین سنگر! ⚠️", 2.5); Sound.sfx("boss_roar"); }
    const targets = () => [P, ...allies, ...rams].filter((t) => !t.dead && (t === P ? !P.dead : t.hp > 0));
    const tg = targets();
    for (const f of foes) {
      if (f.dead) { f.deadT -= dt; continue; } f.hurt = Math.max(0, (f.hurt || 0) - dt); f.cdT -= dt;
      if (f.wall) {
        if (f.cdT <= 0 && G.hp > 0) { let b = null, bd = 42; for (const t of tg) { const d = Math.hypot(t.x - f.x, t.z - f.z); if (d < bd && t.z < ZG - 6) { bd = d; b = t; } } if (b) { f.cdT = 2.4 + Math.random() * 1.4; f.yaw = Math.atan2(b.x - f.x, b.z - f.z); const vx = (b === P ? P.vx : 0), t = bd / 18; arrows.push({ x: f.x, y: WALLH + 1.5, z: f.z, tx: b.x + vx * t, tz: b.z + (b.vz || 0) * t, t: 0, T: t, dmg: 5 + power * 0.1, tg: b }); Sound.sfx("shot_bow", { vol: 0.35 }); } else f.cdT = 0.5; }
        continue;
      }
      if (f.stun > 0) { f.stun -= dt; continue; }
      let b = null, bd = 1e9; for (const t of tg) { let d = Math.hypot(t.x - f.x, t.z - f.z); if (t === P) d *= 0.8; if (d < bd) { bd = d; b = t; } }
      if (!b) continue; const dx = b.x - f.x, dz = b.z - f.z, d = Math.hypot(dx, dz), range = 1.5 * (f.sc || 1), want = Math.atan2(dx, dz);
      f.yaw += angDiff(f.yaw, want) * Math.min(1, dt * 10);
      if (d > range) { const s = f.speed * (f.atkA > 0 ? 0.3 : 1); f.x += dx / d * s * dt; f.z += dz / d * s * dt; f.walk += s * dt * 1.8; }
      else if (f.cdT <= 0) { f.cdT = f.kind === "captain" ? 1.15 : f.beast ? 0.95 : 0.95; f.atkA = 0.4; f.hitD = false; }
      if (f.atkA > 0) { f.atkA -= dt; if (!f.hitD && f.atkA < 0.22) { f.hitD = true; if (b === P) hurtP(f.dmg); else if (b.hp > 0) { b.hp -= f.dmg * (b.maxhp ? 2.6 : 1); b.hurt = 0.2; burst(b.x, 1.2, b.z, 3, "#ff8a8a", 2); } } }
      f.z = Math.min(f.z, ZMAX); f.x = clamp(f.x, -LIMX - 4, LIMX + 4);
    }
    for (let i = foes.length - 1; i >= 0; i--) if (foes[i].dead && foes[i].deadT <= 0) foes.splice(i, 1);
    if (FIELD && !over) { const left = foes.reduce((n, f) => n + (f.dead ? 0 : 1), 0); if (left === 0) { winT += dt; if (winT > 1.1) finish(true); } }
    // پرتاب تیرها
    for (let i = arrows.length - 1; i >= 0; i--) {
      const a = arrows[i]; a.t += dt; if (a.t >= a.T) { const hitT = (t) => Math.hypot(t.x - a.tx, t.z - a.tz) < 1.1; if (a.tg === P) { if (!P.dead && hitT(P)) hurtP(a.dmg); } else if (a.tg && a.tg.hp > 0 && hitT(a.tg)) { a.tg.hp -= a.dmg * (a.tg.maxhp ? 2.6 : 1); a.tg.hurt = 0.2; } burst(a.tx, 0.2, a.tz, 3, "#cbb89a", 1.5); arrows.splice(i, 1); }
    }
    // یاران
    const slots = allies.length; let fr2 = 0; void fr2;
    for (let i = allies.length - 1; i >= 0; i--) {
      const a = allies[i]; if (a.hp <= 0) { lost++; burst(a.x, 1, a.z, 14, "#c04040", 3); text(a.x, 2.2, a.z, "☠", "#ffb0b0"); corpses.push({ a, t: 1.6, dir: Math.random() < 0.5 ? 1 : -1 }); if (a.ow !== undefined) deadOw[a.ow] = (deadOw[a.ow] || 0) + 1; allies.splice(i, 1); Sound.sfx("enemy_die"); say("🕯️ یکی از یارانت افتاد", 1.6); continue; }
      a.hurt = Math.max(0, a.hurt - dt); a.cdT -= dt; const mul = rallyT > 0 ? 1.4 : 1;
      const fr = order === "attack" ? 40 : order === "gate" && !FIELD ? 5 : order === "regroup" ? 0 : 8;
      let t = null, td = fr || 0; if (fr) for (const f of foes) { if (f.dead) continue; if (f.wall && !a.ranged) continue; const ox = order === "guard" ? P.x : a.x, oz = order === "guard" ? P.z : a.z; const d = Math.hypot(f.x - ox, f.z - oz); if (d < td) { td = Math.hypot(f.x - a.x, f.z - a.z); t = f; fr2 = 1; } }
      let gx, gz, engage = false, range = a.ranged ? 11 : 1.7; a.gate = false;
      if (t) { gx = t.x; gz = t.z; engage = true; if (t.wall) range = 13; }
      else if (order === "gate" && G.hp > 0 && !FIELD) { if (a.ranged) { const w = wallArchers.find((q) => !q.dead); if (w) { gx = w.x; gz = w.z; t = w; engage = true; range = 13; } else { gx = P.x; gz = P.z - 2; range = 1; } } else { gx = clamp((a.off - slots / 2) * 1.1, -4, 4); gz = FRONT - 1 - (a.off % 2) * 0.9; range = 0.3; engage = true; a.gate = true; } }
      else { gx = P.x + Math.cos(a.off * 1.9) * (2.4 + (a.off % 3)); gz = P.z - 1.5 - (a.off % 4) * 1.1; range = 0.6; }
      const dx = gx - a.x, dz = gz - a.z, d = Math.hypot(dx, dz);
      if (d > range) { const pd2 = Math.hypot(a.x - P.x, a.z - P.z), s = a.speed * (rallyT > 0 ? 1.3 : 1) * (!t && pd2 > 12 ? 1.9 : 1); a.x += dx / d * s * dt; a.z += dz / d * s * dt; a.walk += s * dt * 1.8; a.yaw += angDiff(a.yaw, Math.atan2(dx, dz)) * Math.min(1, dt * 10); }
      else if (engage) { a.yaw += angDiff(a.yaw, Math.atan2(dx, dz || 0.001)) * Math.min(1, dt * 10); if (a.cdT <= 0) { a.cdT = (a.ranged ? 1.5 : 0.95) / mul; a.atkA = 0.35; if (a.gate) hitGate(a.dmg * 0.5 * mul, a.x, a.z); else if (t) { if (a.ranged) { arrows.push({ x: a.x, y: 1.5, z: a.z, tx: t.x, tz: t.z, t: 0, T: Math.max(0.2, d / 22), dmg: 0, ally: t, ad: a.dmg * mul }); Sound.sfx("shot_bow", { vol: 0.25 }); } else { dmgFoe(t, a.dmg * mul, a); } } } }
      if (a.atkA > 0) a.atkA -= dt; a.x = clamp(a.x, -LIMX + 1, LIMX - 1); a.z = clamp(a.z, FIELD ? -34 : -14, ZMAX);
    }
    // اصلاح تیر یاران
    for (let i = arrows.length - 1; i >= 0; i--) { const a = arrows[i]; if (a.ally && a.t + dt >= a.T && a.ally && !a.done) { a.done = true; if (!a.ally.dead) { if (a.ally.wall) { a.ally.hp -= a.ad; a.ally.hurt = 0.2; if (a.ally.hp <= 0) { a.ally.dead = true; a.ally.deadT = 0.7; kills++; } } else dmgFoe(a.ally, a.ad, a); } } }
    // دروازه‌شکن‌ها
    for (let i = rams.length - 1; i >= 0; i--) {
      const r = rams[i]; if (r.hp <= 0) { burst(r.x, 1, r.z, 20, "#a07a4a", 4); rams.splice(i, 1); continue; }
      if (r.z < FRONT - 1.4) { r.z += 3.6 * dt; r.roll += dt * 5; } else { r.cdT -= dt; if (r.cdT <= 0 && r.hits < 6) { r.cdT = 0.9; r.hits++; r.recoil = 0.3; hitGate(r.dmg, r.x, FRONT); } if (r.hits >= 6) { r.hp -= 9999 * dt; } }
      r.recoil = Math.max(0, (r.recoil || 0) - dt);
    }
    // جداسازی
    const all = [P, ...allies, ...foes.filter((f) => !f.wall && !f.dead)];
    for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) { const a = all[i], b = all[j], dx = b.x - a.x, dz = b.z - a.z, d2 = dx * dx + dz * dz; if (d2 < 0.64 && d2 > 1e-4) { const d = Math.sqrt(d2), p = (0.8 - d) * 0.5; if (a !== P) { a.x -= dx / d * p; a.z -= dz / d * p; } if (b !== P) { b.x += dx / d * p; b.z += dz / d * p; } } }
    // ذرات
    for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.life -= dt; if (p.life <= 0) { parts.splice(i, 1); continue; } if (!p.ring) { p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.vy -= 9 * dt; if (p.y < 0.05) { p.y = 0.05; p.vy *= -0.3; } } }
    for (let i = texts.length - 1; i >= 0; i--) { const t = texts[i]; t.life -= dt; t.y += dt * 1.2; if (t.life <= 0) texts.splice(i, 1); }
    // دوربین
    { const M = CAMM[camMode]; cam.dist = lerp(cam.dist, M.dist, Math.min(1, dt * 4)); cam.h = lerp(cam.h, M.h, Math.min(1, dt * 4)); if (cam.modeT > 0) { cam.modeT -= dt; cam.pb = lerp(cam.pb, M.pitch, Math.min(1, dt * 6)); } cam.dragT = Math.max(0, cam.dragT - dt);
      if (camMode === 0 && !camTouch && cam.dragT <= 0 && !P.dead && P.moving > 1) { const [mx2] = mv(); cam.yaw += angDiff(cam.yaw, P.yaw) * Math.min(1, dt * 1.6 * Math.min(1, Math.abs(mx2) * 1.3)); } }
    const tx = P.x - Math.sin(cam.yaw) * cam.dist, tz = P.z - Math.cos(cam.yaw) * cam.dist;
    cam.x = lerp(cam.x, tx, Math.min(1, dt * 10)); cam.z = lerp(cam.z, tz, Math.min(1, dt * 10)); cam.y = cam.h;
    P.vx = Math.sin(P.yaw) * (P.moving || 0); P.vz = Math.cos(P.yaw) * (P.moving || 0);
    if (!over && time > LIMIT) { finish(false); say("وقت تمام شد!", 2); }
    // HUD
    $("s3php").style.width = (P.hp / P.maxhp * 100) + "%"; $("s3pt").textContent = Math.ceil(P.hp);
    if (FIELD) { let cur = 0, left = 0; for (const f of foes) if (!f.dead) { cur += Math.max(0, f.hp); left++; } $("s3ghp").style.width = (cur / Math.max(1, enemyTotal) * 100) + "%"; $("s3gt").textContent = "دشمن " + left; } else { $("s3ghp").style.width = (G.hp / G.max * 100) + "%"; $("s3gt").textContent = "دروازه " + Math.ceil(G.hp); }
    $("s3lvn").textContent = HX.lv; $("s3xp").style.width = (HX.xp / heroNeed(HX.lv) * 100) + "%"; $("s3dot").style.display = HX.pts > 0 ? "block" : "none";
    $("s3time").textContent = Math.max(0, Math.ceil(LIMIT - time)) + "s";
    const setCd = (id, v, m) => { const el = $(id); el.style.height = v > 0 ? (v / m * 100) + "%" : "0"; el.parentElement.classList.toggle("cd", v > 0); };
    setCd("s3c1", cd.spec, 9); setCd("s3c2", cd.rally, 24); setCd("s3c3", cd.ram, 28); setCd("s3c4", cd.bolt, 30);
  }
  function finish(won, quit) {
    if (over) return; over = true; endWon = won; const f = P.hp / P.maxhp, stars = !won ? 0 : 1 + (f > 0.4 ? 1 : 0) + (time < 100 ? 1 : 0);
    const lostBy = {}; const alive = {}; for (const a of allies) if (a.ow === undefined) alive[a.kind] = (alive[a.kind] || 0) + 1; for (const k in armyIn) { const l = armyIn[k] - (alive[k] || 0); if (l > 0) lostBy[k] = l; } if (!quit && S.ow && S.ow.allies) { const cntOf = (g) => Math.min(4, Math.max(2, g.n)); const gs = S.ow.allies.slice(); gs.forEach((g, gi) => { const d = deadOw[gi] || 0; if (!d) return; const fr = d / cntOf(g); if (fr >= 1) g.pow = 0; else { g.n = Math.max(1, Math.round(g.n * (1 - fr))); g.pow = Math.round(g.pow * (1 - fr)); } }); S.ow.allies = S.ow.allies.filter((g) => g.pow >= 3); }
    const back = quit ? {} : applyLosses(lostBy), ndead = Object.values(back).reduce((a, b) => a + b, 0);
    const done = () => { cleanup(); onEnd({ won, stars, kills, built: 0, skills: 0, evolves: 0, lives: 1, maxLives: 1, wave: 0, troopsSent: nAll, lostUnits: ndead, quit: !!quit }); }; setTimeout(() => { if (!quit && heroInit().pts > 0) openUp(true, done); else done(); }, quit ? 0 : 500);
  }
  function cleanup() { if (ended) return; ended = true; cancelAnimationFrame(raf); removeEventListener("keydown", onKD); removeEventListener("keyup", onKU); removeEventListener("resize", resize); root.remove(); document.body.classList.remove("inbattle"); delete window.__s3d; }
  window.__s3d = { back() { act(paused ? "resume" : "pause"); }, gl: () => GLR };

  // ---------- رندر ----------
  const items = []; let cs, sn, cp, sp, lastR = 0, dtR = 0.016, GLR = false;
  const GLV = { R: [1, 0, 0], U: [0, 1, 0], D: [0, 0, 1], k: 100, dpr: 1, L: LIGHT, fogc: FOG.map((v) => v / 255), sky: [0.8, 0.88, 1], gnd: [0.42, 0.36, 0.3] };
  SQ.init().then((ok) => { GLR = ok && SQ.ready(); }); loadEnv();
  function glActor(e, team, kind, seed, st) {
    if (!e._g) { const sp0 = team === "hero" ? SQ.heroSpec(AV, LOOK) : SQ.spec(team, kind, seed); if (e.dark) Object.assign(sp0.pal, { skin: [0.5, 0.55, 0.7], cloth: [0.16, 0.1, 0.28], cloth2: [0.08, 0.05, 0.16], pants: [0.1, 0.08, 0.14], metal: [0.28, 0.26, 0.4] }); e._g = SQ.make(sp0, seed); }
    const g = e._g, sc = (g.scale || 1) * (st.sc || 1), y = st.y || 0; st.x = e.x; st.z = e.z; st.dt = dtR;
    SQ.drive(g, st);
    const c = proj(e.x, y + 0.95 * sc, e.z); if (c[2] < 0.7 || c[2] > 95) return;
    GLV.k = F / c[2]; const t = renderInst(g, { x: e.x, y, z: e.z, yaw: e.yaw, sc: st.sc || 1, fog: fogOf(c[2]), flash: st.flash || 0 }, GLV); if (!t) return;
    const s0 = toScr(c), al = st.alpha === undefined ? 1 : st.alpha; items.push({ z: c[2], f() { blit(ctx, t, s0[0], s0[1], al); } });
  }
  function proj(x, y, z) { // -> [sx, sy, depth]
    const dx = x - cam.x, dy = y - cam.y, dz = z - cam.z, x1 = dx * cs - dz * sn, z1 = dx * sn + dz * cs, z2 = -dy * sp + z1 * cp, y2 = dy * cp + z1 * sp;
    return [x1, y2, z2];
  }
  const toScr = (v) => [W / 2 + v[0] / v[2] * F, H * 0.52 - v[1] / v[2] * F];
  function polyClip(vs) { // برش با صفحه‌ی نزدیک
    const out = [], N = 0.25; for (let i = 0; i < vs.length; i++) { const a = vs[i], b = vs[(i + 1) % vs.length], ain = a[2] > N, bin = b[2] > N; if (ain) out.push(a); if (ain !== bin) { const t = (N - a[2]) / (b[2] - a[2]); out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, N]); } } return out;
  }
  function drawPoly(vs, fill, stroke) {
    const c = polyClip(vs); if (c.length < 3) return; ctx.beginPath(); for (let i = 0; i < c.length; i++) { const s = toScr(c[i]); if (i) ctx.lineTo(s[0], s[1]); else ctx.moveTo(s[0], s[1]); } ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); }
  }
  const fogOf = (z) => clamp((z - 20) / 95, 0, 0.82);
  // جعبه‌ی چرخیده: مرکز محلی نسبت به محور، دوران حول X در محور، سپس yaw و انتقال
  function box(o, px, py, pz, ax, cx, cy, cz, sx, sy, sz, col, edge = true) {
    const hx = sx / 2, hy = sy / 2, hz = sz / 2, cA = Math.cos(ax), sA = Math.sin(ax), cy2 = Math.cos(o.yaw), sy2 = Math.sin(o.yaw), s = o.sc || 1;
    const V = []; for (let i = 0; i < 8; i++) { let lx = cx + ((i & 1) ? hx : -hx), ly = cy + ((i & 2) ? hy : -hy), lz = cz + ((i & 4) ? hz : -hz); const y1 = ly * cA - lz * sA, z1 = ly * sA + lz * cA; ly = y1; lz = z1; lx += px; ly += py; lz += pz; lx *= s * (o.bw || 1); ly *= s; lz *= s; const wx = o.x + lx * cy2 + lz * sy2, wz = o.z - lx * sy2 + lz * cy2; V.push([wx, (o.y || 0) + ly, wz]); }
    const c = [(V[0][0] + V[7][0]) / 2, (V[0][1] + V[7][1]) / 2, (V[0][2] + V[7][2]) / 2], pc = proj(c[0], c[1], c[2]); if (pc[2] < -4 || pc[2] > 140) return;
    pushBox(V, col, pc[2], edge);
  }
  const FACES = [[0, 1, 3, 2], [4, 6, 7, 5], [0, 2, 6, 4], [1, 5, 7, 3], [0, 4, 5, 1], [2, 3, 7, 6]];
  function prism(o, px, py, pz, ax, cx, cy, cz, rx0, rz0, rx1, rz1, len, col, seg = 8) {
    const cA = Math.cos(ax), sA = Math.sin(ax), cy2 = Math.cos(o.yaw), sy2 = Math.sin(o.yaw), s = o.sc || 1, V = [];
    for (let i = 0; i < seg; i++) { const a = i / seg * TAU, ca = Math.cos(a), sa = Math.sin(a);
      for (let e = 0; e < 2; e++) { let lx = cx + ca * (e ? rx1 : rx0), ly = cy + (e ? len / 2 : -len / 2), lz = cz + sa * (e ? rz1 : rz0); const y1 = ly * cA - lz * sA, z1 = ly * sA + lz * cA; ly = y1; lz = z1; lx += px; ly += py; lz += pz; lx *= s * (o.bw || 1); ly *= s; lz *= s; const wx = o.x + lx * cy2 + lz * sy2, wz = o.z - lx * sy2 + lz * cy2; V.push([wx, (o.y || 0) + ly, wz]); } }
    const F2 = []; for (let i = 0; i < seg; i++) { const j = (i + 1) % seg; F2.push([2 * i, 2 * j, 2 * j + 1, 2 * i + 1]); } F2.push(Array.from({ length: seg }, (_, i) => 2 * i + 1));
    let mx = 0, my = 0, mz = 0; for (const v of V) { mx += v[0]; my += v[1]; mz += v[2]; } const pc = proj(mx / V.length, my / V.length, mz / V.length); if (pc[2] < -4 || pc[2] > 140) return;
    pushMesh(V, F2, col, pc[2], false);
  }
  function pushBox(V, col, depth, edge) { pushMesh(V, FACES, col, depth, edge); }
  function pushMesh(V, FS, col, depth, edge) {
    items.push({ z: depth, f() {
      const fg = fogOf(depth), cen = [0, 0, 0]; for (const v of V) { cen[0] += v[0] / V.length; cen[1] += v[1] / V.length; cen[2] += v[2] / V.length; }
      for (const fc of FS) {
        const a = V[fc[0]], b = V[fc[1]], c = V[fc[2]]; let ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2]; let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
        const fx = (a[0] + c[0]) / 2, fy = (a[1] + c[1]) / 2, fz = (a[2] + c[2]) / 2; if ((fx - cen[0]) * nx + (fy - cen[1]) * ny + (fz - cen[2]) * nz < 0) { nx = -nx; ny = -ny; nz = -nz; }
        if (nx * (cam.x - fx) + ny * (cam.y - fy) + nz * (cam.z - fz) <= 0) continue;
        const nd = nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2], lt = 0.4 + 0.62 * Math.max(0, nd) + 0.1 * Math.max(0, ny) + 0.06 * Math.max(0, -nd), fl = rgb(col, lt, fg, FOG);
        drawPoly(fc.map((i) => proj(V[i][0], V[i][1], V[i][2])), fl, edge ? rgb(col, 0.42, fg, FOG) : (FS !== FACES ? fl : null));
      }
    } });
  }
  function sphere(wx, wy, wz, r, col, lightK = 1) {
    const p = proj(wx, wy, wz); if (p[2] < 0.4) return; items.push({ z: p[2] - 0.01, f() { const s = toScr(p), R = r / p[2] * F, fg = fogOf(p[2]); const g = ctx.createRadialGradient(s[0] - R * 0.35, s[1] - R * 0.4, R * 0.1, s[0], s[1], R); g.addColorStop(0, rgb(col, 1.25 * lightK, fg, FOG)); g.addColorStop(1, rgb(col, 0.62 * lightK, fg, FOG)); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(s[0], s[1], R, 0, TAU); ctx.fill(); ctx.strokeStyle = rgb(col, 0.4, fg, FOG); ctx.lineWidth = 1; ctx.stroke(); } });
  }
  function shadow(x, z, r, hgt = 1.6) { const p = proj(x + 0.35 * hgt * 0.5, 0.02, z - 0.2 * hgt * 0.5); if (p[2] < 0.5) return; const s = toScr(p), R = r * 1.35 / p[2] * F; const g2 = ctx.createRadialGradient(s[0], s[1], R * 0.1, s[0], s[1], R); g2.addColorStop(0, "rgba(0,0,0,0.42)"); g2.addColorStop(0.6, "rgba(0,0,0,0.22)"); g2.addColorStop(1, "rgba(0,0,0,0)"); ctx.save(); ctx.translate(s[0], s[1]); ctx.scale(1, 0.42); ctx.translate(-s[0], -s[1]); ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(s[0], s[1], R, 0, TAU); ctx.fill(); ctx.restore(); }

  // شخصیت چندوجهی کم‌چند — هر موجود با «look» اختصاصی (چهره، اندام، رنگ‌ها)
  function drawChar(o, c) {
    const w = Math.sin(o.walk || 0) * (o.moving === 0 ? 0 : 1), mvK = o.walkAmp === undefined ? 1 : o.walkAmp, fc = c.face || {};
    const sk = hex(c.skin), tun = hex(c.tunic || "#6a8fb8"), leg = hex(c.legs || "#3a3f4a"), bw = buildW(fc.build || "normal"), ht = fc.height || 1;
    const bob = Math.abs(Math.cos(o.walk || 0)) * 0.05 * mvK, atk = o.atkP === undefined ? 0 : o.atkP, leanX = o.roll > 0 ? 1.1 : 0;
    const root = { x: o.x, z: o.z, y: (o.y || 0) + bob, yaw: o.yaw, sc: (o.sc || 1) * ht, bw };
    const hi = proj(o.x, 1, o.z)[2] < 46, pr = (px, py, pz, ax, cy, len, r0, r1, col, rz = 1) => hi ? prism(root, px, py, pz, ax, 0, cy, 0, r0, r0 * rz, r1, r1 * rz, len, col, 8) : box(root, px, py, pz, ax, 0, cy, 0, r1 * 1.9, len, r1 * 1.9 * rz, col);
    const body = hex(c.armor || c.tunic || "#6a8fb8"), sleeve = c.armor ? hex(c.armorSleeve || c.armor) : tun;
    pr(0.16, 0.78, 0, w * 0.7 * mvK, -0.39, 0.78, 0.085, 0.135, leg, 1.05);
    pr(-0.16, 0.78, 0, -w * 0.7 * mvK, -0.39, 0.78, 0.085, 0.135, leg, 1.05);
    box(root, 0.16, 0.2, 0.05, w * 0.7 * mvK, 0, -0.08, 0, 0.27, 0.2, 0.34, hex("#2a2420"));
    box(root, -0.16, 0.2, 0.05, -w * 0.7 * mvK, 0, -0.08, 0, 0.27, 0.2, 0.34, hex("#2a2420"));
    if (c.cape) { const cc = c.cape.color ? hex(c.cape.color) : hex(c.cape); const sway = 0.25 + Math.abs(w) * 0.35 + (o.moving ? 0.2 : 0); box(root, 0, 1.5, -0.2, sway, 0, -0.5, -0.06, 0.66, 1.05, 0.07, cc); if (c.cape.color2) box(root, 0, 1.5, -0.2, sway, 0, -0.95, -0.06, 0.66, 0.16, 0.075, hex(c.cape.color2), false); }
    if (hi) prism(root, 0, 0, 0, leanX, 0, 1.15, 0, 0.26, 0.17, 0.34, 0.2, 0.74, body, 10); else box(root, 0, 0, 0, leanX, 0, 1.15, 0, 0.64, 0.74, 0.36, body);
    if (c.armor) { box(root, 0, 0, 0, leanX, 0, 1.15, 0.185, 0.36, 0.5, 0.03, hex(c.trim || "#ffffff").map((v) => v * 0.75), false); } else box(root, 0, 0, 0, leanX, 0, 1.3, 0.185, 0.3, 0.16, 0.02, tun.map((v) => v * 1.25), false);
    box(root, 0, 0, 0, leanX, 0, 0.82, 0, 0.68, 0.12, 0.4, hex(c.belt || "#5a3a1a")); box(root, 0, 0, 0, leanX, 0, 0.82, 0.2, 0.14, 0.1, 0.03, [224, 190, 90], false);
    if (c.pauldron) { box(root, 0.42, 1.5, 0, 0, 0, 0, 0, 0.28, 0.2, 0.32, hex(c.pauldron)); box(root, -0.42, 1.5, 0, 0, 0, 0, 0, 0.28, 0.2, 0.32, hex(c.pauldron)); }
    { const mc = hex(c.pauldron || (c.armor ? "#8a94a8" : "#6a5a4a")), dk = body.map((v) => v * 0.7);
      box(root, 0, 0, 0, leanX, 0, 1.47, 0, 0.8, 0.2, 0.42, mc); box(root, 0, 0, 0, leanX, 0, 0.64, 0, 0.74, 0.22, 0.44, dk);
      box(root, 0.16, 0.78, 0, w * 0.7 * mvK, 0, -0.56, 0.03, 0.28, 0.2, 0.32, mc); box(root, -0.16, 0.78, 0, -w * 0.7 * mvK, 0, -0.56, 0.03, 0.28, 0.2, 0.32, mc);
      box(root, 0.16, 0.78, 0, w * 0.7 * mvK, 0, -0.27, 0.0, 0.26, 0.22, 0.28, mc.map((v) => v * 0.85)); box(root, -0.16, 0.78, 0, -w * 0.7 * mvK, 0, -0.27, 0.0, 0.26, 0.22, 0.28, mc.map((v) => v * 0.85)); }

    const la = c.shield ? -0.7 : -w * 0.6 * mvK;
    pr(-0.42, 1.45, 0, la, -0.18, 0.36, 0.07, 0.095, sleeve); pr(-0.42, 1.45, 0, la, -0.5, 0.3, 0.05, 0.065, sk); box(root, -0.42, 1.45, 0, la, 0, -0.46, 0, 0.19, 0.16, 0.19, hex(c.pauldron || (c.armor ? "#8a94a8" : "#6a5a4a")));
    if (c.shield) { const sd = c.shield; box(root, -0.42, 1.45, 0, la, -0.16, -0.38, 0.22, 0.09, 0.78, 0.62, hex(sd.color), true); box(root, -0.42, 1.45, 0, la, -0.2, -0.38, 0.22, 0.05, 0.5, 0.4, hex(sd.rim)); if (sd.emblem) box(root, -0.42, 1.45, 0, la, -0.24, -0.38, 0.22, 0.04, 0.2, 0.2, hex("#c43a3a")); }
    let ra = -0.9 + w * 0.2 * mvK; if (o.swing) { const t = clamp(atk, 0, 1), k = o.combo || 0; const up = k === 1 ? -2.0 : -2.7, dn = k === 1 ? -0.2 : 0.1; ra = t < 0.35 ? lerp(-0.9, up, t / 0.35) : lerp(up, dn, clamp((t - 0.35) / 0.3, 0, 1)); }
    pr(0.42, 1.45, 0, ra, -0.18, 0.36, 0.07, 0.095, sleeve); pr(0.42, 1.45, 0, ra, -0.5, 0.3, 0.05, 0.065, sk); box(root, 0.42, 1.45, 0, ra, 0, -0.46, 0, 0.19, 0.16, 0.19, hex(c.pauldron || (c.armor ? "#8a94a8" : "#6a5a4a")));
    const wp = c.sword; if (wp) {
      const L = 1.15 * wp.len, bl = hex(wp.blade), hl = hex(wp.hilt), kd = wp.kind || "sword";
      if (kd === "axe") { box(root, 0.42, 1.45, 0, ra, 0, -0.62, 0.5, 0.07, 0.07, 1.0, hl); box(root, 0.42, 1.45, 0, ra, 0, -0.62, 1.0, 0.05, 0.34, 0.5, bl); box(root, 0.42, 1.45, 0, ra, 0, -0.62, 1.04, 0.07, 0.12, 0.2, hl, false); }
      else if (kd === "mace") { box(root, 0.42, 1.45, 0, ra, 0, -0.62, 0.45, 0.08, 0.08, 0.9, hl); box(root, 0.42, 1.45, 0, ra, 0, -0.62, 1.0, 0.32, 0.32, 0.32, bl); for (const q of [[0.2, 0, 0], [-0.2, 0, 0], [0, 0.2, 0], [0, -0.2, 0]]) box(root, 0.42, 1.45, 0, ra, q[0] * 0.8, -0.62 + q[1] * 0.8, 1.0, 0.1, 0.1, 0.1, hl, false); }
      else {
        box(root, 0.42, 1.45, 0, ra, 0, -0.62, 0.12, 0.1, 0.1, 0.24, hl); box(root, 0.42, 1.45, 0, ra, 0, -0.62, 0.27, 0.34, 0.07, 0.07, hl);
        box(root, 0.42, 1.45, 0, ra, 0, -0.62, 0.3 + L / 2, 0.08, 0.04, L, bl, false); if (wp.twin) box(root, 0.42, 1.45, 0, ra, 0, -0.62, 0.3 + L * 0.8, 0.2, 0.04, 0.32, bl, false);
      }
    }
    // سر: توپ هندسی + چهره‌ی کامل (چشم، ابرو، بینی، دهان، ریش، مو، کلاه‌خود)
    const sc = root.sc, hs = (fc.head || 1);
    const hp = (function () { const cy2 = Math.cos(o.yaw), sy2 = Math.sin(o.yaw); const ly = 1.88 * sc + (o.y || 0) + bob; return [o.x, ly, o.z]; void cy2; void sy2; })();
    pr(0, 1.5, 0, leanX * 0.5, 0.08, 0.16, 0.06, 0.07, sk);
    const fx = Math.sin(o.yaw), fz = Math.cos(o.yaw), pH = proj(hp[0], hp[1], hp[2]);
    if (pH[2] > 0.4) {
      const c1 = -(fx * sn + fz * cs), s1 = fx * cs - fz * sn, fa = Math.atan2(s1, c1), look = { skin: c.skin, hair: c.hair, face: fc, helm: c.helm }, R = 0.27 * sc * hs / pH[2] * F;
      items.push({ z: pH[2] - 0.05, f() { const s2 = toScr(pH); drawHead(ctx, s2[0], s2[1] - R * 0.12, R, look, fa, { lod: R < 9 }); } });
    }
    if (c.horns) { box(root, 0.22, 1.85, 0, 0, 0, 0.28, 0, 0.07, 0.3, 0.07, hex("#e8e0c8"), false); box(root, -0.22, 1.85, 0, 0, 0, 0.28, 0, 0.07, 0.3, 0.07, hex("#e8e0c8"), false); }
  }
  const LOOK = lookOf(AV);
  const playerStyle = () => Object.assign({}, LOOK, { sword: LOOK.weapon, pauldron: LOOK.armorItem ? LOOK.armorItem.color : null, trim: LOOK.armorItem && LOOK.armorItem.trim, armorSleeve: AV.tunic });
  const ALLY_ST = { guard: { tunic: "#2a2f5a", armor: "#d8b84a", pauldron: "#ffd24a", trim: "#fff2b0", helm: { kind: "crest", color: "#e8d890", plume: "#c8302a" }, shield: { color: "#e0b840", rim: "#8a6a1a", emblem: 1 }, sword: { blade: "#f0e6c8", hilt: "#c8923a", len: 1.1, kind: "curve" } }, sword: { tunic: "#4a78c8", armor: "#6a88c0", hair: "#2a1a10", skin: "#e8c498", helm: { kind: "cap", color: "#7a8ab0" }, sword: { blade: "#d0d8e4", hilt: "#8a6a3a", len: 0.9 } }, shield: { tunic: "#3a5a9a", armor: "#8aa0c4", skin: "#d8b084", hair: "#1a1a1a", helm: { kind: "helm", color: "#9aa8c0" }, shield: { color: "#9fc0ff", rim: "#5a70a0" }, sword: { blade: "#c0c8d4", hilt: "#6a5030", len: 0.7 } }, archer: { tunic: "#3a8a5a", armor: "#4a9a68", skin: "#e0b88c", hair: "#5a3a1a", helm: { kind: "cap", color: "#6a4a2a" }, sword: { blade: "#7a5a2a", hilt: "#4a3a1a", len: 0.8 } }, horse: { tunic: "#c8803a", armor: "#d89a4a", skin: "#c89a70", hair: "#2a1a10", helm: { kind: "crest", color: "#c8d0e0", plume: "#ffb347" }, sword: { blade: "#e0e4ec", hilt: "#b08a3a", len: 1.0 } } };
  const FOE_ST = { guard: { tunic: "#8a2a2a", armor: "#a04040", skin: "#d8b084", hair: "#2a1a10", helm: { kind: "helm", color: "#6a6a74" }, sword: { blade: "#b8bcc4", hilt: "#5a3a2a", len: 0.9 }, angry: 1, brow: "#1a1010" }, heavy: { tunic: "#5a2a2a", armor: "#6a6a78", skin: "#c89a70", helm: { kind: "helm", color: "#4a4a58" }, shield: { color: "#7a3a3a", rim: "#3a2a2a" }, sword: { blade: "#9aa0aa", hilt: "#4a3a2a", len: 0.9 }, pauldron: "#4a4a58", angry: 1, brow: "#1a1010" }, captain: { tunic: "#3a1a4a", armor: "#5a2a6a", skin: "#b88a66", helm: { kind: "crest", color: "#8a7a9a", plume: "#ff4a4a" }, shield: { color: "#8a3a8a", rim: "#d8a83a", emblem: 1 }, sword: { blade: "#ffb0a0", hilt: "#d8a83a", len: 1.3, glow: "#ff6a4a" }, pauldron: "#d8a83a", horns: 1, angry: 1, eye: "#ff3a3a", brow: "#000" }, warcher: { tunic: "#8a3a3a", armor: "#8a4a4a", skin: "#d8b084", helm: { kind: "cap", color: "#5a4a3a" }, angry: 1 } };

  function drawCastle() {
    const wc = WALL, hw = LIMX + 6, seg = 6, segW = (hw * 2) / seg;
    const base = { x: 0, z: 0, yaw: 0, y: 0, sc: 1 };
    const gx = GATEW / 2;
    // دیوار: بخش‌های چپ و راست دروازه + لنگه بالای دروازه
    const wallSeg = (x0, x1) => { const n = Math.max(1, Math.ceil((x1 - x0) / 5)); for (let i = 0; i < n; i++) { const a = x0 + (x1 - x0) * i / n, b = x0 + (x1 - x0) * (i + 1) / n; box(base, 0, 0, 0, 0, (a + b) / 2, WALLH / 2, ZG, b - a, WALLH, 3.2, wc); } };
    wallSeg(-hw, -gx); wallSeg(gx, hw); box(base, 0, 0, 0, 0, 0, (GATEH + WALLH) / 2, ZG, GATEW, WALLH - GATEH, 3.2, wc);
    // پیش‌بام و دندانه‌ها
    for (let x = -hw + 1; x < hw; x += 2.2) box(base, 0, 0, 0, 0, x, WALLH + 0.55, ZG - 1.2, 1.2, 1.1, 0.7, wc);
    box(base, 0, 0, 0, 0, 0, WALLH + 0.1, ZG - 0.4, hw * 2, 0.3, 2.6, rgbMul(wc, 0.9));
    // برج‌ها
    for (const sx of [-1, 1]) {
      const tx = sx * (LIMX + 3); box(base, 0, 0, 0, 0, tx, 6.5, ZG, 7, 13, 7, rgbMul(wc, 1.05));
      for (let i = 0; i < 4; i++) { const ax = tx + (i & 1 ? 2.8 : -2.8), az = ZG + (i & 2 ? 2.8 : -2.8); box(base, 0, 0, 0, 0, ax, 13.6, az, 1.3, 1.3, 1.3, wc); }
      box(base, 0, 0, 0, 0, tx, 15.8, ZG, 5, 3.4, 5, ROOF); box(base, 0, 0, 0, 0, tx, 18.4, ZG, 2.6, 2, 2.6, ROOF); box(base, 0, 0, 0, 0, tx, 20.3, ZG, 0.15, 2.6, 0.15, [90, 70, 50], false);
      box(base, 0, 0, 0, 0, tx + sx * -0.4, 20.8, ZG, 1.8, 1.0, 0.06, [220, 60, 60], false);
      for (let i = 0; i < 3; i++) box(base, 0, 0, 0, 0, tx, 4 + i * 3.4, ZG - 3.52, 0.6, 1.2, 0.1, [40, 34, 34], false);
      box(base, 0, 0, 0, 0, sx * (LIMX - 3.5), 1.4, ZG - 1.7, 2, 2.8, 0.3, [50, 36, 28]); // درگاه نگهبانان
    }
    // قصر پشت دیوار
    box(base, 0, 0, 0, 0, 0, 9, ZG + 9, 16, 18, 10, rgbMul(wc, 0.95)); box(base, 0, 0, 0, 0, 0, 20.5, ZG + 9, 12, 5, 8, ROOF); box(base, 0, 0, 0, 0, 0, 24.5, ZG + 9, 5, 4, 5, ROOF); box(base, 0, 0, 0, 0, 0, 27.6, ZG + 9, 0.2, 3, 0.2, [90, 70, 50], false);
    // دروازه
    if (G.hp > 0 || G.fall > 0) {
      const fall = clamp(G.fall / 1.2, 0, 1), sh = G.shake > 0 ? Math.sin(time * 90) * 0.06 : 0, gt = fall * 1.35;
      const g = { x: sh, z: ZG - 1.6 - fall * 0.2, yaw: 0, y: 0, sc: 1 };
      box(g, 0, GATEH / 2, 0, -gt, 0, 0, 0, GATEW - 0.2, GATEH - 0.2, 0.42, [110, 74, 44]);
      for (let i = -2; i <= 2; i++) box(g, 0, GATEH / 2, 0, -gt, i * 1.0, 0, -0.24, 0.1, GATEH - 0.4, 0.1, [80, 52, 30], false);
      for (const yy of [-1.8, 0, 1.8]) box(g, 0, GATEH / 2, 0, -gt, 0, yy, -0.28, GATEW - 0.3, 0.3, 0.1, [58, 60, 66]);
      box(g, 0, GATEH / 2, 0, -gt, 0, 0, -0.34, 0.5, 0.5, 0.1, [196, 160, 70]);
      const dmgF = 1 - G.hp / G.max; for (let i = 0; i < Math.floor(dmgF * 7); i++) box(g, 0, GATEH / 2, 0, -gt, Math.sin(i * 2.3) * 1.8, Math.cos(i * 1.7) * 1.9, -0.31 - i * 0.003, 0.07, 0.9 + (i % 3) * 0.4, 0.05, [30, 20, 14], false);
    } else box(base, 0, 0, 0, 0, 0, 0.1, ZG - 1, GATEW, 0.2, 3, [60, 40, 30]);
  }
  const rgbMul = (c, k) => [c[0] * k, c[1] * k, c[2] * k];

  function drawBG() {
    const sky = ctx.createLinearGradient(0, 0, 0, H * 0.55); sky.addColorStop(0, th.sky[0]); sky.addColorStop(1, th.sky[1]); ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
    const hz = H * 0.52 - (-cam.h * cp + 0) * 0 ; // خط افق تقریبی
    const hy = H * 0.52 - Math.tan(0) * F; void hy;
    const sunx = ((-cam.yaw * 220 + 300) % (W + 400) + W + 400) % (W + 400) - 100; ctx.fillStyle = "rgba(255,248,220,0.85)"; ctx.beginPath(); ctx.arc(sunx, H * 0.17, 28, 0, TAU); ctx.fill();
    // کوه‌های دور
    const off = -cam.yaw * 420; ctx.fillStyle = th.mount; ctx.globalAlpha = 0.55; ctx.beginPath(); const base = H * 0.5 + sp * F * 0.15 + 8; ctx.moveTo(0, H); ctx.lineTo(0, base); for (let x = 0; x <= W + 40; x += 40) { const u = (x - off) / 160; ctx.lineTo(x, base - 34 - (Math.sin(u) * 26 + Math.sin(u * 2.3 + 1) * 16 + 20)); } ctx.lineTo(W, H); ctx.fill(); ctx.globalAlpha = 1;
    // ابرها
    ctx.fillStyle = "rgba(255,255,255,0.5)"; for (let i = 0; i < 5; i++) { const cx = ((i * 260 - cam.yaw * 300 + time * 6) % (W + 260) + W + 260) % (W + 260) - 130, cy = H * (0.1 + (i % 3) * 0.07); ctx.beginPath(); ctx.ellipse(cx, cy, 60, 14, 0, 0, TAU); ctx.ellipse(cx + 30, cy - 8, 40, 12, 0, 0, TAU); ctx.fill(); }
    // زمین: کاشی‌های رنگی
    const g = ctx.createLinearGradient(0, H * 0.45, 0, H); g.addColorStop(0, rgb(hex(th.ground[0]), 1, 0.7, FOG)); g.addColorStop(1, th.ground[0]); ctx.fillStyle = g; ctx.fillRect(0, H * 0.46, W, H);
    const T = 4, c0 = hex(th.ground[0]), c1 = hex(th.ground[1]), r0 = Math.floor((cam.x - 60) / T), r1 = Math.floor((cam.x + 60) / T), zz0 = Math.floor((cam.z - 8) / T), zz1 = Math.min(Math.floor((ZG + 24) / T), zz0 + 24);
    const hsh = (a, b) => { let h = (a * 374761393 + b * 668265263) | 0; h = (h ^ (h >> 13)) * 1274126177; return ((h ^ (h >> 16)) >>> 0) / 4294967295; };
    for (let iz = zz1; iz >= zz0; iz--) for (let ix = r0; ix <= r1; ix++) { const x = ix * T, z = iz * T; const dist = Math.hypot(x - cam.x, z - cam.z); if (dist > 64) continue; const road = !FIELD && Math.abs(x + T / 2) < 3.2 && z < ZG, n = hsh(ix, iz), edgeRoad = !FIELD && !road && Math.abs(x + T / 2) < 4.6 && z < ZG;
      let col = road ? [150 + n * 14, 124 + n * 12, 90 + n * 10] : edgeRoad ? [lerp(c0[0], 150, 0.45), lerp(c0[1], 124, 0.45), lerp(c0[2], 90, 0.45)] : [lerp(c0[0], c1[0], n) * (0.92 + hsh(ix + 9, iz + 4) * 0.16), lerp(c0[1], c1[1], n) * (0.92 + hsh(ix + 9, iz + 4) * 0.16), lerp(c0[2], c1[2], n) * (0.94 + hsh(ix + 3, iz + 7) * 0.12)];
      const fgd = fogOf(dist), V4 = [proj(x, 0, z), proj(x + T, 0, z), proj(x + T, 0, z + T), proj(x, 0, z + T)]; drawPoly(V4, rgb(col, 1, fgd, FOG), null);
      if (dist < 26 && !road) { const q = proj(x + T / 2, 0, z + T / 2); if (q[2] > 0.6) { const sc0 = toScr(q), k = F / q[2], cnt = dist < 12 ? 7 : 3; ctx.lineWidth = Math.max(1, k * 0.03); for (let t = 0; t < cnt; t++) { const rx = hsh(ix * 7 + t, iz), rz = hsh(ix, iz * 7 + t), px = sc0[0] + (rx - 0.5) * T * k * 0.9, py = sc0[1] + (rz - 0.5) * T * k * 0.35, hh = k * (0.18 + hsh(t, ix + iz) * 0.22), sw = Math.sin(time * 1.6 + ix + t) * k * 0.05; ctx.strokeStyle = rgb(col, 0.72 + (t % 3) * 0.2, fgd + 0.1, FOG); ctx.beginPath(); ctx.moveTo(px, py); ctx.quadraticCurveTo(px + sw * 0.5, py - hh * 0.6, px + sw + (rx - 0.5) * k * 0.08, py - hh); ctx.stroke(); } if (hsh(ix + 5, iz + 5) > 0.93 && dist < 20) { ctx.fillStyle = ["#fff3b0", "#ffb0c8", "#ffffff"][(n * 30 | 0) % 3]; ctx.beginPath(); ctx.arc(sc0[0] + (n - 0.5) * k, sc0[1], Math.max(1.2, k * 0.035), 0, TAU); ctx.fill(); } } }
      if (road && dist < 30) { const q = proj(x + T / 2, 0, z + T / 2); if (q[2] > 0.6) { const sc0 = toScr(q), k = F / q[2]; ctx.fillStyle = "rgba(70,50,30,0.2)"; ctx.fillRect(sc0[0] - T * k * 0.28 - 2, sc0[1] - k * 0.04, 4, k * 0.08 + 1); ctx.fillRect(sc0[0] + T * k * 0.2, sc0[1] - k * 0.04, 4, k * 0.08 + 1); if (n > 0.8) { ctx.fillStyle = "rgba(120,110,100,0.55)"; ctx.beginPath(); ctx.ellipse(sc0[0] + (n - 0.9) * T * k * 3, sc0[1], k * 0.07, k * 0.035, 0, 0, TAU); ctx.fill(); } } } }
  }

  const envVis = [];
  function drawEnv() {
    envFrame(8); envVis.length = 0;
    for (const e of envProps) { const q = proj(e.x, 0, e.z); if (q[2] < 1 || q[2] > 85) continue; const sx = W / 2 + q[0] / q[2] * F; if (sx < -W * 0.4 || sx > W * 1.4) continue; envVis.push([q[2], e]); }
    if (envVis.length > 120) { envVis.sort((a, b) => a[0] - b[0]); envVis.length = 120; }
    for (const [dz, e] of envVis) {
      const inf = envInfo(e.n); if (!inf) continue; const sc = e.th / inf.h, spr = envSprite(e.n, cam.yaw, cam.pitch); if (!spr) continue;
      const c = proj(e.x, e.th * 0.5, e.z), sp0 = toScr(c), ppu = F / c[2], fg = fogOf(dz), al = clamp((dz - 1.2) / 2.2, 0, 1) * (1 - fg * 0.55);
      if (e.ty !== "grass" && e.ty !== "flower" && dz < 60) shadow(e.x, e.z, Math.max(0.35, inf.w * sc * (e.ty === "rock" ? 0.4 : 0.26)), e.th * 0.5);
      items.push({ z: dz, f() { envBlit(ctx, spr, sp0[0], sp0[1], ppu, sc, e.flip, al); } });
    }
  }
  const BCOL = { wolf: { b: [104, 108, 118], d: [66, 68, 78], l: [166, 166, 172], n: [26, 24, 28] }, bear: { b: [90, 62, 42], d: [58, 38, 26], l: [124, 90, 62], n: [22, 18, 18] }, boar: { b: [100, 74, 56], d: [62, 44, 34], l: [142, 112, 86], n: [38, 28, 26] }, lion: { b: [198, 152, 86], d: [140, 96, 48], l: [228, 192, 134], n: [48, 34, 28] } };
  // حیوان‌های واقعی (گرگ، خرس، گراز، شیر) با پرِش پا، دم و حمله‌ی گاز
  function drawBeast(f, dead) {
    const C = BCOL[f.beast] || BCOL.wolf, bt = f.beast, dk = dead ? 1 - f.deadT / 0.7 : 0, sc = (f.sc || 1) * (dead ? Math.max(0.15, f.deadT / 0.7) : 1);
    const atk = f.atkA > 0 ? 1 - f.atkA / 0.4 : 0, bite = Math.sin(atk * Math.PI), mvK = dead || f.stun > 0 ? 0.12 : 1, ph = (f.walk || 0) * 0.85, big = bt === "bear" ? 1.18 : 1;
    const lunge = bite * 0.5 * sc, root = { x: f.x + Math.sin(f.yaw) * lunge, z: f.z + Math.cos(f.yaw) * lunge, y: (f.y || 0) + Math.abs(Math.sin(ph)) * 0.07 * mvK - dk * 0.42 * sc, yaw: f.yaw, sc, bw: 1 };
    const bx = (px, py, pz, ax, cx, cy, cz, sx, sy, sz, col, edge = true) => box(root, px, py, pz, ax, cx, cy, cz, sx, sy, sz, col, edge);
    const roll = dk * 0.25;
    bx(0, 0, 0, roll, 0, 0.62, 0, 0.36 * big, 0.38 * big, 0.92, C.b); bx(0, 0, 0, roll, 0, 0.66, 0.3, 0.4 * big, 0.46 * big, 0.42, C.b); bx(0, 0, 0, roll, 0, 0.6, -0.32, 0.37 * big, 0.4 * big, 0.4, C.d);
    bx(0, 0, 0, 0, 0, 0.45, 0.02, 0.3 * big, 0.1, 0.8, C.l, false); bx(0, 0, 0, 0, 0, 0.86 * big, 0.06, 0.12, 0.06, 0.7, C.d, false);
    if (bt === "bear") bx(0, 0, 0, 0, 0, 0.9, 0.35, 0.34, 0.3, 0.3, C.b);
    const hd = (bite * 0.75) + Math.sin(ph * 2) * 0.05 * mvK + dk * 0.7, hy = (bt === "bear" ? 0.92 : 0.9) - dk * 0.25, hz = 0.74;
    bx(0, 0.76, 0.46, 0.5 + hd * 0.4, 0, 0.1, 0.12, 0.22 * big, 0.3, 0.26, C.b);
    if (bt === "lion") bx(0, hy, hz - 0.1, hd, 0, 0, -0.02, 0.46, 0.44, 0.22, C.d);
    bx(0, hy, hz, hd, 0, 0, 0.16, 0.24 * big, 0.22 * big, 0.3, C.b);
    const sn2 = bt === "boar" ? 0.3 : bt === "bear" ? 0.18 : 0.24; bx(0, hy, hz, hd, 0, -0.04, 0.3 + sn2 / 2, 0.13 * big, 0.11 * big, sn2, bt === "boar" ? C.d : C.l); bx(0, hy, hz, hd, 0, -0.02, 0.32 + sn2, 0.07, 0.06, 0.05, C.n, false);
    const jaw = bite * 0.7 + dk * 0.3; bx(0, hy - 0.07, hz + 0.08, hd + jaw, 0, 0, 0.2, 0.1, 0.045, 0.24, C.d, false); if (bite > 0.2) bx(0, hy - 0.05, hz + 0.1, hd + jaw, 0, 0.03, 0.34, 0.07, 0.04, 0.04, [250, 250, 245], false);
    for (const sx of [-1, 1]) { bx(0, hy, hz, hd, sx * 0.085, 0.045, 0.2, 0.04, 0.04, 0.03, bt === "boar" ? [255, 80, 50] : [255, 214, 60], false); bx(0, hy, hz, hd, sx * 0.08, bt === "bear" ? 0.14 : 0.17, 0.02, bt === "bear" ? 0.09 : 0.06, bt === "bear" ? 0.09 : 0.14, 0.05, C.d); if (bt === "boar") bx(0, hy, hz, hd, sx * 0.07, -0.02, 0.34, 0.03, 0.03, 0.14, [240, 236, 220], false); }
    for (let i = 0; i < 4; i++) { const fr = i < 2, sx = i % 2 ? 1 : -1, sw = Math.sin(ph + (fr === (i % 2 === 0) ? 0 : Math.PI)) * 0.75 * mvK + dk * (sx * 1.0), px = sx * 0.14 * big, py = fr ? 0.54 : 0.52, pz = fr ? 0.34 : -0.3;
      bx(px, py, pz, sw, 0, -0.26, 0, 0.11 * big, 0.5, 0.12 * big, C.b); bx(px, py, pz, sw, 0, -0.52, 0.04, 0.13 * big, 0.07, 0.18, C.d); }
    if (bt !== "boar" || true) { const tl = bt === "bear" ? 0.2 : 0.46; bx(0, 0.7, -0.5, 0.5 + Math.sin(time * 5 + f.id * 9) * 0.18 - dk * 0.5, 0, 0, -tl / 2, 0.09 * (bt === "wolf" ? 1.4 : 1), 0.09, tl, C.d); }
  }
  function render() {
    cs = Math.cos(cam.yaw); sn = Math.sin(cam.yaw); cp = Math.cos(cam.pitch); sp = Math.sin(cam.pitch);
    const shx = cam.shake > 0 ? (Math.random() - 0.5) * cam.shake * 14 : 0, shy = cam.shake > 0 ? (Math.random() - 0.5) * cam.shake * 14 : 0;
    ctx.setTransform(DPR, 0, 0, DPR, shx * DPR, shy * DPR); items.length = 0;
    cam.y = cam.h; cam.pitch = cam.pb || 0.34; const nowR = performance.now(); dtR = Math.min(0.05, Math.max(0.001, (nowR - (lastR || nowR)) / 1000)); lastR = nowR; if (GLR) { frameBegin(); GLV.R = [cs, 0, -sn]; GLV.U = [sn * sp, cp, cs * sp]; GLV.D = [sn * cp, -sp, cs * cp]; GLV.dpr = DPR; }
    drawBG();
    // سایه‌ها
    shadow(P.x, P.z, 0.7); for (const a of allies) shadow(a.x, a.z, 0.6); for (const f of foes) if (!f.wall && !f.dead) shadow(f.x, f.z, 0.65 * (f.sc || 1)); for (const r of rams) shadow(r.x, r.z, 1.4);
    if (!FIELD) drawCastle();
    if (EV.ok) drawEnv();
    for (const p of props) { const dd = Math.hypot(p.x - cam.x, p.z - cam.z); if (dd > 70 || p.z < cam.z - 3) continue; const o = { x: p.x, z: p.z, yaw: p.r, y: 0, sc: p.s };
      if ((p.kind === "tree" || p.kind === "rock") && EV.ok) continue;
      if (p.kind === "tree") { const sn2 = p.r > 3, gc = hex(th.ground[1]).map((v, i) => [0.62, 1.0, 0.66][i] * v * 0.8); prism(o, 0, 0, 0, 0, 0, 0.9, 0, 0.26, 0.26, 0.17, 0.17, 1.8, [96, 66, 40], 7);
        if (sn2) { for (let k = 0; k < 3; k++) prism(o, 0, 0, 0, 0, 0, 1.9 + k * 1.1, 0, 1.5 - k * 0.38, 1.5 - k * 0.38, 0.15, 0.15, 1.6, gc.map((v) => v * (0.9 + k * 0.1)), 9); }
        else { prism(o, 0, 0, 0, 0, 0, 2.7, 0, 1.0, 1.0, 1.35, 1.35, 1.5, gc, 9); prism(o, 0, 0, 0, 0, 0.5, 3.5, 0.2, 0.9, 0.9, 1.0, 1.0, 1.2, gc.map((v) => v * 1.12), 9); prism(o, 0, 0, 0, 0, -0.5, 3.3, -0.2, 0.7, 0.7, 0.85, 0.85, 1.0, gc.map((v) => v * 0.92), 8); } }
      else if (p.kind === "rock") { box(o, 0, 0, 0, 0, 0, 0.4, 0, 1.3, 0.8, 1.0, [128, 128, 134]); box(o, 0, 0, 0, 0, 0.2, 0.9, 0.1, 0.7, 0.5, 0.6, [150, 150, 156]); }
      else if (p.kind === "tent") { box(o, 0, 0, 0, 0, 0, 0.8, 0, 2.4, 1.6, 2.4, [214, 198, 160]); box(o, 0, 0, 0, 0, 0, 1.9, 0, 1.6, 0.7, 1.6, [180, 60, 50]); box(o, 0, 0, 0, 0, 0, 2.6, 0, 0.08, 1.0, 0.08, [90, 70, 50], false); }
      else { box(o, 0, 0, 0, 0, 0, 0.9, 0, 0.18, 1.8, 0.18, [90, 66, 44]); const fl = 0.8 + Math.sin(time * 9 + p.z) * 0.2; box(o, 0, 0, 0, 0, 0, 2.0, 0, 0.3 * fl, 0.4 * fl, 0.3 * fl, [255, 170, 60], false); burstTrail(p.x, 2.1, p.z, "rgba(255,150,40,.8)"); } }
    for (const h of oils) { const q = proj(h.x, 0.1, h.z); if (q[2] > 0.5) items.push({ z: q[2] + 30, f() { const s0 = toScr(q), R = 2.6 / q[2] * F, k = Math.sin(time * 14) * 0.15 + 0.45; ctx.fillStyle = `rgba(255,60,30,${k})`; ctx.beginPath(); ctx.ellipse(s0[0], s0[1], R, R * 0.42, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = "rgba(255,200,80,.9)"; ctx.lineWidth = 2; ctx.stroke(); } }); }
    if (LOOK.aura && !P.dead) { const ac = LOOK.aura.col || "#ffd24a"; burstTrail(P.x, 1.0, P.z, ac + "cc"); if (Math.random() < 0.5) parts.push({ x: P.x + (Math.random() - 0.5) * 1.4, y: 0.2, z: P.z + (Math.random() - 0.5) * 1.4, vx: 0, vy: 1.6 + Math.random(), vz: 0, life: 0.9, max: 0.9, c: ac, s: 0.07 + Math.random() * 0.05 }); }
    // بازیکن
    { const swing = P.atkT > 0, p = swing ? 1 - P.atkT / (P.am || 0.46) : 0; const o = { x: P.x, z: P.z, yaw: P.yaw, walk: P.walk, moving: P.moving, swing, atkP: p, combo: P.combo, roll: P.roll, sc: 1, walkAmp: Math.min(1, (P.moving || 0) / 5), y: P.dead ? -0.3 : 0 }; if (!(P.inv > 0 && Math.floor(time * 20) % 2 && P.roll <= 0)) { if (GLR) glActor(P, "hero", "hero", 1, { atk: P.atkT, atkMax: P.am || 0.46, combo: P.heavy ? 1 : P.combo, block: P.block, hurt: P.hurt, dead: P.dead, deadDur: 1.4, roll: P.roll, sc: 1.0 }); else drawChar(o, playerStyle()); } if (swing && SW.glow) { const a = P.yaw + (p - 0.5) * 1.6; burstTrail(P.x + Math.sin(a) * 1.7, 1.4, P.z + Math.cos(a) * 1.7, SW.glow); } }
    for (const a of allies) { const o = { x: a.x, z: a.z, yaw: a.yaw, walk: a.walk, moving: 1, swing: a.atkA > 0, atkP: a.atkA > 0 ? 1 - a.atkA / 0.35 : 0, combo: 0, sc: 0.94, walkAmp: 0.8 }; if (GLR) glActor(a, "ally", a.kind, (parseInt(String(a.id).replace(/\D/g, "")) || 1) * 31 + 7, { atk: a.atkA > 0 ? a.atkA : 0, atkMax: 0.35, hurt: a.hurt || 0, sc: a.sc || 1 }); else drawChar(Object.assign(o, { sc: a.sc, bw: a.bw }), Object.assign({}, ALLY_ST[a.kind] || ALLY_ST.sword, { cape: null, skin: a.look.skin, hair: a.look.hair, face: a.look.face })); if (a.hurt > 0) flashRing(a.x, a.z, "#ff6a6a"); }
    for (let i = corpses.length - 1; i >= 0; i--) { const c = corpses[i]; c.t -= 0.016; if (c.t <= 0) { corpses.splice(i, 1); continue; } const a = c.a, k = Math.min(1, (1.6 - c.t) / 0.5); if (GLR) { glActor(a, "ally", a.kind, (parseInt(String(a.id).replace(/\D/g, "")) || 1) * 31 + 7, { dead: true, deadDur: 1.25, alpha: Math.min(1, c.t / 0.5), sc: a.sc || 1 }); continue; } drawChar({ x: a.x, z: a.z, yaw: a.yaw, walk: 0, moving: 0, y: -k * 0.55, roll: 1, sc: a.sc * (c.t < 0.5 ? c.t / 0.5 : 1), bw: a.bw }, Object.assign({}, ALLY_ST[a.kind] || ALLY_ST.sword, { cape: null, skin: a.look.skin, hair: a.look.hair, face: a.look.face })); }
    for (const f of foes) {
      if (f.dead && f.deadT < 0) continue; const k = FOE_ST[f.kind]; const dead = f.dead; const o = { x: f.x, z: f.z, y: f.y !== undefined ? f.y : (f.wall ? WALLH : 0), yaw: f.yaw, walk: f.walk, moving: f.wall ? 0 : 1, swing: f.atkA > 0, atkP: f.atkA > 0 ? 1 - f.atkA / 0.4 : 0, combo: 0, sc: f.sc || 1, walkAmp: 0.8 };
      if (f.beast) { drawBeast(f, !!dead); if (f.hurt > 0 && !dead) flashRing(f.x, f.z, "#fff"); if (!dead && f.hp < f.maxhp) hpBar(f); continue; }
      if (dead) { o.y = (o.y || 0) - (0.7 - f.deadT) * 1.4; o.sc = (o.sc || 1) * Math.max(0.1, f.deadT / 0.7); } if (f.wall) { o.sc = 0.95; }
      if (GLR) { glActor(f, "foe", f.kind, Math.floor((f.id || 1) * 99991) % 100000 + 5, { atk: f.atkA > 0 ? f.atkA : 0, atkMax: 0.4, hurt: f.hurt || 0, dead: !!dead, deadDur: 0.7, y: f.y !== undefined ? f.y : (f.wall ? WALLH : 0), alpha: dead ? Math.max(0, Math.min(1, f.deadT / 0.3)) : 1, sc: f.sc || 1 }); if (f.hurt > 0 && !dead) flashRing(f.x, f.z, "#fff"); if (!dead && !f.wall && f.hp < f.maxhp || f.kind === "captain") hpBar(f); continue; } if (!f.look) f.look = randomLook(Math.floor((f.id || 1) * 99991) % 100000 + 5, { angry: true, darkTone: Math.random() < 0.3 }); drawChar(o, Object.assign({}, k, { skin: f.look.skin, hair: f.look.hair, face: f.look.face })); if (f.hurt > 0 && !dead) flashRing(f.x, f.z, "#fff");
      if (!dead && !f.wall && f.hp < f.maxhp || f.kind === "captain") hpBar(f);
    }
    // دروازه‌شکن‌ها
    for (const r of rams) { const o = { x: r.x, z: r.z, yaw: 0, y: 0, sc: 1 }, rc = r.recoil || 0, zz = -rc * 3; box(o, 0, 0, 0, 0, -1.2, 0.9, 0, 0.2, 1.8, 3.6, [90, 60, 36]); box(o, 0, 0, 0, 0, 1.2, 0.9, 0, 0.2, 1.8, 3.6, [90, 60, 36]); box(o, 0, 0, zz, 0, 0, 1.4, 0.4, 0.8, 0.8, 4.4, [130, 90, 54]); box(o, 0, 0, zz, 0, 0, 1.4, 2.8, 1.0, 1.0, 0.8, [70, 72, 80]); for (const sx of [-1.2, 1.2]) for (const sz of [-1.2, 1.2]) box(o, 0, 0, 0, 0, sx, 0.4, sz, 0.2, 0.8, 0.8, [50, 34, 22]); box(o, 0, 0, 0, 0, 0, 2.2, 0, 3, 0.2, 4.4, [150, 60, 44]); }
    // پرتاب‌ها و ذرات
    for (const a of arrows) { if (a.ad !== undefined || a.dmg >= 0) { const t = a.t / a.T, x = lerp(a.x, a.tx, t), z = lerp(a.z, a.tz, t), y = lerp(a.y, 0.4, t) + Math.sin(t * Math.PI) * 2.2, dx = a.tx - a.x, dz = a.tz - a.z, l = Math.hypot(dx, dz) || 1; const p1 = proj(x, y, z), p2 = proj(x - dx / l * 0.9, y + 0.15, z - dz / l * 0.9); if (p1[2] > 0.5 && p2[2] > 0.5) items.push({ z: p1[2], f() { const s1 = toScr(p1), s2 = toScr(p2); ctx.strokeStyle = "#5a3a1a"; ctx.lineWidth = Math.max(1.5, 0.06 / p1[2] * F); ctx.beginPath(); ctx.moveTo(s1[0], s1[1]); ctx.lineTo(s2[0], s2[1]); ctx.stroke(); ctx.fillStyle = "#e8e8f0"; ctx.beginPath(); ctx.arc(s1[0], s1[1], Math.max(1.5, 0.08 / p1[2] * F), 0, TAU); ctx.fill(); } }); if (!a.ally && a.tg) markDanger(a); } }
    for (const p of parts) { const q = proj(p.x, p.y, p.z); if (q[2] < 0.5) continue; if (p.ring) { items.push({ z: q[2] + 50, f() { const k = 1 - p.life / p.max, R = p.r * (0.3 + k * 0.7); ctx.strokeStyle = p.c; ctx.globalAlpha = p.life / p.max; ctx.lineWidth = 3; ctx.beginPath(); for (let i = 0; i <= 24; i++) { const a = i / 24 * TAU, s = toScr(proj(p.x + Math.cos(a) * R, 0.1, p.z + Math.sin(a) * R)); if (i) ctx.lineTo(s[0], s[1]); else ctx.moveTo(s[0], s[1]); } ctx.stroke(); ctx.globalAlpha = 1; } }); } else items.push({ z: q[2], f() { const s = toScr(q), R = Math.max(1.2, p.s / q[2] * F); ctx.globalAlpha = clamp(p.life / p.max * 1.4, 0, 1); ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(s[0], s[1], R, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; } }); }
    items.sort((a, b) => b.z - a.z); for (const it of items) it.f();
    // متن‌های شناور
    ctx.textAlign = "center"; ctx.font = "800 16px Vazirmatn, sans-serif"; for (const t of texts) { const q = proj(t.x, t.y, t.z); if (q[2] < 0.5) continue; const s = toScr(q); ctx.globalAlpha = clamp(t.life * 2, 0, 1); ctx.lineWidth = 3; ctx.strokeStyle = "rgba(0,0,0,.7)"; ctx.fillStyle = t.c; ctx.strokeText(t.t, s[0], s[1]); ctx.fillText(t.t, s[0], s[1]); ctx.globalAlpha = 1; }
    // یاد‌دهی پرچم قرمز لبه هنگام آسیب
    if (P.hurt > 0) { ctx.fillStyle = `rgba(255,40,40,${P.hurt * 0.8})`; ctx.fillRect(0, 0, W, H); }
    { const sx0 = ((-cam.yaw * 220 + 300) % (W + 400) + W + 400) % (W + 400) - 100; ctx.globalCompositeOperation = "lighter"; const sg = ctx.createRadialGradient(sx0, H * 0.17, 10, sx0, H * 0.17, H * 0.75); sg.addColorStop(0, "rgba(255,236,190,0.30)"); sg.addColorStop(0.35, "rgba(255,220,160,0.10)"); sg.addColorStop(1, "rgba(255,220,160,0)"); ctx.fillStyle = sg; ctx.fillRect(0, 0, W, H); ctx.globalCompositeOperation = "source-over";
      const wg = ctx.createLinearGradient(0, 0, 0, H); wg.addColorStop(0, "rgba(255,230,190,0.06)"); wg.addColorStop(1, "rgba(30,40,90,0.14)"); ctx.fillStyle = wg; ctx.fillRect(0, 0, W, H); }
    const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.38, W / 2, H / 2, H * 0.98); vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, "rgba(0,0,0,0.5)"); ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
  }
  function burstTrail(x, y, z, c) { const q = proj(x, y, z); if (q[2] < 0.5) return; items.push({ z: q[2] - 0.3, f() { const s = toScr(q), R = 0.5 / q[2] * F; const g = ctx.createRadialGradient(s[0], s[1], 0, s[0], s[1], R); g.addColorStop(0, c); g.addColorStop(1, "rgba(0,0,0,0)"); ctx.globalCompositeOperation = "lighter"; ctx.fillStyle = g; ctx.fillRect(s[0] - R, s[1] - R, R * 2, R * 2); ctx.globalCompositeOperation = "source-over"; } }); }
  function flashRing(x, z, c) { const q = proj(x, 1.2, z); if (q[2] < 0.5) return; items.push({ z: q[2] - 0.5, f() { const s = toScr(q), R = 0.55 / q[2] * F; ctx.globalAlpha = 0.45; ctx.fillStyle = c; ctx.beginPath(); ctx.arc(s[0], s[1], R, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; } }); }
  function markDanger(a) { const q = proj(a.tx, 0.05, a.tz); if (q[2] < 0.5 || a.tg !== P) return; items.push({ z: q[2] + 40, f() { const s = toScr(q), R = 1.0 / q[2] * F; ctx.strokeStyle = "rgba(255,70,70,0.75)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(s[0], s[1], R, R * 0.42, 0, 0, TAU); ctx.stroke(); } }); }
  function hpBar(f) { const q = proj(f.x, (f.y || 0) + 2.7 * (f.sc || 1), f.z); if (q[2] < 0.5) return; items.push({ z: q[2] - 0.6, f() { const s = toScr(q), w = 46 * (f.sc || 1), h = 5; ctx.fillStyle = "rgba(0,0,0,.6)"; ctx.fillRect(s[0] - w / 2 - 1, s[1] - 1, w + 2, h + 2); ctx.fillStyle = f.kind === "captain" ? "#ff5a5a" : "#e6c04a"; ctx.fillRect(s[0] - w / 2, s[1], w * clamp(f.hp / f.maxhp, 0, 1), h); } }); }

  function loop(now) {
    raf = requestAnimationFrame(loop); let dt = Math.min(0.05, (now - last) / 1000); last = now; if (paused) return;
    if (hitStop > 0) { hitStop -= dt; dt *= 0.15; }
    if (!over || G.fall > 0) update(dt); else update(dt * 0.3); render();
  }
  if (FIELD) { const rb = root.querySelector('[data-s=ram]'); if (rb) rb.style.display = 'none'; const gb = root.querySelector('[data-s=o_gate]'); if (gb) gb.style.display = 'none'; }
  updCmd(); try { const ar = ARMY(); if (!ar.seen) { ar.seen = 1; setTimeout(() => say("با 🗡️ حمله کن، با 🌀 جاخالی بده؛ دستورها را از تب 📣 سمت چپ به یاران بده", 5), 3500); } } catch (e) { /* */ }
  Sound.playMusic("attack", { intensity: 0.8 });
  say(FIELD ? `نبرد در میدان! ${nb.name} را نابود کن ⚔️` : `به ${nb.name} حمله کن! دروازه را بشکن ⚔️`, 3.2);
  raf = requestAnimationFrame(loop);
}

// پیش‌نمایش شخصیت برای فروشگاه (چرخان)
export function avatarPreview(canvas, av, getAv) {
  const ctx = canvas.getContext("2d"); let t = 0, raf = 0, alive = true;
  const fake = { skin: "#000" }; void fake;
  function frame() {
    if (!alive || !canvas.isConnected) { return; } raf = requestAnimationFrame(frame); t += 0.016; const a = getAv ? getAv() : av, W = canvas.width, H = canvas.height; ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, W, H);
    const g = ctx.createRadialGradient(W / 2, H * 0.6, 10, W / 2, H * 0.6, H * 0.7); g.addColorStop(0, "#4a3a66"); g.addColorStop(1, "#1a1428"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    mini(ctx, W, H, a, t);
  }
  frame(); return () => { alive = false; cancelAnimationFrame(raf); };
}
// رندر کوچک مستقل برای پیش‌نمایش (دو‌بعدی شبه‌سه‌بعدی با اجزای هندسی)
function mini(ctx, W, H, av, t) {
  const SW = find("sword", av.sword), SH = find("shield", av.shield), HM = find("helm", av.helm), AR = find("armor", av.armor), CP = find("cape", av.cape);
  const u = H / 3.0, cx = W / 2, gy = H * 0.93, ry = Math.sin(t * 1.2), rot = t * 0.8, cr = Math.cos(rot), sr = Math.sin(rot);
  ctx.fillStyle = "rgba(0,0,0,.35)"; ctx.beginPath(); ctx.ellipse(cx, gy, u * 0.9, u * 0.25, 0, 0, TAU); ctx.fill();
  const X = (x, z) => cx + (x * cr + z * sr) * u, Zd = (x, z) => -x * sr + z * cr;
  const P2 = (x, y, z) => [X(x, z), gy - y * u + Zd(x, z) * u * 0.08];
  const items = [];
  const bx = (x, y, z, w, h, d, col, fn) => items.push({ d: Zd(x, z), f() { const [px, py] = P2(x, y, z), k = 0.78 + 0.22 * (Zd(x, z) < 0 ? 1 : 0.8); ctx.fillStyle = rgb(hex(col), k); const W2 = (Math.abs(w * cr) + Math.abs(d * sr)) * u; ctx.beginPath(); roundRect(ctx, px - W2 / 2, py - h * u / 2, W2, h * u, Math.min(6, W2 / 3)); ctx.fill(); ctx.strokeStyle = rgb(hex(col), 0.45); ctx.lineWidth = 1; ctx.stroke(); if (fn) fn(px, py, W2); } });
  const cp = CP.color;
  if (cp) bx(0, 1.0, -0.22, 0.66, 1.05, 0.08, cp);
  bx(0.16, 0.38, 0, 0.24, 0.76, 0.26, "#3a3f4a"); bx(-0.16, 0.38, 0, 0.24, 0.76, 0.26, "#3a3f4a");
  bx(0, 1.15, 0, 0.66, 0.76, 0.36, AR.color || av.tunic); bx(0, 0.84, 0, 0.7, 0.12, 0.4, "#5a3a1a");
  if (AR.id !== "a0") { bx(0.43, 1.52, 0, 0.26, 0.2, 0.3, AR.color); bx(-0.43, 1.52, 0, 0.26, 0.2, 0.3, AR.color); }
  bx(-0.42, 1.12, 0, 0.17, 0.62, 0.17, av.skin); if (SH.id !== "d0") bx(-0.55, 1.1, 0.25, 0.1, 0.8, 0.6, SH.color, (px, py, w) => { if (SH.emblem) { ctx.fillStyle = "#c43a3a"; ctx.beginPath(); ctx.arc(px, py, w * 0.18, 0, TAU); ctx.fill(); } });
  bx(0.42, 1.12, 0.2, 0.17, 0.62, 0.17, av.skin);
  const sw = (px, py) => { const L = 1.2 * SW.len * u; ctx.save(); ctx.translate(px, py); ctx.rotate(-0.12 + ry * 0.05); if (SW.glow) { const g = ctx.createRadialGradient(0, -L / 2, 0, 0, -L / 2, L * 0.7); g.addColorStop(0, SW.glow + "aa"); g.addColorStop(1, "rgba(0,0,0,0)"); ctx.fillStyle = g; ctx.fillRect(-L, -L * 1.3, L * 2, L * 1.6); } ctx.fillStyle = SW.blade; ctx.beginPath(); ctx.moveTo(-u * 0.05, 0); ctx.lineTo(-u * 0.05, -L); ctx.lineTo(0, -L - u * 0.12); ctx.lineTo(u * 0.05, -L); ctx.lineTo(u * 0.05, 0); ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.3)"; ctx.stroke(); ctx.fillStyle = SW.hilt; ctx.fillRect(-u * 0.17, -u * 0.04, u * 0.34, u * 0.08); ctx.fillRect(-u * 0.04, 0, u * 0.08, u * 0.22); if (SW.twin) { ctx.fillStyle = SW.blade; ctx.fillRect(-u * 0.16, -L * 0.8, u * 0.32, u * 0.07); } ctx.restore(); };
  items.push({ d: Zd(0.5, 0.45) - 1, f() { const [px, py] = P2(0.42, 0.88, 0.45); sw(px, py); } });
  bx(0, 1.62, 0, 0.14, 0.14, 0.14, av.skin);
  items.push({ d: Zd(0, 0) - 0.5, f() { const [px, py] = P2(0, 1.86, 0), R = 0.27 * u; const g = ctx.createRadialGradient(px - R * 0.35, py - R * 0.4, R * 0.1, px, py, R); g.addColorStop(0, rgb(hex(av.skin), 1.2)); g.addColorStop(1, rgb(hex(av.skin), 0.7)); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, R, 0, TAU); ctx.fill(); ctx.strokeStyle = rgb(hex(av.skin), 0.4); ctx.stroke();
    const face = cr > 0.1 ? 1 : 0; const cover = (col, r, dy) => { const gg = ctx.createRadialGradient(px - R * 0.3, py + dy - R * 0.4, R * 0.1, px, py + dy, r); gg.addColorStop(0, rgb(hex(col), 1.2)); gg.addColorStop(1, rgb(hex(col), 0.65)); ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(px, py + dy, r, Math.PI, 0); ctx.lineTo(px + r, py + dy + r * 0.1); ctx.lineTo(px - r, py + dy + r * 0.1); ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.3)"; ctx.stroke(); };
    if (face) { const ex = R * 0.42; ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.ellipse(px - ex, py + R * 0.08, R * 0.2, R * 0.16, 0, 0, TAU); ctx.ellipse(px + ex, py + R * 0.08, R * 0.2, R * 0.16, 0, 0, TAU); ctx.fill(); ctx.fillStyle = "#1a1a22"; ctx.beginPath(); ctx.arc(px - ex, py + R * 0.08, R * 0.1, 0, TAU); ctx.arc(px + ex, py + R * 0.08, R * 0.1, 0, TAU); ctx.fill(); ctx.strokeStyle = "rgba(90,40,30,.8)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(px, py + R * 0.3, R * 0.2, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke(); }
    if (HM.kind === "helm" || HM.kind === "crest") cover(HM.color, R * 1.08, -R * 0.02); else if (HM.kind === "cap") cover(HM.color, R * 1.02, -R * 0.12); else cover(av.hair, R * 1.02, -R * 0.1);
    if (HM.kind === "crest") { ctx.fillStyle = HM.plume; ctx.beginPath(); ctx.moveTo(px - R * 0.1, py - R); ctx.quadraticCurveTo(px + R * 0.1, py - R * 2, px + R * 0.7, py - R * 1.2); ctx.lineTo(px + R * 0.1, py - R * 0.9); ctx.fill(); }
    if (HM.kind === "crown") { ctx.fillStyle = HM.color; ctx.beginPath(); ctx.moveTo(px - R * 0.8, py - R * 0.7); for (let i = 0; i < 5; i++) { ctx.lineTo(px - R * 0.8 + i * R * 0.4 + R * 0.2, py - R * (i % 2 ? 1.25 : 1.6)); ctx.lineTo(px - R * 0.8 + (i + 1) * R * 0.4, py - R * 0.7); } ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.3)"; ctx.stroke(); } } });
  items.sort((a, b) => b.d - a.d); for (const i of items) i.f();
}
function roundRect(ctx, x, y, w, h, r) { ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
