// حالت سه‌بعدی (آزمایشی): محاصره‌ی قلعه از پشت شخصیت — موتور سبک با تصویرسازی پرسپکتیو روی canvas
import { S } from "./save.js";
import { Sound } from "./audio.js";
import { TROOPS, troopMul } from "./data.js";
import { find, stats } from "./gear.js";

const TAU = Math.PI * 2, clamp = (v, a, b) => Math.max(a, Math.min(b, v)), lerp = (a, b, t) => a + (b - a) * t;
const hex = (h) => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const rgb = (c, k = 1, fog = 0, fc = [190, 215, 235]) => { const r = lerp(clamp(c[0] * k, 0, 255), fc[0], fog), g = lerp(clamp(c[1] * k, 0, 255), fc[1], fog), b = lerp(clamp(c[2] * k, 0, 255), fc[2], fog); return `rgb(${r | 0},${g | 0},${b | 0})`; };
const angDiff = (a, b) => { let d = (b - a) % TAU; if (d > Math.PI) d -= TAU; if (d < -Math.PI) d += TAU; return d; };
const LIGHT = (() => { const l = [0.45, 0.8, -0.4], n = Math.hypot(...l); return l.map((v) => v / n); })();

// ---------- پالت هر کشور ----------
const THEMES = {
  n1: { sky: ["#8fd0ff", "#e6f6ff"], ground: ["#5fae56", "#4c9a48"], wall: "#b9a27a", roof: "#a8482e", fog: [200, 228, 245], mount: "#7aa88a" },
  n2: { sky: ["#9ab8d8", "#dfe8f2"], ground: ["#8a9a72", "#788a64"], wall: "#9a9a9a", roof: "#5a6a8a", fog: [205, 215, 228], mount: "#7a8696" },
  n3: { sky: ["#ffcf8a", "#ffeccb"], ground: ["#d8b872", "#c8a862"], wall: "#d6b27a", roof: "#2f8a8a", fog: [250, 226, 190], mount: "#c4966a" },
  n4: { sky: ["#a8c8e8", "#eef6ff"], ground: ["#e8f0f8", "#d4e0ee"], wall: "#a8bcd2", roof: "#4a6a9a", fog: [226, 238, 250], mount: "#b8cce0" },
  n5: { sky: ["#5a2a2a", "#ff9a5a"], ground: ["#5a3a30", "#4a2e28"], wall: "#6a4a42", roof: "#c4401a", fog: [150, 80, 60], mount: "#3a2420" },
  n6: { sky: ["#8a7ad8", "#f6e0ff"], ground: ["#c8d0f0", "#b4bee6"], wall: "#e8e0f4", roof: "#7a5ac8", fog: [232, 224, 250], mount: "#a8a0d8" },
};

export function startSiege3D(nb, onEnd) {
  const th = THEMES[nb.id] || THEMES.n1, WALL = hex(th.wall), ROOF = hex(th.roof), FOG = th.fog;
  const root = document.createElement("div"); root.id = "s3d";
  root.innerHTML = `<canvas id="s3c"></canvas>
  <div class="s3top"><div class="s3bar"><i id="s3php"></i><span id="s3pt"></span></div><div class="s3mid"><b>${nb.emoji} ${nb.name}</b><div class="s3bar g"><i id="s3ghp"></i><span id="s3gt"></span></div></div><div class="s3r"><span id="s3time"></span><button class="s3b sm" data-s="pause">⏸</button></div></div>
  <div id="s3msg"></div>
  <div class="s3joy" id="s3joy"><i id="s3knob"></i></div>
  <div class="s3btns"><button class="s3b big" data-s="atk">⚔️</button><button class="s3b" data-s="roll"><span>🌀</span><em>جاخالی</em></button><button class="s3b" data-s="spec"><span>💥</span><em>ضربه شاهانه</em><u id="s3c1"></u></button><button class="s3b" data-s="rally"><span>📣</span><em>فرمان</em><u id="s3c2"></u></button><button class="s3b" data-s="ram"><span>🐏</span><em>دروازه‌شکن</em><u id="s3c3"></u></button></div>
  <div id="s3pause" class="s3pause"><div class="s3card"><h2>توقف</h2><button class="btn l g" data-s="resume">ادامه ▶</button><button class="btn l d" data-s="quit">خروج از نبرد</button></div></div>`;
  document.body.appendChild(root); document.body.classList.add("inbattle");
  const cv = root.querySelector("#s3c"), ctx = cv.getContext("2d", { alpha: false });
  const $ = (id) => root.querySelector("#" + id);
  let W = 0, H = 0, DPR = 1, F = 600;
  function resize() { DPR = Math.min(window.devicePixelRatio || 1, 1.5); W = innerWidth; H = innerHeight; const px = W * H * DPR * DPR, cap = 1.7e6; if (px > cap) DPR *= Math.sqrt(cap / px); cv.width = W * DPR | 0; cv.height = H * DPR | 0; cv.style.width = W + "px"; cv.style.height = H + "px"; F = Math.min(H * 1.15, W * 0.62); }
  resize(); addEventListener("resize", resize);

  // ---------- جهان ----------
  const ZG = 46, WALLH = 8, GATEW = 5.2, GATEH = 6.2, FRONT = ZG - 1.6, LIMX = 26;
  const st = stats(S.avatar), AV = S.avatar, SW = find("sword", AV.sword), SH = find("shield", AV.shield), HM = find("helm", AV.helm), AR = find("armor", AV.armor), CP = find("cape", AV.cape);
  const P = { x: 0, z: 0, yaw: 0, hp: st.hp, maxhp: st.hp, atkT: 0, hitDone: true, combo: 0, comboT: 0, roll: 0, inv: 0, walk: 0, hurt: 0, vx: 0, vz: 0, dead: false, bob: 0 };
  const gateMax = Math.round(nb.gate * 0.85), G = { hp: gateMax, max: gateMax, hit: 0, fall: 0, shake: 0 };
  const allies = [], foes = [], arrows = [], parts = [], texts = [], rams = [];
  const cam = { yaw: 0, x: 0, y: 0, z: -7, pitch: 0.34, dist: 7.6, h: 5.0, shake: 0 };
  const power = nb.power;
  let time = 0, kills = 0, lost = 0, over = false, paused = false, cd = { spec: 0, rally: 0, ram: 0 }, rallyT = 0, spawnT = 4, captain = 0, msgT = 0, ended = false, raf = 0, last = performance.now(), endT = 0, endWon = false, deadT = 0, hitStop = 0;
  const LIMIT = 150;
  // یاران: از سربازان پادگان
  const ready = Object.keys(TROOPS).filter((k) => k !== "ram" && S.buildings.barracks >= TROOPS[k].barracks);
  const nAll = Math.min(10, 3 + S.buildings.barracks * 1 + Math.floor(S.level / 6));
  for (let i = 0; i < nAll; i++) {
    const k = ready[i % ready.length], d = TROOPS[k], m = troopMul(S.troops[k] || 1);
    allies.push({ id: "a" + i, kind: k, x: (i % 2 ? 1 : -1) * (2.2 + Math.floor(i / 2) * 1.5), z: 1.5 - Math.floor(i / 2) * 1.2, yaw: 0, hp: d.hp * m * 0.9, maxhp: d.hp * m * 0.9, dmg: ((d.melee || d.ranged || 8) * 1.6) * m, speed: 3.4 * (k === "horse" ? 1.8 : k === "shield" ? 0.85 : 1), cdT: Math.random(), walk: Math.random() * 6, hurt: 0, atkA: 0, ranged: !!d.ranged, off: i, tgt: null });
  }
  const archerPos = []; const nArch = 3 + nb.tlvl * 2; for (let i = 0; i < nArch; i++) archerPos.push(-LIMX + 6 + (i + 0.5) * ((LIMX * 2 - 12) / nArch));
  const wallArchers = archerPos.map((x, i) => ({ x, z: ZG - 0.4, y: WALLH, yaw: Math.PI, hp: 36 + power * 0.8, maxhp: 36 + power * 0.8, cdT: 1 + i * 0.5, kind: "warcher", walk: 0, hurt: 0, wall: true }));
  for (const a of wallArchers) foes.push(a);

  // ---------- ورودی ----------
  const key = {}, joy = { on: false, id: null, x: 0, y: 0, ox: 0, oy: 0 }; let camTouch = null;
  const mv = () => { let x = (key.d || key.arrowright ? 1 : 0) - (key.a || key.arrowleft ? 1 : 0), y = (key.w || key.arrowup ? 1 : 0) - (key.s || key.arrowdown ? 1 : 0); x += joy.x; y += joy.y; const l = Math.hypot(x, y); return l > 1 ? [x / l, y / l] : [x, y]; };
  const onKD = (e) => { const k = e.key.toLowerCase(); key[k] = true; if (k === " ") { act("atk"); e.preventDefault(); } if (k === "shift") act("roll"); if (k === "r") act("spec"); if (k === "f") act("rally"); if (k === "g") act("ram"); if (k === "escape") act(paused ? "resume" : "pause"); };
  const onKU = (e) => { key[e.key.toLowerCase()] = false; };
  addEventListener("keydown", onKD); addEventListener("keyup", onKU);
  const joyEl = $("s3joy"), knob = $("s3knob");
  joyEl.addEventListener("pointerdown", (e) => { joy.on = true; joy.id = e.pointerId; joyEl.setPointerCapture(e.pointerId); joyMove(e); e.preventDefault(); });
  joyEl.addEventListener("pointermove", (e) => { if (joy.on && e.pointerId === joy.id) joyMove(e); });
  const joyEnd = (e) => { if (e.pointerId === joy.id) { joy.on = false; joy.x = joy.y = 0; knob.style.transform = "translate(0,0)"; } };
  joyEl.addEventListener("pointerup", joyEnd); joyEl.addEventListener("pointercancel", joyEnd);
  function joyMove(e) { const r = joyEl.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2, R = r.width / 2; let dx = (e.clientX - cx) / R, dy = (e.clientY - cy) / R; const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; } joy.x = Math.abs(dx) < 0.1 ? 0 : dx; joy.y = Math.abs(dy) < 0.1 ? 0 : -dy; knob.style.transform = `translate(${dx * R * 0.55}px,${dy * R * 0.55}px)`; }
  cv.addEventListener("pointerdown", (e) => { if (camTouch === null) { camTouch = { id: e.pointerId, x: e.clientX }; cv.setPointerCapture(e.pointerId); } });
  cv.addEventListener("pointermove", (e) => { if (camTouch && camTouch.id === e.pointerId) { cam.yaw -= (e.clientX - camTouch.x) * 0.006; camTouch.x = e.clientX; } });
  const camEnd = (e) => { if (camTouch && camTouch.id === e.pointerId) camTouch = null; };
  cv.addEventListener("pointerup", camEnd); cv.addEventListener("pointercancel", camEnd);
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-s]"); if (b) act(b.dataset.s); });
  root.querySelectorAll(".s3b").forEach((b) => b.addEventListener("pointerdown", (e) => { const a = b.dataset.s; if (a === "atk" || a === "roll" || a === "spec" || a === "rally" || a === "ram") { e.preventDefault(); e.stopPropagation(); act(a); b.classList.add("p"); setTimeout(() => b.classList.remove("p"), 120); } }));
  root.querySelectorAll(".s3b").forEach((b) => b.addEventListener("click", (e) => { const a = b.dataset.s; if (a === "atk" || a === "roll" || a === "spec" || a === "rally" || a === "ram") e.stopPropagation(); }, true));

  function say(t, d = 2.2) { const m = $("s3msg"); m.textContent = t; m.classList.add("on"); msgT = d; }
  function act(a) {
    if (a === "pause") { paused = true; $("s3pause").classList.add("on"); return; }
    if (a === "resume") { paused = false; $("s3pause").classList.remove("on"); last = performance.now(); return; }
    if (a === "quit") { finish(false, true); return; }
    if (paused || over || P.dead) return;
    if (a === "atk") { if (P.atkT <= 0 && P.roll <= 0) { P.atkT = 0.46; P.hitDone = false; P.combo = P.comboT > 0 ? (P.combo + 1) % 3 : 0; P.comboT = 0.9; autoAim(); Sound.sfx("shot_spear", { vol: 0.5 }); } }
    else if (a === "roll") { if (P.roll <= 0) { const [mx, my] = mv(); let d = P.yaw; if (mx || my) d = camAng(mx, my); P.rd = d; P.roll = 0.38; P.inv = 0.5; P.atkT = 0; Sound.sfx("tick"); } }
    else if (a === "spec") { if (cd.spec <= 0) { cd.spec = 9; slam(); } }
    else if (a === "rally") { if (cd.rally <= 0) { cd.rally = 24; rallyT = 8; for (const al of allies) { al.hp = Math.min(al.maxhp, al.hp + al.maxhp * 0.4); burst(al.x, 1, al.z, 8, "#ffd36b", 3); } ring(P.x, P.z, 7, "#ffd36b"); Sound.sfx("skill_kaveh"); say("یاران، به پیش! ⚔️", 1.6); } }
    else if (a === "ram") { if (cd.ram <= 0) { cd.ram = 28; const lv = S.troops.ram || 1; rams.push({ x: clamp(P.x, -5, 5), z: P.z - 6, hp: 260 * troopMul(lv), maxhp: 260 * troopMul(lv), dmg: 150 * troopMul(lv), roll: 0, hits: 0, cdT: 0 }); Sound.sfx("troop_spawn"); say("دروازه‌شکن فرستاده شد! 🐏", 1.8); } }
  }
  const camAng = (mx, my) => { const f = cam.yaw, fx = Math.sin(f), fz = Math.cos(f), rx = Math.cos(f), rz = -Math.sin(f); return Math.atan2(rx * mx + fx * my, rz * mx + fz * my); };
  function autoAim() { let b = null, bd = 4.2; for (const f of foes) { if (f.wall || f.dead) continue; const d = Math.hypot(f.x - P.x, f.z - P.z); if (d < bd) { bd = d; b = f; } } if (b) P.yaw = Math.atan2(b.x - P.x, b.z - P.z); else if (Math.abs(P.z - (FRONT - 0.6)) < 4.5) P.yaw = Math.atan2(-P.x * 0.5, 1); }

  // ---------- افکت‌ها ----------
  function burst(x, y, z, n, color, sp = 3) { if (parts.length > 260) return; for (let i = 0; i < n; i++) { const a = Math.random() * TAU; parts.push({ x, y, z, vx: Math.cos(a) * sp * Math.random(), vy: Math.random() * sp * 1.1, vz: Math.sin(a) * sp * Math.random(), life: 0.5 + Math.random() * 0.4, max: 0.9, c: color, s: 0.09 + Math.random() * 0.1 }); } }
  function ring(x, z, r, color) { parts.push({ ring: true, x, y: 0.08, z, r, life: 0.5, max: 0.5, c: color }); }
  function text(x, y, z, t, color) { texts.push({ x, y, z, t, c: color, life: 0.9 }); }
  function hurtP(dmg, from) {
    if (P.inv > 0 || P.dead) return; dmg = dmg * (1 - st.def); P.hp -= dmg; P.hurt = 0.25; cam.shake = Math.max(cam.shake, 0.18); text(P.x, 2.4, P.z, "-" + Math.round(dmg), "#ff6a6a"); Sound.sfx("hit_heavy", { vol: 0.6 }); burst(P.x, 1.2, P.z, 6, "#ff8a8a", 2.5);
    if (P.hp <= 0) { P.hp = 0; P.dead = true; deadT = 1.4; say("افتادی… 💔", 2); }
  }
  function slam() {
    const dmg = st.dmg * 2.6; ring(P.x, P.z, 5, "#ffd24a"); ring(P.x, P.z, 3, "#fff"); burst(P.x, 0.5, P.z, 30, "#ffd24a", 6); cam.shake = 0.5; Sound.sfx("explode", { vol: 0.7 }); hitStop = 0.08;
    for (const f of foes) { if (f.wall) continue; const d = Math.hypot(f.x - P.x, f.z - P.z); if (d < 5) { dmgFoe(f, dmg, P); f.stun = 1.3; const a = Math.atan2(f.x - P.x, f.z - P.z); f.x += Math.sin(a) * 2; f.z += Math.cos(a) * 2; } }
    if (P.z > FRONT - 5.5 && Math.abs(P.x) < 6) hitGate(dmg * 1.6, P.x, P.z + 1);
  }
  function dmgFoe(f, d, src) {
    if (f.dead) return; f.hp -= d; f.hurt = 0.2; text(f.x, (f.y || 0) + 2.4 * (f.sc || 1), f.z, Math.round(d), src === P ? "#fff2b0" : "#ffd0a0"); burst(f.x, (f.y || 0) + 1.2, f.z, 4, "#ffe0b0", 2.5);
    if (f.hp <= 0) { f.dead = true; f.deadT = 0.7; kills++; burst(f.x, (f.y || 0) + 1, f.z, 14, "#d8c0a0", 4); Sound.sfx("enemy_die"); }
  }
  function hitGate(d, x, z) {
    if (G.hp <= 0) return; G.hp = Math.max(0, G.hp - d); G.hit = 0.18; G.shake = 0.25; cam.shake = Math.max(cam.shake, 0.12); text(x, 3.5, FRONT - 0.5, Math.round(d), "#ffb347"); burst(x, 2.5, FRONT - 0.3, 8, "#caa070", 3); Sound.sfx("gate_hit");
    if (G.hp <= 0) { G.fall = 0.001; Sound.sfx("explode"); cam.shake = 0.9; burst(0, 3, FRONT, 60, "#caa070", 8); say("دروازه شکست! 🏰", 3); }
  }

  // ---------- دشمنان ----------
  function spawnGuard(captainMode) {
    const side = Math.random() < 0.5 ? -1 : 1, x = side * (LIMX - 3.5), z = FRONT - 1;
    const heavy = !captainMode && power > 55 && Math.random() < 0.4;
    const hp = captainMode ? 380 + power * 9 : (heavy ? 2.1 : 1) * (60 + power * 1.8);
    foes.push({ id: Math.random(), kind: captainMode ? "captain" : heavy ? "heavy" : "guard", x, z, yaw: Math.PI, hp, maxhp: hp, dmg: (captainMode ? 22 : heavy ? 10 : 7) + power * (captainMode ? 0.35 : 0.1), speed: captainMode ? 3.0 : heavy ? 2.4 : 3.3, sc: captainMode ? 1.45 : heavy ? 1.12 : 1, walk: Math.random() * 6, cdT: 0.6, hurt: 0, atkA: 0, stun: 0 });
    burst(x, 1, z, 8, "#8a7a6a", 2);
  }

  // ---------- به‌روزرسانی ----------
  function update(dt) {
    time += dt; if (msgT > 0) { msgT -= dt; if (msgT <= 0) $("s3msg").classList.remove("on"); }
    for (const k in cd) cd[k] = Math.max(0, cd[k] - dt); rallyT = Math.max(0, rallyT - dt);
    P.atkT = Math.max(0, P.atkT - dt); P.comboT = Math.max(0, P.comboT - dt); P.hurt = Math.max(0, P.hurt - dt); P.inv = Math.max(0, P.inv - dt);
    G.hit = Math.max(0, G.hit - dt); G.shake = Math.max(0, G.shake - dt); cam.shake = Math.max(0, cam.shake - dt * 1.6);
    if (G.fall > 0) { G.fall += dt; if (G.fall > 1.8 && !over) finish(true); }
    // بازیکن
    if (!P.dead) {
      const [mx, my] = mv(); let sp = 0;
      if (P.roll > 0) { P.roll -= dt; sp = 12; P.x += Math.sin(P.rd) * sp * dt; P.z += Math.cos(P.rd) * sp * dt; P.yaw = P.rd; }
      else if (mx || my) { const d = camAng(mx, my), m = Math.hypot(mx, my); sp = (P.atkT > 0 ? 2.2 : 6.2) * m; P.yaw += angDiff(P.yaw, d) * Math.min(1, dt * 14); P.x += Math.sin(d) * sp * dt; P.z += Math.cos(d) * sp * dt; }
      P.walk += sp * dt * 1.8; P.moving = sp;
      if (P.atkT > 0 && !P.hitDone && P.atkT < 0.46 - 0.17) {
        P.hitDone = true; const dm = st.dmg * (1 + P.combo * 0.18) * (P.combo === 2 ? 1.2 : 1); let hit = 0; hitStop = 0.03;
        for (const f of foes) { if (f.wall || f.dead) continue; const dx = f.x - P.x, dz = f.z - P.z, d = Math.hypot(dx, dz); if (d < 2.9 * (SW.len * 0.9 + 0.2) && Math.abs(angDiff(P.yaw, Math.atan2(dx, dz))) < 1.25) { dmgFoe(f, dm, P); f.x += dx / (d || 1) * 0.7; f.z += dz / (d || 1) * 0.7; f.stun = Math.max(f.stun || 0, 0.25); hit++; } }
        if (P.z > FRONT - 3.4 && Math.abs(P.x) < GATEW / 2 + 1.6 && Math.abs(angDiff(P.yaw, 0)) < 1.1) { hitGate(dm * 1.5, P.x, P.z); hit++; }
        if (hit) { Sound.sfx("hit", { vol: 0.7 }); cam.shake = Math.max(cam.shake, 0.1); } else Sound.sfx("shot_spear", { vol: 0.3 });
        burst(P.x + Math.sin(P.yaw) * 1.8, 1.3, P.z + Math.cos(P.yaw) * 1.8, 5, SW.glow || "#fff", 3);
      }
    } else { deadT -= dt; if (deadT <= 0 && !over) finish(false); }
    P.x = clamp(P.x, -LIMX + 1, LIMX - 1); P.z = clamp(P.z, -14, FRONT - 0.9);
    // نگهبانان
    spawnT -= dt; const aliveG = foes.filter((f) => !f.wall && !f.dead).length;
    if (spawnT <= 0 && G.hp > 0) { spawnT = Math.max(3.4, 9.5 - power / 22) * (0.8 + Math.random() * 0.4); const n = 1 + (power > 40 ? 1 : 0) + (power > 85 ? 1 : 0); if (aliveG < 6 + (power > 60 ? 3 : 0)) for (let i = 0; i < n; i++) spawnGuard(false); }
    const frac = G.hp / G.max;
    if (captain === 0 && frac < 0.62) { captain = 1; spawnGuard(true); say("سردار نگهبانان آمد! ⚠️", 2.5); Sound.sfx("boss_roar"); cam.shake = 0.4; }
    if (captain === 1 && frac < 0.25) { captain = 2; spawnGuard(true); for (let i = 0; i < 3; i++) spawnGuard(false); say("آخرین سنگر! ⚠️", 2.5); Sound.sfx("boss_roar"); }
    const targets = () => [P, ...allies, ...rams].filter((t) => !t.dead && (t === P ? !P.dead : t.hp > 0));
    const tg = targets();
    for (const f of foes) {
      if (f.dead) { f.deadT -= dt; continue; } f.hurt = Math.max(0, (f.hurt || 0) - dt); f.cdT -= dt;
      if (f.wall) {
        if (f.cdT <= 0 && G.hp > 0) { let b = null, bd = 42; for (const t of tg) { const d = Math.hypot(t.x - f.x, t.z - f.z); if (d < bd && t.z < ZG - 6) { bd = d; b = t; } } if (b) { f.cdT = 2.4 + Math.random() * 1.4; f.yaw = Math.atan2(b.x - f.x, b.z - f.z); const vx = (b === P ? P.vx : 0), t = bd / 18; arrows.push({ x: f.x, y: WALLH + 1.5, z: f.z, tx: b.x + vx * t, tz: b.z + (b.vz || 0) * t, t: 0, T: t, dmg: 5 + power * 0.1, tg: b }); Sound.sfx("shot_bow", { vol: 0.35 }); } else f.cdT = 0.5; }
        continue;
      }
      if (f.stun > 0) { f.stun -= dt; continue; }
      let b = null, bd = 1e9; for (const t of tg) { let d = Math.hypot(t.x - f.x, t.z - f.z); if (t === P) d *= 0.8; if (d < bd) { bd = d; b = t; } }
      if (!b) continue; const dx = b.x - f.x, dz = b.z - f.z, d = Math.hypot(dx, dz), range = 1.5 * (f.sc || 1), want = Math.atan2(dx, dz);
      f.yaw += angDiff(f.yaw, want) * Math.min(1, dt * 10);
      if (d > range) { const s = f.speed * (f.atkA > 0 ? 0.3 : 1); f.x += dx / d * s * dt; f.z += dz / d * s * dt; f.walk += s * dt * 1.8; }
      else if (f.cdT <= 0) { f.cdT = f.kind === "captain" ? 1.3 : 1.15; f.atkA = 0.4; f.hitD = false; }
      if (f.atkA > 0) { f.atkA -= dt; if (!f.hitD && f.atkA < 0.22) { f.hitD = true; if (b === P) hurtP(f.dmg); else if (b.hp > 0) { b.hp -= f.dmg; b.hurt = 0.2; burst(b.x, 1.2, b.z, 3, "#ff8a8a", 2); } } }
      f.z = Math.min(f.z, FRONT - 0.9);
    }
    for (let i = foes.length - 1; i >= 0; i--) if (foes[i].dead && foes[i].deadT <= 0) foes.splice(i, 1);
    // پرتاب تیرها
    for (let i = arrows.length - 1; i >= 0; i--) {
      const a = arrows[i]; a.t += dt; if (a.t >= a.T) { const hitT = (t) => Math.hypot(t.x - a.tx, t.z - a.tz) < 1.1; if (a.tg === P) { if (!P.dead && hitT(P)) hurtP(a.dmg); } else if (a.tg && a.tg.hp > 0 && hitT(a.tg)) { a.tg.hp -= a.dmg; a.tg.hurt = 0.2; } burst(a.tx, 0.2, a.tz, 3, "#cbb89a", 1.5); arrows.splice(i, 1); }
    }
    // یاران
    const slots = allies.length;
    for (let i = allies.length - 1; i >= 0; i--) {
      const a = allies[i]; if (a.hp <= 0) { lost++; burst(a.x, 1, a.z, 12, "#9fb8d8", 3); allies.splice(i, 1); continue; }
      a.hurt = Math.max(0, a.hurt - dt); a.cdT -= dt; const mul = rallyT > 0 ? 1.4 : 1;
      let t = null, td = a.ranged ? 15 : 13; for (const f of foes) { if (f.dead) continue; if (f.wall && !a.ranged) continue; const d = Math.hypot(f.x - a.x, f.z - a.z); if (d < td) { td = d; t = f; } }
      let gx, gz, engage = false, range = a.ranged ? 11 : 1.7;
      if (t) { gx = t.x; gz = t.z; engage = true; if (t.wall) range = 13; }
      else if (G.hp > 0 && P.z > 20 && !a.ranged) { gx = clamp(P.x + (a.off - slots / 2) * 1.1, -4, 4); gz = FRONT - 1 - (a.off % 2) * 0.9; range = 0.3; engage = true; a.gate = true; }
      else { gx = P.x + Math.cos(a.off * 1.9) * (2.4 + (a.off % 3)); gz = P.z - 1.5 - (a.off % 4) * 1.1; range = 0.6; }
      const dx = gx - a.x, dz = gz - a.z, d = Math.hypot(dx, dz);
      if (d > range) { const s = a.speed * (rallyT > 0 ? 1.3 : 1); a.x += dx / d * s * dt; a.z += dz / d * s * dt; a.walk += s * dt * 1.8; a.yaw += angDiff(a.yaw, Math.atan2(dx, dz)) * Math.min(1, dt * 10); }
      else if (engage) { a.yaw += angDiff(a.yaw, Math.atan2(dx, dz || 0.001)) * Math.min(1, dt * 10); if (a.cdT <= 0) { a.cdT = (a.ranged ? 1.5 : 0.95) / mul; a.atkA = 0.35; if (a.gate) hitGate(a.dmg * 0.5 * mul, a.x, a.z); else if (t) { if (a.ranged) { arrows.push({ x: a.x, y: 1.5, z: a.z, tx: t.x, tz: t.z, t: 0, T: Math.max(0.2, d / 22), dmg: 0, ally: t, ad: a.dmg * mul }); Sound.sfx("shot_bow", { vol: 0.25 }); } else { dmgFoe(t, a.dmg * mul, a); } } } }
      if (a.atkA > 0) a.atkA -= dt; a.x = clamp(a.x, -LIMX + 1, LIMX - 1); a.z = clamp(a.z, -14, FRONT - 0.9);
    }
    // اصلاح تیر یاران
    for (let i = arrows.length - 1; i >= 0; i--) { const a = arrows[i]; if (a.ally && a.t + dt >= a.T && a.ally && !a.done) { a.done = true; if (!a.ally.dead) { if (a.ally.wall) { a.ally.hp -= a.ad; a.ally.hurt = 0.2; if (a.ally.hp <= 0) { a.ally.dead = true; a.ally.deadT = 0.7; kills++; } } else dmgFoe(a.ally, a.ad, a); } } }
    // دروازه‌شکن‌ها
    for (let i = rams.length - 1; i >= 0; i--) {
      const r = rams[i]; if (r.hp <= 0) { burst(r.x, 1, r.z, 20, "#a07a4a", 4); rams.splice(i, 1); continue; }
      if (r.z < FRONT - 1.4) { r.z += 3.6 * dt; r.roll += dt * 5; } else { r.cdT -= dt; if (r.cdT <= 0 && r.hits < 6) { r.cdT = 0.9; r.hits++; r.recoil = 0.3; hitGate(r.dmg, r.x, FRONT); } if (r.hits >= 6) { r.hp -= 9999 * dt; } }
      r.recoil = Math.max(0, (r.recoil || 0) - dt);
    }
    // جداسازی
    const all = [P, ...allies, ...foes.filter((f) => !f.wall && !f.dead)];
    for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) { const a = all[i], b = all[j], dx = b.x - a.x, dz = b.z - a.z, d2 = dx * dx + dz * dz; if (d2 < 0.64 && d2 > 1e-4) { const d = Math.sqrt(d2), p = (0.8 - d) * 0.5; if (a !== P) { a.x -= dx / d * p; a.z -= dz / d * p; } if (b !== P) { b.x += dx / d * p; b.z += dz / d * p; } } }
    // ذرات
    for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.life -= dt; if (p.life <= 0) { parts.splice(i, 1); continue; } if (!p.ring) { p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.vy -= 9 * dt; if (p.y < 0.05) { p.y = 0.05; p.vy *= -0.3; } } }
    for (let i = texts.length - 1; i >= 0; i--) { const t = texts[i]; t.life -= dt; t.y += dt * 1.2; if (t.life <= 0) texts.splice(i, 1); }
    // دوربین
    const tx = P.x - Math.sin(cam.yaw) * cam.dist, tz = P.z - Math.cos(cam.yaw) * cam.dist;
    cam.x = lerp(cam.x, tx, Math.min(1, dt * 8)); cam.z = lerp(cam.z, tz, Math.min(1, dt * 8)); cam.y = cam.h;
    P.vx = Math.sin(P.yaw) * (P.moving || 0); P.vz = Math.cos(P.yaw) * (P.moving || 0);
    if (!over && time > LIMIT) { finish(false); say("وقت تمام شد!", 2); }
    // HUD
    $("s3php").style.width = (P.hp / P.maxhp * 100) + "%"; $("s3pt").textContent = Math.ceil(P.hp);
    $("s3ghp").style.width = (G.hp / G.max * 100) + "%"; $("s3gt").textContent = "دروازه " + Math.ceil(G.hp);
    $("s3time").textContent = Math.max(0, Math.ceil(LIMIT - time)) + "s";
    const setCd = (id, v, m) => { const el = $(id); el.style.height = v > 0 ? (v / m * 100) + "%" : "0"; el.parentElement.classList.toggle("cd", v > 0); };
    setCd("s3c1", cd.spec, 9); setCd("s3c2", cd.rally, 24); setCd("s3c3", cd.ram, 28);
  }
  function finish(won, quit) {
    if (over) return; over = true; endWon = won; const f = P.hp / P.maxhp, stars = !won ? 0 : 1 + (f > 0.4 ? 1 : 0) + (time < 100 ? 1 : 0);
    setTimeout(() => { cleanup(); onEnd({ won, stars, kills, built: 0, skills: 0, evolves: 0, lives: 1, maxLives: 1, wave: 0, troopsSent: allies.length + lost, quit: !!quit }); }, quit ? 0 : 500);
  }
  function cleanup() { if (ended) return; ended = true; cancelAnimationFrame(raf); removeEventListener("keydown", onKD); removeEventListener("keyup", onKU); removeEventListener("resize", resize); root.remove(); document.body.classList.remove("inbattle"); delete window.__s3d; }
  window.__s3d = { back() { act(paused ? "resume" : "pause"); } };

  // ---------- رندر ----------
  const items = []; let cs, sn, cp, sp;
  function proj(x, y, z) { // -> [sx, sy, depth]
    const dx = x - cam.x, dy = y - cam.y, dz = z - cam.z, x1 = dx * cs - dz * sn, z1 = dx * sn + dz * cs, z2 = -dy * sp + z1 * cp, y2 = dy * cp + z1 * sp;
    return [x1, y2, z2];
  }
  const toScr = (v) => [W / 2 + v[0] / v[2] * F, H * 0.52 - v[1] / v[2] * F];
  function polyClip(vs) { // برش با صفحه‌ی نزدیک
    const out = [], N = 0.25; for (let i = 0; i < vs.length; i++) { const a = vs[i], b = vs[(i + 1) % vs.length], ain = a[2] > N, bin = b[2] > N; if (ain) out.push(a); if (ain !== bin) { const t = (N - a[2]) / (b[2] - a[2]); out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, N]); } } return out;
  }
  function drawPoly(vs, fill, stroke) {
    const c = polyClip(vs); if (c.length < 3) return; ctx.beginPath(); for (let i = 0; i < c.length; i++) { const s = toScr(c[i]); if (i) ctx.lineTo(s[0], s[1]); else ctx.moveTo(s[0], s[1]); } ctx.closePath(); ctx.fillStyle = fill; ctx.fill(); if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); }
  }
  const fogOf = (z) => clamp((z - 20) / 95, 0, 0.82);
  // جعبه‌ی چرخیده: مرکز محلی نسبت به محور، دوران حول X در محور، سپس yaw و انتقال
  function box(o, px, py, pz, ax, cx, cy, cz, sx, sy, sz, col, edge = true) {
    const hx = sx / 2, hy = sy / 2, hz = sz / 2, cA = Math.cos(ax), sA = Math.sin(ax), cy2 = Math.cos(o.yaw), sy2 = Math.sin(o.yaw), s = o.sc || 1;
    const V = []; for (let i = 0; i < 8; i++) { let lx = cx + ((i & 1) ? hx : -hx), ly = cy + ((i & 2) ? hy : -hy), lz = cz + ((i & 4) ? hz : -hz); const y1 = ly * cA - lz * sA, z1 = ly * sA + lz * cA; ly = y1; lz = z1; lx += px; ly += py; lz += pz; lx *= s; ly *= s; lz *= s; const wx = o.x + lx * cy2 + lz * sy2, wz = o.z - lx * sy2 + lz * cy2; V.push([wx, (o.y || 0) + ly, wz]); }
    const c = [(V[0][0] + V[7][0]) / 2, (V[0][1] + V[7][1]) / 2, (V[0][2] + V[7][2]) / 2], pc = proj(c[0], c[1], c[2]); if (pc[2] < -4 || pc[2] > 140) return;
    pushBox(V, col, pc[2], edge);
  }
  const FACES = [[0, 1, 3, 2], [4, 6, 7, 5], [0, 2, 6, 4], [1, 5, 7, 3], [0, 4, 5, 1], [2, 3, 7, 6]];
  function pushBox(V, col, depth, edge) {
    items.push({ z: depth, f() {
      const fg = fogOf(depth), cen = [0, 0, 0]; for (const v of V) { cen[0] += v[0] / 8; cen[1] += v[1] / 8; cen[2] += v[2] / 8; }
      for (const fc of FACES) {
        const a = V[fc[0]], b = V[fc[1]], c = V[fc[2]]; let ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2]; let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
        const fx = (a[0] + c[0]) / 2, fy = (a[1] + c[1]) / 2, fz = (a[2] + c[2]) / 2; if ((fx - cen[0]) * nx + (fy - cen[1]) * ny + (fz - cen[2]) * nz < 0) { nx = -nx; ny = -ny; nz = -nz; }
        if (nx * (cam.x - fx) + ny * (cam.y - fy) + nz * (cam.z - fz) <= 0) continue;
        const lt = 0.52 + 0.55 * Math.max(0, nx * LIGHT[0] + ny * LIGHT[1] + nz * LIGHT[2]);
        drawPoly(fc.map((i) => proj(V[i][0], V[i][1], V[i][2])), rgb(col, lt, fg, FOG), edge ? rgb(col, 0.42, fg, FOG) : null);
      }
    } });
  }
  function sphere(wx, wy, wz, r, col, lightK = 1) {
    const p = proj(wx, wy, wz); if (p[2] < 0.4) return; items.push({ z: p[2] - 0.01, f() { const s = toScr(p), R = r / p[2] * F, fg = fogOf(p[2]); const g = ctx.createRadialGradient(s[0] - R * 0.35, s[1] - R * 0.4, R * 0.1, s[0], s[1], R); g.addColorStop(0, rgb(col, 1.25 * lightK, fg, FOG)); g.addColorStop(1, rgb(col, 0.62 * lightK, fg, FOG)); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(s[0], s[1], R, 0, TAU); ctx.fill(); ctx.strokeStyle = rgb(col, 0.4, fg, FOG); ctx.lineWidth = 1; ctx.stroke(); } });
  }
  function shadow(x, z, r) { const p = proj(x, 0.02, z); if (p[2] < 0.5) return; const s = toScr(p), R = r / p[2] * F; ctx.fillStyle = "rgba(0,0,0,0.28)"; ctx.beginPath(); ctx.ellipse(s[0], s[1], R, R * 0.42, 0, 0, TAU); ctx.fill(); }

  // شخصیت چندوجهی کم‌چند
  function drawChar(o, st2) {
    // st2: {skin, hair, tunic, armor, legs, helm, shield, sword, cape, scale}
    const w = Math.sin(o.walk || 0) * (o.moving === 0 ? 0 : 1), mvK = o.walkAmp === undefined ? 1 : o.walkAmp, c = st2;
    const ly = (o.roll > 0) ? 0 : 0; void ly;
    const sk = hex(c.skin), tun = hex(c.tunic), leg = hex(c.legs || "#3a3f4a"), sw = o.sc || 1;
    const bob = Math.abs(Math.cos(o.walk || 0)) * 0.05 * mvK;
    const atk = o.atkP === undefined ? 0 : o.atkP; // 0..1 پیشرفت ضربه
    const leanX = o.roll > 0 ? 1.1 : 0; void sw;
    const root = { x: o.x, z: o.z, y: (o.y || 0) + bob, yaw: o.yaw, sc: o.sc };
    const body = hex(c.armor || c.tunic);
    // پاها
    box(root, 0.16, 0.78, 0, w * 0.7 * mvK, 0, -0.39, 0, 0.24, 0.78, 0.26, leg);
    box(root, -0.16, 0.78, 0, -w * 0.7 * mvK, 0, -0.39, 0, 0.24, 0.78, 0.26, leg);
    // شنل
    if (c.cape) { const sway = 0.25 + Math.abs(w) * 0.35 + (o.moving ? 0.2 : 0); box(root, 0, 1.5, -0.2, sway, 0, -0.5, -0.06, 0.62, 1.0, 0.07, hex(c.cape)); }
    // تنه
    box(root, 0, 0, 0, leanX, 0, 1.15, 0, 0.64, 0.74, 0.36, body);
    box(root, 0, 0, 0, leanX, 0, 0.82, 0, 0.68, 0.12, 0.4, hex(c.belt || "#5a3a1a"));
    if (c.pauldron) { box(root, 0.42, 1.5, 0, 0, 0, 0, 0, 0.26, 0.2, 0.3, hex(c.pauldron)); box(root, -0.42, 1.5, 0, 0, 0, 0, 0, 0.26, 0.2, 0.3, hex(c.pauldron)); }
    // بازوی چپ (سپر)
    const la = c.shield ? -0.7 : -w * 0.6 * mvK;
    box(root, -0.42, 1.45, 0, la, 0, -0.3, 0, 0.17, 0.62, 0.17, sk);
    if (c.shield) { const sd = c.shield; box(root, -0.42, 1.45, 0, la, -0.16, -0.38, 0.22, 0.09, 0.78, 0.62, hex(sd.color), true); box(root, -0.42, 1.45, 0, la, -0.2, -0.38, 0.22, 0.05, 0.5, 0.4, hex(sd.rim)); if (sd.emblem) box(root, -0.42, 1.45, 0, la, -0.24, -0.38, 0.22, 0.04, 0.2, 0.2, hex("#c43a3a")); }
    // بازوی راست و سلاح
    let ra = -0.9 + w * 0.2 * mvK; if (o.swing) { const t = clamp(atk, 0, 1), k = o.combo || 0; const up = k === 1 ? -2.0 : -2.7, dn = k === 1 ? -0.2 : 0.1; ra = t < 0.35 ? lerp(-0.9, up, t / 0.35) : lerp(up, dn, clamp((t - 0.35) / 0.3, 0, 1)); }
    box(root, 0.42, 1.45, 0, ra, 0, -0.3, 0, 0.17, 0.62, 0.17, sk);
    const wp = c.sword; if (wp) {
      const L = 1.15 * wp.len, bl = hex(wp.blade), hl = hex(wp.hilt);
      box(root, 0.42, 1.45, 0, ra, 0, -0.62, 0.12, 0.1, 0.1, 0.24, hl);
      box(root, 0.42, 1.45, 0, ra, 0, -0.62, 0.27, 0.34, 0.07, 0.07, hl);
      box(root, 0.42, 1.45, 0, ra, 0, -0.62, 0.3 + L / 2, 0.08, 0.04, L, bl, false);
      if (wp.twin) box(root, 0.42, 1.45, 0, ra, 0, -0.62, 0.3 + L * 0.8, 0.2, 0.04, 0.32, bl, false);
      if (wp.glow && o.swing) { items.push({ z: proj(o.x, 1.4, o.z)[2] - 0.5, f() {} }); }
    }
    // سر
    const hp = (function () { const cy2 = Math.cos(o.yaw), sy2 = Math.sin(o.yaw), s = o.sc || 1; const lx = 0, ly = 1.85 * s + (o.y || 0) + bob, lz = 0.0; return [o.x + lx * cy2 + lz * sy2, ly, o.z - lx * sy2 + lz * cy2]; })();
    box(root, 0, 1.5, 0, leanX * 0.5, 0, 0.08, 0, 0.14, 0.14, 0.14, sk);
    sphere(hp[0], hp[1], hp[2], 0.26 * (o.sc || 1), sk);
    // چهره: دو چشم و ابرو وقتی رو به دوربین است
    const fx = Math.sin(o.yaw), fz = Math.cos(o.yaw), vis = fx * (cam.x - hp[0]) + fz * (cam.z - hp[2]);
    const hairC = hex(c.hair || "#3a2a1a");
    if (c.helm && c.helm.kind === "helm" || c.helm && c.helm.kind === "crest") { sphere(hp[0] - 0.0, hp[1] + 0.05 * (o.sc || 1), hp[2], 0.3 * (o.sc || 1), hex(c.helm.color), 1); }
    else if (c.helm && c.helm.kind === "cap") { sphere(hp[0], hp[1] + 0.1 * (o.sc || 1), hp[2] - fz * 0.02, 0.27 * (o.sc || 1), hex(c.helm.color), 1); }
    else if (!c.noHair) sphere(hp[0] - fx * 0.05, hp[1] + 0.07 * (o.sc || 1), hp[2] - fz * 0.05, 0.26 * (o.sc || 1), hairC);
    if (c.helm && c.helm.kind === "crest") box(root, 0, 1.85, 0, 0, 0, 0.35, -0.04, 0.09, 0.28, 0.4, hex(c.helm.plume), false);
    if (c.helm && c.helm.kind === "crown") for (let i = -1; i <= 1; i++) box(root, i * 0.14, 1.85, 0, 0, 0, 0.3, 0, 0.07, 0.2 + (i === 0 ? 0.08 : 0), 0.07, hex(c.helm.color), false);
    if (c.horns) { box(root, 0.22, 1.85, 0, 0, 0, 0.28, 0, 0.07, 0.3, 0.07, hex("#e8e0c8"), false); box(root, -0.22, 1.85, 0, 0, 0, 0.28, 0, 0.07, 0.3, 0.07, hex("#e8e0c8"), false); }
    if (vis > 0) items.push({ z: proj(hp[0], hp[1], hp[2])[2] - 0.2, f() {
      const p = proj(hp[0] + fz * 0.0, hp[1], hp[2]); if (p[2] < 0.4) return; const R = 0.26 * (o.sc || 1) / p[2] * F, s = toScr(p), k = Math.min(1, vis / 2.5 + 0.5);
      const ex = R * 0.42, ey = R * 0.05; ctx.save(); ctx.translate(s[0], s[1] + R * 0.05); ctx.scale(Math.cos(Math.atan2(fx, fz) - Math.atan2(cam.x - hp[0], cam.z - hp[2])) > 0 ? 1 : 1, 1);
      ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.ellipse(-ex, ey, R * 0.2, R * 0.16, 0, 0, TAU); ctx.ellipse(ex, ey, R * 0.2, R * 0.16, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = c.eye || "#1a1a22"; ctx.beginPath(); ctx.arc(-ex, ey, R * 0.1, 0, TAU); ctx.arc(ex, ey, R * 0.1, 0, TAU); ctx.fill();
      ctx.strokeStyle = c.brow || "#2a1a10"; ctx.lineWidth = Math.max(1, R * 0.08); ctx.beginPath(); ctx.moveTo(-ex - R * 0.2, ey - R * 0.25 + (c.angry ? -R * 0.05 : 0)); ctx.lineTo(-ex + R * 0.2, ey - R * 0.25 + (c.angry ? R * 0.1 : 0)); ctx.moveTo(ex + R * 0.2, ey - R * 0.25 + (c.angry ? -R * 0.05 : 0)); ctx.lineTo(ex - R * 0.2, ey - R * 0.25 + (c.angry ? R * 0.1 : 0)); ctx.stroke();
      ctx.strokeStyle = "rgba(90,40,30,0.8)"; ctx.lineWidth = Math.max(1, R * 0.06); ctx.beginPath(); ctx.arc(0, R * 0.38, R * 0.18, c.angry ? Math.PI * 1.15 : 0.15 * Math.PI, c.angry ? Math.PI * 1.85 : 0.85 * Math.PI); ctx.stroke(); ctx.restore(); void k; } });
  }
  const playerStyle = () => ({ skin: AV.skin, hair: AV.hair, tunic: AV.tunic, armor: AR.color, helm: HM, shield: SH.id === "d0" ? null : SH, sword: SW, cape: CP.color || null, pauldron: AR.id === "a0" ? null : AR.color, belt: "#5a3a1a" });
  const ALLY_ST = { sword: { tunic: "#4a78c8", armor: "#6a88c0", hair: "#2a1a10", skin: "#e8c498", helm: { kind: "cap", color: "#7a8ab0" }, sword: { blade: "#d0d8e4", hilt: "#8a6a3a", len: 0.9 } }, shield: { tunic: "#3a5a9a", armor: "#8aa0c4", skin: "#d8b084", hair: "#1a1a1a", helm: { kind: "helm", color: "#9aa8c0" }, shield: { color: "#9fc0ff", rim: "#5a70a0" }, sword: { blade: "#c0c8d4", hilt: "#6a5030", len: 0.7 } }, archer: { tunic: "#3a8a5a", armor: "#4a9a68", skin: "#e0b88c", hair: "#5a3a1a", helm: { kind: "cap", color: "#6a4a2a" }, sword: { blade: "#7a5a2a", hilt: "#4a3a1a", len: 0.8 } }, horse: { tunic: "#c8803a", armor: "#d89a4a", skin: "#c89a70", hair: "#2a1a10", helm: { kind: "crest", color: "#c8d0e0", plume: "#ffb347" }, sword: { blade: "#e0e4ec", hilt: "#b08a3a", len: 1.0 } } };
  const FOE_ST = { guard: { tunic: "#8a2a2a", armor: "#a04040", skin: "#d8b084", hair: "#2a1a10", helm: { kind: "helm", color: "#6a6a74" }, sword: { blade: "#b8bcc4", hilt: "#5a3a2a", len: 0.9 }, angry: 1, brow: "#1a1010" }, heavy: { tunic: "#5a2a2a", armor: "#6a6a78", skin: "#c89a70", helm: { kind: "helm", color: "#4a4a58" }, shield: { color: "#7a3a3a", rim: "#3a2a2a" }, sword: { blade: "#9aa0aa", hilt: "#4a3a2a", len: 0.9 }, pauldron: "#4a4a58", angry: 1, brow: "#1a1010" }, captain: { tunic: "#3a1a4a", armor: "#5a2a6a", skin: "#b88a66", helm: { kind: "crest", color: "#8a7a9a", plume: "#ff4a4a" }, shield: { color: "#8a3a8a", rim: "#d8a83a", emblem: 1 }, sword: { blade: "#ffb0a0", hilt: "#d8a83a", len: 1.3, glow: "#ff6a4a" }, pauldron: "#d8a83a", horns: 1, angry: 1, eye: "#ff3a3a", brow: "#000" }, warcher: { tunic: "#8a3a3a", armor: "#8a4a4a", skin: "#d8b084", helm: { kind: "cap", color: "#5a4a3a" }, angry: 1 } };

  function drawCastle() {
    const wc = WALL, hw = LIMX + 6, seg = 6, segW = (hw * 2) / seg;
    const base = { x: 0, z: 0, yaw: 0, y: 0, sc: 1 };
    const gx = GATEW / 2;
    // دیوار: بخش‌های چپ و راست دروازه + لنگه بالای دروازه
    const wallSeg = (x0, x1) => { const n = Math.max(1, Math.ceil((x1 - x0) / 5)); for (let i = 0; i < n; i++) { const a = x0 + (x1 - x0) * i / n, b = x0 + (x1 - x0) * (i + 1) / n; box(base, 0, 0, 0, 0, (a + b) / 2, WALLH / 2, ZG, b - a, WALLH, 3.2, wc); } };
    wallSeg(-hw, -gx); wallSeg(gx, hw); box(base, 0, 0, 0, 0, 0, (GATEH + WALLH) / 2, ZG, GATEW, WALLH - GATEH, 3.2, wc);
    // پیش‌بام و دندانه‌ها
    for (let x = -hw + 1; x < hw; x += 2.2) box(base, 0, 0, 0, 0, x, WALLH + 0.55, ZG - 1.2, 1.2, 1.1, 0.7, wc);
    box(base, 0, 0, 0, 0, 0, WALLH + 0.1, ZG - 0.4, hw * 2, 0.3, 2.6, rgbMul(wc, 0.9));
    // برج‌ها
    for (const sx of [-1, 1]) {
      const tx = sx * (LIMX + 3); box(base, 0, 0, 0, 0, tx, 6.5, ZG, 7, 13, 7, rgbMul(wc, 1.05));
      for (let i = 0; i < 4; i++) { const ax = tx + (i & 1 ? 2.8 : -2.8), az = ZG + (i & 2 ? 2.8 : -2.8); box(base, 0, 0, 0, 0, ax, 13.6, az, 1.3, 1.3, 1.3, wc); }
      box(base, 0, 0, 0, 0, tx, 15.8, ZG, 5, 3.4, 5, ROOF); box(base, 0, 0, 0, 0, tx, 18.4, ZG, 2.6, 2, 2.6, ROOF); box(base, 0, 0, 0, 0, tx, 20.3, ZG, 0.15, 2.6, 0.15, [90, 70, 50], false);
      box(base, 0, 0, 0, 0, tx + sx * -0.4, 20.8, ZG, 1.8, 1.0, 0.06, [220, 60, 60], false);
      for (let i = 0; i < 3; i++) box(base, 0, 0, 0, 0, tx, 4 + i * 3.4, ZG - 3.52, 0.6, 1.2, 0.1, [40, 34, 34], false);
      box(base, 0, 0, 0, 0, sx * (LIMX - 3.5), 1.4, ZG - 1.7, 2, 2.8, 0.3, [50, 36, 28]); // درگاه نگهبانان
    }
    // قصر پشت دیوار
    box(base, 0, 0, 0, 0, 0, 9, ZG + 9, 16, 18, 10, rgbMul(wc, 0.95)); box(base, 0, 0, 0, 0, 0, 20.5, ZG + 9, 12, 5, 8, ROOF); box(base, 0, 0, 0, 0, 0, 24.5, ZG + 9, 5, 4, 5, ROOF); box(base, 0, 0, 0, 0, 0, 27.6, ZG + 9, 0.2, 3, 0.2, [90, 70, 50], false);
    // دروازه
    if (G.hp > 0 || G.fall > 0) {
      const fall = clamp(G.fall / 1.2, 0, 1), sh = G.shake > 0 ? Math.sin(time * 90) * 0.06 : 0, gt = fall * 1.35;
      const g = { x: sh, z: ZG - 1.6 - fall * 0.2, yaw: 0, y: 0, sc: 1 };
      box(g, 0, GATEH / 2, 0, -gt, 0, 0, 0, GATEW - 0.2, GATEH - 0.2, 0.42, [110, 74, 44]);
      for (let i = -2; i <= 2; i++) box(g, 0, GATEH / 2, 0, -gt, i * 1.0, 0, -0.24, 0.1, GATEH - 0.4, 0.1, [80, 52, 30], false);
      for (const yy of [-1.8, 0, 1.8]) box(g, 0, GATEH / 2, 0, -gt, 0, yy, -0.28, GATEW - 0.3, 0.3, 0.1, [58, 60, 66]);
      box(g, 0, GATEH / 2, 0, -gt, 0, 0, -0.34, 0.5, 0.5, 0.1, [196, 160, 70]);
      const dmgF = 1 - G.hp / G.max; for (let i = 0; i < Math.floor(dmgF * 7); i++) box(g, 0, GATEH / 2, 0, -gt, Math.sin(i * 2.3) * 1.8, Math.cos(i * 1.7) * 1.9, -0.31 - i * 0.003, 0.07, 0.9 + (i % 3) * 0.4, 0.05, [30, 20, 14], false);
    } else box(base, 0, 0, 0, 0, 0, 0.1, ZG - 1, GATEW, 0.2, 3, [60, 40, 30]);
  }
  const rgbMul = (c, k) => [c[0] * k, c[1] * k, c[2] * k];

  function drawBG() {
    const sky = ctx.createLinearGradient(0, 0, 0, H * 0.55); sky.addColorStop(0, th.sky[0]); sky.addColorStop(1, th.sky[1]); ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
    const hz = H * 0.52 - (-cam.h * cp + 0) * 0 ; // خط افق تقریبی
    const hy = H * 0.52 - Math.tan(0) * F; void hy;
    const sunx = ((-cam.yaw * 220 + 300) % (W + 400) + W + 400) % (W + 400) - 100; ctx.fillStyle = "rgba(255,248,220,0.85)"; ctx.beginPath(); ctx.arc(sunx, H * 0.17, 28, 0, TAU); ctx.fill();
    // کوه‌های دور
    const off = -cam.yaw * 420; ctx.fillStyle = th.mount; ctx.globalAlpha = 0.55; ctx.beginPath(); const base = H * 0.5 + sp * F * 0.15 + 8; ctx.moveTo(0, H); ctx.lineTo(0, base); for (let x = 0; x <= W + 40; x += 40) { const u = (x - off) / 160; ctx.lineTo(x, base - 34 - (Math.sin(u) * 26 + Math.sin(u * 2.3 + 1) * 16 + 20)); } ctx.lineTo(W, H); ctx.fill(); ctx.globalAlpha = 1;
    // ابرها
    ctx.fillStyle = "rgba(255,255,255,0.5)"; for (let i = 0; i < 5; i++) { const cx = ((i * 260 - cam.yaw * 300 + time * 6) % (W + 260) + W + 260) % (W + 260) - 130, cy = H * (0.1 + (i % 3) * 0.07); ctx.beginPath(); ctx.ellipse(cx, cy, 60, 14, 0, 0, TAU); ctx.ellipse(cx + 30, cy - 8, 40, 12, 0, 0, TAU); ctx.fill(); }
    // زمین: کاشی‌های رنگی
    const g = ctx.createLinearGradient(0, H * 0.45, 0, H); g.addColorStop(0, rgb(hex(th.ground[0]), 1, 0.7, FOG)); g.addColorStop(1, th.ground[0]); ctx.fillStyle = g; ctx.fillRect(0, H * 0.46, W, H);
    const T = 4, c0 = hex(th.ground[0]), c1 = hex(th.ground[1]), r0 = Math.floor((cam.x - 60) / T), r1 = Math.floor((cam.x + 60) / T), zz0 = Math.floor((cam.z - 8) / T), zz1 = Math.min(Math.floor((ZG + 24) / T), zz0 + 24);
    for (let iz = zz1; iz >= zz0; iz--) for (let ix = r0; ix <= r1; ix++) { const x = ix * T, z = iz * T; const dist = Math.hypot(x - cam.x, z - cam.z); if (dist > 64) continue; const road = Math.abs(x + T / 2) < 3.2 && z < ZG; const col = road ? [150, 124, 90] : ((ix + iz) & 1 ? c0 : c1); drawPoly([proj(x, 0, z), proj(x + T, 0, z), proj(x + T, 0, z + T), proj(x, 0, z + T)], rgb(col, road ? 1 + ((ix + iz) & 1) * 0.06 : 1, fogOf(dist), FOG), null); }
  }

  function render() {
    cs = Math.cos(cam.yaw); sn = Math.sin(cam.yaw); cp = Math.cos(cam.pitch); sp = Math.sin(cam.pitch);
    const shx = cam.shake > 0 ? (Math.random() - 0.5) * cam.shake * 14 : 0, shy = cam.shake > 0 ? (Math.random() - 0.5) * cam.shake * 14 : 0;
    ctx.setTransform(DPR, 0, 0, DPR, shx * DPR, shy * DPR); items.length = 0;
    cam.y = cam.h; cam.pitch = 0.34;
    drawBG();
    // سایه‌ها
    shadow(P.x, P.z, 0.7); for (const a of allies) shadow(a.x, a.z, 0.6); for (const f of foes) if (!f.wall && !f.dead) shadow(f.x, f.z, 0.65 * (f.sc || 1)); for (const r of rams) shadow(r.x, r.z, 1.4);
    drawCastle();
    // بازیکن
    { const swing = P.atkT > 0, p = swing ? 1 - P.atkT / 0.46 : 0; const o = { x: P.x, z: P.z, yaw: P.yaw, walk: P.walk, moving: P.moving, swing, atkP: p, combo: P.combo, roll: P.roll, sc: 1, walkAmp: Math.min(1, (P.moving || 0) / 5), y: P.dead ? -0.3 : 0 }; if (!(P.inv > 0 && Math.floor(time * 20) % 2 && P.roll <= 0)) drawChar(o, playerStyle()); if (swing && SW.glow) { const a = P.yaw + (p - 0.5) * 1.6; burstTrail(P.x + Math.sin(a) * 1.7, 1.4, P.z + Math.cos(a) * 1.7, SW.glow); } }
    for (const a of allies) { const o = { x: a.x, z: a.z, yaw: a.yaw, walk: a.walk, moving: 1, swing: a.atkA > 0, atkP: a.atkA > 0 ? 1 - a.atkA / 0.35 : 0, combo: 0, sc: 0.94, walkAmp: 0.8 }; drawChar(o, Object.assign({}, ALLY_ST[a.kind], { cape: null })); if (a.hurt > 0) flashRing(a.x, a.z, "#ff6a6a"); }
    for (const f of foes) {
      if (f.dead && f.deadT < 0) continue; const k = FOE_ST[f.kind]; const dead = f.dead; const o = { x: f.x, z: f.z, y: f.y !== undefined ? f.y : (f.wall ? WALLH : 0), yaw: f.yaw, walk: f.walk, moving: f.wall ? 0 : 1, swing: f.atkA > 0, atkP: f.atkA > 0 ? 1 - f.atkA / 0.4 : 0, combo: 0, sc: f.sc || 1, walkAmp: 0.8 };
      if (dead) { o.y = (o.y || 0) - (0.7 - f.deadT) * 1.4; o.sc = (o.sc || 1) * Math.max(0.1, f.deadT / 0.7); } if (f.wall) { o.sc = 0.95; }
      drawChar(o, k); if (f.hurt > 0 && !dead) flashRing(f.x, f.z, "#fff");
      if (!dead && !f.wall && f.hp < f.maxhp || f.kind === "captain") hpBar(f);
    }
    // دروازه‌شکن‌ها
    for (const r of rams) { const o = { x: r.x, z: r.z, yaw: 0, y: 0, sc: 1 }, rc = r.recoil || 0, zz = -rc * 3; box(o, 0, 0, 0, 0, -1.2, 0.9, 0, 0.2, 1.8, 3.6, [90, 60, 36]); box(o, 0, 0, 0, 0, 1.2, 0.9, 0, 0.2, 1.8, 3.6, [90, 60, 36]); box(o, 0, 0, zz, 0, 0, 1.4, 0.4, 0.8, 0.8, 4.4, [130, 90, 54]); box(o, 0, 0, zz, 0, 0, 1.4, 2.8, 1.0, 1.0, 0.8, [70, 72, 80]); for (const sx of [-1.2, 1.2]) for (const sz of [-1.2, 1.2]) box(o, 0, 0, 0, 0, sx, 0.4, sz, 0.2, 0.8, 0.8, [50, 34, 22]); box(o, 0, 0, 0, 0, 0, 2.2, 0, 3, 0.2, 4.4, [150, 60, 44]); }
    // پرتاب‌ها و ذرات
    for (const a of arrows) { if (a.ad !== undefined || a.dmg >= 0) { const t = a.t / a.T, x = lerp(a.x, a.tx, t), z = lerp(a.z, a.tz, t), y = lerp(a.y, 0.4, t) + Math.sin(t * Math.PI) * 2.2, dx = a.tx - a.x, dz = a.tz - a.z, l = Math.hypot(dx, dz) || 1; const p1 = proj(x, y, z), p2 = proj(x - dx / l * 0.9, y + 0.15, z - dz / l * 0.9); if (p1[2] > 0.5 && p2[2] > 0.5) items.push({ z: p1[2], f() { const s1 = toScr(p1), s2 = toScr(p2); ctx.strokeStyle = "#5a3a1a"; ctx.lineWidth = Math.max(1.5, 0.06 / p1[2] * F); ctx.beginPath(); ctx.moveTo(s1[0], s1[1]); ctx.lineTo(s2[0], s2[1]); ctx.stroke(); ctx.fillStyle = "#e8e8f0"; ctx.beginPath(); ctx.arc(s1[0], s1[1], Math.max(1.5, 0.08 / p1[2] * F), 0, TAU); ctx.fill(); } }); if (!a.ally && a.tg) markDanger(a); } }
    for (const p of parts) { const q = proj(p.x, p.y, p.z); if (q[2] < 0.5) continue; if (p.ring) { items.push({ z: q[2] + 50, f() { const k = 1 - p.life / p.max, R = p.r * (0.3 + k * 0.7); ctx.strokeStyle = p.c; ctx.globalAlpha = p.life / p.max; ctx.lineWidth = 3; ctx.beginPath(); for (let i = 0; i <= 24; i++) { const a = i / 24 * TAU, s = toScr(proj(p.x + Math.cos(a) * R, 0.1, p.z + Math.sin(a) * R)); if (i) ctx.lineTo(s[0], s[1]); else ctx.moveTo(s[0], s[1]); } ctx.stroke(); ctx.globalAlpha = 1; } }); } else items.push({ z: q[2], f() { const s = toScr(q), R = Math.max(1.2, p.s / q[2] * F); ctx.globalAlpha = clamp(p.life / p.max * 1.4, 0, 1); ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(s[0], s[1], R, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; } }); }
    items.sort((a, b) => b.z - a.z); for (const it of items) it.f();
    // متن‌های شناور
    ctx.textAlign = "center"; ctx.font = "800 16px Vazirmatn, sans-serif"; for (const t of texts) { const q = proj(t.x, t.y, t.z); if (q[2] < 0.5) continue; const s = toScr(q); ctx.globalAlpha = clamp(t.life * 2, 0, 1); ctx.lineWidth = 3; ctx.strokeStyle = "rgba(0,0,0,.7)"; ctx.fillStyle = t.c; ctx.strokeText(t.t, s[0], s[1]); ctx.fillText(t.t, s[0], s[1]); ctx.globalAlpha = 1; }
    // یاد‌دهی پرچم قرمز لبه هنگام آسیب
    if (P.hurt > 0) { ctx.fillStyle = `rgba(255,40,40,${P.hurt * 0.8})`; ctx.fillRect(0, 0, W, H); }
    const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.45, W / 2, H / 2, H * 0.95); vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, "rgba(0,0,0,0.35)"); ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
  }
  function burstTrail(x, y, z, c) { const q = proj(x, y, z); if (q[2] < 0.5) return; items.push({ z: q[2] - 0.3, f() { const s = toScr(q), R = 0.5 / q[2] * F; const g = ctx.createRadialGradient(s[0], s[1], 0, s[0], s[1], R); g.addColorStop(0, c); g.addColorStop(1, "rgba(0,0,0,0)"); ctx.globalCompositeOperation = "lighter"; ctx.fillStyle = g; ctx.fillRect(s[0] - R, s[1] - R, R * 2, R * 2); ctx.globalCompositeOperation = "source-over"; } }); }
  function flashRing(x, z, c) { const q = proj(x, 1.2, z); if (q[2] < 0.5) return; items.push({ z: q[2] - 0.5, f() { const s = toScr(q), R = 0.55 / q[2] * F; ctx.globalAlpha = 0.45; ctx.fillStyle = c; ctx.beginPath(); ctx.arc(s[0], s[1], R, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; } }); }
  function markDanger(a) { const q = proj(a.tx, 0.05, a.tz); if (q[2] < 0.5 || a.tg !== P) return; items.push({ z: q[2] + 40, f() { const s = toScr(q), R = 1.0 / q[2] * F; ctx.strokeStyle = "rgba(255,70,70,0.75)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(s[0], s[1], R, R * 0.42, 0, 0, TAU); ctx.stroke(); } }); }
  function hpBar(f) { const q = proj(f.x, (f.y || 0) + 2.7 * (f.sc || 1), f.z); if (q[2] < 0.5) return; items.push({ z: q[2] - 0.6, f() { const s = toScr(q), w = 46 * (f.sc || 1), h = 5; ctx.fillStyle = "rgba(0,0,0,.6)"; ctx.fillRect(s[0] - w / 2 - 1, s[1] - 1, w + 2, h + 2); ctx.fillStyle = f.kind === "captain" ? "#ff5a5a" : "#e6c04a"; ctx.fillRect(s[0] - w / 2, s[1], w * clamp(f.hp / f.maxhp, 0, 1), h); } }); }

  function loop(now) {
    raf = requestAnimationFrame(loop); let dt = Math.min(0.05, (now - last) / 1000); last = now; if (paused) return;
    if (hitStop > 0) { hitStop -= dt; dt *= 0.15; }
    if (!over || G.fall > 0) update(dt); else update(dt * 0.3); render();
  }
  Sound.playMusic("attack", { intensity: 0.8 });
  say(`به ${nb.name} حمله کن! دروازه را بشکن ⚔️`, 3.2);
  raf = requestAnimationFrame(loop);
}

// پیش‌نمایش شخصیت برای فروشگاه (چرخان)
export function avatarPreview(canvas, av, getAv) {
  const ctx = canvas.getContext("2d"); let t = 0, raf = 0, alive = true;
  const fake = { skin: "#000" }; void fake;
  function frame() {
    if (!alive || !canvas.isConnected) { return; } raf = requestAnimationFrame(frame); t += 0.016; const a = getAv ? getAv() : av, W = canvas.width, H = canvas.height; ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, W, H);
    const g = ctx.createRadialGradient(W / 2, H * 0.6, 10, W / 2, H * 0.6, H * 0.7); g.addColorStop(0, "#4a3a66"); g.addColorStop(1, "#1a1428"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    mini(ctx, W, H, a, t);
  }
  frame(); return () => { alive = false; cancelAnimationFrame(raf); };
}
// رندر کوچک مستقل برای پیش‌نمایش (دو‌بعدی شبه‌سه‌بعدی با اجزای هندسی)
function mini(ctx, W, H, av, t) {
  const SW = find("sword", av.sword), SH = find("shield", av.shield), HM = find("helm", av.helm), AR = find("armor", av.armor), CP = find("cape", av.cape);
  const u = H / 3.0, cx = W / 2, gy = H * 0.93, ry = Math.sin(t * 1.2), rot = t * 0.8, cr = Math.cos(rot), sr = Math.sin(rot);
  ctx.fillStyle = "rgba(0,0,0,.35)"; ctx.beginPath(); ctx.ellipse(cx, gy, u * 0.9, u * 0.25, 0, 0, TAU); ctx.fill();
  const X = (x, z) => cx + (x * cr + z * sr) * u, Zd = (x, z) => -x * sr + z * cr;
  const P2 = (x, y, z) => [X(x, z), gy - y * u + Zd(x, z) * u * 0.08];
  const items = [];
  const bx = (x, y, z, w, h, d, col, fn) => items.push({ d: Zd(x, z), f() { const [px, py] = P2(x, y, z), k = 0.78 + 0.22 * (Zd(x, z) < 0 ? 1 : 0.8); ctx.fillStyle = rgb(hex(col), k); const W2 = (Math.abs(w * cr) + Math.abs(d * sr)) * u; ctx.beginPath(); roundRect(ctx, px - W2 / 2, py - h * u / 2, W2, h * u, Math.min(6, W2 / 3)); ctx.fill(); ctx.strokeStyle = rgb(hex(col), 0.45); ctx.lineWidth = 1; ctx.stroke(); if (fn) fn(px, py, W2); } });
  const cp = CP.color;
  if (cp) bx(0, 1.0, -0.22, 0.66, 1.05, 0.08, cp);
  bx(0.16, 0.38, 0, 0.24, 0.76, 0.26, "#3a3f4a"); bx(-0.16, 0.38, 0, 0.24, 0.76, 0.26, "#3a3f4a");
  bx(0, 1.15, 0, 0.66, 0.76, 0.36, AR.color || av.tunic); bx(0, 0.84, 0, 0.7, 0.12, 0.4, "#5a3a1a");
  if (AR.id !== "a0") { bx(0.43, 1.52, 0, 0.26, 0.2, 0.3, AR.color); bx(-0.43, 1.52, 0, 0.26, 0.2, 0.3, AR.color); }
  bx(-0.42, 1.12, 0, 0.17, 0.62, 0.17, av.skin); if (SH.id !== "d0") bx(-0.55, 1.1, 0.25, 0.1, 0.8, 0.6, SH.color, (px, py, w) => { if (SH.emblem) { ctx.fillStyle = "#c43a3a"; ctx.beginPath(); ctx.arc(px, py, w * 0.18, 0, TAU); ctx.fill(); } });
  bx(0.42, 1.12, 0.2, 0.17, 0.62, 0.17, av.skin);
  const sw = (px, py) => { const L = 1.2 * SW.len * u; ctx.save(); ctx.translate(px, py); ctx.rotate(-0.12 + ry * 0.05); if (SW.glow) { const g = ctx.createRadialGradient(0, -L / 2, 0, 0, -L / 2, L * 0.7); g.addColorStop(0, SW.glow + "aa"); g.addColorStop(1, "rgba(0,0,0,0)"); ctx.fillStyle = g; ctx.fillRect(-L, -L * 1.3, L * 2, L * 1.6); } ctx.fillStyle = SW.blade; ctx.beginPath(); ctx.moveTo(-u * 0.05, 0); ctx.lineTo(-u * 0.05, -L); ctx.lineTo(0, -L - u * 0.12); ctx.lineTo(u * 0.05, -L); ctx.lineTo(u * 0.05, 0); ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.3)"; ctx.stroke(); ctx.fillStyle = SW.hilt; ctx.fillRect(-u * 0.17, -u * 0.04, u * 0.34, u * 0.08); ctx.fillRect(-u * 0.04, 0, u * 0.08, u * 0.22); if (SW.twin) { ctx.fillStyle = SW.blade; ctx.fillRect(-u * 0.16, -L * 0.8, u * 0.32, u * 0.07); } ctx.restore(); };
  items.push({ d: Zd(0.5, 0.45) - 1, f() { const [px, py] = P2(0.42, 0.88, 0.45); sw(px, py); } });
  bx(0, 1.62, 0, 0.14, 0.14, 0.14, av.skin);
  items.push({ d: Zd(0, 0) - 0.5, f() { const [px, py] = P2(0, 1.86, 0), R = 0.27 * u; const g = ctx.createRadialGradient(px - R * 0.35, py - R * 0.4, R * 0.1, px, py, R); g.addColorStop(0, rgb(hex(av.skin), 1.2)); g.addColorStop(1, rgb(hex(av.skin), 0.7)); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, R, 0, TAU); ctx.fill(); ctx.strokeStyle = rgb(hex(av.skin), 0.4); ctx.stroke();
    const face = cr > 0.1 ? 1 : 0; const cover = (col, r, dy) => { const gg = ctx.createRadialGradient(px - R * 0.3, py + dy - R * 0.4, R * 0.1, px, py + dy, r); gg.addColorStop(0, rgb(hex(col), 1.2)); gg.addColorStop(1, rgb(hex(col), 0.65)); ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(px, py + dy, r, Math.PI, 0); ctx.lineTo(px + r, py + dy + r * 0.1); ctx.lineTo(px - r, py + dy + r * 0.1); ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.3)"; ctx.stroke(); };
    if (face) { const ex = R * 0.42; ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.ellipse(px - ex, py + R * 0.08, R * 0.2, R * 0.16, 0, 0, TAU); ctx.ellipse(px + ex, py + R * 0.08, R * 0.2, R * 0.16, 0, 0, TAU); ctx.fill(); ctx.fillStyle = "#1a1a22"; ctx.beginPath(); ctx.arc(px - ex, py + R * 0.08, R * 0.1, 0, TAU); ctx.arc(px + ex, py + R * 0.08, R * 0.1, 0, TAU); ctx.fill(); ctx.strokeStyle = "rgba(90,40,30,.8)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(px, py + R * 0.3, R * 0.2, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke(); }
    if (HM.kind === "helm" || HM.kind === "crest") cover(HM.color, R * 1.08, -R * 0.02); else if (HM.kind === "cap") cover(HM.color, R * 1.02, -R * 0.12); else cover(av.hair, R * 1.02, -R * 0.1);
    if (HM.kind === "crest") { ctx.fillStyle = HM.plume; ctx.beginPath(); ctx.moveTo(px - R * 0.1, py - R); ctx.quadraticCurveTo(px + R * 0.1, py - R * 2, px + R * 0.7, py - R * 1.2); ctx.lineTo(px + R * 0.1, py - R * 0.9); ctx.fill(); }
    if (HM.kind === "crown") { ctx.fillStyle = HM.color; ctx.beginPath(); ctx.moveTo(px - R * 0.8, py - R * 0.7); for (let i = 0; i < 5; i++) { ctx.lineTo(px - R * 0.8 + i * R * 0.4 + R * 0.2, py - R * (i % 2 ? 1.25 : 1.6)); ctx.lineTo(px - R * 0.8 + (i + 1) * R * 0.4, py - R * 0.7); } ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.3)"; ctx.stroke(); } } });
  items.sort((a, b) => b.d - a.d); for (const i of items) i.f();
}
function roundRect(ctx, x, y, w, h, r) { ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
