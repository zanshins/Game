// حالت سه‌بعدی (آزمایشی): محاصره‌ی قلعه از پشت شخصیت — موتور سبک با تصویرسازی پرسپکتیو روی canvas
import { S, heroInit, heroXp, heroNeed, heroBuy, HERO_UP, HERO_MAXUP } from "./save.js";
import * as C3 from "./char3d.js";
import { takeCanvas, W3, initWorld, setTerrain, resize as wResize, frameBegin, drawTerrain, flushModels, frameEnd, inst, drawChar, heightAt, ENV, shadow, puff, decal, project, growModel, addMesh } from "./world3d.js";
import { BIOME, GEO, buildSite } from "./site3d.js";
import { Sound } from "./audio.js";
import { find, stats, lookOf, randomLook, drawHead, buildW } from "./gear.js";
import * as SQ from "./squad.js";

import { A as ARMY, UNITS, SKILLS, mulLv, unitLv, skillLv, pickArmy, applyLosses } from "./army3d.js";

const TAU = Math.PI * 2, clamp = (v, a, b) => Math.max(a, Math.min(b, v)), lerp = (a, b, t) => a + (b - a) * t;
const hex = (h) => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const rgb = (c, k = 1, fog = 0, fc = [190, 215, 235]) => { const r = lerp(clamp(c[0] * k, 0, 255), fc[0], fog), g = lerp(clamp(c[1] * k, 0, 255), fc[1], fog), b = lerp(clamp(c[2] * k, 0, 255), fc[2], fog); return `rgb(${r | 0},${g | 0},${b | 0})`; };
const angDiff = (a, b) => { let d = (b - a) % TAU; if (d > Math.PI) d -= TAU; if (d < -Math.PI) d += TAU; return d; };
const LIGHT = (() => { const l = [0.45, 0.8, -0.4], n = Math.hypot(...l); return l.map((v) => v / n); })();











export function startSiege3D(nb, onEnd) {

  const KIND = nb.site && nb.site.kind ? nb.site.kind : (nb.keep ? "field" : "castle"), FIELD = KIND === "field", KEEP = nb.keep || null;
  const root = document.createElement("div"); root.id = "s3d";
  root.innerHTML = `<canvas id="s3c"></canvas><canvas id="s3o"></canvas><div class="s3vig"></div><div id="s3hurt"></div><div id="s3fps"></div>
  <div class="s3top"><div class="s3col"><div class="s3bar"><i id="s3php"></i><span id="s3pt"></span></div><div class="s3lv"><b id="s3lvn">1</b><div class="s3xp"><i id="s3xp"></i></div></div></div><div class="s3mid"><b>${nb.emoji} ${nb.name}</b><div class="s3bar g"><i id="s3ghp"></i><span id="s3gt"></span></div></div><div class="s3r"><span id="s3time"></span><button class="s3b sm" data-s="cam" id="s3cam">🎥</button><button class="s3b sm" data-s="upg">⬆️<i class="s3dot" id="s3dot"></i></button><button class="s3b sm" data-s="pause">⏸</button></div></div>
  <div id="s3lvup"></div>
  <div id="s3msg"></div><div id="s3perk" class="s3perk"></div><div id="s3obj"></div>
  <div class="s3joy" id="s3joy"><i id="s3knob"></i></div>
  <div class="s3side"><button class="s3b" data-s="lock" id="s3lock"><span>🎯</span><em>قفل هدف</em></button><button class="s3b" data-s="heavy"><span>⚒️</span><em>ضربه‌ی سنگین</em></button><button class="s3b" data-s="block"><span>🛡️</span><em>سپر</em></button></div>
  <div class="s3btns"><button class="s3b big" data-s="atk">⚔️</button><button class="s3b" data-s="roll"><span>🌀</span><em>جاخالی</em></button><button class="s3b" data-s="spec"><span>💥</span><em>ضربه شاهانه</em><u id="s3c1"></u><b class="lk">🔒</b></button><button class="s3b" data-s="rally"><span>📣</span><em>فریاد جنگ</em><u id="s3c2"></u><b class="lk">🔒</b></button><button class="s3b" data-s="ram"><span>🐏</span><em>دروازه‌شکن</em><u id="s3c3"></u><b class="lk">🔒</b></button><button class="s3b" data-s="bolt"><span>⚡</span><em>سپر آذرخش</em><u id="s3c4"></u><b class="lk">🔒</b></button></div>
  <div class="s3cmd" id="s3cmd"><button class="s3tab" data-s="cmdtoggle" id="s3tab"><span>☰</span></button><div class="s3cin"><button data-s="o_attack"><span>⚔️</span>حمله</button><button data-s="o_gate"><span>🚪</span>دروازه</button><button data-s="o_guard"><span>🛡️</span>دفاع</button><button data-s="o_regroup"><span>📯</span>جمع شو</button></div><div class="s3ord" id="s3ord"></div></div>
  <div id="s3up" class="s3pause"></div><div id="s3capv" class="s3pause"></div><div id="s3fade"></div>
  <div id="s3pause" class="s3pause"><div class="s3card"><h2>توقف</h2><button class="btn l g" data-s="resume">ادامه ▶</button><button class="btn l d" data-s="quit">خروج از نبرد</button></div></div>`;
  document.body.appendChild(root); document.body.classList.add("inbattle");
  const cv = takeCanvas(root.querySelector("#s3c")), ovc = root.querySelector("#s3o"), ov = ovc.getContext("2d"), hurtEl = root.querySelector("#s3hurt"), fpsEl = /[?&]fps/.test(location.search) ? root.querySelector("#s3fps") : null;
  const $ = (id) => root.querySelector("#" + id);
  let W = 0, H = 0, oDpr = 1;
  function resize() { W = innerWidth; H = innerHeight; oDpr = Math.min(window.devicePixelRatio || 1, 1.25); if (W3.canvas === cv) wResize(W, H, 1.5); ovc.width = W * oDpr | 0; ovc.height = H * oDpr | 0; ovc.style.width = W + "px"; ovc.style.height = H + "px"; }
  resize(); addEventListener("resize", resize);

  // ---------- جهان ----------
  const GE = GEO[KIND] || GEO.castle, ZG = FIELD ? 46 : GE.ZG, ZI = GE.ZI, WALLH = 8, GATEW = 5.2, GATEH = 6.2, LIMX = FIELD ? 34 : 26, STAGED = !FIELD && !!nb.site, CASTLE = KIND === "castle";
  let FRONT = ZG - 1.6, ZMAX = FIELD ? 34 : FRONT - 0.9, stage = 0, inHall = false, capT = 0, burnT = 0, capDone = false;
  const st = stats(S.avatar), AV = S.avatar, SW = find("sword", AV.sword), SH = find("shield", AV.shield), HM = find("helm", AV.helm), AR = find("armor", AV.armor), CP = find("cape", AV.cape);
  const HX = heroInit(), up = HX.up, hpK = () => (1 + 0.08 * up.hp) * (1 + 0.03 * (HX.lv - 1)), pd = () => st.dmg * (1 + 0.06 * up.pow) * (1 + 0.02 * (HX.lv - 1)), cdK = () => 1 - 0.05 * up.sta, spK = () => (1 + 0.05 * up.spd) * (CLS === "Monk" ? 1.18 : 1);
  const P = { x: 0, z: 0, yaw: 0, hp: st.hp * hpK(), maxhp: st.hp * hpK(), atkT: 0, hitDone: true, combo: 0, comboT: 0, roll: 0, inv: 0, walk: 0, hurt: 0, vx: 0, vz: 0, dead: false, bob: 0 };
  const gateMax = FIELD ? 0 : Math.round((nb.gate || 400) * 0.85), gate0 = { hp: gateMax, max: Math.max(1, gateMax), hit: 0, fall: 0, shake: 0, z: ZG, k: 1 }, gate1 = { hp: 0, max: 1, hit: 0, fall: 0, shake: 0, z: ZI, k: 0.7 };
  let G = gate0;
  const civs = [], shots = [], dfires = [];
  const CLS = (AV.char && ["Knight", "Warrior", "Ranger", "Rogue", "Cleric", "Monk", "Wizard"].includes(AV.char.m)) ? AV.char.m : "Warrior";
  const CLSD = { Knight: ["🛡️", "شوالیه", "سپر آهنین"], Warrior: ["⚔️", "جنگجو", "ضربه‌ی چرخشی سوم"], Rogue: ["🗡️", "دزد", "ضربه‌ی مهلک"], Monk: ["👊", "راهب", "سرعت و رگبار مشت"], Ranger: ["🏹", "کماندار", "رگبار تیر"], Wizard: ["🔮", "جادوگر", "گوی انفجاری"], Cleric: ["✨", "کشیش", "موج شفا"] }, RANGED = { Ranger: "arrow", Wizard: "orb", Cleric: "orb" }[CLS] || null;
  let shotN = 0, healT = 7, lockT = null, perkFx = 0;
  const allies = [], corpses = [], foes = [], arrows = [], parts = [], texts = [], rams = [];
  const CAMM = [{ dist: 3.7, h: 2.1, pitch: 0.13, n: "پشت شانه (نزدیک)" }, { dist: 5.9, h: 3.1, pitch: 0.27, n: "دنبال‌کننده" }, { dist: 10, h: 5.5, pitch: 0.5, n: "تاکتیکی" }, { dist: 18, h: 11, pitch: 0.82, n: "فرماندهی (بالا)" }];
  let camMode = 1; try { const v = parseInt(localStorage.getItem("bs_cam")); if (v >= 0 && v < 4) camMode = v; } catch (e) { /* */ }
  const cam = { tx: 0, tz: 0, yaw: 0, x: 0, y: 0, z: -7, pitch: 0.34, dist: CAMM[camMode].dist, h: CAMM[camMode].h, shake: 0, pb: CAMM[camMode].pitch, modeT: 0, dragT: 0 };
  { const cb = document.getElementById("s3cam"); if (cb) cb.dataset.m = camMode + 1; }
  const power = nb.power;
  const SL = (k) => skillLv(k === "bolt" ? "oil" : k);
  let winT = 0, enemyTotal = 1, upCb = null, time = 0, kills = 0, lost = 0, over = false, paused = false, cd = { spec: 0, rally: 0, ram: 0, bolt: 0, heavy: 0 }, boltT = 0, ordT = 0, rallyT = 0, spawnT = 4, captain = 0, msgT = 0, ended = false, raf = 0, last = performance.now(), endT = 0, endWon = false, deadT = 0, hitStop = 0;
  const LIMIT = FIELD ? 200 : STAGED ? 480 : 150, K = FIELD ? KEEP.k || {} : {};
  // یاران: از سپاه خریداری‌شده/غنیمت (در شروع فقط یک سرباز)
  const army = pickArmy(), nAll = army.length, armyIn = {}; let order = FIELD ? "attack" : "guard"; const orderName = { attack: FIELD ? "حمله‌ی همه‌جانبه" : "حمله به نگهبانان", gate: "کوبیدن دروازه", guard: "دفاع و همراهی", regroup: "جمع شدن" };
  for (let i = 0; i < nAll; i++) {
    const k = army[i], d = UNITS[k], m = mulLv(unitLv(k)); armyIn[k] = (armyIn[k] || 0) + 1;
    const lk = randomLook(900 + i * 7 + k.length, {});
    allies.push({ id: "a" + i, kind: k, look: lk, x: (i % 2 ? 1 : -1) * (2.2 + Math.floor(i / 2) * 1.5), z: 1.5 - Math.floor(i / 2) * 1.2, yaw: 0, hp: d.hp * m, maxhp: d.hp * m, dmg: d.dmg * 1.5 * m, speed: 5.8 * d.speed, cdT: Math.random(), walk: Math.random() * 6, hurt: 0, atkA: 0, ranged: k === "archer", off: i, tgt: null, sc: 0.9 + (lk.face.height - 1) * 1.2, bw: buildW(lk.face.build) });
  }
  const deadOw = {};
  if (nb.keep && S.ow && S.ow.allies) S.ow.allies.forEach((g, gi) => { const kinds = g.k === "turan" ? ["horse", "archer", "archer"] : g.k === "merc" ? ["sword", "shield", "sword"] : ["sword", "sword", "archer"]; const cnt = Math.min(4, Math.max(2, g.n)); for (let j = 0; j < cnt; j++) { const k = kinds[j % 3], d = UNITS[k], m = 0.8 + g.pow / Math.max(1, cnt) / 40, lk = randomLook(300 + gi * 31 + j * 7, {}); lk.skin = g.look[j % g.look.length].s || lk.skin; allies.push({ id: "o" + gi + "_" + j, ow: gi, kind: k, look: lk, x: (j % 2 ? 1 : -1) * (3.4 + j * 0.6), z: 2.8 - gi * 1.0, yaw: 0, hp: d.hp * m, maxhp: d.hp * m, dmg: d.dmg * 1.3 * m, speed: 5.6 * d.speed, cdT: Math.random(), walk: Math.random() * 6, hurt: 0, atkA: 0, ranged: k === "archer", off: 30 + j, tgt: null, sc: 0.9 + (lk.face.height - 1) * 1.2, bw: buildW(lk.face.build) }); } });














  const oils = []; let oilT = 12;
  const archerPos = []; const nArch = 3 + nb.tlvl * 2; for (let i = 0; i < nArch; i++) archerPos.push(-LIMX + 6 + (i + 0.5) * ((LIMX * 2 - 12) / nArch));
  const wallArchers = archerPos.map((x, i) => ({ id: 0.137 * (i + 3), x, z: ZG - 0.4, y: WALLH, yaw: Math.PI, hp: 36 + power * 0.8, maxhp: 36 + power * 0.8, cdT: 1 + i * 0.5, kind: "warcher", walk: 0, hurt: 0, wall: true }));
  if (!FIELD) for (const a of wallArchers) foes.push(a);

  // ---------- مرزها و برخورد ----------
  const gateOpen = (g) => (g === 0 ? stage >= 1 : stage >= 3);
  function limX(z) { if (FIELD) return 34; if (stage >= 1 && z > ZG - 3 && z < ZG + 3.5) return 5.2; if (stage >= 1 && z >= ZG + 3.5 && z < ZI + 2) return GE.HW - 4; if (stage >= 3 && z > ZI + 2) return 28; return 26; }
  function collide(e, r0) { if (!SITE) return; const cs = SITE.cols, rr = r0 || 0.45; for (let i = 0; i < cs.length; i++) { const c = cs[i], dx = e.x - c[0], dz = e.z - c[1], R = c[2] + rr; if (dx * dx + dz * dz < R * R) { const d = Math.sqrt(dx * dx + dz * dz) || 0.01; e.x = c[0] + dx / d * R; e.z = c[1] + dz / d * R; } } }
  function bound(e) {
    if (inHall) { e.x = clamp(e.x, -12.5, 12.5); e.z = clamp(e.z, SITE.hall.z0 + 1, SITE.hall.z1 - 1.5); return; }
    const z0 = e._pz === undefined ? e.z : e._pz;
    e.z = clamp(e.z, FIELD ? -34 : -14, ZMAX);
    if (!FIELD) for (let g = 0; g < (CASTLE ? 2 : 1); g++) { const gz = g ? ZI : ZG; if (gateOpen(g) && e.z > gz - 3 && e.z < gz + 3.5 && Math.abs(e.x) > 5.2 && !e.wall) e.z = z0 < gz ? gz - 3 : gz + 3.5; }
    const lx = limX(e.z); e.x = clamp(e.x, -lx + 1, lx - 1); collide(e); e._pz = e.z;
  }
  const key = {}, joy = { on: false, id: null, x: 0, y: 0, ox: 0, oy: 0 }; let camTouch = null;
  const mv = () => { let x = (key.d || key.arrowright ? 1 : 0) - (key.a || key.arrowleft ? 1 : 0), y = (key.w || key.arrowup ? 1 : 0) - (key.s || key.arrowdown ? 1 : 0); x += joy.x; y += joy.y; const l = Math.hypot(x, y); return l > 1 ? [x / l, y / l] : [x, y]; };
  const onKD = (e) => { const k = e.key.toLowerCase(); key[k] = true; if (k === " ") { act("atk"); e.preventDefault(); } if (k === "shift") act("roll"); if (k === "r") act("spec"); if (k === "f") act("rally"); if (k === "g") act("ram"); if (k === "h") act("bolt"); if (k === "1") act("o_attack"); if (k === "2") act("o_gate"); if (k === "3") act("o_guard"); if (k === "4") act("o_regroup"); if (k === "c") act("cam"); if (k === "e" || k === "tab") { act("lock"); e.preventDefault(); } if (k === "u") act("upg"); if (k === "escape") act(paused ? "resume" : "pause"); };
  const onKU = (e) => { key[e.key.toLowerCase()] = false; };
  addEventListener("keydown", onKD); addEventListener("keyup", onKU);
  const joyEl = $("s3joy"), knob = $("s3knob");
  joyEl.addEventListener("pointerdown", (e) => { joy.on = true; joy.id = e.pointerId; joyEl.setPointerCapture(e.pointerId); joyMove(e); e.preventDefault(); });
  joyEl.addEventListener("pointermove", (e) => { if (joy.on && e.pointerId === joy.id) joyMove(e); });
  const joyEnd = (e) => { if (e.pointerId === joy.id) { joy.on = false; joy.x = joy.y = 0; knob.style.transform = "translate(0,0)"; } };
  joyEl.addEventListener("pointerup", joyEnd); joyEl.addEventListener("pointercancel", joyEnd);
  function joyMove(e) { const r = joyEl.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2, R = r.width / 2; let dx = (e.clientX - cx) / R, dy = (e.clientY - cy) / R; const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; } joy.x = Math.abs(dx) < 0.1 ? 0 : dx; joy.y = Math.abs(dy) < 0.1 ? 0 : -dy; knob.style.transform = `translate(${dx * R * 0.55}px,${dy * R * 0.55}px)`; }
  cv.addEventListener("pointerdown", (e) => { if (camTouch === null) { camTouch = { id: e.pointerId, x: e.clientX, y: e.clientY }; cv.setPointerCapture(e.pointerId); } });
  cv.addEventListener("pointermove", (e) => { if (camTouch && camTouch.id === e.pointerId) { cam.yaw += (e.clientX - camTouch.x) * 0.0065; cam.dragT = 1.4; cam.modeT = 0; cam.pb = clamp((cam.pb || 0.34) + (e.clientY - (camTouch.y || e.clientY)) * 0.003, 0.08, 0.95); camTouch.x = e.clientX; camTouch.y = e.clientY; } });
  const camEnd = (e) => { if (camTouch && camTouch.id === e.pointerId) camTouch = null; };
  cv.addEventListener("pointerup", camEnd); cv.addEventListener("pointercancel", camEnd);
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-s]"); if (b) act(b.dataset.s); });
  root.querySelectorAll(".s3b,.s3cmd button").forEach((b) => b.addEventListener("pointerdown", (e) => { const a = b.dataset.s; if (a === "atk" || a === "roll" || a === "heavy" || a === "spec" || a === "rally" || a === "ram" || a === "bolt" || a === "lock" || a[1] === "_") { e.preventDefault(); e.stopPropagation(); act(a); b.classList.add("p"); setTimeout(() => b.classList.remove("p"), 120); } }));
  root.querySelectorAll(".s3b,.s3cmd button").forEach((b) => b.addEventListener("click", (e) => { const a = b.dataset.s; if (a === "atk" || a === "roll" || a === "heavy" || a === "spec" || a === "rally" || a === "ram" || a === "bolt" || a === "lock" || a[1] === "_") e.stopPropagation(); }, true));

  { const bb = root.querySelector('[data-s=block]'), setB = (v) => { if (paused || over || P.dead) v = false; P.block = v; bb.classList.toggle("p", v); };
    bb.addEventListener("pointerdown", (e) => { e.preventDefault(); e.stopPropagation(); bb.setPointerCapture(e.pointerId); setB(true); });
    const rel = (e) => { e.stopPropagation(); setB(false); }; bb.addEventListener("pointerup", rel); bb.addEventListener("pointercancel", rel); bb.addEventListener("lostpointercapture", () => setB(false));
    addEventListener("keydown", (e) => { if (e.key.toLowerCase() === "q") setB(true); }); addEventListener("keyup", (e) => { if (e.key.toLowerCase() === "q") setB(false); }); }
  function updCmd() { root.querySelectorAll(".s3cmd button").forEach((b) => b.classList.toggle("on", b.dataset.s === "o_" + order)); }
  ['spec', 'rally', 'ram', 'bolt'].forEach((k) => { const b = root.querySelector(`[data-s=${k}]`); b.classList.toggle("locked", !SL(k)); });
  let msgH = 0; function say(t, d = 2.2) { const m = $("s3msg"); m.textContent = t; m.classList.add("on"); msgT = d; clearTimeout(msgH); msgH = setTimeout(() => m.classList.remove("on"), Math.min(4500, d * 1000 + 200)); }
  function act(a) {
    if (a === "pause") { paused = true; $("s3pause").classList.add("on"); return; }
    if (a === "resume") { paused = false; $("s3pause").classList.remove("on"); last = performance.now(); return; }
    if (a === "quit") { finish(false, true); return; }
    if (a === "cam") { camMode = (camMode + 1) % 4; const cb = $("s3cam"); if (cb) cb.dataset.m = camMode + 1; try { localStorage.setItem("bs_cam", camMode); } catch (e) { /* */ } cam.modeT = 0.9; say("دوربین: " + CAMM[camMode].n, 1.2); return; }
    if (a === "upg") { openUp(false); return; }
    if (a === "upclose") { closeUp(); return; }
    if (a.startsWith("up_")) { if (heroBuy(a.slice(3))) { Sound.sfx("click"); applyHero(); } else Sound.sfx("error"); renderUp(); return; }
    if (a.startsWith("cap_")) { pickCap(a.slice(4)); return; }
    if (a === "lock") { if (!paused && !over) toggleLock(); return; }
    if (a === "cmdtoggle") { $("s3cmd").classList.toggle("open"); return; }
    if (paused || over || P.dead) return;
    if (a === "atk") { if (P.atkT <= (P.am || 0.3) * 0.5 && P.roll <= 0 && !P.block) { P.atkT = P.am = CLS === "Monk" ? 0.24 : RANGED ? 0.4 : 0.3; P.heavy = false; P.hitDone = false; P.combo = P.comboT > 0 ? (P.combo + 1) % 3 : 0; P.comboT = 0.8; autoAim(); Sound.sfx("shot_spear", { vol: 0.5 }); } }
    else if (a === "heavy") { if (cd.heavy <= 0 && P.atkT <= 0.1 && P.roll <= 0 && !P.block) { cd.heavy = 1.8 * cdK(); P.atkT = P.am = 0.46; P.heavy = true; P.hitDone = false; P.combo = 1; P.comboT = 0; autoAim(); Sound.sfx("shot_spear", { vol: 0.7 }); } }
    else if (a === "block") { /* با نگه‌داشتن */ }
    else if (a === "roll") { if (P.roll <= 0) { const [mx, my] = mv(); let d = P.yaw; if (mx || my) d = camAng(mx, my); P.rd = d; P.roll = 0.34; P.inv = 0.45; P.atkT = 0; Sound.sfx("tick"); } }
    else if (a[1] === "_") { $("s3cmd").classList.remove("open"); order = a.slice(2); if (order === "gate" && FIELD) order = "attack"; if (order === "regroup") { for (const al of allies) { al.x = P.x + (Math.random() - 0.5) * 4; al.z = P.z - 1 - Math.random() * 2; } ring(P.x, P.z, 4, "#7bd8ff"); order = "guard"; } $("s3ord").textContent = "فرمان: " + orderName[order]; $("s3ord").classList.add("on"); clearTimeout(ordT); ordT = setTimeout(() => $("s3ord").classList.remove("on"), 2500); Sound.sfx("click"); updCmd(); $("s3cmd").classList.remove("open"); }
    else if ((a === "spec" || a === "rally" || a === "ram" || a === "bolt") && !SL(a)) { say("🔒 این مهارت را از «تجهیزات ← مهارت‌ها» بخر", 2.2); Sound.sfx("error"); }
    else if (a === "spec") { if (cd.spec <= 0) { cd.spec = SKILLS.spec.cd[SL("spec") - 1] * cdK(); slam(); } }
    else if (a === "bolt") { if (cd.bolt <= 0) { cd.bolt = SKILLS.oil.cd[SL("bolt") - 1] * cdK(); boltT = 4 + SL("bolt") * 1.5; P.inv = boltT; say("سپر آذرخش! ⚡", 1.6); Sound.sfx("skill_kaveh"); } }
    else if (a === "rally") { if (cd.rally <= 0) { cd.rally = SKILLS.rally.cd[SL("rally") - 1] * cdK(); rallyT = 6 + SL("rally") * 2; for (const al of allies) { al.hp = Math.min(al.maxhp, al.hp + al.maxhp * 0.2); burst(al.x, 1, al.z, 8, "#ffd36b", 3); } ring(P.x, P.z, 7, "#ffd36b"); Sound.sfx("skill_kaveh"); say("یاران، به پیش! ⚔️", 1.6); } }
    else if (a === "ram") { if (cd.ram <= 0 && !FIELD) { cd.ram = SKILLS.ram.cd[SL("ram") - 1]; const lv = SL("ram"); rams.push({ x: clamp(P.x, -5, 5), z: P.z - 6, hp: 220 * (1 + lv * 0.5), maxhp: 220 * (1 + lv * 0.5), dmg: 110 * (1 + lv * 0.55), roll: 0, hits: 0, cdT: 0 }); Sound.sfx("troop_spawn"); say("دروازه‌شکن فرستاده شد! 🐏", 1.8); } }
  }
  const camAng = (mx, my) => { const f = cam.yaw, fx = Math.sin(f), fz = Math.cos(f), rx = Math.cos(f), rz = -Math.sin(f); return Math.atan2(rx * mx + fx * my, rz * mx + fz * my); };
  function autoAim() { if (lockT && !lockT.dead) { P.yaw = Math.atan2(lockT.x - P.x, lockT.z - P.z); return; } let b = null, bd = RANGED ? 20 : 4.2; for (const f of foes) { if (f.wall || f.dead) continue; const d = Math.hypot(f.x - P.x, f.z - P.z); if (d < bd) { bd = d; b = f; } } if (b) P.yaw = Math.atan2(b.x - P.x, b.z - P.z); else if (Math.abs(P.z - (FRONT - 0.6)) < 4.5) P.yaw = Math.atan2(-P.x * 0.5, 1); }

  // ---------- افکت‌ها ----------
  function burst(x, y, z, n, color, sp = 3) { if (parts.length > 260) return; for (let i = 0; i < n; i++) { const a = Math.random() * TAU; parts.push({ x, y, z, vx: Math.cos(a) * sp * Math.random(), vy: Math.random() * sp * 1.1, vz: Math.sin(a) * sp * Math.random(), life: 0.5 + Math.random() * 0.4, max: 0.9, c: color, s: 0.09 + Math.random() * 0.1 }); } }
  function ring(x, z, r, color) { parts.push({ ring: true, x, y: 0.08, z, r, life: 0.5, max: 0.5, c: color }); }
  function text(x, y, z, t, color) { texts.push({ x, y, z, t, c: color, life: 0.9 }); }
  function hurtP(dmg, from) {
    if (P.inv > 0 || P.dead) return; dmg = dmg * (1 - st.def); if (P.block) { dmg *= (0.2 - 0.012 * up.sta) * (CLS === "Knight" ? 0.55 : 1); ring(P.x, P.z, 1.8, "#9fe8ff"); Sound.sfx("hit", { vol: 0.5 }); } P.hp -= dmg; P.hurt = 0.25; cam.shake = Math.max(cam.shake, 0.18); text(P.x, 2.4, P.z, "-" + Math.round(dmg), "#ff6a6a"); Sound.sfx("hit_heavy", { vol: 0.6 }); burst(P.x, 1.2, P.z, 6, "#ff8a8a", 2.5);
    if (P.hp <= 0) { P.hp = 0; P.dead = true; deadT = 1.4; say("افتادی… 💔", 2); }
  }
  function perk(t) { const el = $("s3perk"); el.classList.remove("fx"); void el.offsetWidth; el.classList.add("fx"); if (t) text(P.x, 3.2, P.z, t, "#ffe27a"); }
  function pickTarget(range, cone) { if (lockT && !lockT.dead) return lockT; let b = null, bd = range; for (const f of foes) { if (f.dead) continue; const dx = f.x - P.x, dz = f.z - P.z, d = Math.hypot(dx, dz); if (d > bd || Math.abs(angDiff(P.yaw, Math.atan2(dx, dz))) > cone) continue; bd = d; b = f; } return b; }
  function nearestFoe() { let b = null, bd = 34; for (const f of foes) { if (f.dead || (f.wall && !RANGED)) continue; const d = Math.hypot(f.x - P.x, f.z - P.z) * (f.wall ? 1.3 : 1); if (d < bd) { bd = d; b = f; } } return b; }
  function toggleLock() { if (lockT) { lockT = null; say("قفل هدف خاموش", 0.8); } else { lockT = nearestFoe(); say(lockT ? "قفل شد 🎯" : "هدفی نیست", 0.9); } $("s3lock").classList.toggle("on", !!lockT); }
  function fireHero(heavy) {
    const T = pickTarget(22, 0.75); if (T) P.yaw = Math.atan2(T.x - P.x, T.z - P.z);
    const ox = P.x + Math.sin(P.yaw) * 0.9, oz = P.z + Math.cos(P.yaw) * 0.9, oy = gy(P.x, P.z) + 1.35; let n = 1, spread = 0; shotN++;
    if (CLS === "Ranger" && shotN % 4 === 0) { n = 3; spread = 0.17; perk("رگبار!"); }
    for (let i = 0; i < n; i++) shoot({ kind: RANGED, x: ox, y: oy, z: oz, yaw: P.yaw + (i - (n - 1) / 2) * spread, tg: T, dmg: pd() * (heavy ? 2.1 : 1) * (RANGED === "arrow" ? 0.95 : CLS === "Wizard" ? 1.15 : 0.8) / (n > 1 ? 1.5 : 1), aoe: CLS === "Wizard" ? (heavy ? 4 : 2.6) : CLS === "Cleric" ? 1.6 : 0, col: CLS === "Cleric" ? "#fff0a0" : "#9a7bff" });
    Sound.sfx(RANGED === "arrow" ? "shot_bow" : "skill_kaveh", { vol: 0.45 });
  }
  function shoot(o) { const sp = o.kind === "arrow" ? 30 : 16; shots.push(Object.assign({ vx: Math.sin(o.yaw) * sp, vz: Math.cos(o.yaw) * sp, vy: 0, life: 1.5, sp }, o)); }
  function impact(q, f) {
    if (q.kind === "orb") { const R = q.aoe || 0; ring(q.x, q.z, Math.max(1.4, R), q.col); burst(q.x, q.y, q.z, R ? 18 : 8, q.col, R ? 5 : 3); Sound.sfx("explode", { vol: 0.35 }); if (R) cam.shake = Math.max(cam.shake, 0.12);
      for (const g of foes) { if (g.dead) continue; const d = Math.hypot(g.x - q.x, g.z - q.z); if (g === f) shotHit(g, q.dmg); else if (R && d < R) shotHit(g, q.dmg * 0.7); } }
    else { if (f) shotHit(f, q.dmg); burst(q.x, q.y, q.z, 3, "#cbb89a", 1.5); }
  }
  function shotHit(g, d) { P.critNow = Math.random() < 0.04 * up.crit; dmgFoe(g, d * (P.critNow ? 1.9 : 1), P); P.critNow = false; if (!g.wall && !g.beast) g.stun = Math.max(g.stun || 0, 0.15); }
  function slam() {
    P.critNow = false; const dmg = pd() * (2 + SL("spec") * 0.6); ring(P.x, P.z, 5, "#ffd24a"); ring(P.x, P.z, 3, "#fff"); burst(P.x, 0.5, P.z, 30, "#ffd24a", 6); cam.shake = 0.5; Sound.sfx("explode", { vol: 0.7 }); hitStop = 0.08;
    for (const f of foes) { if (f.wall) continue; const d = Math.hypot(f.x - P.x, f.z - P.z); if (d < 5) { dmgFoe(f, dmg, P); f.stun = 1.3; const a = Math.atan2(f.x - P.x, f.z - P.z); f.x += Math.sin(a) * 2; f.z += Math.cos(a) * 2; } }
    if (P.z > FRONT - 5.5 && Math.abs(P.x) < 6) hitGate(dmg * 1.6, P.x, P.z + 1);
  }
  function dmgFoe(f, d, src) {
    if (f.dead) return; f.hp -= d; f.hurt = 0.2; if (src === P) gainXp(1 + d / 40); text(f.x, (f.y || 0) + 2.4 * (f.sc || 1), f.z, Math.round(d) + (src === P && P.critNow ? "!" : ""), src === P ? (P.critNow ? "#ff9a3a" : "#fff2b0") : "#ffd0a0"); burst(f.x, (f.y || 0) + 1.2, f.z, 4, "#ffe0b0", 2.5);
    if (f.hp <= 0) { f.dead = true; f.deadT = 0.7; kills++; gainXp(6 + f.maxhp / 18); burst(f.x, (f.y || 0) + 1, f.z, 14, "#d8c0a0", 4); Sound.sfx("enemy_die"); }
  }
  function hitGate(d, x, z) {
    if (G.hp <= 0 || FIELD) return; gainXp(d / 45); G.hp = Math.max(0, G.hp - d); G.hit = 0.18; G.shake = 0.25; cam.shake = Math.max(cam.shake, 0.12); text(x, 3.5, FRONT - 0.5, Math.round(d), "#ffb347"); burst(x, 2.5, FRONT - 0.3, 8, "#caa070", 3); Sound.sfx("gate_hit");
    if (G.hp <= 0) { G.fall = 0.001; Sound.sfx("explode"); cam.shake = 0.9; burst(0, 3, FRONT, 60, "#caa070", 8); say("دروازه شکست! 🏰", 3); }
  }

  // ---------- پیشرفت قهرمان ----------
  function applyHero() { const r = P.hp / P.maxhp; P.maxhp = st.hp * hpK(); P.hp = clamp(r * P.maxhp, 0, P.maxhp); }
  function gainXp(x) {
    const n = heroXp(x); if (!n) return; const el = $("s3lvup"); el.innerHTML = `<b>سطح ${HX.lv}</b><span>+${n} امتیاز ارتقا ⬆️</span>`; el.classList.remove("on"); void el.offsetWidth; el.classList.add("on");
    Sound.sfx("skill_kaveh"); ring(P.x, P.z, 3.5, "#ffd24a"); burst(P.x, 1, P.z, 24, "#ffd24a", 5); applyHero(); if (!P.dead) P.hp = Math.min(P.maxhp, P.hp + P.maxhp * 0.25);
  }
  function renderUp() {
    const el = $("s3up"), pips = (v) => Array.from({ length: HERO_MAXUP }, (_, i) => `<i class="${i < v ? "on" : ""}"></i>`).join("");
    el.innerHTML = `<div class="s3card s3upc"><h2>⬆️ ارتقای قهرمان</h2><div class="s3upsum"><b>سطح ${HX.lv}</b> • امتیاز: <b class="${HX.pts ? "hot" : ""}">${HX.pts}</b></div><div class="s3xp big"><i style="width:${HX.xp / heroNeed(HX.lv) * 100}%"></i><span>${Math.round(HX.xp)} / ${heroNeed(HX.lv)}</span></div>` +
      HERO_UP.map((u) => `<div class="s3urow"><span class="ui">${u.i}</span><div class="ut"><b>${u.n}</b><small>${u.d}</small><div class="pips">${pips(up[u.k])}</div></div><button class="s3ubtn" data-s="up_${u.k}" ${HX.pts < 1 || up[u.k] >= HERO_MAXUP ? "disabled" : ""}>＋</button></div>`).join("") +
      `<div class="s3uhint">با کشتن دشمنان و زدن ضربه تجربه می‌گیری؛ هر سطح یک امتیاز می‌دهد.</div><button class="btn l g" data-s="upclose">ادامه ▶</button></div>`;
  }
  function openUp(final, cb) { upCb = cb || null; paused = true; renderUp(); $("s3up").classList.add("on"); }
  function closeUp() { $("s3up").classList.remove("on"); const cb = upCb; upCb = null; if (cb) { cb(); return; } paused = false; last = performance.now(); }
  const BEASTS = { wolf: { hpK: 1, dmgK: 1, spd: 6.8, sc: 1 }, bear: { hpK: 3.6, dmgK: 2.3, spd: 4.4, sc: 1.55 }, boar: { hpK: 1.8, dmgK: 1.4, spd: 5.8, sc: 1.0 }, lion: { hpK: 2.2, dmgK: 1.8, spd: 6.6, sc: 1.2 } };
  const beastOf = () => { if (!FIELD || !K.beast) return null; const id = (K.id || "") + " " + (K.name || ""); if (/bear|خرس/i.test(id)) return "bear"; if (/boar|گراز/.test(id)) return "boar"; if (/lion|شیر|panther|پلنگ/i.test(id)) return "lion"; return "wolf"; };
  if (FIELD) {
    P.z = -12; for (const a of allies) a.z -= 12; cam.tx = 0; cam.tz = P.z;
    const bt = beastOf(), En = clamp(Math.round(KEEP.n * 1.7 + 1), 4, 40), upow = Math.max(2, KEEP.pow / Math.max(1, KEEP.n)); let sd = 11; const rr = () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
    for (let i = 0; i < En; i++) {
      const col = i % 8, row = Math.floor(i / 8), x = (col - 3.5) * 2.0 + (rr() - 0.5) * 1.2, z = 22 + row * 2.2 + (rr() - 0.5) * 1.5;
      if (bt) { const B = BEASTS[bt], hp = (30 + upow * 4) * B.hpK; foes.push({ id: 0.01 + rr(), kind: "beast", beast: bt, x, z, yaw: Math.PI, hp, maxhp: hp, dmg: (5 + upow * 0.6) * B.dmgK, speed: B.spd * (0.9 + rr() * 0.2), sc: B.sc * (0.92 + rr() * 0.16), walk: rr() * 6, cdT: 0.6 + rr(), hurt: 0, atkA: 0, stun: rr() * 1.6 }); }
      else { const boss = i === 0 && En >= 10, heavy = !boss && upow > 6 && rr() < 0.22, kind = boss ? "captain" : heavy ? "heavy" : "guard", hp = boss ? 260 + upow * 18 : (heavy ? 2.1 : 1) * (50 + upow * 6), spawnX = boss ? 0 : x; foes.push({ id: 0.01 + rr(), kind, dark: K.id === "div", x: spawnX, z: boss ? 27 : z, yaw: Math.PI, hp, maxhp: hp, dmg: boss ? 13 + upow * 0.8 : (heavy ? 1.4 : 1) * (5 + upow * 0.5), speed: boss ? 4.6 : heavy ? 3.8 : 5.0 * (0.9 + rr() * 0.2), sc: boss ? 1.4 : heavy ? 1.12 : 1, walk: rr() * 6, cdT: 0.6 + rr(), hurt: 0, atkA: 0, stun: rr() * 1.6 }); }
    }
    enemyTotal = foes.reduce((n, f) => n + f.maxhp, 0);
  }
  // ---------- دشمنان ----------
  function spawnGuard(captainMode, px, pz, hold) {
    const side = Math.random() < 0.5 ? -1 : 1, lim = stage === 2 ? 16 : Math.min(limX(FRONT), LIMX), x = px !== undefined ? px : side * (lim - 3.5), z = pz !== undefined ? pz : FRONT - 1;
    const heavy = !captainMode && power > 55 && Math.random() < 0.4;
    const hp = captainMode ? 380 + power * 9 : (heavy ? 2.1 : 1) * (60 + power * 1.8);
    foes.push({ id: Math.random(), kind: captainMode ? "captain" : heavy ? "heavy" : "guard", x, z, yaw: Math.PI, hp, maxhp: hp, dmg: (captainMode ? 22 : heavy ? 10 : 7) + power * (captainMode ? 0.35 : 0.1), speed: captainMode ? 4.6 : heavy ? 3.8 : 5.0, sc: captainMode ? 1.45 : heavy ? 1.12 : 1, walk: Math.random() * 6, cdT: 0.6, hurt: 0, atkA: 0, stun: 0, hold: !!hold });
    burst(x, 1, z, 8, "#8a7a6a", 2);
  }

  // ---------- مراحل تسخیر ----------
  const RR = (() => { let sd = 77; return () => { sd = (sd * 16807) % 2147483647; return sd / 2147483647; }; })();
  const aliveFoes = () => foes.reduce((n, f) => n + (f.dead || f.wall ? 0 : 1), 0);
  function setObj(t) { const el = $("s3obj"); el.textContent = t || ""; el.classList.toggle("on", !!t); }
  const OBJ = { 0: "دروازه‌ی بیرونی را بشکن", 1: "نگهبانان حیاط را شکست بده", 2: "دروازه‌ی داخلی را بشکن", 3: "وارد کاخ شو 🏰", 5: "فرمانده را شکست بده 👑", 4: "به نقطه‌ی پرچم برو و بایست 🏴" };
  function advance() { if (!STAGED) { finish(true); return; } if (stage === 0) enterCourt(); else if (stage === 2) { stage = 3; ZMAX = GE.ZK - 9; G.fall = 0; say("دروازه‌ی داخلی شکست! به سوی کاخ 🏰", 2.6); setObj(OBJ[3]); dfires.push([2.5, 1, ZI, 2], [-2.5, 0.8, ZI + 1, 1.7]); } }
  function enterCourt() {
    stage = 1; ZMAX = ZI - 3; for (const f of foes) if (f.wall) { f.dead = true; f.deadT = 0.6; } say("دروازه شکست! نگهبانان حیاط را شکست بده ⚔️", 3); setObj(OBJ[1]); dfires.push([2.5, 1, ZG, 2.2], [-2.5, 0.8, ZG + 1, 1.7]);
    const gar = (nb.site.garrison || (KEEP && KEEP.n * 3) || 8), N = clamp(Math.round(gar * 0.5) + 3, 5, 14), hw = GE.HW - 16;
    for (let i = 0; i < N; i++) spawnGuard(false, (RR() * 2 - 1) * hw, ZG + 12 + RR() * (ZI - ZG - 26), true);
    if (!CASTLE) spawnGuard(true, 0, ZI - 12, true);
    enemyTotal = foes.reduce((n, f) => n + (f.dead ? 0 : f.maxhp), 0);
    for (let i = 0; i < 12; i++) civs.push({ id: i + 3, x: (RR() * 2 - 1) * (GE.HW - 14), z: ZG + 10 + RR() * (ZI - ZG - 20), yaw: RR() * TAU, sc: 0.82 + RR() * 0.22, walk: RR() * 6, ph: RR() * 6 });
    for (const a of allies) { a.x = P.x + (RR() - 0.5) * 6; a.z = Math.min(P.z, ZG - 4) - RR() * 3; }
  }
  function courtClear() {
    if (CASTLE) { stage = 2; G = gate1; G.hp = G.max = Math.max(60, Math.round(gateMax * 0.5)); FRONT = ZI - 1.6; ZMAX = FRONT - 0.9; captain = 0; spawnT = 3; oilT = 10; say("نگهبانان حیاط شکست خوردند! دروازه‌ی کاخ را بشکن 🚪", 3); setObj(OBJ[2]);
      for (let i = 0; i < 4; i++) { const x = (i % 2 ? 1 : -1) * (11 + (i >> 1) * 9); foes.push({ id: 0.37 * (i + 5), x, z: ZI - 0.4, y: WALLH, yaw: Math.PI, hp: 36 + power * 0.8, maxhp: 36 + power * 0.8, cdT: 1 + i * 0.5, kind: "warcher", walk: 0, hurt: 0, wall: true }); } }
    else { stage = 4; ZMAX = ZI - 3; capPt(); }
  }
  let CAPX = 0, CAPZ = 0;
  function capPt() { setObj(OBJ[4]); say("نگهبانان شکست خوردند! 🏴", 2.4); if (inHall) { CAPX = 0; CAPZ = SITE.hall.bz - 2; } else { CAPX = 0; CAPZ = KIND === "town" ? SITE.plazaZ - 10 : SITE.plazaZ - 2; } stage = 4; capT = 0; }
  function enterHall() {
    inHall = true; stage = 3; const H = SITE.hall, f = $("s3fade"); f.style.transition = "none"; f.style.opacity = 1; void f.offsetWidth; f.style.transition = "opacity 1s"; f.style.opacity = 0;
    P.x = 0; P.z = H.z; P._pz = undefined; cam.tx = P.x; cam.tz = P.z; cam.yaw = 0; allies.forEach((a, i) => { a.x = (i % 2 ? 1 : -1) * (2 + (i >> 1) * 1.2); a.z = H.z - 1 - (i >> 1); });
    for (const x of [-6, 6, -3, 3]) spawnGuard(false, x, H.bz - 6, true); spawnGuard(true, 0, H.bz - 2, true); enemyTotal = foes.reduce((n, q) => n + (q.dead || q.wall ? 0 : q.maxhp), 0); stage = 5; say("تالار شاه! فرمانده را شکست بده 👑", 3); setObj(OBJ[5]);
  }
  function showCapture() {
    paused = true; const el = $("s3capv"), nm = (nb.site && nb.site.name) || nb.name;
    el.innerHTML = `<div class="s3card"><h2>🏴 «${nm}» سقوط کرد</h2><div class="s3capq">با آن چه می‌کنی؟</div><button class="btn l g s3cb" data-s="cap_occupy">🏴 اشغال و حفظ<small>به قلمرو تو می‌پیوندد؛ مردم آرام می‌مانند</small></button><button class="btn l s3cb" data-s="cap_loot">💰 غارت<small>غنیمت بیشتر؛ آوازه‌ی تو بدنام می‌شود</small></button><button class="btn l d s3cb" data-s="cap_burn">🔥 به آتش کشیدن<small>شهر می‌سوزد؛ بدون غنیمت و پر از نفرت</small></button></div>`; el.classList.add("on"); Sound.sfx("click");
  }
  function pickCap(k) {
    $("s3capv").classList.remove("on"); paused = false; last = performance.now(); capDone = true; capture = k; setObj("");
    try { if (S.ow && typeof S.ow.rep === "number") S.ow.rep += k === "occupy" ? 2 : k === "loot" ? -3 : -6; if (k === "loot") S.coins += Math.round(power * 22); else if (k === "occupy") S.coins += Math.round(power * 6); } catch (e) { /* */ }
    if (k === "burn") { burnT = 3.8; say("🔥 شهر در آتش می‌سوزد…", 3); Sound.sfx("explode"); } else { say(k === "loot" ? "💰 غنیمت جمع شد!" : "🏴 پرچم تو برافراشته شد!", 2); for (const a of allies) burst(a.x, 1.5, a.z, 6, "#ffd24a", 3); setTimeout(() => finish(true), 1300); }
  }
  let capture = "occupy";

  // ---------- به‌روزرسانی ----------
  function update(dt) {
    time += dt; if (msgT > 0) { msgT -= dt; if (msgT <= 0) $("s3msg").classList.remove("on"); }
    for (const k in cd) cd[k] = Math.max(0, cd[k] - dt); rallyT = Math.max(0, rallyT - dt);
    if (boltT > 0) { boltT -= dt; if (Math.random() < dt * 14) burst(P.x + (Math.random() - 0.5) * 2, 0.5 + Math.random() * 2, P.z + (Math.random() - 0.5) * 2, 2, "#9fe8ff", 3); for (const f of foes) { if (f.wall || f.dead) continue; if (Math.hypot(f.x - P.x, f.z - P.z) < 3.2 && Math.random() < dt * 3) dmgFoe(f, pd() * 0.8, P); } }
    P.atkT = Math.max(0, P.atkT - dt); P.comboT = Math.max(0, P.comboT - dt); P.hurt = Math.max(0, P.hurt - dt); P.inv = Math.max(0, P.inv - dt);
    G.hit = Math.max(0, G.hit - dt); G.shake = Math.max(0, G.shake - dt); cam.shake = Math.max(0, cam.shake - dt * 1.6);
    if (G.fall > 0) { G.fall += dt; if (G.fall > (STAGED ? 1.3 : 1.8) && !over && !G.done) { G.done = 1; advance(); } }
    // بازیکن
    if (!P.dead) {
      const [mx, my] = mv(); let sp = 0;
      if (P.roll > 0) { P.roll -= dt; sp = 17 * spK(); P.x += Math.sin(P.rd) * sp * dt; P.z += Math.cos(P.rd) * sp * dt; P.yaw = P.rd; }
      else if (mx || my) { const d = camAng(mx, my), m = Math.hypot(mx, my); sp = (P.atkT > 0 ? 4.6 : P.block ? 4.2 : 10.6 * spK()) * m; P.yaw += angDiff(P.yaw, d) * Math.min(1, dt * 14); P.x += Math.sin(d) * sp * dt; P.z += Math.cos(d) * sp * dt; }
      P.walk += sp * dt * 1.8; P.moving = sp;
      if (RANGED && P.atkT > 0 && !P.hitDone && P.atkT < (P.am || 0.3) - (P.heavy ? 0.2 : 0.11)) { P.hitDone = true; fireHero(P.heavy); }
      else if (!RANGED && P.atkT > 0 && !P.hitDone && P.atkT < (P.am || 0.3) - (P.heavy ? 0.2 : 0.11)) {
        P.hitDone = true; const crit = Math.random() < 0.04 * up.crit + (CLS === "Rogue" ? 0.16 : 0); P.critNow = crit; const dm = pd() * (crit ? 1.9 : 1) * (P.heavy ? 2.6 : (1 + P.combo * 0.18) * (P.combo === 2 ? 1.2 : 1)), HV = P.heavy ? 1 : 0; let hit = 0; hitStop = 0.03; if (crit) text(P.x, 3.0, P.z, "✦", "#ffcf5a");
        for (const f of foes) { if (f.wall || f.dead) continue; const dx = f.x - P.x, dz = f.z - P.z, d = Math.hypot(dx, dz); if (d < 2.9 * (SW.len * 0.9 + 0.2) * (HV ? 1.25 : 1) && Math.abs(angDiff(P.yaw, Math.atan2(dx, dz))) < (HV ? 1.9 : CLS === "Warrior" && P.combo === 2 ? 3.2 : 1.25)) { dmgFoe(f, dm, P); if (CLS === "Rogue" && !f.wall && Math.abs(angDiff(f.yaw, Math.atan2(dx, dz))) < 1.1) { dmgFoe(f, dm * 0.9, P); perk("ضربه‌ی مهلک!"); } if (CLS === "Monk" && P.combo === 2) { dmgFoe(f, dm * 0.5, P); dmgFoe(f, dm * 0.5, P); perk("رگبار مشت!"); } if (CLS === "Warrior" && P.combo === 2) perk(); const kb = HV ? 1.9 : 0.7; f.x += dx / (d || 1) * kb; f.z += dz / (d || 1) * kb; f.stun = Math.max(f.stun || 0, HV ? 0.7 : 0.25); hit++; } }
        if (P.z > FRONT - 3.4 && Math.abs(P.x) < GATEW / 2 + 1.6 && Math.abs(angDiff(P.yaw, 0)) < 1.1) { hitGate(dm * 1.5, P.x, P.z); hit++; }
        if (hit) { Sound.sfx("hit", { vol: 0.7 }); cam.shake = Math.max(cam.shake, HV ? 0.3 : 0.1); if (HV) ring(P.x + Math.sin(P.yaw) * 1.5, P.z + Math.cos(P.yaw) * 1.5, 2.6, "#ff9a5a"); } else Sound.sfx("shot_spear", { vol: 0.3 });
        burst(P.x + Math.sin(P.yaw) * 1.8, 1.3, P.z + Math.cos(P.yaw) * 1.8, 5, SW.glow || "#fff", 3); P.critNow = false;
      }
    } else { deadT -= dt; if (deadT <= 0 && !over && (!FIELD || allies.length === 0)) finish(false); }
    bound(P);
    if (!P.dead && lockT && P.roll <= 0 && (P.atkT > 0 || !(key.w || key.s || key.a || key.d || joy.x || joy.y))) P.yaw += angDiff(P.yaw, Math.atan2(lockT.x - P.x, lockT.z - P.z)) * Math.min(1, dt * 12);
    if (stage === 3 && !inHall && P.z > GE.ZK - 13 && Math.abs(P.x) < 8) enterHall();
    // نگهبانان
    spawnT -= dt; const aliveG = foes.filter((f) => !f.wall && !f.dead).length;
    if (spawnT <= 0 && G.hp > 0) { spawnT = Math.max(3.4, 9.5 - power / 22) * (0.8 + Math.random() * 0.4); const n = 1 + (power > 40 ? 1 : 0) + (power > 85 ? 1 : 0); if (aliveG < 6 + (power > 60 ? 3 : 0)) for (let i = 0; i < n; i++) spawnGuard(false); }
    oilT -= dt; if (oilT <= 0 && G.hp > 0) { oilT = Math.max(7, 16 - power / 12); const px = P.z > FRONT - 8 ? P.x : (Math.random() - 0.5) * 8; oils.push({ x: clamp(px, -6, 6), z: FRONT - 2.4, t: 1.9 }); say("روغن داغ از دیوار! جاخالی بده 🔥", 1.8); }
    for (let i = oils.length - 1; i >= 0; i--) { const h = oils[i]; h.t -= dt; if (h.t <= 0) { burst(h.x, 0.5, h.z, 26, "#ff8a3a", 5); ring(h.x, h.z, 2.6, "#ff6a2a"); cam.shake = Math.max(cam.shake, 0.2); if (!P.dead && Math.hypot(P.x - h.x, P.z - h.z) < 2.6) hurtP(14 + power * 0.18); for (const a of allies) if (Math.hypot(a.x - h.x, a.z - h.z) < 2.6) { a.hp -= 12 + power * 0.15; a.hurt = 0.2; } oils.splice(i, 1); } }
    const frac = G.hp / G.max;
    if (!FIELD && G.hp > 0 && captain === 0 && frac < 0.62) { captain = 1; spawnGuard(true); say("سردار نگهبانان آمد! ⚠️", 2.5); Sound.sfx("boss_roar"); cam.shake = 0.4; }
    if (!FIELD && G.hp > 0 && captain === 1 && frac < 0.25) { captain = 2; spawnGuard(true); for (let i = 0; i < 3; i++) spawnGuard(false); say("آخرین سنگر! ⚠️", 2.5); Sound.sfx("boss_roar"); }
    const targets = () => [P, ...allies, ...rams].filter((t) => !t.dead && (t === P ? !P.dead : t.hp > 0));
    const tg = targets();
    for (const f of foes) {
      if (f.dead) { f.deadT -= dt; continue; } f.hurt = Math.max(0, (f.hurt || 0) - dt); f.cdT -= dt;
      if (f.wall) {
        if (f.cdT <= 0 && G.hp > 0) { let b = null, bd = 42; for (const t of tg) { const d = Math.hypot(t.x - f.x, t.z - f.z); if (d < bd && t.z < f.z - 6) { bd = d; b = t; } } if (b) { f.cdT = 2.4 + Math.random() * 1.4; f.yaw = Math.atan2(b.x - f.x, b.z - f.z); const vx = (b === P ? P.vx : 0), t = bd / 18; arrows.push({ x: f.x, y: WALLH + 1.5, z: f.z, tx: b.x + vx * t, tz: b.z + (b.vz || 0) * t, t: 0, T: t, dmg: 5 + power * 0.1, tg: b }); Sound.sfx("shot_bow", { vol: 0.35 }); } else f.cdT = 0.5; }
        continue;
      }
      if (f.stun > 0) { f.stun -= dt; continue; }
      let b = null, bd = 1e9; for (const t of tg) { let d = Math.hypot(t.x - f.x, t.z - f.z); if (t === P) d *= 0.8; if (d < bd) { bd = d; b = t; } }
      if (!b) continue; if (f.hold) { if (bd > 15) continue; f.hold = false; } const dx = b.x - f.x, dz = b.z - f.z, d = Math.hypot(dx, dz), range = 1.5 * (f.sc || 1), want = Math.atan2(dx, dz);
      f.yaw += angDiff(f.yaw, want) * Math.min(1, dt * 10);
      if (d > range) { const s = f.speed * (f.atkA > 0 ? 0.3 : 1); f.x += dx / d * s * dt; f.z += dz / d * s * dt; f.walk += s * dt * 1.8; }
      else if (f.cdT <= 0) { f.cdT = f.kind === "captain" ? 1.15 : f.beast ? 0.95 : 0.95; f.atkA = 0.4; f.hitD = false; }
      if (f.atkA > 0) { f.atkA -= dt; if (!f.hitD && f.atkA < 0.22) { f.hitD = true; if (b === P) hurtP(f.dmg); else if (b.hp > 0) { b.hp -= f.dmg * (b.maxhp ? 2.6 : 1); b.hurt = 0.2; burst(b.x, 1.2, b.z, 3, "#ff8a8a", 2); } } }
      bound(f);
    }
    for (let i = foes.length - 1; i >= 0; i--) if (foes[i].dead && foes[i].deadT <= 0) foes.splice(i, 1);
    if (FIELD && !over) { const left = foes.reduce((n, f) => n + (f.dead ? 0 : 1), 0); if (left === 0) { winT += dt; if (winT > 1.1) finish(true); } }
    // پرتاب تیرها
    for (let i = arrows.length - 1; i >= 0; i--) {
      const a = arrows[i]; a.t += dt; if (a.t >= a.T) { const hitT = (t) => Math.hypot(t.x - a.tx, t.z - a.tz) < 1.1; if (a.tg === P) { if (!P.dead && hitT(P)) hurtP(a.dmg); } else if (a.tg && a.tg.hp > 0 && hitT(a.tg)) { a.tg.hp -= a.dmg * (a.tg.maxhp ? 2.6 : 1); a.tg.hurt = 0.2; } burst(a.tx, 0.2, a.tz, 3, "#cbb89a", 1.5); arrows.splice(i, 1); }
    }
    // یاران
    const slots = allies.length; let fr2 = 0; void fr2;
    for (let i = allies.length - 1; i >= 0; i--) {
      const a = allies[i]; if (a.hp <= 0) { lost++; burst(a.x, 1, a.z, 14, "#c04040", 3); text(a.x, 2.2, a.z, "☠", "#ffb0b0"); corpses.push({ a, t: 1.6, dir: Math.random() < 0.5 ? 1 : -1 }); if (a.ow !== undefined) deadOw[a.ow] = (deadOw[a.ow] || 0) + 1; allies.splice(i, 1); Sound.sfx("enemy_die"); say("🕯️ یکی از یارانت افتاد", 1.6); continue; }
      a.hurt = Math.max(0, a.hurt - dt); a.cdT -= dt; const mul = rallyT > 0 ? 1.4 : 1;
      const fr = order === "attack" ? 40 : order === "gate" && !FIELD ? 5 : order === "regroup" ? 0 : 8;
      let t = null, td = fr || 0; if (fr) for (const f of foes) { if (f.dead) continue; if (f.wall && !a.ranged) continue; const ox = order === "guard" ? P.x : a.x, oz = order === "guard" ? P.z : a.z; const d = Math.hypot(f.x - ox, f.z - oz); if (d < td) { td = Math.hypot(f.x - a.x, f.z - a.z); t = f; fr2 = 1; } }
      let gx, gz, engage = false, range = a.ranged ? 11 : 1.7; a.gate = false;
      if (t) { gx = t.x; gz = t.z; engage = true; if (t.wall) range = 13; }
      else if (order === "gate" && G.hp > 0 && !FIELD) { if (a.ranged) { const w = wallArchers.find((q) => !q.dead); if (w) { gx = w.x; gz = w.z; t = w; engage = true; range = 13; } else { gx = P.x; gz = P.z - 2; range = 1; } } else { gx = clamp((a.off - slots / 2) * 1.1, -4, 4); gz = FRONT - 1 - (a.off % 2) * 0.9; range = 0.3; engage = true; a.gate = true; } }
      else { gx = P.x + Math.cos(a.off * 1.9) * (2.4 + (a.off % 3)); gz = P.z - 1.5 - (a.off % 4) * 1.1; range = 0.6; }
      const dx = gx - a.x, dz = gz - a.z, d = Math.hypot(dx, dz);
      if (d > range) { const pd2 = Math.hypot(a.x - P.x, a.z - P.z), s = a.speed * (rallyT > 0 ? 1.3 : 1) * (!t && pd2 > 12 ? 1.9 : 1); a.x += dx / d * s * dt; a.z += dz / d * s * dt; a.walk += s * dt * 1.8; a.yaw += angDiff(a.yaw, Math.atan2(dx, dz)) * Math.min(1, dt * 10); }
      else if (engage) { a.yaw += angDiff(a.yaw, Math.atan2(dx, dz || 0.001)) * Math.min(1, dt * 10); if (a.cdT <= 0) { a.cdT = (a.ranged ? 1.5 : 0.95) / mul; a.atkA = 0.35; if (a.gate) hitGate(a.dmg * 0.5 * mul, a.x, a.z); else if (t) { if (a.ranged) { arrows.push({ x: a.x, y: 1.5, z: a.z, tx: t.x, tz: t.z, t: 0, T: Math.max(0.2, d / 22), dmg: 0, ally: t, ad: a.dmg * mul }); Sound.sfx("shot_bow", { vol: 0.25 }); } else { dmgFoe(t, a.dmg * mul, a); } } } }
      if (a.atkA > 0) a.atkA -= dt; bound(a);
    }
    // اصلاح تیر یاران
    for (let i = arrows.length - 1; i >= 0; i--) { const a = arrows[i]; if (a.ally && a.t + dt >= a.T && a.ally && !a.done) { a.done = true; if (!a.ally.dead) { if (a.ally.wall) { a.ally.hp -= a.ad; a.ally.hurt = 0.2; if (a.ally.hp <= 0) { a.ally.dead = true; a.ally.deadT = 0.7; kills++; } } else dmgFoe(a.ally, a.ad, a); } } }
    // دروازه‌شکن‌ها
    for (let i = rams.length - 1; i >= 0; i--) {
      const r = rams[i]; if (r.hp <= 0) { burst(r.x, 1, r.z, 20, "#a07a4a", 4); rams.splice(i, 1); continue; }
      if (r.z < FRONT - 1.4) { r.z += 3.6 * dt; r.roll += dt * 5; } else { r.cdT -= dt; if (r.cdT <= 0 && r.hits < 6) { r.cdT = 0.9; r.hits++; r.recoil = 0.3; hitGate(r.dmg, r.x, FRONT); } if (r.hits >= 6) { r.hp -= 9999 * dt; } }
      r.recoil = Math.max(0, (r.recoil || 0) - dt);
    }
    // جداسازی
    const all = [P, ...allies, ...foes.filter((f) => !f.wall && !f.dead)];
    for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) { const a = all[i], b = all[j], dx = b.x - a.x, dz = b.z - a.z, d2 = dx * dx + dz * dz; if (d2 < 0.64 && d2 > 1e-4) { const d = Math.sqrt(d2), p = (0.8 - d) * 0.5; if (a !== P) { a.x -= dx / d * p; a.z -= dz / d * p; } if (b !== P) { b.x += dx / d * p; b.z += dz / d * p; } } }
    // تیرها/گوی‌های جادویی قهرمان
    for (let i = shots.length - 1; i >= 0; i--) {
      const q = shots[i]; q.life -= dt;
      if (q.kind === "orb" && q.tg && !q.tg.dead) { let cur = Math.atan2(q.vx, q.vz); cur += clamp(angDiff(cur, Math.atan2(q.tg.x - q.x, q.tg.z - q.z)), -3.2 * dt, 3.2 * dt); q.vx = Math.sin(cur) * q.sp; q.vz = Math.cos(cur) * q.sp; }
      if (q.kind === "arrow") { if (q.tg && !q.tg.dead) q.vy += ((q.tg.wall ? (SITE ? SITE.wallTop : 6) : gy(q.tg.x, q.tg.z)) + 1.1 - q.y) * 1.2 * dt - 1.5 * dt; else q.vy -= 3 * dt; }
      q.x += q.vx * dt; q.y += q.vy * dt; q.z += q.vz * dt;
      let hit = null; for (const f of foes) { if (f.dead) continue; const dx = f.x - q.x, dz = f.z - q.z, R = (f.wall ? 1.4 : 0.9) * (f.sc || 1); if (dx * dx + dz * dz < R * R) { const fy = f.wall ? (SITE ? SITE.wallTop : 6) : gy(f.x, f.z); if (q.y > fy - 0.3 && q.y < fy + 2.7 * (f.sc || 1)) { hit = f; break; } } }
      let end = true;
      if (hit) impact(q, hit);
      else if (!FIELD && G.hp > 0 && q.z > FRONT && Math.abs(q.x) < GATEW / 2 + 2.5 && q.y < GATEH + 1) { hitGate(q.dmg * 1.2, q.x, q.z); impact(q, null); }
      else if (q.y < gy(q.x, q.z) + 0.1 || q.life <= 0 || Math.abs(q.x) > 60) impact(q, null);
      else { end = false; if (q.kind === "orb" && parts.length < 320) parts.push({ x: q.x, y: q.y, z: q.z, vx: 0, vy: 0.3, vz: 0, life: 0.4, max: 0.4, c: q.col, s: 0.16, add: 1 }); }
      if (end) shots.splice(i, 1);
    }
    if (lockT && (lockT.dead || lockT.hp <= 0)) { lockT = nearestFoe(); if (!lockT) $("s3lock").classList.remove("on"); }
    if (lockT && Math.hypot(lockT.x - P.x, lockT.z - P.z) > 46) { lockT = null; $("s3lock").classList.remove("on"); }
    if (CLS === "Cleric" && !P.dead) { healT -= dt; if (healT <= 0) { healT = 7; perk("موج شفا ✨"); ring(P.x, P.z, 6, "#fff0a0"); P.hp = Math.min(P.maxhp, P.hp + P.maxhp * 0.07); for (const a of allies) if (Math.hypot(a.x - P.x, a.z - P.z) < 8) { a.hp = Math.min(a.maxhp, a.hp + a.maxhp * 0.15); burst(a.x, 1, a.z, 5, "#fff0a0", 2); } Sound.sfx("skill_kaveh", { vol: 0.35 }); } }
    // غیرنظامیان
    for (const c of civs) { const dP = Math.hypot(c.x - P.x, c.z - P.z); let fx = 0, fz = 0; if (dP < 10) { fx += (c.x - P.x) / dP; fz += (c.z - P.z) / dP; } for (const f of foes) { if (f.dead || f.wall) continue; const d = Math.hypot(c.x - f.x, c.z - f.z); if (d < 6 && d > 0.01) { fx += (c.x - f.x) / d; fz += (c.z - f.z) / d; } } if (burnT > 0) { fx += Math.sin(c.ph * 3 + time); fz += Math.cos(c.ph * 2 + time); }
      const m = Math.hypot(fx, fz); let sp = 0.9; c.ph += dt * 0.4; if (m > 0.1) { sp = 5; c.x += fx / m * sp * dt; c.z += fz / m * sp * dt; c.yaw += angDiff(c.yaw, Math.atan2(fx, fz)) * Math.min(1, dt * 10); } else { c.x += Math.sin(c.ph * 2) * 0.9 * dt; c.z += Math.cos(c.ph * 1.7) * 0.9 * dt; c.yaw += angDiff(c.yaw, Math.atan2(Math.sin(c.ph * 2), Math.cos(c.ph * 1.7))) * Math.min(1, dt * 3); }
      c.walk += sp * dt * 1.8; c.x = clamp(c.x, -GE.HW + 6, GE.HW - 6); c.z = clamp(c.z, ZG + 5, ZI - 4); collide(c, 0.6); }
    // مراحل
    if (STAGED && !over) {
      if (stage === 1 && aliveFoes() === 0) courtClear();
      else if (stage === 5 && aliveFoes() === 0) { stage = 4; capPt(); }
      else if (stage === 4 && !capDone) { const near = Math.hypot(P.x - CAPX, P.z - CAPZ) < 3.4 && !P.dead; capT = near ? capT + dt : Math.max(0, capT - dt * 0.6); if (capT >= 2.2) { capDone = true; showCapture(); } }
      if (burnT > 0) { burnT -= dt; if (burnT <= 0 && !over) finish(true); }
    }
    // ذرات
    for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.life -= dt; if (p.life <= 0) { parts.splice(i, 1); continue; } if (!p.ring) { p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.vy -= 9 * dt; if (p.y < 0.05) { p.y = 0.05; p.vy *= -0.3; } } }
    for (let i = texts.length - 1; i >= 0; i--) { const t = texts[i]; t.life -= dt; t.y += dt * 1.2; if (t.life <= 0) texts.splice(i, 1); }
    // دوربین
    { const M = CAMM[camMode]; cam.dist = lerp(cam.dist, M.dist, Math.min(1, dt * 4)); cam.h = lerp(cam.h, M.h, Math.min(1, dt * 4)); if (cam.modeT > 0) { cam.modeT -= dt; cam.pb = lerp(cam.pb, M.pitch, Math.min(1, dt * 6)); } cam.dragT = Math.max(0, cam.dragT - dt);
      if (camMode <= 1 && !camTouch && cam.dragT <= 0 && !P.dead && P.moving > 1) { const [mx2] = mv(); cam.yaw += angDiff(cam.yaw, P.yaw) * Math.min(1, dt * 1.6 * Math.min(1, Math.abs(mx2) * 1.3)); } }
    if (lockT && !P.dead && cam.dragT <= 0) { const yt = Math.atan2(lockT.x - P.x, lockT.z - P.z); cam.yaw += angDiff(cam.yaw, yt) * Math.min(1, dt * 3.2); }
    { const lf = lockT && !P.dead ? 0.32 : 0, ltx = P.x + (lockT ? (lockT.x - P.x) * lf : 0), ltz = P.z + (lockT ? (lockT.z - P.z) * lf : 0); cam.tx = lerp(cam.tx, ltx, Math.min(1, dt * 12)); cam.tz = lerp(cam.tz, ltz, Math.min(1, dt * 12)); if (lockT) cam.dist += Math.min(5, Math.hypot(lockT.x - P.x, lockT.z - P.z) * 0.22) * Math.min(1, dt * 3); }

    P.vx = Math.sin(P.yaw) * (P.moving || 0); P.vz = Math.cos(P.yaw) * (P.moving || 0);
    if (!over && time > LIMIT) { finish(false); say("وقت تمام شد!", 2); }
    // HUD
    $("s3php").style.width = (P.hp / P.maxhp * 100) + "%"; $("s3pt").textContent = Math.ceil(P.hp);
    if (FIELD || (STAGED && (stage === 1 || stage >= 3))) { let cur = 0, left = 0; for (const f of foes) if (!f.dead) { cur += Math.max(0, f.hp); left++; } $("s3ghp").style.width = (cur / Math.max(1, enemyTotal) * 100) + "%"; $("s3gt").textContent = stage === 4 ? "پرچم " + Math.round(capT / 2.2 * 100) + "٪" : "دشمن " + left; if (stage === 4) $("s3ghp").style.width = (capT / 2.2 * 100) + "%"; } else { $("s3ghp").style.width = (G.hp / G.max * 100) + "%"; $("s3gt").textContent = "دروازه " + Math.ceil(G.hp); }
    $("s3lvn").textContent = HX.lv; $("s3xp").style.width = (HX.xp / heroNeed(HX.lv) * 100) + "%"; $("s3dot").style.display = HX.pts > 0 ? "block" : "none";
    $("s3time").textContent = Math.max(0, Math.ceil(LIMIT - time)) + "s";
    const setCd = (id, v, m) => { const el = $(id); el.style.height = v > 0 ? (v / m * 100) + "%" : "0"; el.parentElement.classList.toggle("cd", v > 0); };
    setCd("s3c1", cd.spec, 9); setCd("s3c2", cd.rally, 24); setCd("s3c3", cd.ram, 28); setCd("s3c4", cd.bolt, 30);
  }
  function finish(won, quit) {
    if (over) return; over = true; endWon = won; const f = P.hp / P.maxhp, stars = !won ? 0 : 1 + (f > 0.4 ? 1 : 0) + (time < 100 ? 1 : 0);
    const lostBy = {}; const alive = {}; for (const a of allies) if (a.ow === undefined) alive[a.kind] = (alive[a.kind] || 0) + 1; for (const k in armyIn) { const l = armyIn[k] - (alive[k] || 0); if (l > 0) lostBy[k] = l; } if (!quit && S.ow && S.ow.allies) { const cntOf = (g) => Math.min(4, Math.max(2, g.n)); const gs = S.ow.allies.slice(); gs.forEach((g, gi) => { const d = deadOw[gi] || 0; if (!d) return; const fr = d / cntOf(g); if (fr >= 1) g.pow = 0; else { g.n = Math.max(1, Math.round(g.n * (1 - fr))); g.pow = Math.round(g.pow * (1 - fr)); } }); S.ow.allies = S.ow.allies.filter((g) => g.pow >= 3); }
    const back = quit ? {} : applyLosses(lostBy), ndead = Object.values(back).reduce((a, b) => a + b, 0);
    const done = () => { cleanup(); onEnd({ won, stars, kills, built: 0, skills: 0, evolves: 0, lives: 1, maxLives: 1, wave: 0, troopsSent: nAll, lostUnits: ndead, quit: !!quit, capture, site: nb.site ? nb.site.name : null }); }; setTimeout(() => { if (!quit && heroInit().pts > 0) openUp(true, done); else done(); }, quit ? 0 : 500);
  }
  function cleanup() { if (ended) return; ended = true; cancelAnimationFrame(raf); removeEventListener("keydown", onKD); removeEventListener("keyup", onKU); removeEventListener("resize", resize); try { C3.setMode("atlas"); } catch (e) { /* */ } root.remove(); document.body.classList.remove("inbattle"); delete window.__s3d; }
  window.__s3d = { back() { act(paused ? "resume" : "pause"); }, gl: () => GLOK, dbg: { P, foes, allies, cam, civs, shots, gate0, gate1, W3, cd, get S() { return SITE; }, get stage() { return stage; }, get lock() { return lockT; }, get G() { return G; }, act, hitGate, finish, pickCap, get capDone() { return capDone; } } };

  // ---------- رندر (WebGL: world3d) ----------
  const FIXSC = /[?&]fixscale/.test(location.search); let lowN = 0, hiN = 0; let GLOK = false, SITE = null, dtR = 0.016, lastR = 0, fpsN = 0, fpsT = 0, fpsV = 60;
  const LOOK = lookOf(AV), EMPTY = {};
  const cc = (() => { const m = {}; return (h) => m[h] || (m[h] = hex(String(h).slice(0, 7)).map((v) => v / 255)); })();
  const gy = (x, z) => heightAt(x, z);
  const bars = [];
  const BEAST_LOOK = { wolf: { tint: [1, 1, 1] }, bear: { tint: [0.62, 0.42, 0.28] }, boar: { tint: [0.72, 0.52, 0.4] }, lion: { tint: [1.25, 0.98, 0.55] } };
  const WOLF_YAW = 0;
  function buildRamMesh() {
    if (W3.models.s_ram) return;
    const P = [], N = [], C = [];
    const tri = (a, b, c, col) => { const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2]; let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; const l = Math.hypot(nx, ny, nz) || 1; for (const p of [a, b, c]) { P.push(p[0], p[1], p[2]); N.push(nx / l, ny / l, nz / l); C.push(col[0], col[1], col[2], 0); } };
    const quad = (a, b, c, d, col) => { tri(a, b, c, col); tri(a, c, d, col); };
    const box = (cx, cy, cz, sx, sy, sz, col) => { const x0 = cx - sx / 2, x1 = cx + sx / 2, y0 = cy - sy / 2, y1 = cy + sy / 2, z0 = cz - sz / 2, z1 = cz + sz / 2; quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], col); quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], col); quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], col); quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], col); quad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], col); quad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], col); };
    const wood = [128, 88, 52], dark = [84, 56, 32], iron = [70, 72, 80], roof = [150, 62, 46];
    box(-1.2, 0.9, 0, 0.2, 1.8, 3.6, dark); box(1.2, 0.9, 0, 0.2, 1.8, 3.6, dark); box(0, 1.4, 0.4, 0.8, 0.8, 4.4, wood); box(0, 1.4, 2.8, 1.0, 1.0, 0.8, iron);
    for (const sx of [-1.2, 1.2]) for (const sz of [-1.2, 1.2]) box(sx, 0.4, sz, 0.2, 0.8, 0.8, [50, 34, 22]);
    box(0, 2.2, 0, 3, 0.2, 4.4, roof);
    addMesh("s_ram", { pos: new Float32Array(P), nor: new Float32Array(N), col: new Uint8Array(C), h: 2.4, w: 4.4, cap: 16 });
  }
  async function initGL() {
    W3.scale = 1;
    const ok = await initWorld(cv, {}).catch(() => false); W3.mirrorX = true; W3.scale = (navigator.maxTouchPoints || 0) > 0 ? 0.8 : 1;
    if (ended) return;
    if (!ok) { say("⚠️ WebGL2 پشتیبانی نمی‌شود", 3); setTimeout(() => finish(false, true), 2200); return; }
    C3.setMode("ext"); await SQ.init().catch(() => false); if (ended) return;
    let tc = (nb.site && nb.site.color) || [0.7, 0.15, 0.15]; if (Math.max(...tc) > 1.5) tc = tc.map((v) => v / 255);
    SITE = buildSite({ kind: KIND, id: nb.id, seed: ((nb.power | 0) * 31 + 7) | 0, power, tlvl: nb.tlvl, color: tc }, W3.models);
    for (const n in W3.models) if (/Tree|Palm|Bush|Flower|Plant|Grass|Petals|Rock|^sn_/.test(n)) growModel(n, 2048);
    SITE.wallTop = (SITE.WALLH || 6) + 0.3; buildRamMesh();
    const cell = 1.5, nx = Math.ceil((SITE.x1 - SITE.x0) / cell) + 1, nz = Math.ceil((SITE.z1 - SITE.z0) / cell) + 1;
    setTerrain({ x0: SITE.x0, z0: SITE.z0, x1: SITE.x1, z1: SITE.z1, nx, nz, h: SITE.H, color: SITE.color, wl: -1e9 });
    const b = SITE.bio; ENV.top = b.sky[0]; ENV.hor = b.sky[1]; ENV.fogc = b.fog; ENV.sun = b.sun; ENV.fogd = [70, 250]; ENV.sky = b.sky[1].map((v) => v * 0.85 + 0.1); ENV.gnd = hex(b.g1).map((v) => v / 255 * 0.8 + 0.1);
    { const cd = CLSD[CLS]; $("s3perk").innerHTML = `<b>${cd[0]}</b><span>${cd[1]}: ${cd[2]}</span>`; if (STAGED) setObj(OBJ[0]); }
    GLOK = true; resize();
    if (FIELD) { cam.tx = P.x; cam.tz = P.z; }
  }
  const visP = (x, y, z, m = 90) => { const p = project(x, y, z); return p && p[0] > -m && p[0] < W + m && p[1] > -m && p[1] < H + m && p[2] < 200 ? p : null; };
  function ringFx(x, y, z, R, c, a, sz) { const n = Math.min(30, 10 + (R * 5 | 0)); for (let i = 0; i < n; i++) { const t = i / n * TAU; decal(x + Math.cos(t) * R, y, z + Math.sin(t) * R, sz, c[0], c[1], c[2], a); } }
  // شخصیت اسکلتی: انیمیشن + رسم
  function actor(e, team, kind, seed, st) {
    if (!e._g) { const sp0 = team === "hero" ? SQ.heroSpec(AV, LOOK) : SQ.spec(team, kind, seed); if (e.dark) Object.assign(sp0.pal, { skin: [0.5, 0.55, 0.7], cloth: [0.16, 0.1, 0.28], cloth2: [0.08, 0.05, 0.16], pants: [0.1, 0.08, 0.14], metal: [0.28, 0.26, 0.4] }); e._g = SQ.make(sp0, seed); }
    const g = e._g, y = st.y !== undefined ? st.y : gy(e.x, e.z); let sc = st.sc || 1; st.x = e.x; st.z = e.z; st.dt = dtR; SQ.drive(g, st);
    if (st.alpha !== undefined && st.alpha < 1) sc *= Math.max(0.05, st.alpha);
    const p = visP(e.x, y + 1, e.z); if (!p) return false;
    if (st.alpha === undefined || st.alpha > 0.5) shadow(e.x, y, e.z, 0.85 * sc, 0.42);
    drawChar(g, e.x, y, e.z, e.yaw, { sc, flash: st.flash || 0 }); return y;
  }
  function hpBar(f, y) { bars.push([f.x, y + 2.5 * (f.sc || 1), f.z, 46 * (f.sc || 1), clamp(f.hp / f.maxhp, 0, 1), f.kind === "captain" ? "#ff5a5a" : "#e6c04a"]); }
  function drawWolf(f, dead) {
    const Bk = BEAST_LOOK[f.beast] || BEAST_LOOK.wolf, dk = dead ? 1 - f.deadT / 0.7 : 0, sc = (f.sc || 1) * 0.62 * (dead ? Math.max(0.2, f.deadT / 0.7) : 1);
    const atk = f.atkA > 0 ? 1 - f.atkA / 0.4 : 0, bite = Math.sin(atk * Math.PI), lunge = bite * 0.5 * (f.sc || 1), x = f.x + Math.sin(f.yaw) * lunge, z = f.z + Math.cos(f.yaw) * lunge, mv = dead || f.stun > 0 ? 0.1 : 1;
    const y = gy(x, z) + Math.abs(Math.sin((f.walk || 0) * 0.85)) * 0.1 * mv * (f.sc || 1);
    if (!visP(x, y + 1, z)) return y;
    shadow(x, y, z, 1.0 * (f.sc || 1), 0.42); inst("wolf", x, y, z, f.yaw + WOLF_YAW, sc, { tint: Bk.tint, rx: -bite * 0.3 + Math.sin((f.walk || 0) * 0.85) * 0.07 * mv + dk * 0.9, noLod: 1 }); return y;
  }
  function render() {
    const nowR = performance.now(); dtR = Math.min(0.05, Math.max(0.001, (nowR - (lastR || nowR)) / 1000)); lastR = nowR;
    const M = CAMM[camMode], w = W3.cam, sh = cam.shake > 0 ? cam.shake : 0;
    cam.pitch = cam.pb || M.pitch; w.x = cam.tx + (Math.random() - 0.5) * sh * 0.5; w.z = cam.tz + (Math.random() - 0.5) * sh * 0.5; w.y = gy(cam.tx, cam.tz) + 1.5 + (Math.random() - 0.5) * sh * 0.5; w.yaw = cam.yaw; w.pitch = cam.pitch; w.dist = cam.dist; w.minY = 1.2; w.fov = 0.82;
    frameBegin(dtR); W3.stats.tris = 0; drawTerrain(); bars.length = 0;
    // ساکن‌ها
    { const e = W3.eye, st = SITE.statics; for (let i = 0; i < st.length; i++) { const o = st[i], dx = o.x - e[0], dz = o.z - e[2], dd = o.d || 200; if (dx * dx + dz * dz > dd * dd) continue; inst(o.n, o.x, o.y, o.z, o.yaw, o.s, o.o || EMPTY); } }
    for (const f of SITE.fires.concat(dfires)) { const dx = f[0] - W3.eye[0], dz = f[2] - W3.eye[2]; if (dx * dx + dz * dz > 6400) continue; const fl = 0.8 + Math.sin(time * 17 + f[0] * 3) * 0.2; puff(f[0], f[1] + 0.2, f[2], f[3] * 0.34 * fl, 1, 0.6, 0.2, 0.7, true); const ph = (time * 0.6 + f[0] * 0.13) % 1; puff(f[0] + Math.sin(ph * 5) * 0.2, f[1] + 0.8 + ph * 2.6, f[2], 0.3 + ph * 0.9, 0.3, 0.3, 0.32, 0.28 * (1 - ph)); }
    if (!FIELD) { // دروازه
      const gt = SITE.M, sw = gate0.shake > 0 ? Math.sin(time * 90) * 0.08 : 0, sw1 = gate1.shake > 0 ? Math.sin(time * 90) * 0.08 : 0;
      if (gate0.hp > 0) inst(gt.gate, SITE.gateX + sw, gy(0, SITE.gateZ), SITE.gateZ, 0, SITE.SW, { big: 1, team: SITE.team }); else inst(gt.open, SITE.gateX, gy(0, SITE.gateZ), SITE.gateZ, 0, SITE.SW, { team: SITE.team });
      if (CASTLE) inst(stage >= 3 ? gt.open : gt.gate, sw1, gy(0, ZI), ZI, 0, SITE.SW * 0.7, { big: 1, team: SITE.team });
    }
    for (const r of rams) { const rc = r.recoil || 0; inst("s_ram", r.x, gy(r.x, r.z), r.z - rc * 3, 0, 1, EMPTY); shadow(r.x, gy(r.x, r.z), r.z, 2.2, 0.4); }
    for (const a of arrows) { if (a.ad === undefined && !(a.dmg >= 0)) continue; const t = a.t / a.T, y1 = gy(a.tx, a.tz) + 0.8, ay = (u) => lerp(a.y, y1, u) + Math.sin(u * Math.PI) * 2.2, dx = a.tx - a.x, dz = a.tz - a.z, hl = Math.hypot(dx, dz) || 1, dy = (y1 - a.y) + Math.cos(t * Math.PI) * 2.2 * Math.PI;
      inst("i_arrow", lerp(a.x, a.tx, t), ay(t), lerp(a.z, a.tz, t), Math.atan2(dx, dz), 0.7, { rx: Math.PI / 2 - Math.atan2(dy, hl), noLod: 1, noCull: 1 }); if (!a.ally && a.tg === P) ringFx(a.tx, gy(a.tx, a.tz) + 0.06, a.tz, 0.9, [1, 0.27, 0.27], 0.6, 0.3); }
    for (const q of shots) if (q.kind === "arrow") inst("i_arrow", q.x, q.y, q.z, Math.atan2(q.vx, q.vz), 0.85, { rx: Math.PI / 2 - Math.atan2(q.vy, Math.hypot(q.vx, q.vz)), noLod: 1, noCull: 1 });
    if (stage === 4 && !capDone) inst("d_banner", CAPX, gy(CAPX, CAPZ), CAPZ, Math.PI, 1.1, { team: SITE.team, noLod: 1 });
    // شخصیت‌ها
    for (const c of civs) actor(c, "civ", "civ", c.id * 37 + 5, { sc: c.sc });
    if (!(P.inv > 0 && Math.floor(time * 20) % 2 && P.roll <= 0)) actor(P, "hero", "hero", 1, { atk: P.atkT, atkMax: P.am || 0.46, combo: P.heavy ? 1 : P.combo, block: P.block, hurt: P.hurt, dead: P.dead, deadDur: 1.4, roll: P.roll, sc: 1.0 });
    for (const a of allies) { actor(a, "ally", a.kind, (parseInt(String(a.id).replace(/\D/g, "")) || 1) * 31 + 7, { atk: a.atkA > 0 ? a.atkA : 0, atkMax: 0.35, hurt: a.hurt || 0, sc: a.sc || 1 }); }
    for (let i = corpses.length - 1; i >= 0; i--) { const c = corpses[i]; c.t -= dtR; if (c.t <= 0) { corpses.splice(i, 1); continue; } const a = c.a; actor(a, "ally", a.kind, (parseInt(String(a.id).replace(/\D/g, "")) || 1) * 31 + 7, { dead: true, deadDur: 1.25, alpha: Math.min(1, c.t / 0.5), sc: a.sc || 1 }); }
    for (const f of foes) {
      if (f.dead && f.deadT < 0) continue; const dead = f.dead;
      if (f.beast) { const y = drawWolf(f, !!dead); if (!dead && f.hp < f.maxhp) hpBar(f, y); continue; }
      const y0 = f.wall ? SITE.wallTop : undefined, y = actor(f, "foe", f.kind, Math.floor((f.id || 1) * 99991) % 100000 + 5, { atk: f.atkA > 0 ? f.atkA : 0, atkMax: 0.4, hurt: f.hurt || 0, dead: !!dead, deadDur: 0.7, y: y0, alpha: dead ? Math.max(0, Math.min(1, f.deadT / 0.3)) : 1, sc: f.sc || 1 });
      if (y !== false && ((!dead && !f.wall && f.hp < f.maxhp) || (f.kind === "captain" && !dead))) hpBar(f, y);
    }
    flushModels();
    // اثرها
    for (const h of oils) { const k = Math.sin(time * 14) * 0.15 + 0.45, g0 = gy(h.x, h.z) + 0.06; decal(h.x, g0, h.z, 2.6, 1, 0.22, 0.1, k); ringFx(h.x, g0 + 0.01, h.z, 2.3, [1, 0.8, 0.3], 0.8, 0.28); }
    if (LOOK.aura && !P.dead) { const ac = cc(LOOK.aura.col || "#ffd24a"); puff(P.x, gy(P.x, P.z) + 1.0, P.z, 1.1, ac[0], ac[1], ac[2], 0.35, true); if (Math.random() < 0.5) parts.push({ x: P.x + (Math.random() - 0.5) * 1.4, y: gy(P.x, P.z) + 0.2, z: P.z + (Math.random() - 0.5) * 1.4, vx: 0, vy: 1.6 + Math.random(), vz: 0, life: 0.9, max: 0.9, c: LOOK.aura.col || "#ffd24a", s: 0.07 + Math.random() * 0.05, add: 1 }); }
    if (P.atkT > 0 && SW.glow) { const p = 1 - P.atkT / (P.am || 0.46), a = P.yaw + (p - 0.5) * 1.6, c = cc(SW.glow); puff(P.x + Math.sin(a) * 1.7, gy(P.x, P.z) + 1.4, P.z + Math.cos(a) * 1.7, 0.5, c[0], c[1], c[2], 0.7, true); }
    for (const p of parts) { const k = p.life / p.max, c = cc(p.c); if (p.ring) { ringFx(p.x, gy(p.x, p.z) + 0.07, p.z, p.r * (0.3 + (1 - k) * 0.7), c, k * 0.9, 0.34 + p.r * 0.04); } else puff(p.x, p.y, p.z, p.s * 2.4, c[0], c[1], c[2], clamp(k * 1.4, 0, 1) * 0.9, p.add); }
    for (const q of shots) if (q.kind === "orb") { const c = cc(q.col); puff(q.x, q.y, q.z, 1.0, c[0], c[1], c[2], 0.75, true); puff(q.x, q.y, q.z, 0.45, 1, 1, 1, 0.95, true); }
    if (lockT && !lockT.dead) { const sc = lockT.sc || 1, y = lockT.wall ? SITE.wallTop : gy(lockT.x, lockT.z); if (!lockT.wall) ringFx(lockT.x, y + 0.06, lockT.z, 1.0 * sc + Math.sin(time * 6) * 0.08, [1, 0.2, 0.15], 0.95, 0.26); puff(lockT.x, y + 2.9 * sc + Math.sin(time * 5) * 0.12, lockT.z, 0.38, 1, 0.2, 0.15, 0.95, true); }
    if (stage === 4 && !capDone) { const y = gy(CAPX, CAPZ) + 0.07; ringFx(CAPX, y, CAPZ, 3.4, [1, 0.85, 0.3], 0.55, 0.34); ringFx(CAPX, y + 0.01, CAPZ, 3.4 * clamp(capT / 2.2, 0, 1), [1, 1, 0.6], 0.95, 0.3); puff(CAPX, y + 4 + Math.sin(time * 3) * 0.3, CAPZ, 0.7, 1, 0.9, 0.4, 0.5, true); }
    if (burnT > 0 && SITE.bl) { const k = clamp(1 - burnT / 3.8, 0.15, 1); for (const b of SITE.bl) { const w = (W3.models[b.n] ? W3.models[b.n].w : 1) * b.s * 0.45, h = (W3.models[b.n] ? W3.models[b.n].h : 1) * b.s; for (let j = 0; j < 3; j++) { const fx = b.x + (Math.random() - 0.5) * w, fz = b.z + (Math.random() - 0.5) * w, fy = b.y + h * (0.25 + Math.random() * 0.8); puff(fx, fy, fz, (1.2 + Math.random() * 1.6) * k, 1, 0.45 + Math.random() * 0.25, 0.12, 0.8, true); } puff(b.x + (Math.random() - 0.5) * w, b.y + h * 1.1 + Math.random() * 3, b.z + (Math.random() - 0.5) * w, 2.4 * k, 0.18, 0.17, 0.17, 0.45 * k); } }
    frameEnd();
    // رویه‌ی دوبعدی: نوار جان، اعداد
    ov.setTransform(oDpr, 0, 0, oDpr, 0, 0); ov.clearRect(0, 0, W, H);
    for (const b of bars) { const q = visP(b[0], b[1], b[2], 40); if (!q) continue; const bw = b[3] * clamp(36 / q[2] + 0.55, 0.55, 1.5), s0 = q[0] - bw / 2; ov.fillStyle = "rgba(0,0,0,.6)"; ov.fillRect(s0 - 1, q[1] - 1, bw + 2, 7); ov.fillStyle = b[5]; ov.fillRect(s0, q[1], bw * b[4], 5); }
    ov.textAlign = "center"; ov.font = "800 16px Vazirmatn, sans-serif"; ov.lineWidth = 3; ov.strokeStyle = "rgba(0,0,0,.7)";
    for (const t of texts) { const q = project(t.x, t.y, t.z); if (!q || q[2] < 0.5) continue; ov.globalAlpha = clamp(t.life * 2, 0, 1); ov.fillStyle = t.c; ov.strokeText(t.t, q[0], q[1]); ov.fillText(t.t, q[0], q[1]); } ov.globalAlpha = 1;
    hurtEl.style.opacity = P.hurt > 0 ? P.hurt * 0.8 : 0;
    fpsN++; fpsT += dtR; if (fpsT > 0.5) { fpsV = fpsN / fpsT; fpsN = 0; fpsT = 0; if (!FIXSC && time > 4) { if (fpsV < 26 && W3.scale > 0.6) { if (++lowN >= 3) { W3.scale = Math.max(0.6, W3.scale - 0.12); lowN = 0; resize(); } } else if (fpsV > 56 && W3.scale < 1) { if (++hiN >= 8) { W3.scale = Math.min(1, W3.scale + 0.1); hiN = 0; resize(); } } else { lowN = 0; hiN = 0; } } if (fpsEl) fpsEl.textContent = `${fpsV.toFixed(0)}fps • ${(W3.stats.tris / 1000).toFixed(0)}k tri • ${W3.stats.draws} draws • ${W3.stats.inst} inst • x${W3.scale.toFixed(2)}`; }
  }

  function loop(now) {
    raf = requestAnimationFrame(loop); let dt = Math.min(0.05, (now - last) / 1000); last = now; if (paused || !GLOK) return;
    if (hitStop > 0) { hitStop -= dt; dt *= 0.15; }
    if (!over || G.fall > 0) update(dt); else update(dt * 0.3); render();
  }
  if (FIELD) { const rb = root.querySelector('[data-s=ram]'); if (rb) rb.style.display = 'none'; const gb = root.querySelector('[data-s=o_gate]'); if (gb) gb.style.display = 'none'; }
  updCmd(); try { const ar = ARMY(); if (!ar.seen) { ar.seen = 1; setTimeout(() => say("با 🗡️ حمله کن، با 🌀 جاخالی بده؛ دستورها را از تب 📣 سمت چپ به یاران بده", 5), 3500); } } catch (e) { /* */ }
  Sound.playMusic("attack", { intensity: 0.8 });
  say(FIELD ? `نبرد در میدان! ${nb.name} را نابود کن ⚔️` : `به ${nb.name} حمله کن! دروازه را بشکن ⚔️`, 3.2);
  raf = requestAnimationFrame(loop); initGL(); resize();
}

// پیش‌نمایش شخصیت برای فروشگاه (چرخان)
export function avatarPreview(canvas, av, getAv) {
  const ctx = canvas.getContext("2d"); let t = 0, raf = 0, alive = true;
  const fake = { skin: "#000" }; void fake;
  function frame() {
    if (!alive || !canvas.isConnected) { return; } raf = requestAnimationFrame(frame); t += 0.016; const a = getAv ? getAv() : av, W = canvas.width, H = canvas.height; ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, W, H);
    const g = ctx.createRadialGradient(W / 2, H * 0.6, 10, W / 2, H * 0.6, H * 0.7); g.addColorStop(0, "#4a3a66"); g.addColorStop(1, "#1a1428"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    mini(ctx, W, H, a, t);
  }
  frame(); return () => { alive = false; cancelAnimationFrame(raf); };
}
// رندر کوچک مستقل برای پیش‌نمایش (دو‌بعدی شبه‌سه‌بعدی با اجزای هندسی)
function mini(ctx, W, H, av, t) {
  const SW = find("sword", av.sword), SH = find("shield", av.shield), HM = find("helm", av.helm), AR = find("armor", av.armor), CP = find("cape", av.cape);
  const u = H / 3.0, cx = W / 2, gy = H * 0.93, ry = Math.sin(t * 1.2), rot = t * 0.8, cr = Math.cos(rot), sr = Math.sin(rot);
  ctx.fillStyle = "rgba(0,0,0,.35)"; ctx.beginPath(); ctx.ellipse(cx, gy, u * 0.9, u * 0.25, 0, 0, TAU); ctx.fill();
  const X = (x, z) => cx + (x * cr + z * sr) * u, Zd = (x, z) => -x * sr + z * cr;
  const P2 = (x, y, z) => [X(x, z), gy - y * u + Zd(x, z) * u * 0.08];
  const items = [];
  const bx = (x, y, z, w, h, d, col, fn) => items.push({ d: Zd(x, z), f() { const [px, py] = P2(x, y, z), k = 0.78 + 0.22 * (Zd(x, z) < 0 ? 1 : 0.8); ctx.fillStyle = rgb(hex(col), k); const W2 = (Math.abs(w * cr) + Math.abs(d * sr)) * u; ctx.beginPath(); roundRect(ctx, px - W2 / 2, py - h * u / 2, W2, h * u, Math.min(6, W2 / 3)); ctx.fill(); ctx.strokeStyle = rgb(hex(col), 0.45); ctx.lineWidth = 1; ctx.stroke(); if (fn) fn(px, py, W2); } });
  const cp = CP.color;
  if (cp) bx(0, 1.0, -0.22, 0.66, 1.05, 0.08, cp);
  bx(0.16, 0.38, 0, 0.24, 0.76, 0.26, "#3a3f4a"); bx(-0.16, 0.38, 0, 0.24, 0.76, 0.26, "#3a3f4a");
  bx(0, 1.15, 0, 0.66, 0.76, 0.36, AR.color || av.tunic); bx(0, 0.84, 0, 0.7, 0.12, 0.4, "#5a3a1a");
  if (AR.id !== "a0") { bx(0.43, 1.52, 0, 0.26, 0.2, 0.3, AR.color); bx(-0.43, 1.52, 0, 0.26, 0.2, 0.3, AR.color); }
  bx(-0.42, 1.12, 0, 0.17, 0.62, 0.17, av.skin); if (SH.id !== "d0") bx(-0.55, 1.1, 0.25, 0.1, 0.8, 0.6, SH.color, (px, py, w) => { if (SH.emblem) { ctx.fillStyle = "#c43a3a"; ctx.beginPath(); ctx.arc(px, py, w * 0.18, 0, TAU); ctx.fill(); } });
  bx(0.42, 1.12, 0.2, 0.17, 0.62, 0.17, av.skin);
  const sw = (px, py) => { const L = 1.2 * SW.len * u; ctx.save(); ctx.translate(px, py); ctx.rotate(-0.12 + ry * 0.05); if (SW.glow) { const g = ctx.createRadialGradient(0, -L / 2, 0, 0, -L / 2, L * 0.7); g.addColorStop(0, SW.glow + "aa"); g.addColorStop(1, "rgba(0,0,0,0)"); ctx.fillStyle = g; ctx.fillRect(-L, -L * 1.3, L * 2, L * 1.6); } ctx.fillStyle = SW.blade; ctx.beginPath(); ctx.moveTo(-u * 0.05, 0); ctx.lineTo(-u * 0.05, -L); ctx.lineTo(0, -L - u * 0.12); ctx.lineTo(u * 0.05, -L); ctx.lineTo(u * 0.05, 0); ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.3)"; ctx.stroke(); ctx.fillStyle = SW.hilt; ctx.fillRect(-u * 0.17, -u * 0.04, u * 0.34, u * 0.08); ctx.fillRect(-u * 0.04, 0, u * 0.08, u * 0.22); if (SW.twin) { ctx.fillStyle = SW.blade; ctx.fillRect(-u * 0.16, -L * 0.8, u * 0.32, u * 0.07); } ctx.restore(); };
  items.push({ d: Zd(0.5, 0.45) - 1, f() { const [px, py] = P2(0.42, 0.88, 0.45); sw(px, py); } });
  bx(0, 1.62, 0, 0.14, 0.14, 0.14, av.skin);
  items.push({ d: Zd(0, 0) - 0.5, f() { const [px, py] = P2(0, 1.86, 0), R = 0.27 * u; const g = ctx.createRadialGradient(px - R * 0.35, py - R * 0.4, R * 0.1, px, py, R); g.addColorStop(0, rgb(hex(av.skin), 1.2)); g.addColorStop(1, rgb(hex(av.skin), 0.7)); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, R, 0, TAU); ctx.fill(); ctx.strokeStyle = rgb(hex(av.skin), 0.4); ctx.stroke();
    const face = cr > 0.1 ? 1 : 0; const cover = (col, r, dy) => { const gg = ctx.createRadialGradient(px - R * 0.3, py + dy - R * 0.4, R * 0.1, px, py + dy, r); gg.addColorStop(0, rgb(hex(col), 1.2)); gg.addColorStop(1, rgb(hex(col), 0.65)); ctx.fillStyle = gg; ctx.beginPath(); ctx.arc(px, py + dy, r, Math.PI, 0); ctx.lineTo(px + r, py + dy + r * 0.1); ctx.lineTo(px - r, py + dy + r * 0.1); ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.3)"; ctx.stroke(); };
    if (face) { const ex = R * 0.42; ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.ellipse(px - ex, py + R * 0.08, R * 0.2, R * 0.16, 0, 0, TAU); ctx.ellipse(px + ex, py + R * 0.08, R * 0.2, R * 0.16, 0, 0, TAU); ctx.fill(); ctx.fillStyle = "#1a1a22"; ctx.beginPath(); ctx.arc(px - ex, py + R * 0.08, R * 0.1, 0, TAU); ctx.arc(px + ex, py + R * 0.08, R * 0.1, 0, TAU); ctx.fill(); ctx.strokeStyle = "rgba(90,40,30,.8)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(px, py + R * 0.3, R * 0.2, 0.15 * Math.PI, 0.85 * Math.PI); ctx.stroke(); }
    if (HM.kind === "helm" || HM.kind === "crest") cover(HM.color, R * 1.08, -R * 0.02); else if (HM.kind === "cap") cover(HM.color, R * 1.02, -R * 0.12); else cover(av.hair, R * 1.02, -R * 0.1);
    if (HM.kind === "crest") { ctx.fillStyle = HM.plume; ctx.beginPath(); ctx.moveTo(px - R * 0.1, py - R); ctx.quadraticCurveTo(px + R * 0.1, py - R * 2, px + R * 0.7, py - R * 1.2); ctx.lineTo(px + R * 0.1, py - R * 0.9); ctx.fill(); }
    if (HM.kind === "crown") { ctx.fillStyle = HM.color; ctx.beginPath(); ctx.moveTo(px - R * 0.8, py - R * 0.7); for (let i = 0; i < 5; i++) { ctx.lineTo(px - R * 0.8 + i * R * 0.4 + R * 0.2, py - R * (i % 2 ? 1.25 : 1.6)); ctx.lineTo(px - R * 0.8 + (i + 1) * R * 0.4, py - R * 0.7); } ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.3)"; ctx.stroke(); } } });
  items.sort((a, b) => b.d - a.d); for (const i of items) i.f();
}
function roundRect(ctx, x, y, w, h, r) { ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
