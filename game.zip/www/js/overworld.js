// نقشه‌ی بزرگ سه‌بعدی: گشت‌وگذار آزاد، ملت‌ها و دیپلماسی، آبادی‌های واقعی، گروه‌ها، صندوق و ردیاب (الهام از «انسان و فولاد»/توتال‌وار)
// رندر: ow3d.js (یک بوم GL + بوم برچسب)، منطق ملت‌ها: factions.js
import { S, give, save, addXp } from "./save.js";
import * as SV from "./save.js";
import { NEIGHBORS, fa, rng } from "./data.js";
import { lookOf } from "./gear.js";
import * as SQ from "./squad.js";
import * as C3 from "./char3d.js";
import { createOW3D, K, hash, vn, W3, puff, takeCanvas } from "./ow3d.js";
import * as FX from "./factions.js";

const TS = 40, WT = 130, HT = 86, WW = WT * TS, WH = HT * TS, TAU = Math.PI * 2;
const KINDS = [
  { id: "bandit", name: "راهزنان", icon: "🗡️", mem: ["club", "sword"], cloth: ["#6a4a2a", "#5a3a2a", "#4a4a38"], n: [3, 6], spd: 1 },
  { id: "turan", name: "سواران تورانی", icon: "🏹", mem: ["bow", "spear"], cloth: ["#8a2a2a", "#7a3a1a"], armor: "#8a7a5a", n: [3, 5], spd: 1.1 },
  { id: "wolf", name: "گله‌ی گرگ", icon: "🐺", mem: [], n: [3, 5], spd: 1.25, beast: true },
  { id: "bear", name: "خرس‌های کوهی", icon: "🏔", mem: [], n: [1, 2], spd: 1.0, beast: true },
  { id: "boar", name: "گله‌ی گراز", icon: "🌲", mem: [], n: [2, 4], spd: 1.1, beast: true },
  { id: "lion", name: "شیرهای دشت", icon: "🦁", mem: [], n: [2, 3], spd: 1.2, beast: true },
  { id: "div", name: "دیوان مازندران", icon: "👹", mem: ["club"], cloth: ["#2a4a3a"], skin: "#4a7a5a", n: [2, 3], spd: 0.8, big: true },
];
export async function startOverworld(cb, resume) {
  const root = document.createElement("div"); root.id = "s3d"; root.className = "ow";
  root.innerHTML = `<canvas id="owgl"></canvas><canvas id="owl"></canvas>
  <div class="s3top"><div class="owbar"><b>🗺️ نقشه‌ی بزرگ</b> <span id="owp"></span> <div class="s3bar"><i id="owhp"></i><span id="owhpt"></span></div><div class="s3bar g"><i id="owfd"></i><span id="owfdt"></span></div></div><div class="s3r"><button class="s3b sm" data-o="camp">⛺</button><button class="s3b sm" data-oz="ft">🐎</button><button class="s3b sm" data-o="army">👥</button><button class="s3b sm" data-o="dip">🏛️</button><button class="s3b sm" data-o="track">🔍</button><button class="s3b sm" data-o="quit">✖</button></div></div>
  <div id="s3msg"></div><div class="owzoom"><button data-oz="in">+</button><button data-oz="out">-</button><button data-oz="home">🎯</button></div><div class="owcomp" id="owcomp"><i></i><b>ش</b></div><canvas id="owmini" width="270" height="180"></canvas><div id="owfps"></div>
  <div class="owpanel" id="owpanel" style="display:none"></div><div id="owload"><div class="owspin"></div><span>در حال ساخت جهان…</span></div>`;
  document.body.appendChild(root); document.body.classList.add("inbattle");
  const cv = takeCanvas(root.querySelector("#owgl")), ovc = root.querySelector("#owl"), mini = root.querySelector("#owmini").getContext("2d");
  const $ = (id) => root.querySelector("#" + id), dbgFps = /[?&]fps/.test(location.search);
  if (!S.ow) S.ow = { hp: 100, vol: 0, found: [], per: -1, x: -1, y: 0, food: 100 }; if (S.ow.food === undefined) S.ow.food = 100; if (!S.ow.allies) S.ow.allies = []; if (!S.ow.vs) S.ow.vs = {}; if (S.ow.rep === undefined) S.ow.rep = 0;
  const ow = S.ow, seed = 77;
  const elev = (x, y) => vn(x / 9, y / 9, seed) * 0.62 + vn(x / 4, y / 4, seed + 1) * 0.26 + vn(x / 1.7, y / 1.7, seed + 3) * 0.12, fnoise = (x, y) => vn(x / 5, y / 5, seed + 2) * 0.75 + vn(x / 2, y / 2, seed + 4) * 0.25;
  const cls = (fx, fy) => { const e = elev(fx, fy), edge = Math.min(fx, fy, WT - fx, HT - fy); if (e < 0.25 || edge < 1.2) return 0; if (e > 0.76) return 3; if (fnoise(fx, fy) > 0.62 && e > 0.42) return 2; return 1; };
  const walk = (x, y) => cls(x / TS, y / TS);
  const sst = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
  const Efn = (px, py) => { const fx = px / TS, fy = py / TS, ed = Math.min(fx, fy, WT - fx, HT - fy); let e = elev(fx, fy) - sst(2.2, 1.0, ed) * 0.35; if (ed < 1.3) e = Math.min(e, 0.25 - (1.3 - ed) * 0.12); return e; };
  const rr = rng(9);
  // ---- نقاط مهم: آبادی‌ها با شعاع‌های واقعی چیده می‌شوند ----
  const used = [];
  const landOK = (x, y, r) => { if (walk(x, y) !== 1) return false; const q = r * 0.62; for (const [a, b] of [[q, 0], [-q, 0], [0, q], [0, -q], [q * .7, q * .7], [-q * .7, -q * .7]]) if (walk(x + a, y + b) === 0) return false; return true; };
  const free = (r) => { for (let pass = 0; pass < 3; pass++) for (let k = 0; k < 900; k++) { const x = (5 + rr() * (WT - 10)) * TS, y = (5 + rr() * (HT - 10)) * TS, m = pass === 0 ? 260 : pass === 1 ? 90 : -50; if (!landOK(x, y, pass === 2 ? r * 0.4 : r)) continue; if (used.every(([a, b, r2]) => Math.hypot(a - x, b - y) > r + r2 + m)) { used.push([x, y, r]); return [x, y]; } } return [WW / 2 + rr() * 200, WH / 2 + rr() * 200]; };
  const landPt = () => { for (let k = 0; k < 400; k++) { const x = (4 + Math.random() * (WT - 8)) * TS, y = (4 + Math.random() * (HT - 8)) * TS; if (walk(x, y) === 1) return [x, y]; } return [WW / 2, WH / 2]; };
  const mkSite = (o, r, ent) => Object.assign(o, { r, clear: r * 1.12, flat: r * 0.9, dirt: r * 0.9, ent: { x: o.x, y: o.y + ent } });
  const castles = NEIGHBORS.map((n) => { const [x, y] = free(165); return mkSite({ kind: "castle", n, id: n.id, name: n.name, x, y }, 165, 160); });
  const towns = ["شهر بازار", "شهر سپیدرود", "شهر کوهستان"].map((name, i) => { const [x, y] = free(150); return mkSite({ kind: "town", name, x, y, i, id: "t" + i }, 150, 150); });
  const [hx, hy] = free(125); const home = mkSite({ kind: "home", name: "کشور من", x: hx, y: hy, id: "me" }, 125, 110);
  const villages = ["روستای گلستان", "ده‌ی مرغزار", "آبادی سرچشمه", "روستای دامغان", "ده‌ی کوهپایه", "آبادی مهرآباد", "روستای سیمین", "ده‌ی چناران", "روستای بیشه", "ده‌ی کوهسار", "آبادی لاله‌زار", "روستای سروستان", "ده‌ی آبشار", "آبادی نیلوفر"].map((name, i) => { const [x, y] = free(100); return mkSite({ kind: "village", name, x, y, i, id: "v" + i }, 100, 70); });
  const camps = [0, 1, 2, 3, 4, 5, 6, 7].map((i) => { const [x, y] = free(60); return mkSite({ kind: "camp", name: "اردوگاه", x, y, id: "k" + i }, 60, 0); });
  const mines = [0, 1, 2, 3, 4].map((i) => { const [x, y] = free(60); return mkSite({ kind: "mine", name: "معدن", x, y, id: "m" + i }, 60, 0); });
  if (ow.ws !== WT) { ow.ws = WT; ow.x = -1; }
  if (ow.x < 0) { ow.x = home.ent.x + 40; ow.y = home.ent.y + 30; if (walk(ow.x, ow.y) === 0) { ow.x = home.x; ow.y = home.y; } }
  const allSites = [...castles, ...towns, home, ...villages, ...camps, ...mines];
  // ---------- جاده‌ها و مزرعه‌ها ----------
  const roads = [], fields = [];
  (function decor() {
    const pts = [...castles, ...villages, ...towns, home], nearest = (o, arr) => arr.filter((q) => q !== o).sort((a, b2) => Math.hypot(a.x - o.x, a.y - o.y) - Math.hypot(b2.x - o.x, b2.y - o.y))[0];
    const pairs = [[home, towns[0]], [towns[0], towns[1]]]; for (const v of villages) pairs.push([v, nearest(v, [...towns, home, ...villages])]); for (const c of castles) pairs.push([c, nearest(c, [...towns, home])]);
    for (const [a, b2] of pairs) { if (!a || !b2) continue; const pa = findPath(a.ent.x, a.ent.y, b2.ent.x, b2.ent.y, true); roads.push([{ x: a.ent.x, y: a.ent.y }, ...pa.filter((q) => walk(q.x, q.y) !== 0)]); }
    for (const v of villages) for (let k = 0; k < 3; k++) { const a = hash(v.x | 0, k, 77) * TAU, r = 175 + hash(k, v.y | 0, 78) * 50, cx = v.x + Math.cos(a) * r, cy = v.y + Math.sin(a) * r * 0.8, w2 = 78, h2 = 52; if (![[-1, -1], [1, -1], [1, 1], [-1, 1]].every(([sx, sy]) => walk(cx + sx * w2, cy + sy * h2) === 1)) continue; if (used.some(([ux, uy, ur]) => Math.hypot(ux - cx, uy - cy) < ur + 40 && (ux !== v.x || uy !== v.y))) continue; fields.push({ x: cx, y: cy, w: w2, h: h2, a: (hash(k, v.x | 0, 79) - 0.5) * 0.5, k: k + i0(v) }); }
  })();
  function i0(v) { return v.i || 0; }
  const P = { x: ow.x, y: ow.y, dir: 1, ph: 0, tx: null, ty: null, vx: 0, vy: 0 }, look = lookOf(S.avatar);
  const per = Math.floor(Date.now() / 21600000); if (ow.per !== per) { ow.per = per; ow.found = []; }
  const rc = rng(per * 31 + 5), chests = Array.from({ length: 12 }, (_, i) => { const x = (3 + rc() * (WT - 6)) * TS, y = (3 + rc() * (HT - 6)) * TS; return { id: "c" + i, x, y, gem: i % 4 === 3, ok: walk(x, y) !== 0 }; }).filter((c) => c.ok);
  const allyPow = () => ow.allies.reduce((a, q) => a + q.pow, 0);
  const myPow = () => Math.max(4, (SV.kingdomPower() + 2 * ow.vol + allyPow()) * (0.45 + 0.55 * ow.hp / 100) * (0.75 + 0.25 * Math.min(1, ow.food / 40)));
  const bands = [];
  function spawnBand(initial) { const k = KINDS[Math.floor(Math.random() * KINDS.length)], [x, y] = landPt(); if (initial && Math.hypot(x - P.x, y - P.y) < 350) return spawnBand(initial);
    const base = SV.kingdomPower() + 2 * ow.vol, ratio = [0.35, 0.5, 0.6, 0.8, 1, 1.2, 1.5, 1.9, 2.5][Math.floor(Math.random() * 9)] * (k.big ? 1.3 : 1), n = k.n[0] + Math.floor(Math.random() * (k.n[1] - k.n[0] + 1));
    bands.push({ k, x, y, hx: x, hy: y, pow: Math.max(3, Math.round(base * ratio)), n, ph: Math.random() * 6, dir: 1, st: "patrol", tx: x, ty: y, tt: 0, dead: 0, look: Array.from({ length: n }, (_, i) => ({ c: k.cloth ? k.cloth[i % k.cloth.length] : "#5a4a3a", w: k.mem[i % Math.max(1, k.mem.length)], s: ["#d2a074", "#b07a50", "#8a5a3a", "#e8c0a0"][(i + x) % 4 | 0] })) }); }
  for (let i = 0; i < 38; i++) spawnBand(true);
  const rel = (b) => { const r = b.pow / myPow(); return r < 0.8 ? 0 : r < 1.3 ? 1 : 2; }, RC = ["#5be07a", "#ffd24a", "#ff5a4a"], RN = ["ضعیف", "هم‌قدر", "قوی"];
  // ---------- ملت‌ها: مالکیت، سپاه‌ها، دیپلماسی ----------
  const allFacSites = [...castles, ...towns, ...villages, home];
  FX.init(ow, allFacSites, S.conquered);
  const ownerInfo = (s) => { const o = FX.owner(s.id), f = o ? FX.fac(o) : null; return f ? { id: o, css: f.css, name: f.name, rgb: f.rgb } : null; };
  const defTeam = (s) => s.kind === "village" ? [0.75, 0.62, 0.42] : s.kind === "town" ? [0.9, 0.55, 0.2] : s.kind === "castle" ? [0.55, 0.55, 0.6] : [0.6, 0.15, 0.12];
  function applyOwners() { if (!R) return; for (const s of allFacSites) { const o = ownerInfo(s); R.setTeam(s, o ? o.rgb : defTeam(s)); } }
  const FK = (f) => ({ id: "army", name: "سپاه " + f.name, icon: f.emoji, mem: ["sword", "spear", "bow"], cloth: [f.css], armor: "#8a8a98", n: [4, 6], spd: 1 });
  function mkArmy(f, k) { const hs = FX.sitesOf(f.id)[0]; if (!hs) return; const x = hs.ent.x + (k ? 70 : -70), y = hs.ent.y + 30, n = 4 + (k % 2); bands.push({ k: FK(f), fac: { id: f.id, col: f.css, rgb: f.rgb }, x, y, hx: x, hy: y, pow: Math.max(6, Math.round(FX.state().str[f.id] * (0.55 + 0.1 * k))), n, ph: Math.random() * 6, dir: 1, st: "patrol", tx: x, ty: y, tt: 0, dead: 0, path: null, pathT: 0, cool: 4 + Math.random() * 10, look: Array.from({ length: n }, (_, i) => ({ c: f.css, w: ["sword", "spear", "bow"][i % 3], s: ["#d2a074", "#b07a50", "#e8c0a0"][i % 3] })) }); }
  FX.FACS.forEach((f) => { mkArmy(f, 0); if (FX.state().str[f.id] > 42) mkArmy(f, 1); });
  const fname = (id) => (FX.fac(id) || { name: "مردم" }).name;
  function facStep(dt) {
    const F = FX.state(); for (const m of FX.tick(dt)) msg(m);
    for (const b of bands) { if (!b.fac) continue; const fid = b.fac.id, f = FX.fac(fid);
      if (b.dead > 0) { b.dead -= dt; if (b.dead <= 0) { const h = FX.sitesOf(fid)[0]; if (h && FX.alive(fid)) { b.x = h.ent.x; b.y = h.ent.y + 30; b.pow = Math.max(8, Math.round(F.str[fid] * 0.6)); b.dead = 0; b.path = null; b.tgtSite = null; } else b.dead = 30; } continue; }
      if (!FX.alive(fid)) { b.dead = 30; continue; }
      b.ph += dt * 6; b.cool -= dt; b.pathT -= dt; b.pow = Math.min(Math.round(F.str[fid] * 0.75), b.pow + dt * 0.12); const d = Math.hypot(b.x - P.x, b.y - P.y); let tx = null, ty = null, sp = 52;
      if (FX.hostileToMe(fid) && d < 330) { b.st = "chase"; tx = P.x; ty = P.y; sp = 82; if (b.noFight > 0) b.noFight -= dt; else if (d < 36 && !battle && !paused) { P.tx = null; contact(b); } b.path = null; }
      else {
        b.st = "patrol";
        if (b.cool <= 0 || (b.tgtSite && FX.owner(b.tgtSite.id) === fid)) { b.tgtSite = null; let best = null, bd = 1e9; for (const s of allFacSites) { const o = FX.owner(s.id); if (!o || o === fid || FX.relAB(fid, o) !== "war" || s.kind === "home" || (o === "me" && s.kind === "castle")) continue; const dd = Math.hypot(s.x - b.x, s.y - b.y); if (dd < bd) { bd = dd; best = s; } } b.tgtSite = best; b.cool = 12 + Math.random() * 8; b.path = null; }
        if (b.tgtSite) { const s = b.tgtSite; tx = s.ent.x; ty = s.ent.y; if (Math.hypot(tx - b.x, ty - b.y) < 80) { const o = FX.owner(s.id), g = FX.garrison(s); if (o !== fid) { if (b.pow * (0.7 + Math.random() * 0.6) > g) { FX.setOwner(s.id, fid); applyOwners(); b.pow = Math.max(6, Math.round(b.pow * 0.7)); msg(`🏴 ${f.name} «${s.name}» را از ${fname(o)} گرفت`); } else b.pow = Math.max(4, Math.round(b.pow * 0.6)); } b.tgtSite = null; b.cool = 14; b.path = null; tx = null; } }
        else { b.tt -= dt; if (b.tt <= 0) { b.tt = 3 + Math.random() * 4; const a = Math.random() * TAU, rad = Math.random() * 130; b.tx = b.hx + Math.cos(a) * rad; b.ty = b.hy + Math.sin(a) * rad; } if (Math.hypot(b.tx - b.x, b.ty - b.y) > 8) { tx = b.tx; ty = b.ty; sp = 40; } }
        if (tx !== null && b.tgtSite) { if (!b.path || b.pathT <= 0) { b.path = findPath(b.x, b.y, tx, ty, true); b.pathT = 7; } while (b.path.length > 1 && Math.hypot(b.path[0].x - b.x, b.path[0].y - b.y) < 16) b.path.shift(); tx = b.path[0].x; ty = b.path[0].y; }
      }
      if (tx !== null) { const dx = tx - b.x, dy = ty - b.y, dd = Math.hypot(dx, dy) || 1; b.x += dx / dd * sp * dt; b.y += dy / dd * sp * dt; b.fx = dx / dd; b.fy = dy / dd; } else { b.fx = b.fx || 0; }
      for (const o of bands) { if (!o.fac || o === b || o.dead > 0 || bands.indexOf(o) < bands.indexOf(b)) continue; if (Math.hypot(o.x - b.x, o.y - b.y) < 55 && FX.relAB(fid, o.fac.id) === "war") { const w = b.pow * (0.7 + Math.random() * 0.6) > o.pow * (0.7 + Math.random() * 0.6) ? [b, o] : [o, b]; w[0].pow = Math.max(5, Math.round(w[0].pow * 0.65)); w[1].dead = 40; w[1].pow = 0; if (R && R.dist(b.x, b.y) < 90) msg(`⚔️ نبرد سپاه‌های ${fname(w[0].fac.id)} و ${fname(w[1].fac.id)}`); } }
    }
  }
  // ---------- دیپلماسی ----------
  function dipPanel() {
    const F = FX.state(), rows = FX.FACS.map((f) => { const r = FX.relMe(f.id), n = FX.sitesOf(f.id).length, al = n > 0, wars = FX.FACS.filter((q) => q !== f && FX.alive(q.id) && FX.relAB(f.id, q.id) === "war").map((q) => q.emoji).join(" ");
      return `<div class="owfac ${al ? "" : "dead"}" style="border-color:${f.css}"><div class="fh"><i style="background:${f.css}"></i><b>${f.emoji} ${f.name}</b><span class="rl" style="color:${FX.RELC[r]}">${FX.REL[r]}</span></div><div class="xs mut">${f.leader} • قدرت ${fa(F.str[f.id])} • ${fa(n)} آبادی • دوستی ${fa(F.fav[f.id])}${wars ? " • در جنگ با " + wars : ""}</div>
      ${al ? `<div class="row wrap" style="gap:6px;margin-top:5px">${r === "war" ? `<button class="btn s g" data-o="dipa" data-f="${f.id}" data-a="peace">🕊️ صلح (${fa(300)})</button>` : `<button class="btn s r" data-o="dipa" data-f="${f.id}" data-a="war">⚔️ اعلان جنگ</button>`}<button class="btn s g" data-o="dipa" data-f="${f.id}" data-a="gift">🎁 هدیه (${fa(FX.giftCost(f.id, S.level))})</button>${r === "neutral" ? `<button class="btn s g" data-o="dipa" data-f="${f.id}" data-a="ally" ${FX.canAlly(f.id) ? "" : "disabled"}>🤝 پیمان (${fa(600)})</button>` : ""}</div>` : '<div class="xs">☠️ نابود شد</div>'}</div>`; }).join("");
    panel(`<div class="owp owdip"><h3>🏛️ دیپلماسی و ملت‌ها</h3><div class="xs mut" style="margin-bottom:6px">با هدیه دوستی بساز؛ با دوستی ≥۲ می‌توانی پیمان ببندی. ملت‌ها خودشان هم با هم می‌جنگند و آبادی‌ها دست‌به‌دست می‌شوند.</div><div class="owfacs">${rows}</div><button class="btn s d" data-o="close" style="margin-top:8px">بستن</button></div>`);
  }
  function dipAct(fid, a) {
    const f = FX.fac(fid);
    if (a === "gift") { const c = FX.giftCost(fid, S.level); if (S.coins < c) return msg("سکه کافی نیست"); S.coins -= c; FX.gift(fid); msg(`🎁 هدیه‌ات ${f.name} را خشنود کرد`); }
    else if (a === "ally") { if (S.coins < 600) return msg("سکه کافی نیست"); if (!FX.makeAlly(fid)) return msg("دوستی کافی نیست — هدیه بده"); S.coins -= 600; msg(`🤝 پیمان با ${f.name} بسته شد`); }
    else if (a === "war") { FX.declareWar(fid); msg(`🚩 به ${f.name} اعلان جنگ دادی`); }
    else if (a === "peace") { if (S.coins < 300) return msg("سکه کافی نیست"); if (!FX.makePeace(fid)) return msg("آن‌ها صلح نمی‌خواهند — هدیه بده"); S.coins -= 300; msg(`🕊️ صلح با ${f.name}`); }
    save(); window.dispatchEvent(new Event("wm-gain")); dipPanel();
  }
  const hostilePanel = (s) => { const o = FX.owner(s.id), f = FX.fac(o); pend = s; panel(`<div class="owp"><h3>${s.kind === "town" ? "🏙️" : "🏘️"} ${s.name}</h3><div class="xs" style="color:${f.css}">🏴 تحت حاکمیت ${f.name} — در جنگ با تو</div><div class="xs mut" style="margin:6px 0 8px">نگهبانان: ${fa(FX.garrison(s))} • با نبرد سه‌بعدی آن را بگیر.</div><div class="row wrap" style="gap:8px;justify-content:center"><button class="btn s r" data-o="satk">⚔️ حمله</button><button class="btn s d" data-o="close">برگرد</button></div></div>`); };
  const isHostile = (s) => { const o = FX.owner(s.id); return o && o !== "me" && FX.hostileToMe(o); };
  function siteAttack(s) {
    const o = FX.owner(s.id), f = FX.fac(o), g = FX.garrison(s); panel(""); ow.x = P.x; ow.y = P.y;
    const k = { id: "turan", name: "نگهبانان " + s.name, icon: f ? f.emoji : "🏯", mem: ["spear", "bow"], cloth: [f ? f.css : "#8a2a2a"], armor: "#8a7a5a", n: [3, 5], spd: 1 };
    const site = { kind: s.kind, name: s.name, id: s.id, owner: o, color: f ? f.rgb.slice() : [0.6, 0.5, 0.4], garrison: g, walls: s.kind !== "village", level: s.kind === "town" ? 2 : 1 };
    const keep = { pow: g * 2, n: Math.min(8, 3 + Math.floor(g / 6)), k, my: Math.max(4, Math.round(myPow() / 6)), ally: ow.allies.reduce((a, q) => a + (q.n || 0), 0), site };
    quit(false); cb && cb.band && cb.band({ id: s.kind === "town" ? "n3" : "n1", name: s.name, emoji: f ? f.emoji : "🏘️", gate: Math.max(140, g * 30), power: Math.max(8, g * 2), keep, site });
  }
  let pT = 0, msgT = 0, paused = false, ended = false, raf = 0, last = performance.now(), trackT = 0, battle = null, hudT = 0;
  let msgH = 0; const msg = (m) => { const e = $("s3msg"); e.textContent = m; e.classList.add("on"); msgT = 3.2; clearTimeout(msgH); msgH = setTimeout(() => e.classList.remove("on"), 3000); };
  const key = {}, joy = { x: 0, y: 0 };
  const onKD = (e) => { key[e.key.toLowerCase()] = true; if (e.key === "Escape") quit(); }, onKU = (e) => { key[e.key.toLowerCase()] = false; };
  addEventListener("keydown", onKD); addEventListener("keyup", onKU);
  let R = null, GLO = false, dtO = 0.016, lastD = 0, VW = 800, VH = 450, loading = true;
  const resize = () => { if (R) { R.resize(); VW = R.vw; VH = R.vh; } }; addEventListener("resize", resize);
  // ---- ورودی: لمس برای حرکت، کشیدن برای جابه‌جایی دوربین، دو انگشت برای زوم/چرخش ----
  let follow = true, g0 = null, tapFx = null; const ptrs = new Map(), camT = { x: 0, y: 0 };
  const clampCam = () => { const c = R.cam; const m = Math.min(700, Math.max(60, c.dist * 7)); c.x = Math.max(m, Math.min(WW - m, c.x)); c.y = Math.max(m, Math.min(WH - m, c.y)); };
  const setZoom = (d) => { const c = R.cam; c.dist = Math.max(12, Math.min(78, d)); c.pitch = 0.8 + 0.42 * sst(22, 75, c.dist); };
  function tapAt(cx, cy) {
    const r = cv.getBoundingClientRect(), sx = cx - r.left, sy = cy - r.top; let best = null, bd = 1e9;
    const cand = [...bands.filter((b) => b.dead <= 0).map((b) => ({ x: b.x, y: b.y, b, h: 1.6, rad: 48 })), ...villages, ...towns, ...castles, home, ...chests.filter((c) => !ow.found.includes(c.id))];
    for (const o of cand) { const p = R.proj(o.x, o.y, o.b ? 1.6 : (o.kind === "castle" ? 6 : o.kind ? 3 : 0.8)); if (!p) continue; const d = Math.hypot(p[0] - sx, p[1] - sy), lim = o.b ? 46 : o.kind ? 62 : 40; if (d < lim && d < bd) { bd = d; best = o; } }
    let wx, wy; if (best) { P.chase = best.b ? best.b : null; if (best.b) { wx = best.x; wy = best.y; } else if (best.ent) { wx = best.ent.x; wy = best.ent.y; } else { wx = best.x; wy = best.y; } }
    else { const g = R.pick(sx, sy); if (!g) return; P.chase = null; wx = g[0]; wy = g[1]; }
    wx = Math.max(16, Math.min(WW - 16, wx)); wy = Math.max(16, Math.min(WH - 16, wy)); follow = true; goTo(wx, wy); tapFx = { x: wx, y: wy, t: 0 };
  }
  cv.addEventListener("pointerdown", (e) => { if (battle || paused || loading) return; try { cv.setPointerCapture(e.pointerId); } catch (_) {} ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, t: performance.now(), moved: false }); if (ptrs.size === 2) { const [a, b2] = [...ptrs.values()]; g0 = { d: Math.hypot(a.x - b2.x, a.y - b2.y), z: R.cam.dist, an: Math.atan2(b2.y - a.y, b2.x - a.x), yaw: R.cam.yaw }; a.moved = b2.moved = true; } });
  cv.addEventListener("pointermove", (e) => { const p = ptrs.get(e.pointerId); if (!p) return; const r = cv.getBoundingClientRect(), ox = p.x, oy = p.y; p.x = e.clientX; p.y = e.clientY; if (Math.hypot(p.x - p.sx, p.y - p.sy) > 9) p.moved = true;
    if (ptrs.size === 2 && g0) { const [a, b2] = [...ptrs.values()]; setZoom(g0.z * g0.d / Math.max(20, Math.hypot(a.x - b2.x, a.y - b2.y))); let da = Math.atan2(b2.y - a.y, b2.x - a.x) - g0.an; da = Math.atan2(Math.sin(da), Math.cos(da)); R.cam.yaw = g0.yaw - da; }
    else if (ptrs.size === 1 && p.moved) { const a = R.pick(ox - r.left, oy - r.top), b2 = R.pick(p.x - r.left, p.y - r.top); if (a && b2) { follow = false; R.cam.x += a[0] - b2[0]; R.cam.y += a[1] - b2[1]; clampCam(); } } });
  const pup = (e) => { const p = ptrs.get(e.pointerId); ptrs.delete(e.pointerId); if (ptrs.size < 2) g0 = null; if (p && !p.moved && e.type === "pointerup" && !battle && !paused && performance.now() - p.t < 600) tapAt(e.clientX, e.clientY); };
  cv.addEventListener("pointerup", pup); cv.addEventListener("pointercancel", pup);
  cv.addEventListener("wheel", (e) => { e.preventDefault(); if (R) setZoom(R.cam.dist * (e.deltaY < 0 ? 0.9 : 1.11)); }, { passive: false });
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-oz]"); if (!b || !R) return; const a = b.dataset.oz; if (a === "in") setZoom(R.cam.dist * 0.8); else if (a === "out") setZoom(R.cam.dist * 1.25); else if (a === "home") { follow = true; setZoom(28); R.cam.yaw = Math.PI; } });
  { const miniEl = $("owmini"); miniEl.addEventListener("pointerdown", (e) => { const r = miniEl.getBoundingClientRect(); R.cam.x = (e.clientX - r.left) / r.width * WW; R.cam.y = (e.clientY - r.top) / r.height * WH; follow = false; clampCam(); e.stopPropagation(); }); }
  // ---- مسیریابی A* روی شبکه‌ی ۴۰ پیکسلی (خشکی ارزان، آب با قایق گران‌تر، کوه گران) ----
  const tcost = (c) => c === 1 ? 1 : c === 2 ? 1.5 : c === 3 ? 4 : 2.6;
  function findPath(sx, sy, tx, ty, road) {
    const gx = (v) => Math.max(0, Math.min(WT - 1, Math.floor(v / TS))), gy = (v) => Math.max(0, Math.min(HT - 1, Math.floor(v / TS)));
    const s0 = gy(sy) * WT + gx(sx), g1 = gy(ty) * WT + gx(tx); if (s0 === g1) return [{ x: tx, y: ty }];
    const N = WT * HT, gs = new Float32Array(N).fill(1e9), from = new Int32Array(N).fill(-1), closed = new Uint8Array(N), heap = [[0, s0]]; gs[s0] = 0;
    const hf = (i) => Math.hypot((i % WT) - (g1 % WT), Math.floor(i / WT) - Math.floor(g1 / WT));
    const push = (it) => { heap.push(it); let i = heap.length - 1; while (i > 0) { const q = (i - 1) >> 1; if (heap[q][0] <= heap[i][0]) break; [heap[q], heap[i]] = [heap[i], heap[q]]; i = q; } };
    const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { let l = 2 * i + 1, r = l + 1, m = i; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; i = m; } } return top; };
    while (heap.length) { const [, c] = pop(); if (closed[c]) continue; closed[c] = 1; if (c === g1) break; const cx = c % WT, cy = (c / WT) | 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { if (!dx && !dy) continue; const nx = cx + dx, ny = cy + dy; if (nx < 0 || ny < 0 || nx >= WT || ny >= HT) continue; const n = ny * WT + nx; if (closed[n]) continue; const cc = cls(nx + 0.5, ny + 0.5), w = (road ? (cc === 0 ? 90 : cc === 3 ? 7 : cc === 2 ? 2.2 : 1) : tcost(cc)) * (dx && dy ? 1.414 : 1), ng = gs[c] + w; if (ng < gs[n]) { gs[n] = ng; from[n] = c; push([ng + hf(n), n]); } } }
    if (from[g1] < 0) return [{ x: tx, y: ty }];
    const pts = []; for (let c = g1; c !== s0 && c >= 0; c = from[c]) pts.push({ x: (c % WT + 0.5) * TS, y: (((c / WT) | 0) + 0.5) * TS }); pts.reverse();
    const out = []; for (let i = 0; i < pts.length; i++) { const a = out[out.length - 1] || { x: sx, y: sy }, b2 = pts[i], c2 = pts[i + 1]; if (c2) { const d1 = Math.atan2(b2.y - a.y, b2.x - a.x), d2 = Math.atan2(c2.y - b2.y, c2.x - b2.x); if (Math.abs(d1 - d2) < 0.05) continue; } out.push(b2); }
    out.pop(); out.push({ x: tx, y: ty }); return out;
  }
  function goTo(x, y) { P.tx = x; P.ty = y; P.path = findPath(P.x, P.y, x, y); }
  function panel(html) { const p = $("owpanel"); p.innerHTML = html; p.style.display = html ? "flex" : "none"; paused = !!html; }
  function quit(callQuit = true) { if (ended) return; ended = true; cancelAnimationFrame(raf); removeEventListener("keydown", onKD); removeEventListener("keyup", onKU); removeEventListener("resize", resize); try { C3.setMode("atlas"); } catch (_) {} ow.x = P.x; ow.y = P.y; save(); root.remove(); document.body.classList.remove("inbattle"); window.__s3d = null; if (callQuit) cb && cb.quit && cb.quit(); }
  window.__s3d = { back() { if (battle) return; if ($("owpanel").style.display !== "none") panel(""); else quit(); } };
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-o]"); if (!b) return; const a = b.dataset.o;
    if (a === "quit") quit(); else if (a === "track") { trackT = 6; msg("🔍 ردیابی فعال: سبز = ضعیف، قرمز = قوی"); } else if (a === "close") panel("");
    else if (a === "rest") { const c = 40; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.hp = 100; save(); panel(""); msg("🛌 سپاه استراحت کرد — سلامت کامل"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "vol") { if (ow.vol >= 12) { msg("حداکثر داوطلب"); return; } const c = +b.dataset.c || (150 + ow.vol * 40); if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.vol++; save(); panel(""); msg(`🏹 داوطلب تازه! قدرت +۲ (جمعاً ${fa(ow.vol)})`); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "b3d") { const bd = pend; panel(""); const th = { bandit: "n2", turan: "n3", wolf: "n1", div: "n4" }[bd.k.id] || "n2"; ow.x = P.x; ow.y = P.y; const site = { kind: "field", name: bd.k.name, id: bd.fac ? bd.fac.id : null, owner: bd.fac ? bd.fac.id : null, color: bd.fac ? bd.fac.rgb.slice() : [0.6, 0.2, 0.15], garrison: bd.n, walls: false, level: 1 }; const keep = { pow: bd.pow, n: bd.n, k: bd.k, my: Math.max(4, Math.round(myPow() / 6)), ally: ow.allies.reduce((a, q) => a + (q.n || 0), 0), site }; quit(false); cb && cb.band && cb.band({ id: th, name: bd.k.name, emoji: bd.k.icon, gate: Math.max(140, bd.pow * 16), power: Math.max(8, bd.pow), keep, site }); }
    else if (a === "bq") { const bd = pend; panel(""); fight(bd); }
    else if (a === "bpay") { const bd = pend, c = Math.round(bd.pow * 9 + 40); if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; panel(""); bd.dead = 30; save(); window.dispatchEvent(new Event("wm-gain")); msg(`💰 ${fa(c)} سکه دادی و آن‌ها رفتند`); }
    else if (a === "bflee") { pend.noFight = 4; panel(""); msg("🏃 از کنارشان گریختی"); }
    else if (a === "camp") { if (ow.food < 12) { msg("آذوقه کافی نیست"); return; } if (ow.campT > 0) { msg("هنوز نمی‌توانی اردو بزنی"); return; } ow.campT = 25; ow.fire = { x: P.x + 60, y: P.y + 20, t: 14 }; ow.food -= 10; ow.hp = Math.min(100, ow.hp + 25); msg("⛺ اردو زدی — سلامت +۲۵٪، آذوقه −۱۰٪"); }
    else if (a === "feed") { const c = 30; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.food = 100; save(); panel(""); msg("🍖 آذوقه پر شد"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "btalk") talk(pend);
    else if (a === "bjoin") { const bd = pend, c = joinCost(bd); if (ow.allies.length >= 4) { msg("حداکثر ۴ گروه هم‌پیمان"); return; } if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.allies.push({ k: bd.k.id, name: bd.k.name, icon: bd.k.icon, pow: Math.max(3, Math.round(bd.pow * 0.75)), n: bd.n, look: bd.look, x: bd.x, y: bd.y }); bd.dead = 0.01; panel(""); save(); msg(`🤝 ${bd.k.name} به سپاه تو پیوستند! قدرت +${fa(Math.round(bd.pow * 0.75))}`); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "bhag") { const bd = pend; panel(""); if (Math.random() < 0.35 + ow.rep * 0.02) { const c = Math.round(joinCost(bd) * 0.5); if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; if (ow.allies.length < 4) { ow.allies.push({ k: bd.k.id, name: bd.k.name, icon: bd.k.icon, pow: Math.max(3, Math.round(bd.pow * 0.6)), n: bd.n, look: bd.look, x: bd.x, y: bd.y }); bd.dead = 0.01; msg(`🤝 چانه زدی و ${bd.k.name} پذیرفتند`); } save(); window.dispatchEvent(new Event("wm-gain")); } else { bd.noFight = 0; msg("😠 نپذیرفتند — آماده‌ی نبرد باش"); setTimeout(() => contact(bd), 600); } }
    else if (a === "army") armyPanel();
    else if (a === "dip") dipPanel();
    else if (a === "dipa") dipAct(b.dataset.f, b.dataset.a);
    else if (a === "satk") siteAttack(pend);
    else if (a === "dis") { const i = +b.dataset.i; ow.allies.splice(i, 1); save(); armyPanel(); }
    else if (a === "vsack") sack(pend);
    else if (a === "vdev") develop(pend);
    else if (a === "vtax") collect(pend);
    else if (a === "vrest") { ow.hp = 100; save(); panel(""); msg("🛌 استراحت رایگان در آبادی خودت"); }
    else if (a === "vfeed") { ow.food = 100; save(); panel(""); msg("🍖 آذوقه‌ی رایگان"); }
    else if (a === "tav") tavern(pend);
    else if (a === "rumor") { const c = 60; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.rumorT = 90; trackT = 25; save(); panel(""); msg("🗣️ شایعه شنیدی: صندوق‌ها روی نقشه‌ی کوچک پیدایند و ردیاب فعال است"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "merc") { const base = SV.kingdomPower(), c = Math.round(120 + base * 14); if (ow.allies.length >= 4) { msg("حداکثر ۴ گروه هم‌پیمان"); return; } if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.allies.push({ k: "merc", name: "مزدوران شمشیرزن", icon: "⚔️", pow: Math.max(4, Math.round(base * 0.45)), n: 3, look: [0, 1, 2].map((i) => ({ c: ["#4a5a7a", "#6a4a4a", "#4a6a4a"][i], w: ["sword", "spear", "sword"][i], s: ["#d2a074", "#b07a50", "#8a5a3a"][i] })), x: P.x, y: P.y }); save(); panel(""); msg("⚔️ مزدوران به سپاهت پیوستند"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "heal") { const c = 70; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.hp = 100; ow.food = Math.max(ow.food, 70); save(); panel(""); msg("🍲 غذای گرم و استراحت — سلامت و آذوقه پر شد"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "arena") arena(pend);
    else if (a === "duel") duel(+b.dataset.t);
    else if (a === "atkc") { const id = b.dataset.id; quit(); cb && cb.castle && cb.castle(id); } });
  // ---- نبرد خودکار ----
  function fight(bd) {
    const mp = myPow(), a = Math.pow(mp, 1.35), b = Math.pow(bd.pow, 1.35), win = Math.random() < a / (a + b) * 1.06 - 0.03;
    battle = { bd, t: 0, win, mp }; paused = true;
  }
  let pend = null;
  function contact(b) {
    pend = b; const r = rel(b), pay = Math.round(b.pow * 9 + 40);
    panel(`<div class="owp"><h3>${b.k.icon} ${b.k.name}</h3><div class="xs">قدرت آن‌ها <b style="color:${RC[r]}">${fa(b.pow)} (${RN[r]})</b> • قدرت تو <b>${fa(Math.round(myPow()))}</b></div>
    <div class="xs mut" style="margin:4px 0 8px">${r === 0 ? "این‌ها از تو می‌ترسند؛ شکست‌شان آسان است." : r === 1 ? "نبردی هم‌قدر؛ با خودت وارد میدان شو تا شانس بیشتر شود." : "بسیار خطرناک! بهتر است فرار کنی یا با دستِ خودت بجنگی."}</div>
    <div class="row wrap" style="gap:8px;justify-content:center"><button class="btn s r" data-o="b3d">⚔️ نبرد سه‌بعدی</button><button class="btn s g" data-o="bq">⚡ نبرد سریع</button>${b.k.beast || b.fac ? "" : '<button class="btn s g" data-o="btalk">🗣️ گفتگو</button>'}<button class="btn s d" data-o="bpay">💰 باج (${fa(pay)})</button><button class="btn s d" data-o="bflee">🏃 فرار</button></div></div>`);
  }
  function settle(bd, win, how) {
    if (win && bd.site && bd.site.kind !== "field" && bd.site.id) { FX.setOwner(bd.site.id, "me"); applyOwners(); setTimeout(() => msg(`🏴 «${bd.site.name}» را فتح کردی!`), 900); }
    const loss = Math.round(Math.min(60, 6 + 28 * bd.pow / Math.max(4, myPow())));
    if (win) { const coins = Math.round(bd.pow * (14 + S.level * 0.8) * (1 + rel(bd) * 0.25) * (how === "3d" ? 1.25 : 1)), xp = 10 + bd.pow, gem = rel(bd) === 2 ? 2 + Math.floor(Math.random() * 4) : (Math.random() < 0.15 ? 1 : 0); give({ coins, gems: gem }); addXp(xp); ow.hp = Math.max(8, ow.hp - loss * (how === "3d" ? 0.4 : 0.7)); S.stats.kills = (S.stats.kills || 0) + bd.n * 4; msg(`🏆 پیروزی! +${fa(coins)} 🪙${gem ? " +" + fa(gem) + " 💎" : ""}`); if (bd.dead !== undefined) bd.dead = 45; }
    else { ow.hp = Math.max(6, ow.hp - loss); const lost = Math.min(S.coins, Math.round(S.coins * 0.04 + 30)); S.coins -= lost; P.x = home.x; P.y = home.y + 30; if (R) { R.cam.x = P.x; R.cam.y = P.y; } if (ow.allies.length && Math.random() < 0.4) { const q = ow.allies.pop(); msg(`💀 شکست! ${q.name} فرار کردند • −${fa(lost)} 🪙`); } else msg(`💀 شکست! سپاه به کشور عقب نشست • −${fa(lost)} 🪙`); if (bd.st) { bd.st = "patrol"; bd.x = bd.hx; bd.y = bd.hy; } }
    save(); window.dispatchEvent(new Event("wm-gain"));
  }
  if (resume && resume.band) { setTimeout(() => settle(resume.band, resume.won, "3d"), 1800); }
  // ---- گفتگو و هم‌پیمانی ----
  const joinCost = (bd) => Math.round((bd.pow * (bd.k.id === "turan" ? 13 : 10) + 70) * (1 - Math.min(0.3, ow.rep * 0.03)) * (1 + Math.max(0, -ow.rep) * 0.1));
  function talk(bd) {
    pend = bd; const r = rel(bd), c = joinCost(bd), cap = ow.allies.length >= 4;
    if (bd.k.id === "div") { panel(`<div class="owp"><h3>${bd.k.icon} ${bd.k.name}</h3><div class="xs mut" style="margin:8px 0">دیوان زبانِ آدمیان نمی‌فهمند؛ فقط غرش می‌کنند.</div><div class="row wrap" style="gap:8px;justify-content:center"><button class="btn s r" data-o="b3d">⚔️ نبرد</button><button class="btn s d" data-o="bflee">🏃 فرار</button></div></div>`); return; }
    const txt = r === 0 ? "«ما از نبرد خسته‌ایم؛ اگر مزد بدهی، زیر درفش تو می‌جنگیم.»" : r === 1 ? "«تو را می‌شناسیم، سردار. هم‌پیمانی ما بهایی دارد.»" : "«به ما فرمان می‌دهی؟ نخست ثابت کن که شایسته‌ای!»";
    panel(`<div class="owp"><h3>🗣️ ${bd.k.icon} ${bd.k.name}</h3><div class="xs" style="margin:6px 0">${txt}</div><div class="xs mut">اعتبار تو: ${fa(ow.rep)} • هم‌پیمانان: ${fa(ow.allies.length)}/۴</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin-top:8px">${r === 2 ? "" : `<button class="btn s g" data-o="bjoin" ${cap ? "disabled" : ""}>🤝 هم‌پیمان شو (${fa(c)} 🪙)</button>`}<button class="btn s g" data-o="bhag" ${cap ? "disabled" : ""}>🎲 چانه‌زنی</button><button class="btn s r" data-o="b3d">⚔️ نبرد</button><button class="btn s d" data-o="bflee">🏃 برو</button></div></div>`);
  }
  function armyPanel() {
    const list = ow.allies.map((q, i) => `<div class="row" style="justify-content:space-between;gap:8px;margin:4px 0"><span>${q.icon} ${q.name} — قدرت ${fa(q.pow)}</span><button class="btn s d" data-o="dis" data-i="${i}">اخراج</button></div>`).join("") || '<div class="xs mut">هنوز هم‌پیمانی نداری. با گروه‌های روی نقشه گفتگو کن یا از میخانه‌ی شهر مزدور بگیر.</div>';
    panel(`<div class="owp"><h3>👥 سپاه من</h3><div class="xs">قدرت کل: <b>${fa(Math.round(myPow()))}</b> • هم‌پیمانان ${fa(ow.allies.length)}/۴ • اعتبار ${fa(ow.rep)}</div><div style="margin:8px 0;max-height:150px;overflow:auto">${list}</div><div class="xs mut">هر هم‌پیمان آذوقه‌ی بیشتری مصرف می‌کند.</div><button class="btn s d" data-o="close" style="margin-top:6px">بستن</button></div>`);
  }
  // ---- روستا: غارت یا آباد کردن ----
  const vst = (v) => (ow.vs[v.name] = ow.vs[v.name] || { dev: 0, last: Date.now() });
  const devCost = (v) => Math.round(300 * (vst(v).dev + 1) * (1 + S.level * 0.05));
  function villagePanel(v) {
    if (isHostile(v)) return hostilePanel(v);
    pend = v; const st = vst(v), d = st.dev, tax = taxAmt(v);
    const rest = d >= 1 ? '<button class="btn s g" data-o="vrest">🛌 استراحت (رایگان)</button>' : '<button class="btn s g" data-o="rest">🛌 استراحت (۴۰ 🪙)</button>', feed = d >= 2 ? '<button class="btn s g" data-o="vfeed">🍖 آذوقه (رایگان)</button>' : '<button class="btn s g" data-o="feed">🍖 آذوقه (۳۰ 🪙)</button>';
    const vc = Math.round((150 + ow.vol * 40) * (d >= 3 ? 0.5 : 1));
    panel(`<div class="owp"><h3>🏘️ ${v.name} ${d ? "• " + "⭐".repeat(d) : ""}</h3><div class="xs mut">سلامت: ${fa(Math.round(ow.hp))}٪ • داوطلبان: ${fa(ow.vol)} • اعتبار: ${fa(ow.rep)}</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin:8px 0">${rest}${feed}<button class="btn s g" data-o="vol" data-c="${vc}">🏹 داوطلب (${fa(vc)} 🪙)</button></div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin-bottom:6px">${d < 3 ? `<button class="btn s g" data-o="vdev">🏗️ آباد کن (${fa(devCost(v))} 🪙)</button>` : '<span class="xs">✅ آبادی کامل</span>'}${d > 0 ? `<button class="btn s g" data-o="vtax" ${tax < 1 ? "disabled" : ""}>📦 مالیات (${fa(tax)})</button>` : ""}<button class="btn s r" data-o="vsack">🔥 غارت</button></div>
    <div class="xs mut">آبادی: سطح ۱ استراحت رایگان • ۲ آذوقه رایگان و مالیات بیشتر • ۳ داوطلب نیم‌قیمت. غارت اعتبار را کم می‌کند.</div><button class="btn s d" data-o="close" style="margin-top:6px">ادامه‌ی سفر</button></div>`);
  }
  const taxAmt = (v) => { const st = vst(v); return Math.floor(st.dev * 45 * (1 + S.level * 0.1) * Math.min(10, (Date.now() - st.last) / 3600000)); };
  function develop(v) { const st = vst(v), c = devCost(v); if (st.dev >= 3) return; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; st.dev++; if (st.dev === 1) st.last = Date.now(); ow.rep = Math.min(10, ow.rep + 1); save(); msg(`🏗️ ${v.name} آباد شد (سطح ${fa(st.dev)}) • اعتبار +۱`); window.dispatchEvent(new Event("wm-gain")); villagePanel(v); }
  function collect(v) { const t = taxAmt(v); if (t < 1) return; give({ coins: t }); vst(v).last = Date.now(); save(); msg(`📦 مالیات روستا: +${fa(t)} 🪙`); window.dispatchEvent(new Event("wm-gain")); villagePanel(v); }
  function sack(v) { const st = vst(v), loot = Math.round(220 * (1 + S.level * 0.12) * (1 + st.dev * 0.8)), risk = Math.random() < 0.3; panel("");
    give({ coins: loot }); st.dev = 0; st.last = Date.now(); ow.rep = Math.max(-10, ow.rep - 2); v.cd = 20;
    if (risk) { const loss = 14 + Math.floor(Math.random() * 10); ow.hp = Math.max(8, ow.hp - loss); msg(`🔥 غارت شد: +${fa(loot)} 🪙 • مردم شورش کردند: −${fa(loss)}٪ سلامت`); } else msg(`🔥 ${v.name} غارت شد: +${fa(loot)} 🪙 • اعتبار −۲`);
    ow.food = Math.min(100, ow.food + 25); save(); window.dispatchEvent(new Event("wm-gain")); }
  // ---- شهر: میخانه، بازار، میدان ----
  function tavern(t) { if (isHostile(t)) return hostilePanel(t); pend = t; panel(`<div class="owp"><h3>🏙️ ${t.name}</h3><div class="xs mut">میخانه • بازار • میدان گلادیاتورها</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin:8px 0"><button class="btn s g" data-o="rumor">🍺 شایعه (۶۰ 🪙)</button><button class="btn s g" data-o="merc">⚔️ مزدور (${fa(Math.round(120 + SV.kingdomPower() * 14))} 🪙)</button><button class="btn s g" data-o="heal">🍲 غذا و استراحت (۷۰ 🪙)</button><button class="btn s g" data-o="arena">🏟️ میدان</button></div><button class="btn s d" data-o="close">ادامه‌ی سفر</button></div>`); }
  function arena(t) { const cs = Math.round(100 * (1 + S.level * 0.1));
    panel(`<div class="owp"><h3>🏟️ میدان گلادیاتورها</h3><div class="xs mut">تک‌نبرد با پهلوان. هرچه حریف سخت‌تر، پاداش بزرگ‌تر.</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin:8px 0"><button class="btn s g" data-o="duel" data-t="0">🥉 تازه‌کار (${fa(cs)}) ~۷۰٪</button><button class="btn s g" data-o="duel" data-t="1">🥈 جنگاور (${fa(cs * 2)}) ~۵۰٪</button><button class="btn s r" data-o="duel" data-t="2">🥇 پهلوان (${fa(cs * 4)}) ~۳۰٪</button></div><button class="btn s d" data-o="close">برگرد</button></div>`); }
  function duel(tier) { const cs = Math.round(100 * (1 + S.level * 0.1)) * [1, 2, 4][tier]; if (S.coins < cs) { msg("سکه کافی نیست"); return; } S.coins -= cs;
    const p = Math.min(0.9, [0.7, 0.5, 0.3][tier] + Math.min(0.15, SV.kingdomPower() / 400) + (ow.hp - 60) / 600), win = Math.random() < p; panel("");
    if (win) { const coins = Math.round(cs * [1.7, 2.6, 4.2][tier]), gem = tier === 2 ? 3 : tier === 1 ? 1 : 0; give({ coins, gems: gem }); addXp(15 + tier * 20); ow.hp = Math.max(8, ow.hp - 6 - tier * 4); ow.rep = Math.min(10, ow.rep + (tier === 2 ? 1 : 0)); msg(`🏆 در میدان پیروز شدی! +${fa(coins)} 🪙${gem ? " +" + fa(gem) + " 💎" : ""}`); }
    else { ow.hp = Math.max(8, ow.hp - 14 - tier * 6); msg(`🩸 در میدان شکست خوردی • −${fa(cs)} 🪙`); }
    save(); window.dispatchEvent(new Event("wm-gain")); }
  function endFight() {
    const { bd, win } = battle; battle = null; paused = false;
    const loss = Math.round(Math.min(60, 6 + 28 * bd.pow / Math.max(4, myPow())));
    if (win) { const coins = Math.round(bd.pow * (14 + S.level * 0.8) * (1 + rel(bd) * 0.25)), xp = 10 + bd.pow, gem = rel(bd) === 2 ? 2 + Math.floor(Math.random() * 4) : (Math.random() < 0.15 ? 1 : 0); give({ coins, gems: gem }); addXp(xp); ow.hp = Math.max(8, ow.hp - loss * 0.7); bd.dead = 45; S.stats.kills = (S.stats.kills || 0) + bd.n * 4; msg(`🏆 پیروزی! +${fa(coins)} 🪙${gem ? " +" + fa(gem) + " 💎" : ""} • خسارت سپاه ${fa(Math.round(loss * 0.7))}٪`); }
    else { ow.hp = Math.max(6, ow.hp - loss); const lost = Math.min(S.coins, Math.round(S.coins * 0.04 + 30)); S.coins -= lost; P.x = home.x; P.y = home.y + 30; if (R) { R.cam.x = P.x; R.cam.y = P.y; } bd.st = "patrol"; bd.x = bd.hx; bd.y = bd.hy; msg(`💀 شکست! سپاه به کشور عقب نشست • −${fa(lost)} 🪙`); }
    save(); window.dispatchEvent(new Event("wm-gain"));
  }
  const nearest = (f) => { let b = null, bd = 1e9; for (const q of bands) if (!q.dead && f(q)) { const d = Math.hypot(q.x - P.x, q.y - P.y); if (d < bd) { bd = d; b = q; } } return b; };
  function step(dt) {
    if (msgT > 0) { msgT -= dt; if (msgT <= 0) $("s3msg").classList.remove("on"); }
    if (trackT > 0) trackT -= dt; if (ow.rumorT > 0) ow.rumorT -= dt;
    if (battle) { battle.t += dt; if (battle.t > 3.4) endFight(); return; }
    if (paused) return;
    const kx = (key.d || key.arrowright ? 1 : 0) - (key.a || key.arrowleft ? 1 : 0), ky = (key.w || key.arrowup ? 1 : 0) - (key.s || key.arrowdown ? 1 : 0), cya = R.cam.yaw; let mx = kx * -Math.cos(cya) + ky * Math.sin(cya), my = kx * Math.sin(cya) + ky * Math.cos(cya); if (key.q) R.cam.yaw -= dt * 1.5; if (key.e) R.cam.yaw += dt * 1.5;
    if (mx || my) { P.tx = null; P.path = null; P.chase = null; follow = true; }
    if (P.tx === null) P.path = null; else if (!P.path) P.path = [{ x: P.tx, y: P.ty }];
    if (P.chase) { const cb = P.chase; if (cb.dead > 0 || !bands.includes(cb)) P.chase = null; else { P.tx = cb.x; P.ty = cb.y; pT -= dt; if (pT <= 0 || !P.path) { pT = 0.5; P.path = findPath(P.x, P.y, cb.x, cb.y); } } }
    if (P.path && !mx && !my) { const w = P.path[0], dx = w.x - P.x, dy = w.y - P.y, d = Math.hypot(dx, dy); if (d < (P.path.length > 1 ? 14 : 8)) { P.path.shift(); if (!P.path.length) { P.tx = null; P.path = null; P.chase = null; } } else { mx = dx / d; my = dy / d; } }
    const l = Math.hypot(mx, my); if (l > 1) { mx /= l; my /= l; }
    const tl = walk(P.x, P.y), sp = 230 * (tl === 0 ? 0.92 : tl === 2 ? 0.65 : tl === 3 ? 0.4 : 1) * (0.7 + 0.3 * ow.hp / 100); P.boat = tl === 0;
    if (l > 0.05) { P.x = Math.max(14, Math.min(WW - 14, P.x + mx * sp * dt)); P.y = Math.max(14, Math.min(WH - 14, P.y + my * sp * dt)); P.ph += dt * 9 * Math.min(1, l); P.fx = mx / l; P.fy = my / l; P.moving = true; } else { P.ph *= 0.8; P.moving = false; }
    if (follow) { R.cam.x += (P.x - R.cam.x) * Math.min(1, dt * 5); R.cam.y += (P.y - R.cam.y) * Math.min(1, dt * 5); } clampCam();
    if (l > 0.05 && !P.boat) { evDist += sp * dt; if (evDist > evNext && !battle) { evDist = 0; evNext = 700 + Math.random() * 700; roadEvent(); } }
    if (l > 0.05) { ow.food = Math.max(0, ow.food - dt * 0.3 * (1 + 0.25 * ow.allies.length)); if (ow.food <= 0) ow.hp = Math.max(5, ow.hp - dt * 1.2); } if (ow.campT > 0) ow.campT -= dt;
    const nearVillage = villages.some((v) => Math.hypot(v.x - P.x, v.y - P.y) < 150); ow.hp = Math.min(100, ow.hp + dt * (nearVillage ? 3 : 0.25));
    for (const v of villages) if (Math.hypot(v.ent.x - P.x, v.ent.y - P.y) < 46 && !v.cd) { v.cd = 6; P.tx = null; villagePanel(v); }
    for (const t of towns) { if (Math.hypot(t.ent.x - P.x, t.ent.y - P.y) < 50 && !t.cd) { t.cd = 8; P.tx = null; tavern(t); } if (t.cd) t.cd = Math.max(0, t.cd - dt) || 0; }
    const ap = ow.allies; for (let i = 0; i < ap.length; i++) { const q = ap[i], fx = P.fx || 0, fy = P.fy || 1, sd = i % 2 ? 30 : -30, tx = P.x - fx * (60 + i * 36) - fy * sd, ty = P.y - fy * (60 + i * 36) + fx * sd; q.x += (tx - q.x) * Math.min(1, dt * 3.5); q.y += (ty - q.y) * Math.min(1, dt * 3.5); q.ph = (q.ph || 0) + (Math.hypot(tx - q.x, ty - q.y) > 6 ? dt * 9 : 0); }
    for (const v of villages) if (v.cd) v.cd = Math.max(0, v.cd - dt) || 0;
    for (const c of castles) { const st = S.conquered[c.n.id] ? "conq" : (S.level >= c.n.need ? "open" : "locked"); if (Math.hypot(c.ent.x - P.x, c.ent.y - P.y) < 50 && !c.cd) { c.cd = 8; P.tx = null; if (st === "locked") msg(`🔒 ${c.n.name} — نیاز به سطح ${fa(c.n.need)} کشور`); else if (st === "conq") msg(`🏴 ${c.n.name} جزو قلمرو توست`); else panel(`<div class="owp"><h3>${c.n.emoji} ${c.n.name}</h3><div class="xs mut">${c.n.ruler} • قدرت ${fa(c.n.power)} • دروازه ${fa(c.n.gate)}</div><div class="xs" style="margin:6px 0">غنیمت: 🪙${fa(c.n.loot)} 💎${fa(c.n.gems)}</div><div class="row wrap" style="gap:8px;justify-content:center"><button class="btn s r" data-o="atkc" data-id="${c.n.id}">⚔️ حمله</button><button class="btn s d" data-o="close">برگرد</button></div></div>`); } if (c.cd) c.cd = Math.max(0, c.cd - dt) || 0; }
    for (const c of chests) if (!ow.found.includes(c.id) && Math.hypot(c.x - P.x, c.y - P.y) < 26) { ow.found.push(c.id); if (c.gem) { const n = 2 + Math.floor(Math.random() * 4); give({ gems: n }); msg(`🎁 صندوق گنج! +${fa(n)} 💎`); } else { const n = Math.round(140 * (1 + S.level * 0.1) * (0.8 + Math.random() * 0.5)); give({ coins: n }); msg(`🎁 صندوق گنج! +${fa(n)} 🪙`); } save(); window.dispatchEvent(new Event("wm-gain")); }
    facStep(dt);
    for (const b of bands) {
      if (b.fac) continue;
      if (b.dead > 0) { b.dead -= dt; if (b.dead <= 0) { bands.splice(bands.indexOf(b), 1); spawnBand(true); } continue; }
      const d = Math.hypot(b.x - P.x, b.y - P.y), r = rel(b); b.ph += dt * 6;
      let sx = 0, sy = 0, sp2 = 70 * b.k.spd;
      if (d < 280 && r === 0 && myPow() > b.pow * 1.35) { b.st = "flee"; sx = (b.x - P.x) / d; sy = (b.y - P.y) / d; sp2 = 110 * b.k.spd; }
      else if (d < 300 && r >= 1) { b.st = "chase"; sx = (P.x - b.x) / d; sy = (P.y - b.y) / d; sp2 = (r === 2 ? 118 : 100) * b.k.spd; }
      else { b.st = "patrol"; b.tt -= dt; if (b.tt <= 0) { b.tt = 2 + Math.random() * 3; const a = Math.random() * TAU, rad = Math.random() * 120; b.tx = b.hx + Math.cos(a) * rad; b.ty = b.hy + Math.sin(a) * rad; } const dx = b.tx - b.x, dy = b.ty - b.y, dd = Math.hypot(dx, dy); if (dd > 6) { sx = dx / dd; sy = dy / dd; sp2 = 45; } }
      const nx = b.x + sx * sp2 * dt, ny = b.y + sy * sp2 * dt; if (walk(nx, ny) === 1 || walk(nx, ny) === 2) { b.x = nx; b.y = ny; } if (sx || sy) { b.fx = sx; b.fy = sy; }
      if (b.noFight > 0) b.noFight -= dt; else if (d < 34 && !battle && !paused) { P.tx = null; contact(b); }
    }
    if ((hudT -= dt) <= 0) { hudT = 0.2; $("owp").textContent = "قدرت سپاه: " + fa(Math.round(myPow())); $("owhp").style.width = ow.hp + "%"; $("owhpt").textContent = "❤️ " + fa(Math.round(ow.hp)) + "٪"; $("owfd").style.width = ow.food + "%"; $("owfdt").textContent = "🍖 " + fa(Math.round(ow.food)) + "٪"; }
  }
  // ---------- رویدادهای مسیر ----------
  let evDist = 0, evNext = 520 + Math.random() * 380;
  const EVT = [
    () => ({ t: "🛒 تاجر دوره‌گرد", d: "تاجری کنار جاده بساط کرده است: «آذوقه‌ی تازه دارم، رفیق!»", o: [["🍖 خرید آذوقه (۶۰ 🪙)", "ev_food"], ["🗣️ شنیدن شایعه", "ev_rumor"], ["برو", "close"]] }),
    () => ({ t: "🗡️ کمین راهزنان", d: "چند راهزن از پشت صخره‌ها بیرون پریدند و راه را بستند!", o: [["💰 باج (۵۰ 🪙)", "ev_pay"], ["⚔️ مقابله", "ev_fight"], ["🏃 فرار", "ev_flee"]] }),
    () => ({ t: "🤝 کودک گم‌شده", d: "کودکی گریان کنار جاده نشسته و راه خانه را گم کرده است.", o: [["🤝 همراهی‌اش کنم", "ev_child"], ["نادیده بگیر", "close"]] }),
    () => ({ t: "🙏 زیارتگاه کهن", d: "زیارتگاهی قدیمی میان درختان پنهان است؛ آتش مقدسش هنوز روشن است.", o: [["🕯 نیایش (سلامت کامل)", "ev_pray"], ["💎 هدیه (۱ 💎) برای برکت", "ev_gift"], ["برو", "close"]] }),
    () => ({ t: "🐎 اسب سرگردان", d: "اسبی رها شده و زین‌دار میان علف‌ها می‌چرد.", o: [["🐎 بگیرش (آذوقه +۲۰٪)", "ev_horse"], ["بگذار برود", "close"]] }),
  ];
  function roadEvent() { const e = EVT[Math.floor(Math.random() * EVT.length)](); P.tx = null; P.path = null; P.chase = null; panel(`<div class="owp"><h3>${e.t}</h3><div class="xs" style="margin:6px 0 10px;max-width:300px">${e.d}</div><div class="row wrap" style="gap:8px;justify-content:center">${e.o.map(([l, a]) => a === "close" ? `<button class="btn s d" data-o="close">${l}</button>` : `<button class="btn s g" data-ev="${a}">${l}</button>`).join("")}</div></div>`); }
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-ev]"); if (!b) return; const a = b.dataset.ev, done = (m) => { panel(""); msg(m); save(); window.dispatchEvent(new Event("wm-gain")); };
    if (a === "ev_food") { if (S.coins < 60) return msg("سکه کافی نیست"); S.coins -= 60; ow.food = Math.min(100, ow.food + 40); done("🍖 آذوقه +۴۰٪"); }
    else if (a === "ev_rumor") { ow.rumorT = 30; done("🗣️ تاجر جای صندوق‌های گنج را فاش کرد — روی نقشه‌ی کوچک ببین"); }
    else if (a === "ev_pay") { if (S.coins < 50) return msg("سکه کافی نیست"); S.coins -= 50; done("💰 راهزنان با باج رفتند"); }
    else if (a === "ev_fight") { if (Math.random() < Math.min(0.9, 0.35 + myPow() / 120)) { const c = Math.round(60 + S.level * 18); give({ coins: c }); ow.hp = Math.max(8, ow.hp - 6); done(`⚔️ راهزنان را شکست دادی! +${fa(c)} 🪙`); } else { ow.hp = Math.max(6, ow.hp - 18); S.coins = Math.max(0, S.coins - 40); done("🩸 زخمی شدی و کمی سکه از دست رفت"); } }
    else if (a === "ev_flee") { ow.food = Math.max(0, ow.food - 8); done("🏃 گریختی — آذوقه −۸٪"); }
    else if (a === "ev_child") { ow.rep = (ow.rep || 0) + 1; const c = 90 + S.level * 10; give({ coins: c }); done(`🤝 خانواده‌اش سپاسگزارند! +${fa(c)} 🪙 و اعتبار +۱`); }
    else if (a === "ev_pray") { ow.hp = 100; done("🕯 نیرویی تازه در تنت دمید — سلامت کامل"); }
    else if (a === "ev_gift") { if ((S.gems || 0) < 1) return msg("الماس کافی نیست"); S.gems -= 1; ow.hp = 100; ow.food = Math.min(100, ow.food + 25); done("✨ برکت زیارتگاه — سلامت کامل و آذوقه +۲۵٪"); }
    else if (a === "ev_horse") { ow.food = Math.min(100, ow.food + 20); done("🐎 اسب را گرفتی — آذوقه +۲۰٪"); } });
  // ---------- سفر سریع ----------
  function fastTravel() { const dests = [{ n: "🏠 کشور من", x: home.ent.x, y: home.ent.y }, ...towns.map((t) => ({ n: "🏙️ " + t.name, x: t.ent.x, y: t.ent.y })), ...castles.filter((c) => S.conquered[c.n.id]).map((c) => ({ n: "🏴 " + c.n.name, x: c.ent.x, y: c.ent.y }))];
    panel(`<div class="owp"><h3>🐎 سفر سریع</h3><div class="xs mut" style="margin-bottom:8px">هزینه بسته به فاصله است</div><div style="display:flex;flex-direction:column;gap:7px">${dests.map((d, i) => { const c = Math.round(20 + Math.hypot(d.x - P.x, d.y - P.y) / 18); return `<button class="btn s g" data-ft="${i}" data-c="${c}">${d.n} — ${fa(c)} 🪙</button>`; }).join("")}<button class="btn s d" data-o="close">بستن</button></div></div>`);
    $("owpanel").querySelectorAll("[data-ft]").forEach((b) => b.onclick = () => { const d = dests[+b.dataset.ft], c = +b.dataset.c; if (S.coins < c) return msg("سکه کافی نیست"); S.coins -= c; P.x = d.x; P.y = d.y; P.tx = null; P.path = null; P.chase = null; if (R) { R.cam.x = P.x; R.cam.y = P.y; } follow = true; panel(""); msg("🐎 به مقصد رسیدی"); save(); window.dispatchEvent(new Event("wm-gain")); }); }
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-oz=ft]"); if (b && !battle) fastTravel(); });
  // ---------- رسم شخصیت‌ها و جانوران ----------
  const faceOf = (dx, dy) => Math.atan2(dx, dy);
  function chr(o, key, mk, px, py, tyaw, atk, sc = 1, yo = 0, turn = true) {
    if (!GLO) return false;
    const m = o._g || (o._g = {}); let e = m[key]; if (!e) { e = m[key] = SQ.make(mk(), key.length * 7 + Math.round(px)); e.yw = tyaw; }
    if (turn) { let d = tyaw - e.yw; d = Math.atan2(Math.sin(d), Math.cos(d)); e.yw += d * Math.min(1, dtO * 9); }
    SQ.drive(e, { x: px * K, z: py * K, atk: atk || 0, atkMax: 0.5, hurt: 0, dt: dtO });
    return R.char(e, px, py, e.yw, sc, yo);
  }
  const BEAST = { wolf: { s: 0.62, tint: [0.9, 0.92, 1] }, bear: { s: 0.95, tint: [0.62, 0.4, 0.26] }, boar: { s: 0.6, tint: [0.55, 0.42, 0.34] }, lion: { s: 0.74, tint: [1.45, 1.1, 0.6] } };
  const beastT = { tint: [1, 1, 1] };
  function drawBeast(type, px, py, yaw, ph, moving, t) { const B = BEAST[type] || BEAST.wolf, bob = moving ? Math.abs(Math.sin(ph * 2)) * 0.14 : Math.sin(t * 2 + px) * 0.02, x = px * K, z = py * K; beastT.tint = B.tint; const ok = R.inst("wolf", px, py, yaw + (moving ? Math.sin(ph) * 0.05 : 0), B.s, beastT, heightAt3(x, z) + bob); R.shadow(px, py, 0.9 * B.s, 0.34); return ok; }
  const heightAt3 = (x, z) => W3.models ? hAt(x, z) : 0, hAt = (x, z) => R.gy(x / K, z / K);
  const boatO = { tint: [1, 1, 1], team: [0.86, 0.24, 0.2] };
  function drawBoat(px, py, yaw, t, mv, sc = 1, col) { const x = px * K, z = py * K, bob = Math.sin(t * 2.6 + px * 0.04) * 0.08, tilt = Math.sin(t * 2.1 + py * 0.03) * 0.04; if (col) boatO.team = col; boatO.rx = tilt; const ok = R.instW("ow_boat", x, 0.05 + bob, z, yaw, sc, boatO); if (mv) { puff(x - Math.sin(yaw) * 2, 0.15, z - Math.cos(yaw) * 2, 0.8, 1, 1, 1, 0.35); } return ok; }
  const hudLabel = (txt, px, py, h, col, size, opt) => R.label(txt, px, py, h, col, size, opt);
  // ---------- صحنه ----------
  function drawScene(t) {
    R.begin(dtO); const g = R.ov;
    for (const c of chests) if (!ow.found.includes(c.id) && R.dist(c.x, c.y) < 90) { const cx = c.x * K, cz = c.y * K, cy = R.gy(c.x, c.y); boatO.tint = c.gem ? [0.5, 0.9, 1.6] : [1.5, 1.1, 0.5]; const o = { tint: c.gem ? [0.5, 0.9, 1.6] : [1.5, 1.1, 0.5] }; R.instW("d_chest", cx, cy + 0.02, cz, hash(c.x | 0, 1, 2) * TAU, 1.7, o); puff(cx, cy + 1.6 + Math.sin(t * 3 + c.x) * 0.12, cz, 1.3 + Math.sin(t * 4) * 0.2, c.gem ? 0.3 : 1, c.gem ? 0.8 : 0.8, c.gem ? 1 : 0.2, 0.5, true); }
    if (ow.fire && ow.fire.t > 0) { ow.fire.t -= dtO; const f = ow.fire; R.inst("c_campfire", f.x, f.y, 0, 2.1, null); R.inst("c_tent", f.x - 60, f.y + 14, 0.5, 2.0, null); const x = f.x * K, z = f.y * K, y = R.gy(f.x, f.y); R.instW("c_fire", x, y + 0.1, z, t * 3, 2.4 + Math.sin(t * 13) * 0.25, { tint: [1.5, 1.1, 0.6] }); puff(x, y + 1.1, z, 2.6 + Math.sin(t * 17) * 0.3, 1, 0.65, 0.2, 0.55, true); for (let i = 0; i < 3; i++) { const ph = (t * 0.5 + i / 3) % 1; puff(x + Math.sin(ph * 5 + i) * 0.4, y + 2 + ph * 5, z, 0.8 + ph * 2, 0.8, 0.8, 0.82, 0.38 * (1 - ph)); } }
    if (R.drawSites) R.drawSites(t);
    // هم‌پیمانان
    const fx = P.fx || 0, fy = P.fy || 1;
    for (const q of ow.allies) { const qb = walk(q.x, q.y) === 0, face = faceOf(P.fx || 0, P.fy || 1); if (R.dist(q.x, q.y) > 80) continue; if (qb) drawBoat(q.x, q.y, face, t, true, 0.8);
      for (let i = 0; i < Math.min(3, q.n); i++) { const ox = (i - 1) * 30 * -(P.fy || 1) + (P.fx || 0) * (i % 2) * 20, oy = (i - 1) * 30 * (P.fx || 0) + (i % 2) * 20 * (P.fy || 1); chr(q, "a" + i, () => SQ.spec("ally", i === 0 ? "shield" : "sword", i + 3), q.x + ox, q.y + oy, face, 0, 1, qb ? 0.4 : 0, true); }
      hudLabel("🤝 " + q.icon + " " + fa(q.pow), q.x, q.y, 3.6, "#8affb0", 10); }
    // گروه‌ها
    for (const b of bands) { if (b.dead > 0) continue; const d = R.dist(b.x, b.y); if (d > 150) continue; const col = b.fac ? b.fac.col : RC[rel(b)], moving = !(b.st === "patrol" && Math.hypot(b.tx - b.x, b.ty - b.y) < 8), face = faceOf(b.fx || 1, b.fy || 0);
      if (d < 75) { if (b.k.beast) { for (let i = 0; i < b.n; i++) { const px = b.x + ((i % 3) - 1) * 36, py = b.y + Math.floor(i / 3) * 30 + (i % 2) * 8; drawBeast(b.k.id, px, py, face + Math.sin(i * 2.3) * 0.2, b.ph * 1.4 + i * 1.3, moving, t); } }
        else { const nn = Math.min(b.n, d < 45 ? 6 : 3); for (let i = 0; i < nn; i++) { const m = b.look[i], px = b.x + ((i % 3) - 1) * 32 + (Math.floor(i / 3) % 2) * 12, py = b.y + Math.floor(i / 3) * 28; chr(b, "m" + i, () => SQ.spec("foe", b.k.big ? "heavy" : b.k.armor ? "shield" : (m.w === "bow" ? "archer" : "sword"), i + 11), px, py, face, 0, b.k.big ? 1.35 : 1, 0, true); } } }
      else if (d < 150) { R.shadow(b.x, b.y, 1.5, 0.35); }
      const by = b.k.big ? 4.8 : 3.8; hudLabel(`${b.k.icon} ${fa(b.pow)}${b.fac ? "" : " • " + RN[rel(b)]}`, b.x, b.y, by, "#101018", 11, { plate: true, edge: col, dot: col, fix: true });
      if (b.st === "flee") hudLabel("💨", b.x, b.y, by + 1.6, "#fff", 15); else if (b.st === "chase") hudLabel("❗", b.x, b.y, by + 1.6, "#ff6a6a", 15); }
    // قهرمان
    const hy = P.boat ? 0.45 + Math.sin(t * 2.6 + P.x * 0.04) * 0.08 : 0, hface = faceOf(P.fx || 0, P.fy || 1);
    if (P.boat) drawBoat(P.x, P.y, hface, t, !!(P.path || P.moving), 1);
    chr(P, "hero", () => SQ.heroSpec(S.avatar || {}, look), P.x, P.y, hface, 0, 1, hy, true);
    hudLabel("قهرمان", P.x, P.y, 2.9, "#9ac0ff", 11);
    R.end(dtO);
    // --- روکش دوبعدی ---
    for (const s of allSites) { if (s.kind === "camp" || s.kind === "mine") continue; const d = R.dist(s.x, s.y); if (d > (s.kind === "village" ? 95 : 160)) continue; labelSite(s); }
    if (P.path && P.path.length) { const pr = (x, y) => R.proj(x, y, 0.3); g.save(); g.strokeStyle = "rgba(255,255,255,0.7)"; g.lineWidth = 2.4; g.setLineDash([6, 7]); g.lineDashOffset = -t * 30; g.beginPath(); let p = pr(P.x, P.y); if (p) g.moveTo(p[0], p[1]); for (const w of P.path) { p = pr(w.x, w.y); if (p) g.lineTo(p[0], p[1]); } g.stroke(); g.restore(); const e = P.path[P.path.length - 1], pe = pr(e.x, e.y); if (pe) ring(pe[0], pe[1], 12 + Math.sin(t * 6) * 2.5, pe[2], "#ffe08a", 1); }
    if (tapFx) { tapFx.t += dtO; if (tapFx.t > 0.6) tapFx = null; else { const p = R.proj(tapFx.x, tapFx.y, 0.2); if (p) ring(p[0], p[1], 8 + tapFx.t * 60, p[2], "#fff", 1 - tapFx.t / 0.6); } }
    if (trackT > 0) for (const [f, col] of [[(q) => rel(q) === 0, RC[0]], [(q) => rel(q) === 2, RC[2]]]) { const q = nearest(f); if (!q) continue; const dx = q.x - P.x, dz = q.y - P.y, ya = R.cam.yaw, sxv = dx * -Math.cos(ya) + dz * Math.sin(ya), syv = -(dx * Math.sin(ya) + dz * Math.cos(ya)), a = Math.atan2(syv, sxv), cx = VW / 2 + Math.cos(a) * Math.min(VW, VH) * 0.34, cy = VH / 2 + Math.sin(a) * Math.min(VW, VH) * 0.34; g.save(); g.translate(cx, cy); g.rotate(a); g.fillStyle = col; g.strokeStyle = "#000"; g.lineWidth = 2; g.beginPath(); g.moveTo(16, 0); g.lineTo(-8, -10); g.lineTo(-8, 10); g.closePath(); g.fill(); g.stroke(); g.restore(); g.fillStyle = col; g.font = "bold 11px sans-serif"; g.textAlign = "center"; g.fillText(Math.round(Math.hypot(dx, dz) / 10) + "م", cx, cy + 24); }
    if (battle) drawBattle(g, t);
    miniDraw(); if (dbgFps) { const e = $("owfps"); if (e) e.textContent = `${R.fps.toFixed(0)}fps ${R.ms.toFixed(1)}ms • ${(R.tris / 1000).toFixed(0)}k tri • ${R.draws} draws • scale ${W3.scale.toFixed(2)} • lod ${R.lodD.toFixed(0)}/${R.smallD.toFixed(0)}`; }
  }
  function ring(x, y, r, depth, col, a) { const g = R.ov; g.save(); g.globalAlpha = a; g.strokeStyle = col; g.lineWidth = 2.5; g.beginPath(); g.ellipse(x, y, r, r * Math.sin(R.cam.pitch) * 0.8, 0, 0, TAU); g.stroke(); g.fillStyle = col; g.globalAlpha = a * 0.22; g.fill(); g.restore(); }
  function labelSite(s) {
    const own = ownerInfo(s), st = s.kind === "castle" ? (S.conquered[s.n.id] ? "conq" : S.level >= s.n.need ? "open" : "locked") : "", pre = s.kind === "castle" ? (st === "locked" ? "🔒 " : st === "conq" ? "🏴 " : "") : s.kind === "town" ? "🏙️ " : s.kind === "home" ? "🏠 " : "", col = s.kind === "castle" ? (st === "open" ? "#ffb0a0" : st === "conq" ? "#9ac0ff" : "#ddd") : s.kind === "home" ? "#9ac0ff" : s.kind === "town" ? "#ffd9a0" : "#ffe9a8";
    const h = s.kind === "castle" ? 15 : s.kind === "town" ? 13 : s.kind === "home" ? 9 : 6.5;
    R.label(pre + s.name, s.x, s.y, h, col, s.kind === "village" ? 11 : 13, { plate: true, edge: own ? own.css : undefined, dot: own ? own.css : undefined });
  }
  // ---------- نبرد خودکار (روکش) ----------
  function drawBattle(g, t) {
    const k = Math.min(1, battle.t / 3.4); g.fillStyle = `rgba(0,0,0,${0.55 * Math.min(1, battle.t * 2)})`; g.fillRect(0, 0, VW, VH); const cx = VW / 2, cy = VH / 2;
    g.font = "bold 22px Vazirmatn, sans-serif"; g.textAlign = "center"; g.fillStyle = "#fff"; g.fillText(`⚔️ ${battle.bd.k.name}`, cx, cy - 70); g.fillStyle = "#333"; g.fillRect(cx - 120, cy - 52, 240, 12); g.fillStyle = "#4f86ff"; g.fillRect(cx - 120, cy - 52, 240 * (battle.win ? 0.5 + 0.5 * k : 0.5 - 0.5 * k), 12);
    for (let i = 0; i < 9; i++) { const a = hash(i, Math.floor(t * 9), 5) * TAU, r = 16 + hash(i, Math.floor(t * 9), 6) * 34; g.strokeStyle = `rgba(255,${200 + i * 5},120,0.85)`; g.lineWidth = 2; g.beginPath(); g.moveTo(cx + Math.cos(a) * r * 0.4, cy + 20 + Math.sin(a) * r * 0.25); g.lineTo(cx + Math.cos(a) * r, cy + 20 + Math.sin(a) * r * 0.6); g.stroke(); }
    g.font = "bold 13px Vazirmatn, sans-serif"; g.fillStyle = "#9ac0ff"; g.textAlign = "right"; g.fillText(`🛡️ سپاه تو: ${fa(Math.round(battle.mp))}`, cx - 8, cy - 32); g.fillStyle = "#ff9a8a"; g.textAlign = "left"; g.fillText(`${battle.bd.k.icon} ${fa(battle.bd.pow)}`, cx + 8, cy - 32); g.textAlign = "center";
    if (k > 0.85) { const loss = Math.round(Math.min(60, 6 + 28 * battle.bd.pow / Math.max(4, battle.mp)) * 0.7); g.fillStyle = battle.win ? "#7bff9a" : "#ff6a6a"; g.font = "bold 26px Vazirmatn, sans-serif"; g.fillText(battle.win ? "پیروزی!" : "شکست!", cx, cy + 4); g.font = "12px Vazirmatn, sans-serif"; g.fillStyle = "#e8e8f0"; g.fillText(battle.win ? `تلفات سپاه ≈ ${fa(loss)}٪` : "سپاه به کشور عقب می‌نشیند", cx, cy + 24); }
  }
  // ---------- نقشه‌ی کوچک ----------
  const MW = 270, MH = 180, miniBg = document.createElement("canvas"); miniBg.width = MW; miniBg.height = MH;
  function bakeMini() {
    const c = miniBg.getContext("2d"), img = c.createImageData(MW, MH), d = img.data;
    for (let j = 0; j < MH; j++) for (let i = 0; i < MW; i++) { const px = (i + 0.5) / MW * WW, py = (j + 0.5) / MH * WH, e = Efn(px, py), k = cls(px / TS, py / TS), n = (vn(px / 15, py / 15, 6) - 0.5) * 18; let r, g, b;
      if (e < 0.25) { const f = sst(0.0, 0.25, e); r = 12 + f * 70; g = 50 + f * 120; b = 100 + f * 90; } else if (e < 0.272) { r = 218; g = 200; b = 146; } else if (k === 3) { const s = sst(0.82, 0.92, e); r = 130 + s * 115 + n; g = 126 + s * 120 + n; b = 120 + s * 130 + n; } else if (k === 2) { r = 40 + n; g = 92 + n; b = 44 + n; } else { r = 96 + n * 1.5 + e * 30; g = 150 + n; b = 66 + n; }
      const o = (j * MW + i) * 4; d[o] = r; d[o + 1] = g; d[o + 2] = b; d[o + 3] = 255; }
    c.putImageData(img, 0, 0); c.strokeStyle = "rgba(190,150,90,0.9)"; c.lineWidth = 1.6; c.lineJoin = "round"; for (const r of roads) { c.beginPath(); r.forEach((q, i) => i ? c.lineTo(q.x / WW * MW, q.y / WH * MH) : c.moveTo(q.x / WW * MW, q.y / WH * MH)); c.stroke(); }
  }
  function miniDraw() {
    const sx = MW / WW, sy = MH / WH; mini.drawImage(miniBg, 0, 0);
    for (const b of bands) if (b.dead <= 0) { mini.fillStyle = b.fac ? b.fac.col : RC[rel(b)]; mini.fillRect(b.x * sx - 2, b.y * sy - 2, 4, 4); }
    for (const c of castles) { mini.fillStyle = siteCol(c); mini.strokeStyle = "#000"; mini.lineWidth = 1; mini.fillRect(c.x * sx - 3.5, c.y * sy - 3.5, 7, 7); mini.strokeRect(c.x * sx - 3.5, c.y * sy - 3.5, 7, 7); }
    for (const t of towns) { mini.fillStyle = siteCol(t); mini.beginPath(); mini.arc(t.x * sx, t.y * sy, 4, 0, TAU); mini.fill(); mini.strokeStyle = "#000"; mini.stroke(); }
    for (const v of villages) { mini.fillStyle = siteCol(v); mini.fillRect(v.x * sx - 1.8, v.y * sy - 1.8, 3.6, 3.6); }
    if (ow.rumorT > 0) { mini.fillStyle = "#5fd8ff"; for (const c of chests) if (!ow.found.includes(c.id)) mini.fillRect(c.x * sx - 1.5, c.y * sy - 1.5, 3, 3); }
    mini.fillStyle = "#9bd0ff"; mini.strokeStyle = "#fff"; mini.lineWidth = 1.5; mini.beginPath(); mini.arc(home.x * sx, home.y * sy, 4, 0, TAU); mini.fill(); mini.stroke();
    mini.fillStyle = "#4f86ff"; mini.beginPath(); mini.arc(P.x * sx, P.y * sy, 4, 0, TAU); mini.fill(); mini.stroke();
    // میدان دید دوربین (ذوزنقه‌ی تقریبی)
    const c = R.cam, w = c.dist * 1.15 / K * 0.9, hh = c.dist * 0.8 / K; mini.strokeStyle = "rgba(255,255,255,0.75)"; mini.lineWidth = 1.2; const ys = Math.sin(c.yaw), yc = Math.cos(c.yaw); mini.beginPath(); for (const [a, b] of [[-w, -hh], [w, -hh], [w, hh], [-w, hh]]) { const wx = c.x + a * -yc + b * ys * -1, wy = c.y + a * ys + b * -yc; mini.lineTo(wx * sx, wy * sy); } mini.closePath(); mini.stroke();
    mini.save(); mini.translate(MW - 22, 22); mini.restore();
  }
  const siteCol = (s) => { const o = ownerInfo(s); return o ? o.css : "#ffd24a"; };
  function loop(now) { if (ended) return; const dt = Math.min(0.05, (now - last) / 1000); last = now; try { dtO = dt; if (R && !loading) { step(dt); drawScene(now / 1000); } } catch (e) { console.error(e); } raf = requestAnimationFrame(loop); }
  window.__owdbg = { walk, goTo, spawnTest: (id) => { const k = KINDS.find((q) => q.id === id), b = bands.find((q) => q.k.beast) || bands[0]; b.k = k; b.x = P.x + 90; b.y = P.y + 20; b.hx = b.x; b.hy = b.y; b.n = 3; b.noFight = 999; return b; }, P, bands, ow, villages, towns, chests, castles, home, camps, mines, allSites, get R() { return R; }, setZoom: (z) => setZoom(z), tapAt, contact: (b) => contact(b), panel, FX };
  raf = requestAnimationFrame(loop);
  // ---- راه‌اندازی GL ----
  R = createOW3D(cv, ovc, { WW, WH, E: Efn, cls: walk, fn: (px, py) => fnoise(px / TS, py / TS), roads, sites: allSites, fields, start: { x: P.x, y: P.y } });
  const okGL = await R.init().catch((e) => { console.error(e); return false; });
  if (!okGL) { $("owload").innerHTML = "<span>⚠️ خطا در راه‌اندازی نقشه سه‌بعدی<br><small style=\"direction:ltr;display:block;opacity:.8\">" + String(R.err || "").slice(0, 160) + "</small></span>"; setTimeout(() => quit(), 6000); return; }
  R.resize(); VW = R.vw; VH = R.vh; bakeMini(); R.cam.x = P.x; R.cam.y = P.y; setZoom(36); C3.setMode("ext"); GLO = await SQ.init().then((ok) => ok && SQ.ready()).catch(() => false);
  for (const s of allSites) s.team = defTeam(s); for (const s of allFacSites) { const o = ownerInfo(s); if (o) s.team = o.rgb; }
  R.setupSites(allSites);
  loading = false; $("owload").remove(); msg("🗺️ برای حرکت روی نقشه لمس کن • با دو انگشت زوم کن • 🔍 ردیاب");
}
