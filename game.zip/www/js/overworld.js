// نقشه‌ی بزرگ: گشت‌وگذار آزاد، گروه‌های ضعیف و قوی، روستا، قلعه، صندوق و ردیاب (الهام از «انسان و فولاد»/مونت‌اند‌بلید)
import { S, give, save, addXp } from "./save.js";
import * as SV from "./save.js";
import { NEIGHBORS, fa, rng } from "./data.js";
import { drawHuman } from "./human.js";
import { lookOf } from "./gear.js";
import * as SQ from "./squad.js";
import { frameBegin, renderInst, blit } from "./char3d.js";

const TS = 40, WT = 70, HT = 46, WW = WT * TS, WH = HT * TS, TAU = Math.PI * 2;
const hash = (x, y, s) => { let h = (x * 374761393 + y * 668265263 + s * 2147483647) | 0; h = (h ^ (h >> 13)) * 1274126177; return ((h ^ (h >> 16)) >>> 0) / 4294967295; };
const vn = (x, y, s) => { const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, sm = (t) => t * t * (3 - 2 * t), a = hash(xi, yi, s), b = hash(xi + 1, yi, s), c = hash(xi, yi + 1, s), d = hash(xi + 1, yi + 1, s); return a + (b - a) * sm(fx) + (c - a) * sm(fy) + (a - b - c + d) * sm(fx) * sm(fy); };
const KINDS = [
  { id: "bandit", name: "راهزنان", icon: "🗡️", mem: ["club", "sword"], cloth: ["#6a4a2a", "#5a3a2a", "#4a4a38"], n: [3, 6], spd: 1 },
  { id: "turan", name: "سواران تورانی", icon: "🏹", mem: ["bow", "spear"], cloth: ["#8a2a2a", "#7a3a1a"], armor: "#8a7a5a", n: [3, 5], spd: 1.1 },
  { id: "wolf", name: "گله‌ی گرگ", icon: "🐺", mem: [], n: [3, 5], spd: 1.25, beast: true },
  { id: "div", name: "دیوان مازندران", icon: "👹", mem: ["club"], cloth: ["#2a4a3a"], skin: "#4a7a5a", n: [2, 3], spd: 0.8, big: true },
];
export function startOverworld(cb, resume) {
  const root = document.createElement("div"); root.id = "s3d"; root.className = "ow";
  root.innerHTML = `<canvas id="owc"></canvas>
  <div class="s3top"><div class="owbar"><b>🗺️ نقشه‌ی بزرگ</b> <span id="owp"></span> <div class="s3bar"><i id="owhp"></i><span id="owhpt"></span></div><div class="s3bar g"><i id="owfd"></i><span id="owfdt"></span></div></div><div class="s3r"><button class="s3b sm" data-o="camp">⛺</button><button class="s3b sm" data-o="army">👥</button><button class="s3b sm" data-o="track">🔍</button><button class="s3b sm" data-o="quit">✖</button></div></div>
  <div id="s3msg"></div><div class="s3joy" id="s3joy"><i id="s3knob"></i></div><canvas id="owmini" width="150" height="100"></canvas>
  <div class="owpanel" id="owpanel" style="display:none"></div>`;
  document.body.appendChild(root); document.body.classList.add("inbattle");
  const cv = root.querySelector("#owc"), g = cv.getContext("2d", { alpha: false }), mini = root.querySelector("#owmini").getContext("2d");
  const $ = (id) => root.querySelector("#" + id);
  if (!S.ow) S.ow = { hp: 100, vol: 0, found: [], per: -1, x: -1, y: 0, food: 100 }; if (S.ow.food === undefined) S.ow.food = 100; if (!S.ow.allies) S.ow.allies = []; if (!S.ow.vs) S.ow.vs = {}; if (S.ow.rep === undefined) S.ow.rep = 0;
  const ow = S.ow, seed = 77;
  const elev = (x, y) => vn(x / 9, y / 9, seed) * 0.62 + vn(x / 4, y / 4, seed + 1) * 0.26 + vn(x / 1.7, y / 1.7, seed + 3) * 0.12, fnoise = (x, y) => vn(x / 5, y / 5, seed + 2) * 0.75 + vn(x / 2, y / 2, seed + 4) * 0.25;
  const cls = (fx, fy) => { const e = elev(fx, fy), edge = Math.min(fx, fy, WT - fx, HT - fy); if (e < 0.25 || edge < 1.2) return 0; if (e > 0.76) return 3; if (fnoise(fx, fy) > 0.62 && e > 0.42) return 2; return 1; };
  const walk = (x, y) => cls(x / TS, y / TS);
  // نقشه‌ی از پیش‌کشیده‌ی پیوسته (ساحل، جنگل، کوه)
  const MS = 0.5, bg = document.createElement("canvas"); bg.width = WW * MS; bg.height = WH * MS; const bx = bg.getContext("2d"); bx.scale(MS, MS);
  const ST = 5; for (let y = 0; y < WH; y += ST) for (let x = 0; x < WW; x += ST) { const fx = x / TS, fy = y / TS, e = elev(fx, fy), c = cls(fx, fy), n = hash(x, y, 3) * 8;
    let col; if (c === 0) { const d = Math.max(0, Math.min(1, (0.25 - e) / 0.2)); col = e > 0.2 ? `rgb(${120 + n},${190 + n},${210})` : `rgb(${40 - d * 18 + n},${110 - d * 40 + n},${170 - d * 40 + n})`; }
    else if (c === 3) col = `rgb(${118 + (e - 0.76) * 300 + n},${116 + (e - 0.76) * 300 + n},${124 + (e - 0.76) * 300 + n})`;
    else if (e < 0.268) col = `rgb(${222 + n},${204 + n},${150 + n})`;
    else if (c === 2) col = `rgb(${38 + n},${94 + fnoise(fx, fy) * 40 + n},${48 + n})`;
    else col = `rgb(${88 + vn(fx * 2, fy * 2, 6) * 36 + n},${150 + vn(fx * 3, fy * 3, 7) * 30 + n},${70 + n})`;
    bx.fillStyle = col; bx.fillRect(x, y, ST + 1, ST + 1); }
  for (let j = 0; j < HT * 2; j++) for (let i = 0; i < WT * 2; i++) { const x = i * TS / 2 + hash(i, j, 11) * TS / 2, y = j * TS / 2 + hash(i, j, 12) * TS / 2, c = cls(x / TS, y / TS), h = hash(i, j, 13);
    if (c === 2 && h > 0.25) { bx.fillStyle = "rgba(0,0,0,0.25)"; bx.beginPath(); bx.ellipse(x, y + 14, 13, 4, 0, 0, TAU); bx.fill(); bx.fillStyle = "#5a3a22"; bx.fillRect(x - 2, y, 4, 14); bx.fillStyle = h > 0.65 ? "#2a6e36" : "#348a42"; bx.beginPath(); bx.moveTo(x - 14, y + 2); bx.lineTo(x, y - 26); bx.lineTo(x + 14, y + 2); bx.fill(); bx.fillStyle = "rgba(255,255,255,0.12)"; bx.beginPath(); bx.moveTo(x - 4, y - 8); bx.lineTo(x, y - 22); bx.lineTo(x + 4, y - 8); bx.fill(); }
    else if (c === 3 && h > 0.3) { bx.fillStyle = "#7a7a88"; bx.strokeStyle = "#3a3a46"; bx.lineWidth = 1; bx.beginPath(); bx.moveTo(x - 20, y + 12); bx.lineTo(x - 2, y - 24 - h * 14); bx.lineTo(x + 20, y + 12); bx.closePath(); bx.fill(); bx.stroke(); bx.fillStyle = "#f4f6fc"; bx.beginPath(); bx.moveTo(x - 9, y - 6 - h * 14); bx.lineTo(x - 2, y - 24 - h * 14); bx.lineTo(x + 6, y - 8 - h * 14); bx.closePath(); bx.fill(); }
    else if (c === 1 && h > 0.93) { bx.fillStyle = ["#ffe58a", "#ff9ab0", "#fff"][(h * 1000) % 3 | 0]; bx.beginPath(); bx.arc(x, y, 2.2, 0, TAU); bx.fill(); }
    else if (c === 1 && h < 0.04) { bx.fillStyle = "#8a8a98"; bx.beginPath(); bx.ellipse(x, y, 6, 4, 0, 0, TAU); bx.fill(); } }
  const rr = rng(9);
  // ---- نقاط مهم ----
  const used = []; const free = (sp = 260) => { for (let k = 0; k < 600; k++) { const x = (4 + rr() * (WT - 8)) * TS, y = (4 + rr() * (HT - 8)) * TS; if (walk(x, y) === 1 && walk(x + 30, y) === 1 && walk(x - 30, y) === 1 && used.every(([a, b]) => Math.hypot(a - x, b - y) > sp)) { used.push([x, y]); return [x, y]; } } return [WW / 2 + rr() * 80, WH / 2 + rr() * 80]; };
  const castles = NEIGHBORS.map((n, i) => { const [x, y] = free(300); return { n, x, y }; });
  const villages = ["روستای گلستان", "ده‌ی مرغزار", "آبادی سرچشمه", "روستای دامغان", "ده‌ی کوهپایه", "آبادی مهرآباد", "روستای سیمین", "ده‌ی چناران"].map((name) => { const [x, y] = free(240); return { name, x, y }; });
  const towns = ["شهر بازار", "شهر سپیدرود"].map((name, i) => { const [x, y] = free(320); return { name, x, y, i }; });
  const [hx, hy] = free(300); const home = { x: hx, y: hy };
  if (ow.x < 0) { ow.x = hx + 60; ow.y = hy + 40; if (walk(ow.x, ow.y) === 0) { ow.x = hx; ow.y = hy; } }
  const P = { x: ow.x, y: ow.y, dir: 1, ph: 0, tx: null, ty: null, vx: 0, vy: 0 }, look = lookOf(S.avatar);
  const per = Math.floor(Date.now() / 21600000); if (ow.per !== per) { ow.per = per; ow.found = []; }
  const rc = rng(per * 31 + 5), chests = Array.from({ length: 12 }, (_, i) => { const x = (3 + rc() * (WT - 6)) * TS, y = (3 + rc() * (HT - 6)) * TS; return { id: "c" + i, x, y, gem: i % 4 === 3, ok: walk(x, y) !== 0 }; }).filter((c) => c.ok);
  const allyPow = () => ow.allies.reduce((a, q) => a + q.pow, 0);
  const myPow = () => Math.max(4, (SV.kingdomPower() + 2 * ow.vol + allyPow()) * (0.45 + 0.55 * ow.hp / 100) * (0.75 + 0.25 * Math.min(1, ow.food / 40)));
  const bands = [];
  function spawnBand(initial) { const k = KINDS[Math.floor(Math.random() * KINDS.length)], [x, y] = free(0); used.pop(); if (initial && Math.hypot(x - P.x, y - P.y) < 350) return spawnBand(initial);
    const base = SV.kingdomPower() + 2 * ow.vol, ratio = [0.35, 0.5, 0.6, 0.8, 1, 1.2, 1.5, 1.9, 2.5][Math.floor(Math.random() * 9)] * (k.big ? 1.3 : 1), n = k.n[0] + Math.floor(Math.random() * (k.n[1] - k.n[0] + 1));
    bands.push({ k, x, y, hx: x, hy: y, pow: Math.max(3, Math.round(base * ratio)), n, ph: Math.random() * 6, dir: 1, st: "patrol", tx: x, ty: y, tt: 0, dead: 0, look: Array.from({ length: n }, (_, i) => ({ c: k.cloth ? k.cloth[i % k.cloth.length] : "#5a4a3a", w: k.mem[i % Math.max(1, k.mem.length)], s: ["#d2a074", "#b07a50", "#8a5a3a", "#e8c0a0"][(i + x) % 4 | 0] })) }); }
  for (let i = 0; i < 20; i++) spawnBand(true);
  const rel = (b) => { const r = b.pow / myPow(); return r < 0.8 ? 0 : r < 1.3 ? 1 : 2; }, RC = ["#5be07a", "#ffd24a", "#ff5a4a"], RN = ["ضعیف", "هم‌قدر", "قوی"];
  let msgT = 0, paused = false, ended = false, raf = 0, last = performance.now(), trackT = 0, battle = null, hudT = 0;
  const msg = (m) => { const e = $("s3msg"); e.textContent = m; e.classList.add("on"); msgT = 3.2; };
  const key = {}, joy = { x: 0, y: 0, id: null };
  const onKD = (e) => { key[e.key.toLowerCase()] = true; if (e.key === "Escape") quit(); }, onKU = (e) => { key[e.key.toLowerCase()] = false; };
  addEventListener("keydown", onKD); addEventListener("keyup", onKU);
  const joyEl = $("s3joy"), knob = $("s3knob");
  const jm = (e) => { const r = joyEl.getBoundingClientRect(), R = r.width / 2; let dx = (e.clientX - r.left - R) / R, dy = (e.clientY - r.top - R) / R; const l = Math.hypot(dx, dy); if (l > 1) { dx /= l; dy /= l; } joy.x = Math.abs(dx) < 0.1 ? 0 : dx; joy.y = Math.abs(dy) < 0.1 ? 0 : dy; knob.style.transform = `translate(${dx * R * 0.55}px,${dy * R * 0.55}px)`; P.tx = null; };
  joyEl.addEventListener("pointerdown", (e) => { joy.id = e.pointerId; joyEl.setPointerCapture(e.pointerId); jm(e); e.preventDefault(); });
  joyEl.addEventListener("pointermove", (e) => { if (e.pointerId === joy.id) jm(e); });
  const je = (e) => { if (e.pointerId === joy.id) { joy.id = null; joy.x = joy.y = 0; knob.style.transform = ""; } }; joyEl.addEventListener("pointerup", je); joyEl.addEventListener("pointercancel", je);
  let camX = P.x, camY = P.y, VW = 800, VH = 400, dpr = 1;
  const resize = () => { dpr = Math.min(2, devicePixelRatio || 1); VW = root.clientWidth; VH = root.clientHeight; cv.width = VW * dpr; cv.height = VH * dpr; cv.style.width = VW + "px"; cv.style.height = VH + "px"; }; resize(); addEventListener("resize", resize);
  cv.addEventListener("pointerdown", (e) => { if (battle) return; const r = cv.getBoundingClientRect(); P.tx = camX - VW / 2 + (e.clientX - r.left); P.ty = camY - VH / 2 + (e.clientY - r.top); });
  function panel(html) { const p = $("owpanel"); p.innerHTML = html; p.style.display = html ? "flex" : "none"; paused = !!html; }
  function quit(callQuit = true) { if (ended) return; ended = true; cancelAnimationFrame(raf); removeEventListener("keydown", onKD); removeEventListener("keyup", onKU); removeEventListener("resize", resize); ow.x = P.x; ow.y = P.y; save(); root.remove(); document.body.classList.remove("inbattle"); window.__s3d = null; if (callQuit) cb && cb.quit && cb.quit(); }
  window.__s3d = { back() { if (battle) return; if ($("owpanel").style.display !== "none") panel(""); else quit(); } };
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-o]"); if (!b) return; const a = b.dataset.o;
    if (a === "quit") quit(); else if (a === "track") { trackT = 6; msg("🔍 ردیابی فعال: سبز = ضعیف، قرمز = قوی"); } else if (a === "close") panel("");
    else if (a === "rest") { const c = 40; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.hp = 100; save(); panel(""); msg("🛌 سپاه استراحت کرد — سلامت کامل"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "vol") { if (ow.vol >= 12) { msg("حداکثر داوطلب"); return; } const c = +b.dataset.c || (150 + ow.vol * 40); if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.vol++; save(); panel(""); msg(`🏹 داوطلب تازه! قدرت +۲ (جمعاً ${fa(ow.vol)})`); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "b3d") { const bd = pend; panel(""); const th = { bandit: "n2", turan: "n3", wolf: "n1", div: "n4" }[bd.k.id] || "n2"; ow.x = P.x; ow.y = P.y; const keep = { pow: bd.pow, n: bd.n, k: bd.k }; quit(false); cb && cb.band && cb.band({ id: th, name: bd.k.name, emoji: bd.k.icon, gate: Math.max(140, bd.pow * 16), power: Math.max(8, bd.pow), keep }); }
    else if (a === "bq") { const bd = pend; panel(""); fight(bd); }
    else if (a === "bpay") { const bd = pend, c = Math.round(bd.pow * 9 + 40); if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; panel(""); bd.dead = 30; save(); window.dispatchEvent(new Event("wm-gain")); msg(`💰 ${fa(c)} سکه دادی و آن‌ها رفتند`); }
    else if (a === "bflee") { pend.noFight = 4; panel(""); msg("🏃 از کنارشان گریختی"); }
    else if (a === "camp") { if (ow.food < 12) { msg("آذوقه کافی نیست"); return; } if (ow.campT > 0) { msg("هنوز نمی‌توانی اردو بزنی"); return; } ow.campT = 25; ow.food -= 10; ow.hp = Math.min(100, ow.hp + 25); msg("⛺ اردو زدی — سلامت +۲۵٪، آذوقه −۱۰٪"); }
    else if (a === "feed") { const c = 30; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.food = 100; save(); panel(""); msg("🍖 آذوقه پر شد"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "btalk") talk(pend);
    else if (a === "bjoin") { const bd = pend, c = joinCost(bd); if (ow.allies.length >= 4) { msg("حداکثر ۴ گروه هم‌پیمان"); return; } if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.allies.push({ k: bd.k.id, name: bd.k.name, icon: bd.k.icon, pow: Math.max(3, Math.round(bd.pow * 0.75)), n: bd.n, look: bd.look, x: bd.x, y: bd.y }); bd.dead = 0.01; panel(""); save(); msg(`🤝 ${bd.k.name} به سپاه تو پیوستند! قدرت +${fa(Math.round(bd.pow * 0.75))}`); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "bhag") { const bd = pend; panel(""); if (Math.random() < 0.35 + ow.rep * 0.02) { const c = Math.round(joinCost(bd) * 0.5); if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; if (ow.allies.length < 4) { ow.allies.push({ k: bd.k.id, name: bd.k.name, icon: bd.k.icon, pow: Math.max(3, Math.round(bd.pow * 0.6)), n: bd.n, look: bd.look, x: bd.x, y: bd.y }); bd.dead = 0.01; msg(`🤝 چانه زدی و ${bd.k.name} پذیرفتند`); } save(); window.dispatchEvent(new Event("wm-gain")); } else { bd.noFight = 0; msg("😠 نپذیرفتند — آماده‌ی نبرد باش"); setTimeout(() => contact(bd), 600); } }
    else if (a === "army") armyPanel();
    else if (a === "dis") { const i = +b.dataset.i; ow.allies.splice(i, 1); save(); armyPanel(); }
    else if (a === "vsack") sack(pend);
    else if (a === "vdev") develop(pend);
    else if (a === "vtax") collect(pend);
    else if (a === "vrest") { ow.hp = 100; save(); panel(""); msg("🛌 استراحت رایگان در آبادی خودت"); }
    else if (a === "vfeed") { ow.food = 100; save(); panel(""); msg("🍖 آذوقه‌ی رایگان"); }
    else if (a === "tav") tavern(pend);
    else if (a === "rumor") { const c = 60; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.rumorT = 90; trackT = 25; save(); panel(""); msg("🗣️ شایعه شنیدی: صندوق‌ها روی نقشه‌ی کوچک پیدایند و ردیاب فعال است"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "merc") { const base = SV.kingdomPower(), c = Math.round(120 + base * 14); if (ow.allies.length >= 4) { msg("حداکثر ۴ گروه هم‌پیمان"); return; } if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.allies.push({ k: "merc", name: "مزدوران شمشیرزن", icon: "⚔️", pow: Math.max(4, Math.round(base * 0.45)), n: 3, look: [0, 1, 2].map((i) => ({ c: ["#4a5a7a", "#6a4a4a", "#4a6a4a"][i], w: ["sword", "spear", "sword"][i], s: ["#d2a074", "#b07a50", "#8a5a3a"][i] })), x: P.x, y: P.y }); save(); panel(""); msg("⚔️ مزدوران به سپاهت پیوستند"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "heal") { const c = 70; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.hp = 100; ow.food = Math.max(ow.food, 70); save(); panel(""); msg("🍲 غذای گرم و استراحت — سلامت و آذوقه پر شد"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "arena") arena(pend);
    else if (a === "duel") duel(+b.dataset.t);
    else if (a === "atkc") { const id = b.dataset.id; quit(); cb && cb.castle && cb.castle(id); } });
  // ---- نبرد خودکار ----
  function fight(bd) {
    const mp = myPow(), a = Math.pow(mp, 1.35), b = Math.pow(bd.pow, 1.35), win = Math.random() < a / (a + b) * 1.06 - 0.03;
    battle = { bd, t: 0, win, mp }; paused = true;
  }
  let pend = null;
  function contact(b) {
    pend = b; const r = rel(b), pay = Math.round(b.pow * 9 + 40);
    panel(`<div class="owp"><h3>${b.k.icon} ${b.k.name}</h3><div class="xs">قدرت آن‌ها <b style="color:${RC[r]}">${fa(b.pow)} (${RN[r]})</b> • قدرت تو <b>${fa(Math.round(myPow()))}</b></div>
    <div class="xs mut" style="margin:4px 0 8px">${r === 0 ? "این‌ها از تو می‌ترسند؛ شکست‌شان آسان است." : r === 1 ? "نبردی هم‌قدر؛ با خودت وارد میدان شو تا شانس بیشتر شود." : "بسیار خطرناک! بهتر است فرار کنی یا با دستِ خودت بجنگی."}</div>
    <div class="row wrap" style="gap:8px;justify-content:center"><button class="btn s r" data-o="b3d">⚔️ نبرد سه‌بعدی</button><button class="btn s g" data-o="bq">⚡ نبرد سریع</button>${b.k.beast ? "" : '<button class="btn s g" data-o="btalk">🗣️ گفتگو</button>'}<button class="btn s d" data-o="bpay">💰 باج (${fa(pay)})</button><button class="btn s d" data-o="bflee">🏃 فرار</button></div></div>`);
  }
  function settle(bd, win, how) {
    const loss = Math.round(Math.min(60, 6 + 28 * bd.pow / Math.max(4, myPow())));
    if (win) { const coins = Math.round(bd.pow * (14 + S.level * 0.8) * (1 + rel(bd) * 0.25) * (how === "3d" ? 1.25 : 1)), xp = 10 + bd.pow, gem = rel(bd) === 2 ? 2 + Math.floor(Math.random() * 4) : (Math.random() < 0.15 ? 1 : 0); give({ coins, gems: gem }); addXp(xp); ow.hp = Math.max(8, ow.hp - loss * (how === "3d" ? 0.4 : 0.7)); S.stats.kills = (S.stats.kills || 0) + bd.n * 4; msg(`🏆 پیروزی! +${fa(coins)} 🪙${gem ? " +" + fa(gem) + " 💎" : ""}`); if (bd.dead !== undefined) bd.dead = 45; }
    else { ow.hp = Math.max(6, ow.hp - loss); const lost = Math.min(S.coins, Math.round(S.coins * 0.04 + 30)); S.coins -= lost; P.x = home.x; P.y = home.y + 30; camX = P.x; camY = P.y; if (ow.allies.length && Math.random() < 0.4) { const q = ow.allies.pop(); msg(`💀 شکست! ${q.name} فرار کردند • −${fa(lost)} 🪙`); } else msg(`💀 شکست! سپاه به کشور عقب نشست • −${fa(lost)} 🪙`); if (bd.st) { bd.st = "patrol"; bd.x = bd.hx; bd.y = bd.hy; } }
    save(); window.dispatchEvent(new Event("wm-gain"));
  }
  if (resume && resume.band) { setTimeout(() => settle(resume.band, resume.won, "3d"), 400); }
  // ---- گفتگو و هم‌پیمانی ----
  const joinCost = (bd) => Math.round((bd.pow * (bd.k.id === "turan" ? 13 : 10) + 70) * (1 - Math.min(0.3, ow.rep * 0.03)) * (1 + Math.max(0, -ow.rep) * 0.1));
  function talk(bd) {
    pend = bd; const r = rel(bd), c = joinCost(bd), cap = ow.allies.length >= 4;
    if (bd.k.id === "div") { panel(`<div class="owp"><h3>${bd.k.icon} ${bd.k.name}</h3><div class="xs mut" style="margin:8px 0">دیوان زبانِ آدمیان نمی‌فهمند؛ فقط غرش می‌کنند.</div><div class="row wrap" style="gap:8px;justify-content:center"><button class="btn s r" data-o="b3d">⚔️ نبرد</button><button class="btn s d" data-o="bflee">🏃 فرار</button></div></div>`); return; }
    const txt = r === 0 ? "«ما از نبرد خسته‌ایم؛ اگر مزد بدهی، زیر درفش تو می‌جنگیم.»" : r === 1 ? "«تو را می‌شناسیم، سردار. هم‌پیمانی ما بهایی دارد.»" : "«به ما فرمان می‌دهی؟ نخست ثابت کن که شایسته‌ای!»";
    panel(`<div class="owp"><h3>🗣️ ${bd.k.icon} ${bd.k.name}</h3><div class="xs" style="margin:6px 0">${txt}</div><div class="xs mut">اعتبار تو: ${fa(ow.rep)} • هم‌پیمانان: ${fa(ow.allies.length)}/۴</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin-top:8px">${r === 2 ? "" : `<button class="btn s g" data-o="bjoin" ${cap ? "disabled" : ""}>🤝 هم‌پیمان شو (${fa(c)} 🪙)</button>`}<button class="btn s g" data-o="bhag" ${cap ? "disabled" : ""}>🎲 چانه‌زنی</button><button class="btn s r" data-o="b3d">⚔️ نبرد</button><button class="btn s d" data-o="bflee">🏃 برو</button></div></div>`);
  }
  function armyPanel() {
    const list = ow.allies.map((q, i) => `<div class="row" style="justify-content:space-between;gap:8px;margin:4px 0"><span>${q.icon} ${q.name} — قدرت ${fa(q.pow)}</span><button class="btn s d" data-o="dis" data-i="${i}">اخراج</button></div>`).join("") || '<div class="xs mut">هنوز هم‌پیمانی نداری. با گروه‌های روی نقشه گفتگو کن یا از میخانه‌ی شهر مزدور بگیر.</div>';
    panel(`<div class="owp"><h3>👥 سپاه من</h3><div class="xs">قدرت کل: <b>${fa(Math.round(myPow()))}</b> • هم‌پیمانان ${fa(ow.allies.length)}/۴ • اعتبار ${fa(ow.rep)}</div><div style="margin:8px 0;max-height:150px;overflow:auto">${list}</div><div class="xs mut">هر هم‌پیمان آذوقه‌ی بیشتری مصرف می‌کند.</div><button class="btn s d" data-o="close" style="margin-top:6px">بستن</button></div>`);
  }
  // ---- روستا: غارت یا آباد کردن ----
  const vst = (v) => (ow.vs[v.name] = ow.vs[v.name] || { dev: 0, last: Date.now() });
  const devCost = (v) => Math.round(300 * (vst(v).dev + 1) * (1 + S.level * 0.05));
  function villagePanel(v) {
    pend = v; const st = vst(v), d = st.dev, tax = taxAmt(v);
    const rest = d >= 1 ? '<button class="btn s g" data-o="vrest">🛌 استراحت (رایگان)</button>' : '<button class="btn s g" data-o="rest">🛌 استراحت (۴۰ 🪙)</button>', feed = d >= 2 ? '<button class="btn s g" data-o="vfeed">🍖 آذوقه (رایگان)</button>' : '<button class="btn s g" data-o="feed">🍖 آذوقه (۳۰ 🪙)</button>';
    const vc = Math.round((150 + ow.vol * 40) * (d >= 3 ? 0.5 : 1));
    panel(`<div class="owp"><h3>🏘️ ${v.name} ${d ? "• " + "⭐".repeat(d) : ""}</h3><div class="xs mut">سلامت: ${fa(Math.round(ow.hp))}٪ • داوطلبان: ${fa(ow.vol)} • اعتبار: ${fa(ow.rep)}</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin:8px 0">${rest}${feed}<button class="btn s g" data-o="vol" data-c="${vc}">🏹 داوطلب (${fa(vc)} 🪙)</button></div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin-bottom:6px">${d < 3 ? `<button class="btn s g" data-o="vdev">🏗️ آباد کن (${fa(devCost(v))} 🪙)</button>` : '<span class="xs">✅ آبادی کامل</span>'}${d > 0 ? `<button class="btn s g" data-o="vtax" ${tax < 1 ? "disabled" : ""}>📦 مالیات (${fa(tax)})</button>` : ""}<button class="btn s r" data-o="vsack">🔥 غارت</button></div>
    <div class="xs mut">آبادی: سطح ۱ استراحت رایگان • ۲ آذوقه رایگان و مالیات بیشتر • ۳ داوطلب نیم‌قیمت. غارت اعتبار را کم می‌کند.</div><button class="btn s d" data-o="close" style="margin-top:6px">ادامه‌ی سفر</button></div>`);
  }
  const taxAmt = (v) => { const st = vst(v); return Math.floor(st.dev * 45 * (1 + S.level * 0.1) * Math.min(10, (Date.now() - st.last) / 3600000)); };
  function develop(v) { const st = vst(v), c = devCost(v); if (st.dev >= 3) return; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; st.dev++; if (st.dev === 1) st.last = Date.now(); ow.rep = Math.min(10, ow.rep + 1); save(); msg(`🏗️ ${v.name} آباد شد (سطح ${fa(st.dev)}) • اعتبار +۱`); window.dispatchEvent(new Event("wm-gain")); villagePanel(v); }
  function collect(v) { const t = taxAmt(v); if (t < 1) return; give({ coins: t }); vst(v).last = Date.now(); save(); msg(`📦 مالیات روستا: +${fa(t)} 🪙`); window.dispatchEvent(new Event("wm-gain")); villagePanel(v); }
  function sack(v) { const st = vst(v), loot = Math.round(220 * (1 + S.level * 0.12) * (1 + st.dev * 0.8)), risk = Math.random() < 0.3; panel("");
    give({ coins: loot }); st.dev = 0; st.last = Date.now(); ow.rep = Math.max(-10, ow.rep - 2); v.cd = 20;
    if (risk) { const loss = 14 + Math.floor(Math.random() * 10); ow.hp = Math.max(8, ow.hp - loss); msg(`🔥 غارت شد: +${fa(loot)} 🪙 • مردم شورش کردند: −${fa(loss)}٪ سلامت`); } else msg(`🔥 ${v.name} غارت شد: +${fa(loot)} 🪙 • اعتبار −۲`);
    ow.food = Math.min(100, ow.food + 25); save(); window.dispatchEvent(new Event("wm-gain")); }
  // ---- شهر: میخانه، بازار، میدان ----
  function tavern(t) { pend = t; panel(`<div class="owp"><h3>🏙️ ${t.name}</h3><div class="xs mut">میخانه • بازار • میدان گلادیاتورها</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin:8px 0"><button class="btn s g" data-o="rumor">🍺 شایعه (۶۰ 🪙)</button><button class="btn s g" data-o="merc">⚔️ مزدور (${fa(Math.round(120 + SV.kingdomPower() * 14))} 🪙)</button><button class="btn s g" data-o="heal">🍲 غذا و استراحت (۷۰ 🪙)</button><button class="btn s g" data-o="arena">🏟️ میدان</button></div><button class="btn s d" data-o="close">ادامه‌ی سفر</button></div>`); }
  function arena(t) { const cs = Math.round(100 * (1 + S.level * 0.1));
    panel(`<div class="owp"><h3>🏟️ میدان گلادیاتورها</h3><div class="xs mut">تک‌نبرد با پهلوان. هرچه حریف سخت‌تر، پاداش بزرگ‌تر.</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin:8px 0"><button class="btn s g" data-o="duel" data-t="0">🥉 تازه‌کار (${fa(cs)}) ~۷۰٪</button><button class="btn s g" data-o="duel" data-t="1">🥈 جنگاور (${fa(cs * 2)}) ~۵۰٪</button><button class="btn s r" data-o="duel" data-t="2">🥇 پهلوان (${fa(cs * 4)}) ~۳۰٪</button></div><button class="btn s d" data-o="close">برگرد</button></div>`); }
  function duel(tier) { const cs = Math.round(100 * (1 + S.level * 0.1)) * [1, 2, 4][tier]; if (S.coins < cs) { msg("سکه کافی نیست"); return; } S.coins -= cs;
    const p = Math.min(0.9, [0.7, 0.5, 0.3][tier] + Math.min(0.15, SV.kingdomPower() / 400) + (ow.hp - 60) / 600), win = Math.random() < p; panel("");
    if (win) { const coins = Math.round(cs * [1.7, 2.6, 4.2][tier]), gem = tier === 2 ? 3 : tier === 1 ? 1 : 0; give({ coins, gems: gem }); addXp(15 + tier * 20); ow.hp = Math.max(8, ow.hp - 6 - tier * 4); ow.rep = Math.min(10, ow.rep + (tier === 2 ? 1 : 0)); msg(`🏆 در میدان پیروز شدی! +${fa(coins)} 🪙${gem ? " +" + fa(gem) + " 💎" : ""}`); }
    else { ow.hp = Math.max(8, ow.hp - 14 - tier * 6); msg(`🩸 در میدان شکست خوردی • −${fa(cs)} 🪙`); }
    save(); window.dispatchEvent(new Event("wm-gain")); }
  function endFight() {
    const { bd, win } = battle; battle = null; paused = false;
    const loss = Math.round(Math.min(60, 6 + 28 * bd.pow / Math.max(4, myPow())));
    if (win) { const coins = Math.round(bd.pow * (14 + S.level * 0.8) * (1 + rel(bd) * 0.25)), xp = 10 + bd.pow, gem = rel(bd) === 2 ? 2 + Math.floor(Math.random() * 4) : (Math.random() < 0.15 ? 1 : 0); give({ coins, gems: gem }); addXp(xp); ow.hp = Math.max(8, ow.hp - loss * 0.7); bd.dead = 45; S.stats.kills = (S.stats.kills || 0) + bd.n * 4; msg(`🏆 پیروزی! +${fa(coins)} 🪙${gem ? " +" + fa(gem) + " 💎" : ""} • خسارت سپاه ${fa(Math.round(loss * 0.7))}٪`); }
    else { ow.hp = Math.max(6, ow.hp - loss); const lost = Math.min(S.coins, Math.round(S.coins * 0.04 + 30)); S.coins -= lost; P.x = home.x; P.y = home.y + 30; camX = P.x; camY = P.y; bd.st = "patrol"; bd.x = bd.hx; bd.y = bd.hy; msg(`💀 شکست! سپاه به کشور عقب نشست • −${fa(lost)} 🪙`); }
    save(); window.dispatchEvent(new Event("wm-gain"));
  }
  const nearest = (f) => { let b = null, bd = 1e9; for (const q of bands) if (!q.dead && f(q)) { const d = Math.hypot(q.x - P.x, q.y - P.y); if (d < bd) { bd = d; b = q; } } return b; };
  function step(dt) {
    if (msgT > 0) { msgT -= dt; if (msgT <= 0) $("s3msg").classList.remove("on"); }
    if (trackT > 0) trackT -= dt; if (ow.rumorT > 0) ow.rumorT -= dt;
    if (battle) { battle.t += dt; if (battle.t > 2.4) endFight(); return; }
    if (paused) return;
    let mx = (key.d || key.arrowright ? 1 : 0) - (key.a || key.arrowleft ? 1 : 0) + joy.x, my = (key.s || key.arrowdown ? 1 : 0) - (key.w || key.arrowup ? 1 : 0) + joy.y;
    if (P.tx !== null && !mx && !my) { const dx = P.tx - P.x, dy = P.ty - P.y, d = Math.hypot(dx, dy); if (d < 8) P.tx = null; else { mx = dx / d; my = dy / d; } }
    const l = Math.hypot(mx, my); if (l > 1) { mx /= l; my /= l; }
    const tl = walk(P.x, P.y), sp = 150 * (tl === 2 ? 0.65 : tl === 3 ? 0.4 : 1) * (0.7 + 0.3 * ow.hp / 100);
    if (l > 0.05) { const nx = P.x + mx * sp * dt, ny = P.y + my * sp * dt; if (walk(nx, P.y) !== 0) P.x = nx; if (walk(P.x, ny) !== 0) P.y = ny; P.ph += dt * 9 * Math.min(1, l); if (Math.abs(mx) > 0.1) P.dir = mx > 0 ? 1 : -1; } else P.ph *= 0.8;
    camX += (P.x - camX) * Math.min(1, dt * 5); camY += (P.y - camY) * Math.min(1, dt * 5); camX = Math.max(VW / 2, Math.min(WW - VW / 2, camX)); camY = Math.max(VH / 2, Math.min(WH - VH / 2, camY));
    if (l > 0.05) { ow.food = Math.max(0, ow.food - dt * 0.3 * (1 + 0.25 * ow.allies.length)); if (ow.food <= 0) ow.hp = Math.max(5, ow.hp - dt * 1.2); } if (ow.campT > 0) ow.campT -= dt;
    const nearVillage = villages.some((v) => Math.hypot(v.x - P.x, v.y - P.y) < 70); ow.hp = Math.min(100, ow.hp + dt * (nearVillage ? 3 : 0.25));
    for (const v of villages) if (Math.hypot(v.x - P.x, v.y - P.y) < 36 && !v.cd) { v.cd = 6; P.tx = null; villagePanel(v); }
    for (const t of towns) { if (Math.hypot(t.x - P.x, t.y - P.y) < 50 && !t.cd) { t.cd = 8; P.tx = null; tavern(t); } if (t.cd) t.cd = Math.max(0, t.cd - dt) || 0; }
    const ap = ow.allies; for (let i = 0; i < ap.length; i++) { const q = ap[i], tx = P.x - P.dir * (34 + i * 30), ty = P.y + (i % 2 ? 16 : -8); q.x += (tx - q.x) * Math.min(1, dt * 3.5); q.y += (ty - q.y) * Math.min(1, dt * 3.5); q.ph = (q.ph || 0) + (Math.hypot(tx - q.x, ty - q.y) > 6 ? dt * 9 : 0); }
    for (const v of villages) if (v.cd) v.cd = Math.max(0, v.cd - dt) || 0;
    for (const c of castles) { const st = S.conquered[c.n.id] ? "conq" : (S.level >= c.n.need ? "open" : "locked"); if (Math.hypot(c.x - P.x, c.y - P.y) < 46 && !c.cd) { c.cd = 8; P.tx = null; if (st === "locked") msg(`🔒 ${c.n.name} — نیاز به سطح ${fa(c.n.need)} کشور`); else if (st === "conq") msg(`🏴 ${c.n.name} جزو قلمرو توست`); else panel(`<div class="owp"><h3>${c.n.emoji} ${c.n.name}</h3><div class="xs mut">${c.n.ruler} • قدرت ${fa(c.n.power)} • دروازه ${fa(c.n.gate)}</div><div class="xs" style="margin:6px 0">غنیمت: 🪙${fa(c.n.loot)} 💎${fa(c.n.gems)}</div><div class="row wrap" style="gap:8px;justify-content:center"><button class="btn s r" data-o="atkc" data-id="${c.n.id}">⚔️ حمله</button><button class="btn s d" data-o="close">برگرد</button></div></div>`); } if (c.cd) c.cd = Math.max(0, c.cd - dt) || 0; }
    for (const c of chests) if (!ow.found.includes(c.id) && Math.hypot(c.x - P.x, c.y - P.y) < 26) { ow.found.push(c.id); if (c.gem) { const n = 2 + Math.floor(Math.random() * 4); give({ gems: n }); msg(`🎁 صندوق گنج! +${fa(n)} 💎`); } else { const n = Math.round(140 * (1 + S.level * 0.1) * (0.8 + Math.random() * 0.5)); give({ coins: n }); msg(`🎁 صندوق گنج! +${fa(n)} 🪙`); } save(); window.dispatchEvent(new Event("wm-gain")); }
    for (const b of bands) {
      if (b.dead > 0) { b.dead -= dt; if (b.dead <= 0) { bands.splice(bands.indexOf(b), 1); spawnBand(true); } continue; }
      const d = Math.hypot(b.x - P.x, b.y - P.y), r = rel(b); b.ph += dt * 6;
      let sx = 0, sy = 0, sp2 = 70 * b.k.spd;
      if (d < 280 && r === 0 && myPow() > b.pow * 1.35) { b.st = "flee"; sx = (b.x - P.x) / d; sy = (b.y - P.y) / d; sp2 = 110 * b.k.spd; }
      else if (d < 300 && r >= 1) { b.st = "chase"; sx = (P.x - b.x) / d; sy = (P.y - b.y) / d; sp2 = (r === 2 ? 118 : 100) * b.k.spd; }
      else { b.st = "patrol"; b.tt -= dt; if (b.tt <= 0) { b.tt = 2 + Math.random() * 3; const a = Math.random() * TAU, rad = Math.random() * 120; b.tx = b.hx + Math.cos(a) * rad; b.ty = b.hy + Math.sin(a) * rad; } const dx = b.tx - b.x, dy = b.ty - b.y, dd = Math.hypot(dx, dy); if (dd > 6) { sx = dx / dd; sy = dy / dd; sp2 = 45; } }
      const nx = b.x + sx * sp2 * dt, ny = b.y + sy * sp2 * dt; if (walk(nx, ny) === 1 || walk(nx, ny) === 2) { b.x = nx; b.y = ny; } if (Math.abs(sx) > 0.1) b.dir = sx > 0 ? 1 : -1;
      if (b.noFight > 0) b.noFight -= dt; else if (d < 34 && !battle && !paused) { P.tx = null; contact(b); }
    }
    if ((hudT -= dt) <= 0) { hudT = 0.2; $("owp").textContent = "قدرت سپاه: " + fa(Math.round(myPow())); $("owhp").style.width = ow.hp + "%"; $("owhpt").textContent = "❤️ " + fa(Math.round(ow.hp)) + "٪"; $("owfd").style.width = ow.food + "%"; $("owfdt").textContent = "🍖 " + fa(Math.round(ow.food)) + "٪"; }
  }
  let GLO = false, lastD = 0; SQ.init().then((ok) => { GLO = ok && SQ.ready(); });
  const PHI = 0.62, CPH = Math.cos(PHI), SPH = Math.sin(PHI), GLW = { R: [1, 0, 0], U: [0, CPH, SPH], D: [0, -SPH, CPH], k: 27, dpr: 1, L: (() => { const l = [0.45, 0.8, -0.4], n = Math.hypot(...l); return l.map((v) => v / n); })(), fogc: [0.7, 0.8, 0.9], sky: [1, 1, 1], gnd: [0.85, 0.8, 0.7] };
  // رسم یک شخصیت سه‌بعدی؛ برمی‌گرداند true اگر رسم شد
  function gch(o, key, mk, x, y, H, face, atk) {
    if (!GLO) return false;
    const k = H * 1.2 / 1.9, m = o._g || (o._g = {}); let e = m[key]; if (!e) { e = m[key] = SQ.make(mk(), key.length * 7 + Math.round(x)); e.yw = face > 0 ? 1.57 : -1.57; }
    const dx = x - (e.lx ?? x), dy = y - (e.ly ?? y); e.lx = x; e.ly = y;
    if (dx * dx + dy * dy > 0.01) { const ty = Math.atan2(dx, -dy); let d = ty - e.yw; d = Math.atan2(Math.sin(d), Math.cos(d)); e.yw += d * 0.25; }
    SQ.drive(e, { x: x / k, z: -y / k, atk: atk || 0, atkMax: 0.5, hurt: 0, dt: dtO });
    GLW.k = k; GLW.dpr = dpr;
    const tl = renderInst(e, { x: 0, y: 0, z: 0, yaw: e.yw, sc: 1, fog: 0, flash: 0 }, GLW); if (!tl) return false;
    blit(g, tl, x, y - 0.95 * CPH * k * (e.scale || 1));
    return true;
  }
  let dtO = 0.016;
  function draw(t) {
    dtO = Math.min(0.05, Math.max(0.001, t - lastD)); lastD = t; if (GLO) frameBegin();
    g.setTransform(dpr, 0, 0, dpr, 0, 0); g.fillStyle = "#143a6a"; g.fillRect(0, 0, VW, VH);
    const ox = Math.round(camX - VW / 2), oy = Math.round(camY - VH / 2); g.save(); g.translate(-ox, -oy);
    g.drawImage(bg, 0, 0, bg.width, bg.height, 0, 0, WW, WH);
    const vis = (x, y, m = 80) => x > ox - m && x < ox + VW + m && y > oy - m && y < oy + VH + m, items = [];
    for (const v of villages) if (vis(v.x, v.y)) items.push({ y: v.y, f: () => { for (let i = -1; i <= 1; i++) { const px = v.x + i * 34, py = v.y + (i % 2) * 8; g.fillStyle = "#c8a46a"; g.fillRect(px - 12, py - 10, 24, 16); g.fillStyle = "#a83a2a"; g.beginPath(); g.moveTo(px - 15, py - 10); g.lineTo(px, py - 26); g.lineTo(px + 15, py - 10); g.fill(); g.fillStyle = "#3a2410"; g.fillRect(px - 3, py - 2, 6, 8); } lab(v.name, v.x, v.y - 34, "#ffe9a8"); } });
    for (const c of castles) if (vis(c.x, c.y)) items.push({ y: c.y, f: () => { const st = S.conquered[c.n.id] ? "conq" : S.level >= c.n.need ? "open" : "locked"; g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(c.x, c.y + 4, 38, 9, 0, 0, TAU); g.fill(); g.fillStyle = st === "locked" ? "#6a6a78" : "#b8b8c8"; g.strokeStyle = "#2a2030"; g.lineWidth = 1.5; g.fillRect(c.x - 30, c.y - 28, 60, 32); g.strokeRect(c.x - 30, c.y - 28, 60, 32); for (const s of [-1, 1]) { g.fillRect(c.x + s * 30 - 9, c.y - 46, 18, 50); g.strokeRect(c.x + s * 30 - 9, c.y - 46, 18, 50); g.fillStyle = st === "conq" ? "#3f7bff" : "#c83a2a"; g.beginPath(); g.moveTo(c.x + s * 30, c.y - 46); g.lineTo(c.x + s * 30, c.y - 62); g.lineTo(c.x + s * 30 + 12, c.y - 57); g.lineTo(c.x + s * 30, c.y - 52); g.fill(); g.fillStyle = st === "locked" ? "#6a6a78" : "#b8b8c8"; } g.fillStyle = "#2a1a10"; g.beginPath(); g.moveTo(c.x - 8, c.y + 4); g.lineTo(c.x - 8, c.y - 12); g.quadraticCurveTo(c.x, c.y - 22, c.x + 8, c.y - 12); g.lineTo(c.x + 8, c.y + 4); g.fill(); lab((st === "locked" ? "🔒 " : st === "conq" ? "🏴 " : "") + c.n.name, c.x, c.y - 68, st === "open" ? "#ff9a8a" : "#fff"); } });
    for (const c of chests) if (!ow.found.includes(c.id) && vis(c.x, c.y)) items.push({ y: c.y, f: () => { g.fillStyle = "rgba(255,230,120,0.25)"; g.beginPath(); g.arc(c.x, c.y, 16 + Math.sin(t * 4) * 2, 0, TAU); g.fill(); g.fillStyle = c.gem ? "#5fd8ff" : "#c8863a"; g.strokeStyle = "#3a2410"; g.lineWidth = 1.5; g.fillRect(c.x - 8, c.y - 6, 16, 12); g.strokeRect(c.x - 8, c.y - 6, 16, 12); g.fillStyle = "#ffd24a"; g.fillRect(c.x - 2, c.y - 3, 4, 6); } });
    for (const t of towns) if (vis(t.x, t.y, 120)) items.push({ y: t.y, f: () => { g.fillStyle = "rgba(0,0,0,0.28)"; g.beginPath(); g.ellipse(t.x, t.y + 6, 70, 12, 0, 0, TAU); g.fill(); g.fillStyle = "#9a8a70"; g.strokeStyle = "#2a2030"; g.lineWidth = 1.5; g.fillRect(t.x - 64, t.y - 16, 128, 18); g.strokeRect(t.x - 64, t.y - 16, 128, 18); for (let i = -3; i <= 3; i++) { const px = t.x + i * 18, h = 22 + ((i * 7) & 3) * 6; g.fillStyle = i % 2 ? "#d8c9a6" : "#c9b88c"; g.fillRect(px - 8, t.y - 16 - h, 16, h); g.strokeRect(px - 8, t.y - 16 - h, 16, h); g.fillStyle = i % 3 ? "#b0402e" : "#3f6ab0"; g.beginPath(); g.moveTo(px - 11, t.y - 16 - h); g.lineTo(px, t.y - 30 - h); g.lineTo(px + 11, t.y - 16 - h); g.fill(); g.stroke(); } g.fillStyle = "#2a1a10"; g.beginPath(); g.moveTo(t.x - 9, t.y + 2); g.lineTo(t.x - 9, t.y - 12); g.quadraticCurveTo(t.x, t.y - 24, t.x + 9, t.y - 12); g.lineTo(t.x + 9, t.y + 2); g.fill(); lab("🏙️ " + t.name, t.x, t.y - 78, "#ffd9a0", 13); lab("🍺 🏟️ 🛒", t.x, t.y - 94, "#fff", 11); } });
    for (const q of ow.allies) items.push({ y: q.y, f: () => { for (let i = 0; i < Math.min(3, q.n); i++) { const m = q.look[i % q.look.length]; if (gch(q, "a" + i, () => SQ.spec("ally", i === 0 ? "shield" : "sword", i + 3), q.x + (i - 1) * 14, q.y + (i % 2) * 8, 46, P.dir)) continue; drawHuman(g, q.x + (i - 1) * 14, q.y + (i % 2) * 8, { H: 44, skin: m.s, cloth: m.c, weapon: m.w, dir: P.dir, walk: q.ph + i, pants: "#3a3030", hair: "#1a1210", armor: "#7a8498", helm: i === 0 ? "#8a94a8" : undefined }); } lab("🤝 " + q.icon + " " + fa(q.pow), q.x, q.y - 56, "#8affb0", 10); } });
    // خانه‌ی خودمان
    items.push({ y: home.y, f: () => { g.fillStyle = "#e8dcc0"; g.strokeStyle = "#2a2030"; g.lineWidth = 1.5; g.fillRect(home.x - 22, home.y - 20, 44, 24); g.strokeRect(home.x - 22, home.y - 20, 44, 24); g.fillStyle = "#3f7bff"; g.beginPath(); g.moveTo(home.x - 28, home.y - 20); g.lineTo(home.x, home.y - 42); g.lineTo(home.x + 28, home.y - 20); g.fill(); g.stroke(); lab("🏠 کشور من", home.x, home.y - 48, "#9ac0ff"); } });
    for (const b of bands) if (b.dead <= 0 && vis(b.x, b.y)) items.push({ y: b.y, f: () => drawBand(b, t) });
    items.push({ y: P.y, f: () => { if (!gch(P, "hero", () => SQ.heroSpec(S.avatar || {}, look), P.x, P.y, 56, P.dir)) drawHuman(g, P.x, P.y, { H: 52, skin: look.skin || "#d2a074", hair: look.hair || "#2a1a10", cloth: S.avatar?.tunic || "#2f5a8a", armor: "#aab4c8", helm: "#9aa4b8", plume: "#e8453a", cape: "#c83a2a", weapon: "sword", shield: "#3f6ad8", dir: P.dir, walk: P.ph }); lab("قهرمان", P.x, P.y - 64, "#9ac0ff", 10); } });
    items.sort((a, b) => a.y - b.y); for (const it of items) it.f();
    if (P.tx !== null) { g.strokeStyle = "rgba(255,255,255,0.7)"; g.beginPath(); g.arc(P.tx, P.ty, 8 + Math.sin(t * 6) * 2, 0, TAU); g.stroke(); }
    g.restore();
    if (trackT > 0) for (const [f, col] of [[(q) => rel(q) === 0, RC[0]], [(q) => rel(q) === 2, RC[2]]]) { const q = nearest(f); if (!q) continue; const a = Math.atan2(q.y - P.y, q.x - P.x), cx = VW / 2 + Math.cos(a) * Math.min(VW, VH) * 0.34, cy = VH / 2 + Math.sin(a) * Math.min(VW, VH) * 0.34; g.save(); g.translate(cx, cy); g.rotate(a); g.fillStyle = col; g.strokeStyle = "#000"; g.lineWidth = 2; g.beginPath(); g.moveTo(16, 0); g.lineTo(-8, -10); g.lineTo(-8, 10); g.closePath(); g.fill(); g.stroke(); g.restore(); g.fillStyle = col; g.font = "bold 11px sans-serif"; g.textAlign = "center"; g.fillText(Math.round(Math.hypot(q.x - P.x, q.y - P.y) / 10) + "م", cx, cy + 24); }
    if (battle) { const k = Math.min(1, battle.t / 2.4); g.fillStyle = `rgba(0,0,0,${0.55 * Math.min(1, battle.t * 2)})`; g.fillRect(0, 0, VW, VH); const cx = VW / 2, cy = VH / 2;
      for (let i = 0; i < 4; i++) { drawHuman(g, cx - 90 - i * 22 + Math.sin(t * 14 + i) * 8, cy + 40 + (i % 2) * 14, { H: 90, cloth: "#2f5a8a", armor: "#aab4c8", helm: "#9aa4b8", weapon: "sword", shield: "#3f6ad8", dir: 1, walk: t * 8 + i }); }
      for (let i = 0; i < Math.min(5, battle.bd.n); i++) { const m = battle.bd.look[i]; drawHuman(g, cx + 90 + i * 22 - Math.sin(t * 14 + i) * 8, cy + 40 + (i % 2) * 14, { H: 90, cloth: m.c, skin: m.s, weapon: m.w, dir: -1, walk: t * 8 + i, beard: i % 2 === 0, pants: "#3a3030" }); }
      g.fillStyle = "#fff"; g.font = "bold 22px Vazirmatn, sans-serif"; g.textAlign = "center"; g.fillText(`⚔️ ${battle.bd.k.name}`, cx, cy - 70); g.fillStyle = "#333"; g.fillRect(cx - 120, cy - 52, 240, 12); g.fillStyle = "#4f86ff"; g.fillRect(cx - 120, cy - 52, 240 * (battle.win ? 0.5 + 0.5 * k : 0.5 - 0.5 * k) * 1, 12);
      if (k > 0.85) { g.fillStyle = battle.win ? "#7bff9a" : "#ff6a6a"; g.font = "bold 26px Vazirmatn, sans-serif"; g.fillText(battle.win ? "پیروزی!" : "شکست!", cx, cy - 20); } }
    miniDraw();
  }
  function lab(txt, x, y, col, size = 12) { g.font = `bold ${size}px Vazirmatn, sans-serif`; g.textAlign = "center"; g.lineWidth = 3.5; g.strokeStyle = "rgba(10,10,25,0.85)"; g.strokeText(txt, x, y); g.fillStyle = col; g.fillText(txt, x, y); }
  function drawBand(b, t) {
    const col = RC[rel(b)], mem = b.look;
    if (b.k.beast) { for (let i = 0; i < b.n; i++) { const px = b.x + ((i % 3) - 1) * 18, py = b.y + Math.floor(i / 3) * 14, w = Math.sin(b.ph + i) * 2; g.save(); g.translate(px, py); g.scale(b.dir, 1); g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(0, 4, 14, 4, 0, 0, TAU); g.fill(); g.fillStyle = "#6a6a74"; g.strokeStyle = "#1a1a22"; g.lineWidth = 1; g.beginPath(); g.ellipse(0, -6, 13, 7, 0, 0, TAU); g.fill(); g.stroke(); g.beginPath(); g.ellipse(13, -10, 7, 5, 0.3, 0, TAU); g.fill(); g.stroke(); g.beginPath(); g.moveTo(12, -15); g.lineTo(15, -21); g.lineTo(17, -14); g.fill(); g.fillStyle = "#ffd24a"; g.fillRect(16, -11, 2, 2); g.strokeStyle = "#4a4a54"; g.lineWidth = 3; g.beginPath(); g.moveTo(-10, -2); g.lineTo(-10 + w, 4); g.moveTo(8, -2); g.lineTo(8 - w, 4); g.stroke(); g.beginPath(); g.moveTo(-12, -8); g.quadraticCurveTo(-22, -10 + w, -20, -2); g.stroke(); g.restore(); } }
    else for (let i = 0; i < b.n; i++) { const m = mem[i], px = b.x + ((i % 3) - 1) * 22 + (Math.floor(i / 3) % 2) * 8, py = b.y + Math.floor(i / 3) * 16; if (gch(b, "m" + i, () => SQ.spec("foe", b.k.big ? "heavy" : b.k.armor ? "shield" : (m.w === "bow" ? "archer" : "sword"), i + 11), px, py, b.k.big ? 66 : 50, b.dir)) continue; drawHuman(g, px, py, { H: b.k.big ? 64 : 46, skin: m.s || b.k.skin, cloth: m.c, armor: b.k.armor, weapon: m.w, dir: b.dir, walk: b.st === "patrol" && Math.hypot(b.tx - b.x, b.ty - b.y) < 8 ? 0 : b.ph + i, beard: i % 2 === 0, pants: "#3a3030", hair: "#1a1210", helm: b.k.armor ? "#7a6a4a" : undefined }); }
    g.fillStyle = col; g.strokeStyle = "#000"; g.lineWidth = 1.5; const by = b.y - (b.k.big ? 82 : 66); g.beginPath(); g.roundRect ? g.roundRect(b.x - 30, by - 11, 60, 18, 8) : g.rect(b.x - 30, by - 11, 60, 18); g.globalAlpha = 0.9; g.fill(); g.globalAlpha = 1; g.stroke(); g.fillStyle = "#101018"; g.font = "bold 11px Vazirmatn, sans-serif"; g.textAlign = "center"; g.fillText(`${b.k.icon} ${fa(b.pow)} • ${RN[rel(b)]}`, b.x, by + 2);
    if (b.st === "flee") lab("💨", b.x, by - 14, "#fff", 14); else if (b.st === "chase") lab("❗", b.x, by - 14, "#ff6a6a", 14);
  }
  function miniDraw() {
    const mw = 150, mh = 100, sx = mw / WW, sy = mh / WH; mini.clearRect(0, 0, mw, mh); mini.drawImage(bg, 0, 0, bg.width, bg.height, 0, 0, mw, mh);
    for (const b of bands) if (b.dead <= 0) { mini.fillStyle = RC[rel(b)]; mini.fillRect(b.x * sx - 1.5, b.y * sy - 1.5, 3, 3); }
    mini.fillStyle = "#ffd24a"; for (const c of castles) mini.fillRect(c.x * sx - 2, c.y * sy - 2, 4, 4); mini.fillStyle = "#ff9a3a"; for (const t of towns) mini.fillRect(t.x * sx - 3, t.y * sy - 3, 6, 6); if (ow.rumorT > 0) { mini.fillStyle = "#5fd8ff"; for (const c of chests) if (!ow.found.includes(c.id)) mini.fillRect(c.x * sx - 1.5, c.y * sy - 1.5, 3, 3); } mini.fillStyle = "#fff"; for (const v of villages) mini.fillRect(v.x * sx - 1.5, v.y * sy - 1.5, 3, 3);
    mini.fillStyle = "#4f86ff"; mini.strokeStyle = "#fff"; mini.beginPath(); mini.arc(P.x * sx, P.y * sy, 3.5, 0, TAU); mini.fill(); mini.stroke(); mini.strokeStyle = "rgba(255,255,255,0.7)"; mini.strokeRect((camX - VW / 2) * sx, (camY - VH / 2) * sy, VW * sx, VH * sy);
  }
  function loop(now) { if (ended) return; const dt = Math.min(0.05, (now - last) / 1000); last = now; try { step(dt); draw(now / 1000); } catch (e) { console.error(e); } raf = requestAnimationFrame(loop); }
  window.__owdbg = { P, bands, ow, villages, towns, chests };
  raf = requestAnimationFrame(loop); msg("🗺️ برای حرکت صفحه را لمس کن یا از جوی‌استیک استفاده کن. ۔ 🔍 ردیاب را بزن");
}
