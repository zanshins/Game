// نقشه‌ی بزرگ: گشت‌وگذار آزاد، گروه‌های ضعیف و قوی، روستا، قلعه، صندوق و ردیاب (الهام از «انسان و فولاد»/مونت‌اند‌بلید)
import { S, give, save, addXp } from "./save.js";
import * as SV from "./save.js";
import { NEIGHBORS, fa, rng } from "./data.js";
import { drawHuman } from "./human.js";
import { lookOf } from "./gear.js";
import * as SQ from "./squad.js";
import { frameBegin, renderInst, blit } from "./char3d.js";
import { loadEnv, envFrame, envSprite, envBlit, envInfo, EV } from "./env3d.js";

const TS = 40, WT = 70, HT = 46, WW = WT * TS, WH = HT * TS, TAU = Math.PI * 2;
const hash = (x, y, s) => { let h = (x * 374761393 + y * 668265263 + s * 2147483647) | 0; h = (h ^ (h >> 13)) * 1274126177; return ((h ^ (h >> 16)) >>> 0) / 4294967295; };
const vn = (x, y, s) => { const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, sm = (t) => t * t * (3 - 2 * t), a = hash(xi, yi, s), b = hash(xi + 1, yi, s), c = hash(xi, yi + 1, s), d = hash(xi + 1, yi + 1, s); return a + (b - a) * sm(fx) + (c - a) * sm(fy) + (a - b - c + d) * sm(fx) * sm(fy); };
const KINDS = [
  { id: "bandit", name: "راهزنان", icon: "🗡️", mem: ["club", "sword"], cloth: ["#6a4a2a", "#5a3a2a", "#4a4a38"], n: [3, 6], spd: 1 },
  { id: "turan", name: "سواران تورانی", icon: "🏹", mem: ["bow", "spear"], cloth: ["#8a2a2a", "#7a3a1a"], armor: "#8a7a5a", n: [3, 5], spd: 1.1 },
  { id: "wolf", name: "گله‌ی گرگ", icon: "🐺", mem: [], n: [3, 5], spd: 1.25, beast: true },
  { id: "bear", name: "خرس‌های کوهی", icon: "🏔", mem: [], n: [1, 2], spd: 1.0, beast: true },
  { id: "boar", name: "گله‌ی گراز", icon: "🌲", mem: [], n: [2, 4], spd: 1.1, beast: true },
  { id: "lion", name: "شیرهای دشت", icon: "🦁", mem: [], n: [2, 3], spd: 1.2, beast: true },
  { id: "div", name: "دیوان مازندران", icon: "👹", mem: ["club"], cloth: ["#2a4a3a"], skin: "#4a7a5a", n: [2, 3], spd: 0.8, big: true },
];
export function startOverworld(cb, resume) {
  const root = document.createElement("div"); root.id = "s3d"; root.className = "ow";
  root.innerHTML = `<canvas id="owc"></canvas>
  <div class="s3top"><div class="owbar"><b>🗺️ نقشه‌ی بزرگ</b> <span id="owp"></span> <div class="s3bar"><i id="owhp"></i><span id="owhpt"></span></div><div class="s3bar g"><i id="owfd"></i><span id="owfdt"></span></div></div><div class="s3r"><button class="s3b sm" data-o="camp">⛺</button><button class="s3b sm" data-oz="ft">🐎</button><button class="s3b sm" data-o="army">👥</button><button class="s3b sm" data-o="track">🔍</button><button class="s3b sm" data-o="quit">✖</button></div></div>
  <div id="s3msg"></div><div class="owzoom"><button data-oz="in">+</button><button data-oz="out">-</button><button data-oz="home">🎯</button></div><div class="owcomp" id="owcomp"><i></i><b>ش</b></div><canvas id="owmini" width="180" height="120"></canvas>
  <div class="owpanel" id="owpanel" style="display:none"></div>`;
  document.body.appendChild(root); document.body.classList.add("inbattle");
  const cv = root.querySelector("#owc"), g = cv.getContext("2d", { alpha: false }), mini = root.querySelector("#owmini").getContext("2d");
  const $ = (id) => root.querySelector("#" + id);
  if (!S.ow) S.ow = { hp: 100, vol: 0, found: [], per: -1, x: -1, y: 0, food: 100 }; if (S.ow.food === undefined) S.ow.food = 100; if (!S.ow.allies) S.ow.allies = []; if (!S.ow.vs) S.ow.vs = {}; if (S.ow.rep === undefined) S.ow.rep = 0;
  const ow = S.ow, seed = 77;
  const elev = (x, y) => vn(x / 9, y / 9, seed) * 0.62 + vn(x / 4, y / 4, seed + 1) * 0.26 + vn(x / 1.7, y / 1.7, seed + 3) * 0.12, fnoise = (x, y) => vn(x / 5, y / 5, seed + 2) * 0.75 + vn(x / 2, y / 2, seed + 4) * 0.25;
  const cls = (fx, fy) => { const e = elev(fx, fy), edge = Math.min(fx, fy, WT - fx, HT - fy); if (e < 0.25 || edge < 1.2) return 0; if (e > 0.76) return 3; if (fnoise(fx, fy) > 0.62 && e > 0.42) return 2; return 1; };
  const walk = (x, y) => cls(x / TS, y / TS);
  // ---------- نقشه‌ی از پیش‌کشیده: میدان‌های ارتفاع هموار + سایه‌روشن + ساحل ----------
  const MS = 0.7, GS = 4, GW = Math.ceil(WW / GS) + 2, GH = Math.ceil(WH / GS) + 2, bg = document.createElement("canvas"); bg.width = Math.round(WW * MS); bg.height = Math.round(WH * MS); const bx = bg.getContext("2d");
  const sst = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
  const EG = new Float32Array(GW * GH), FG = new Float32Array(GW * GH), SG = new Float32Array(GW * GH), VG = new Float32Array(GW * GH);
  for (let j = 0; j < GH; j++) for (let i = 0; i < GW; i++) { const fx = i * GS / TS, fy = j * GS / TS, edge = Math.min(fx, fy, WT - fx, HT - fy), k = j * GW + i; EG[k] = elev(fx, fy) - sst(2.2, 1.0, edge) * 0.35; FG[k] = fnoise(fx, fy); VG[k] = vn(fx * 1.1, fy * 1.1, 6); }
  for (let j = 1; j < GH - 1; j++) for (let i = 1; i < GW - 1; i++) { const k = j * GW + i; SG[k] = Math.max(-0.55, Math.min(0.55, ((EG[k + 1] - EG[k - 1]) * 0.6 + (EG[k + GW] - EG[k - GW]) * 0.75) * 16)); }
  const NT = new Float32Array(65536); for (let i = 0; i < 65536; i++) NT[i] = hash(i & 255, i >> 8, 5) - 0.5;
  (function bakeBase() {
    const W = bg.width, H = bg.height, img = bx.createImageData(W, H), d = img.data, inv = 1 / MS / GS;
    for (let py = 0; py < H; py++) { const gyf = py * inv, gy = gyf | 0, fy = gyf - gy;
      for (let px = 0; px < W; px++) { const gxf = px * inv, gx = gxf | 0, fx = gxf - gx, k = gy * GW + gx, w00 = (1 - fx) * (1 - fy), w10 = fx * (1 - fy), w01 = (1 - fx) * fy, w11 = fx * fy;
        const e = EG[k] * w00 + EG[k + 1] * w10 + EG[k + GW] * w01 + EG[k + GW + 1] * w11, fn = FG[k] * w00 + FG[k + 1] * w10 + FG[k + GW] * w01 + FG[k + GW + 1] * w11, sh = SG[k] * w00 + SG[k + 1] * w10 + SG[k + GW] * w01 + SG[k + GW + 1] * w11, vg = VG[k] * w00 + VG[k + 1] * w10 + VG[k + GW] * w01 + VG[k + GW + 1] * w11, nz = NT[((py & 255) << 8) | (px & 255)] * 9;
        let r, g2, b2;
        if (e < 0.25) { const dp = Math.max(0, Math.min(1, (0.25 - e) / 0.32)), q = dp * dp * (3 - 2 * dp); r = 102 - q * 92 + nz * 0.5; g2 = 204 - q * 138 + nz * 0.6 + vg * 10; b2 = 210 - q * 82 + nz * 0.6; if (e > 0.226) { const f = sst(0.226, 0.25, e); r += f * 18; g2 += f * 12; b2 += f * 6; } }
        else if (e < 0.274) { const f = 0; r = 226 + nz; g2 = 210 + nz; b2 = 156 + nz; if (e < 0.262) { const ff = 1 - sst(0.25, 0.262, e); r += (250 - r) * ff * 0.8; g2 += (250 - g2) * ff * 0.8; b2 += (246 - b2) * ff * 0.8; } r *= 1 + sh * 0.25; g2 *= 1 + sh * 0.25; b2 *= 1 + sh * 0.25; }
        else {
          const gt = sst(0.272, 0.292, e); // ساحل → چمن
          let gr = 78 + vg * 52 + fn * 30, gg = 146 + vg * 28 - fn * 6, gb = 62 + vg * 14;
          const fm = sst(0.58, 0.66, fn) * sst(0.38, 0.46, e); gr += (44 - gr) * fm * 0.8; gg += (98 - gg) * fm * 0.8; gb += (50 - gb) * fm * 0.8;
          const mt = sst(0.7, 0.78, e); const rk = 128 + (e - 0.7) * 120; gr += (rk - gr) * mt; gg += (rk - 6 - gg) * mt; gb += (rk - 8 - gb) * mt;
          const sn = sst(0.84, 0.9, e + nz * 0.004); gr += (240 - gr) * sn; gg += (244 - gg) * sn; gb += (250 - gb) * sn;
          const lit = 1 + sh * (0.35 + mt * 0.9); gr = (gr + nz) * lit; gg = (gg + nz) * lit; gb = (gb + nz) * lit;
          r = 226 + (gr - 226) * gt; g2 = 208 + (gg - 208) * gt; b2 = 152 + (gb - 152) * gt;
        }
        const o = (py * W + px) * 4; d[o] = r < 0 ? 0 : r > 255 ? 255 : r; d[o + 1] = g2 < 0 ? 0 : g2 > 255 ? 255 : g2; d[o + 2] = b2 < 0 ? 0 : b2 > 255 ? 255 : b2; d[o + 3] = 255; } }
    bx.putImageData(img, 0, 0);
  })();
  bx.scale(MS, MS);
  const rr = rng(9);
  // ---- نقاط مهم ----
  const used = []; const free = (sp = 260) => { for (let k = 0; k < 600; k++) { const x = (4 + rr() * (WT - 8)) * TS, y = (4 + rr() * (HT - 8)) * TS; if (walk(x, y) === 1 && walk(x + 30, y) === 1 && walk(x - 30, y) === 1 && used.every(([a, b]) => Math.hypot(a - x, b - y) > sp)) { used.push([x, y]); return [x, y]; } } return [WW / 2 + rr() * 80, WH / 2 + rr() * 80]; };
  const castles = NEIGHBORS.map((n, i) => { const [x, y] = free(300); return { n, x, y }; });
  const villages = ["روستای گلستان", "ده‌ی مرغزار", "آبادی سرچشمه", "روستای دامغان", "ده‌ی کوهپایه", "آبادی مهرآباد", "روستای سیمین", "ده‌ی چناران"].map((name) => { const [x, y] = free(240); return { name, x, y }; });
  const towns = ["شهر بازار", "شهر سپیدرود"].map((name, i) => { const [x, y] = free(320); return { name, x, y, i }; });
  const [hx, hy] = free(300); const home = { x: hx, y: hy };
  if (ow.x < 0) { ow.x = hx + 60; ow.y = hy + 40; if (walk(ow.x, ow.y) === 0) { ow.x = hx; ow.y = hy; } }
  // ---------- تزئین: جاده، مزرعه، سایه‌ی درخت و پوشش گیاهی (درخت‌های واقعی از env3d) ----------
  const roads = [], flora = [], small = [], sparks = []; let ENVR = false; for (let i = 0; i < 1400; i++) { const x = hash(i, 1, 91) * WW, y = hash(i, 2, 92) * WH; if (walk(x, y) === 0 && EG[((y / GS) | 0) * GW + ((x / GS) | 0)] < 0.22) sparks.push({ x, y, p: hash(i, 3, 93) * 20 }); }
  (function decor() {
    const pts = [...castles, ...villages, ...towns, home], nearest = (o, arr) => arr.filter((q) => q !== o).sort((a, b2) => Math.hypot(a.x - o.x, a.y - o.y) - Math.hypot(b2.x - o.x, b2.y - o.y))[0];
    const pairs = [[home, towns[0]], [towns[0], towns[1]]]; for (const v of villages) pairs.push([v, nearest(v, [...towns, home, ...villages])]); for (const c of castles) pairs.push([c, nearest(c, [...towns, home])]);
    for (const [a, b2] of pairs) { if (!a || !b2) continue; const pa = findPath(a.x, a.y + 14, b2.x, b2.y + 14, true); roads.push([{ x: a.x, y: a.y + 14 }, ...pa]); }
    bx.lineCap = "round"; bx.lineJoin = "round";
    for (const [w, col, al] of [[13, "#4a3820", 0.28], [9, "#a8895a", 1], [4.5, "#cdb68a", 0.55]]) { bx.strokeStyle = col; bx.globalAlpha = al; bx.lineWidth = w; for (const r of roads) { bx.beginPath(); let started = false; for (let i = 0; i < r.length; i++) { const q = r[i]; if (walk(q.x, q.y) === 0) { started = false; continue; } if (!started) { bx.moveTo(q.x, q.y); started = true; } else { const pq = r[i - 1], mx = (pq.x + q.x) / 2, my = (pq.y + q.y) / 2; bx.quadraticCurveTo(pq.x, pq.y, mx, my); } } bx.stroke(); } }
    bx.globalAlpha = 1;
    // مزرعه‌ها
    for (const v of villages) for (let k = 0; k < 3; k++) { const a = hash(v.x | 0, k, 77) * TAU, r = 75 + hash(k, v.y | 0, 78) * 40, cx = v.x + Math.cos(a) * r, cy = v.y + Math.sin(a) * r * 0.8, w2 = 46, h2 = 30; if (![[-1, -1], [1, -1], [1, 1], [-1, 1]].every(([sx, sy]) => walk(cx + sx * w2, cy + sy * h2) === 1)) continue;
      bx.save(); bx.translate(cx, cy); bx.rotate((hash(k, v.x | 0, 79) - 0.5) * 0.5); bx.fillStyle = "#6a8a3a"; bx.fillRect(-w2, -h2, w2 * 2, h2 * 2); for (let i = -h2; i < h2; i += 6) { bx.fillStyle = (i / 6) % 2 ? "#b49a4a" : "#8aa044"; bx.fillRect(-w2 + 2, i, w2 * 2 - 4, 4); } bx.strokeStyle = "rgba(60,40,20,0.5)"; bx.lineWidth = 1.5; bx.strokeRect(-w2, -h2, w2 * 2, h2 * 2); bx.restore(); }
    // نقاط ممنوعه برای درخت: نزدیک آبادی‌ها و جاده‌ها
    const roadPts = []; for (const r of roads) for (let i = 0; i + 1 < r.length; i++) { const a = r[i], b2 = r[i + 1], n = Math.ceil(Math.hypot(b2.x - a.x, b2.y - a.y) / 14); for (let t2 = 0; t2 < n; t2++) roadPts.push([a.x + (b2.x - a.x) * t2 / n, a.y + (b2.y - a.y) * t2 / n]); }
    const blocked = (x, y) => { for (const o of pts) if (Math.hypot(o.x - x, (o.y - y) * 1.3) < (o.i !== undefined ? 110 : 84)) return true; for (const q of roadPts) if (Math.abs(q[0] - x) < 17 && Math.abs(q[1] - y) < 17) return true; return false; };
    const G = { normal: ["NormalTree_1", "NormalTree_5", "NormalTree_3"], birch: ["BirchTree_4", "BirchTree_1"], maple: ["MapleTree_4", "MapleTree_1"], pine: ["PineTree_5", "PineTree_1", "PineTree_3"], palm: ["PalmTree_1", "PalmTree_5"], dead: ["DeadTree_5", "DeadTree_9", "DeadTree_4"], bush: ["Bush", "Bush_Small", "Bush_Large_Flowers", "Bush_Flowers"], flower: ["Flower_1_Clump", "Flower_2_Clump", "Flower_3_Clump", "Flower_4_Clump", "Flower_5_Clump", "Plant_2", "Plant_Flowers", "Petals_1"], rock: ["Rock_1", "Rock_2", "Rock_3", "Rock_4", "Rock_5"], grass: ["Grass_Small", "Grass_Large_Extruded"] };
    const pick = (a, h) => a[Math.floor(h * a.length) % a.length], STEP = 25;
    for (let j = 0; j * STEP < WH; j++) for (let i = 0; i * STEP < WW; i++) {
      const x = (i + hash(i, j, 41)) * STEP, y = (j + hash(i, j, 43)) * STEP, c = cls(x / TS, y / TS); if (c === 0) continue; const h = hash(i, j, 44), h2 = hash(i, j, 45), zone = vn(x / 260, y / 260, 31), ee = EG[((y / GS) | 0) * GW + ((x / GS) | 0)], bl = blocked(x, y);
      const add = (arr, grp, w, big) => arr.push({ n: pick(G[grp], h2), x, y, w, fl: h2 > 0.5, yw: (h * 7 | 0) % 3, big });
      if (c === 2) { if (bl) continue; if (h < 0.8) { const g = zone < 0.3 ? "pine" : zone < 0.62 ? (h2 < 0.5 ? "normal" : "birch") : "maple"; add(flora, g, (g === "pine" ? 60 : 84) + h2 * 30, 1); } else if (h < 0.9) add(small, "bush", 30 + h2 * 10); else add(small, "flower", 15 + h2 * 8); }
      else if (c === 1) { if (ee < 0.31 && ee > 0.28) { if (h < 0.11 && !bl) add(flora, "palm", 66 + h2 * 16, 1); } else if (h < 0.028 && !bl) add(flora, h2 < 0.2 ? "dead" : zone < 0.5 ? "normal" : "birch", 70 + h2 * 26, 1); else if (h < 0.055) add(small, "bush", 30 + h2 * 10); else if (h < 0.13) add(small, "flower", 12 + h2 * 7); else if (h < 0.27) add(small, "grass", 15); else if (h < 0.285) add(small, "rock", 22 + h2 * 14); }
      else if (c === 3) { if (h < 0.2) add(flora, ee > 0.85 ? "pine" : h2 < 0.5 ? "rock" : "dead", ee > 0.85 ? 56 : h2 < 0.5 ? 42 + h2 * 50 : 56, 1); else if (h < 0.26) add(small, "rock", 24 + h2 * 20); }
    }
    for (const f of flora) if (/Tree|Palm/.test(f.n)) { bx.fillStyle = "rgba(10,25,10,0.26)"; bx.beginPath(); bx.ellipse(f.x + f.w * 0.1, f.y + 2, f.w * 0.34, f.w * 0.1, 0, 0, TAU); bx.fill(); }
    // پیش‌گرم کردن اسپرایت‌ها و پختن گل/بوته/علف روی نقشه
    const YW = [0.8, 2.4, 4.0], PIT = 0.48;
    loadEnv().then((ok) => { if (!ok) { for (const f of flora) { bx.fillStyle = "#3a6a30"; bx.beginPath(); bx.arc(f.x, f.y - f.w * 0.3, f.w * 0.28, 0, TAU); bx.fill(); } return; }
      envFrame(9999); const names = new Set([...flora, ...small].map((f) => f.n)); for (const n of names) for (const y of YW) envSprite(n, y, PIT);
      const cp = Math.cos(PIT);
      for (const f of small) { const sp = envSprite(f.n, YW[f.yw], PIT), inf = envInfo(f.n); if (!sp || !inf) continue; const ppu = f.w / (2 * sp.hw); envBlit(bx, sp, f.x, f.y - inf.h / 2 * cp * ppu, ppu, 1, f.fl); }
      ENVR = true; });
  })();
  const P = { x: ow.x, y: ow.y, dir: 1, ph: 0, tx: null, ty: null, vx: 0, vy: 0 }, look = lookOf(S.avatar);
  const per = Math.floor(Date.now() / 21600000); if (ow.per !== per) { ow.per = per; ow.found = []; }
  const rc = rng(per * 31 + 5), chests = Array.from({ length: 12 }, (_, i) => { const x = (3 + rc() * (WT - 6)) * TS, y = (3 + rc() * (HT - 6)) * TS; return { id: "c" + i, x, y, gem: i % 4 === 3, ok: walk(x, y) !== 0 }; }).filter((c) => c.ok);
  const allyPow = () => ow.allies.reduce((a, q) => a + q.pow, 0);
  const myPow = () => Math.max(4, (SV.kingdomPower() + 2 * ow.vol + allyPow()) * (0.45 + 0.55 * ow.hp / 100) * (0.75 + 0.25 * Math.min(1, ow.food / 40)));
  const bands = [];
  function spawnBand(initial) { const k = KINDS[Math.floor(Math.random() * KINDS.length)], [x, y] = free(0); used.pop(); if (initial && Math.hypot(x - P.x, y - P.y) < 350) return spawnBand(initial);
    const base = SV.kingdomPower() + 2 * ow.vol, ratio = [0.35, 0.5, 0.6, 0.8, 1, 1.2, 1.5, 1.9, 2.5][Math.floor(Math.random() * 9)] * (k.big ? 1.3 : 1), n = k.n[0] + Math.floor(Math.random() * (k.n[1] - k.n[0] + 1));
    bands.push({ k, x, y, hx: x, hy: y, pow: Math.max(3, Math.round(base * ratio)), n, ph: Math.random() * 6, dir: 1, st: "patrol", tx: x, ty: y, tt: 0, dead: 0, look: Array.from({ length: n }, (_, i) => ({ c: k.cloth ? k.cloth[i % k.cloth.length] : "#5a4a3a", w: k.mem[i % Math.max(1, k.mem.length)], s: ["#d2a074", "#b07a50", "#8a5a3a", "#e8c0a0"][(i + x) % 4 | 0] })) }); }
  for (let i = 0; i < 20; i++) spawnBand(true);
  const rel = (b) => { const r = b.pow / myPow(); return r < 0.8 ? 0 : r < 1.3 ? 1 : 2; }, RC = ["#5be07a", "#ffd24a", "#ff5a4a"], RN = ["ضعیف", "هم‌قدر", "قوی"];
  let pT = 0, msgT = 0, paused = false, ended = false, raf = 0, last = performance.now(), trackT = 0, battle = null, hudT = 0;
  const msg = (m) => { const e = $("s3msg"); e.textContent = m; e.classList.add("on"); msgT = 3.2; };
  const key = {}, joy = { x: 0, y: 0 };
  const onKD = (e) => { key[e.key.toLowerCase()] = true; if (e.key === "Escape") quit(); }, onKU = (e) => { key[e.key.toLowerCase()] = false; };
  addEventListener("keydown", onKD); addEventListener("keyup", onKU);
  let camX = P.x, camY = P.y, VW = 800, VH = 400, dpr = 1;
  const resize = () => { dpr = Math.min(2, devicePixelRatio || 1); VW = root.clientWidth; VH = root.clientHeight; cv.width = VW * dpr; cv.height = VH * dpr; cv.style.width = VW + "px"; cv.style.height = VH + "px"; }; resize(); addEventListener("resize", resize);
  // ---- ورودی: لمس برای حرکت، کشیدن برای جابه‌جایی دوربین، دو انگشت برای زوم ----
  let zoom = 1, follow = true, g0 = null; const ptrs = new Map();
  const VWz = () => VW / zoom, VHz = () => VH / zoom;
  const clampCam = () => { camX = Math.max(Math.min(VWz() / 2, WW / 2), Math.min(WW - Math.min(VWz() / 2, WW / 2), camX)); camY = Math.max(Math.min(VHz() / 2, WH / 2), Math.min(WH - Math.min(VHz() / 2, WH / 2), camY)); };
  const setZoom = (z) => { zoom = Math.max(0.5, Math.min(2.2, z)); clampCam(); };
  const s2w = (cx, cy) => { const r = cv.getBoundingClientRect(); return [camX - VWz() / 2 + (cx - r.left) / zoom, camY - VHz() / 2 + (cy - r.top) / zoom]; };
  function tapAt(cx, cy) {
    let [wx, wy] = s2w(cx, cy), best = null, bd = 34 / Math.max(0.8, zoom);
    const cand = [...bands.filter((b) => b.dead <= 0).map((b) => ({ x: b.x, y: b.y, b })), ...villages, ...towns, ...castles, home, ...chests.filter((c) => !ow.found.includes(c.id))];
    for (const o of cand) { const d = Math.hypot(o.x - wx, o.y - wy); if (d < bd + (o.b ? 10 : 22)) { bd = d; best = o; } }
    P.chase = best && best.b ? best.b : null; if (best) { wx = best.x; wy = best.y + (best.b ? 0 : 24); }
    wx = Math.max(16, Math.min(WW - 16, wx)); wy = Math.max(16, Math.min(WH - 16, wy)); follow = true; goTo(wx, wy); tapFx = { x: wx, y: wy, t: 0 };
  }
  let tapFx = null;
  cv.addEventListener("pointerdown", (e) => { if (battle || paused) return; try { cv.setPointerCapture(e.pointerId); } catch (_) {} ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, t: performance.now(), moved: false }); if (ptrs.size === 2) { const [a, b2] = [...ptrs.values()]; g0 = { d: Math.hypot(a.x - b2.x, a.y - b2.y), z: zoom }; a.moved = b2.moved = true; } });
  cv.addEventListener("pointermove", (e) => { const p = ptrs.get(e.pointerId); if (!p) return; const dx = e.clientX - p.x, dy = e.clientY - p.y; p.x = e.clientX; p.y = e.clientY; if (Math.hypot(p.x - p.sx, p.y - p.sy) > 9) p.moved = true;
    if (ptrs.size === 2 && g0) { const [a, b2] = [...ptrs.values()]; setZoom(g0.z * Math.hypot(a.x - b2.x, a.y - b2.y) / Math.max(20, g0.d)); }
    else if (ptrs.size === 1 && p.moved) { follow = false; camX -= dx / zoom; camY -= dy / zoom; clampCam(); } });
  const pup = (e) => { const p = ptrs.get(e.pointerId); ptrs.delete(e.pointerId); if (ptrs.size < 2) g0 = null; if (p && !p.moved && e.type === "pointerup" && !battle && !paused && performance.now() - p.t < 600) tapAt(e.clientX, e.clientY); };
  cv.addEventListener("pointerup", pup); cv.addEventListener("pointercancel", pup);
  cv.addEventListener("wheel", (e) => { e.preventDefault(); setZoom(zoom * (e.deltaY < 0 ? 1.12 : 0.89)); }, { passive: false });
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-oz]"); if (!b) return; const a = b.dataset.oz; if (a === "in") setZoom(zoom * 1.25); else if (a === "out") setZoom(zoom / 1.25); else { follow = true; setZoom(1); } });
  { const miniEl = $("owmini"); miniEl.addEventListener("pointerdown", (e) => { const r = miniEl.getBoundingClientRect(); camX = (e.clientX - r.left) / r.width * WW; camY = (e.clientY - r.top) / r.height * WH; follow = false; clampCam(); e.stopPropagation(); }); }
  // ---- مسیریابی A* روی شبکه‌ی ۴۰ پیکسلی (خشکی ارزان، آب با قایق گران‌تر، کوه گران) ----
  const tcost = (c) => c === 1 ? 1 : c === 2 ? 1.5 : c === 3 ? 4 : 2.6;
  function findPath(sx, sy, tx, ty, road) {
    const gx = (v) => Math.max(0, Math.min(WT - 1, Math.floor(v / TS))), gy = (v) => Math.max(0, Math.min(HT - 1, Math.floor(v / TS)));
    const s0 = gy(sy) * WT + gx(sx), g1 = gy(ty) * WT + gx(tx); if (s0 === g1) return [{ x: tx, y: ty }];
    const N = WT * HT, gs = new Float32Array(N).fill(1e9), from = new Int32Array(N).fill(-1), closed = new Uint8Array(N), heap = [[0, s0]]; gs[s0] = 0;
    const hf = (i) => Math.hypot((i % WT) - (g1 % WT), Math.floor(i / WT) - Math.floor(g1 / WT));
    const push = (it) => { heap.push(it); let i = heap.length - 1; while (i > 0) { const q = (i - 1) >> 1; if (heap[q][0] <= heap[i][0]) break; [heap[q], heap[i]] = [heap[i], heap[q]]; i = q; } };
    const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { let l = 2 * i + 1, r = l + 1, m = i; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; i = m; } } return top; };
    while (heap.length) { const [, c] = pop(); if (closed[c]) continue; closed[c] = 1; if (c === g1) break; const cx = c % WT, cy = (c / WT) | 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { if (!dx && !dy) continue; const nx = cx + dx, ny = cy + dy; if (nx < 0 || ny < 0 || nx >= WT || ny >= HT) continue; const n = ny * WT + nx; if (closed[n]) continue; const cc = cls(nx + 0.5, ny + 0.5), w = (road ? (cc === 0 ? 90 : cc === 3 ? 7 : cc === 2 ? 2.2 : 1) : tcost(cc)) * (dx && dy ? 1.414 : 1), ng = gs[c] + w; if (ng < gs[n]) { gs[n] = ng; from[n] = c; push([ng + hf(n), n]); } } }
    if (from[g1] < 0) return [{ x: tx, y: ty }];
    const pts = []; for (let c = g1; c !== s0 && c >= 0; c = from[c]) pts.push({ x: (c % WT + 0.5) * TS, y: (((c / WT) | 0) + 0.5) * TS }); pts.reverse();
    const out = []; for (let i = 0; i < pts.length; i++) { const a = out[out.length - 1] || { x: sx, y: sy }, b2 = pts[i], c2 = pts[i + 1]; if (c2) { const d1 = Math.atan2(b2.y - a.y, b2.x - a.x), d2 = Math.atan2(c2.y - b2.y, c2.x - b2.x); if (Math.abs(d1 - d2) < 0.05) continue; } out.push(b2); }
    out.pop(); out.push({ x: tx, y: ty }); return out;
  }
  function goTo(x, y) { P.tx = x; P.ty = y; P.path = findPath(P.x, P.y, x, y); }
  function panel(html) { const p = $("owpanel"); p.innerHTML = html; p.style.display = html ? "flex" : "none"; paused = !!html; }
  function quit(callQuit = true) { if (ended) return; ended = true; cancelAnimationFrame(raf); removeEventListener("keydown", onKD); removeEventListener("keyup", onKU); removeEventListener("resize", resize); ow.x = P.x; ow.y = P.y; save(); root.remove(); document.body.classList.remove("inbattle"); window.__s3d = null; if (callQuit) cb && cb.quit && cb.quit(); }
  window.__s3d = { back() { if (battle) return; if ($("owpanel").style.display !== "none") panel(""); else quit(); } };
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-o]"); if (!b) return; const a = b.dataset.o;
    if (a === "quit") quit(); else if (a === "track") { trackT = 6; msg("🔍 ردیابی فعال: سبز = ضعیف، قرمز = قوی"); } else if (a === "close") panel("");
    else if (a === "rest") { const c = 40; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.hp = 100; save(); panel(""); msg("🛌 سپاه استراحت کرد — سلامت کامل"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "vol") { if (ow.vol >= 12) { msg("حداکثر داوطلب"); return; } const c = +b.dataset.c || (150 + ow.vol * 40); if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.vol++; save(); panel(""); msg(`🏹 داوطلب تازه! قدرت +۲ (جمعاً ${fa(ow.vol)})`); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "b3d") { const bd = pend; panel(""); const th = { bandit: "n2", turan: "n3", wolf: "n1", div: "n4" }[bd.k.id] || "n2"; ow.x = P.x; ow.y = P.y; const keep = { pow: bd.pow, n: bd.n, k: bd.k, my: Math.max(4, Math.round(myPow() / 6)), ally: ow.allies.reduce((a, q) => a + (q.n || 0), 0) }; quit(false); cb && cb.band && cb.band({ id: th, name: bd.k.name, emoji: bd.k.icon, gate: Math.max(140, bd.pow * 16), power: Math.max(8, bd.pow), keep }); }
    else if (a === "bq") { const bd = pend; panel(""); fight(bd); }
    else if (a === "bpay") { const bd = pend, c = Math.round(bd.pow * 9 + 40); if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; panel(""); bd.dead = 30; save(); window.dispatchEvent(new Event("wm-gain")); msg(`💰 ${fa(c)} سکه دادی و آن‌ها رفتند`); }
    else if (a === "bflee") { pend.noFight = 4; panel(""); msg("🏃 از کنارشان گریختی"); }
    else if (a === "camp") { if (ow.food < 12) { msg("آذوقه کافی نیست"); return; } if (ow.campT > 0) { msg("هنوز نمی‌توانی اردو بزنی"); return; } ow.campT = 25; ow.fire = { x: P.x + 30, y: P.y + 6, t: 14 }; ow.food -= 10; ow.hp = Math.min(100, ow.hp + 25); msg("⛺ اردو زدی — سلامت +۲۵٪، آذوقه −۱۰٪"); }
    else if (a === "feed") { const c = 30; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.food = 100; save(); panel(""); msg("🍖 آذوقه پر شد"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "btalk") talk(pend);
    else if (a === "bjoin") { const bd = pend, c = joinCost(bd); if (ow.allies.length >= 4) { msg("حداکثر ۴ گروه هم‌پیمان"); return; } if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.allies.push({ k: bd.k.id, name: bd.k.name, icon: bd.k.icon, pow: Math.max(3, Math.round(bd.pow * 0.75)), n: bd.n, look: bd.look, x: bd.x, y: bd.y }); bd.dead = 0.01; panel(""); save(); msg(`🤝 ${bd.k.name} به سپاه تو پیوستند! قدرت +${fa(Math.round(bd.pow * 0.75))}`); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "bhag") { const bd = pend; panel(""); if (Math.random() < 0.35 + ow.rep * 0.02) { const c = Math.round(joinCost(bd) * 0.5); if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; if (ow.allies.length < 4) { ow.allies.push({ k: bd.k.id, name: bd.k.name, icon: bd.k.icon, pow: Math.max(3, Math.round(bd.pow * 0.6)), n: bd.n, look: bd.look, x: bd.x, y: bd.y }); bd.dead = 0.01; msg(`🤝 چانه زدی و ${bd.k.name} پذیرفتند`); } save(); window.dispatchEvent(new Event("wm-gain")); } else { bd.noFight = 0; msg("😠 نپذیرفتند — آماده‌ی نبرد باش"); setTimeout(() => contact(bd), 600); } }
    else if (a === "army") armyPanel();
    else if (a === "dis") { const i = +b.dataset.i; ow.allies.splice(i, 1); save(); armyPanel(); }
    else if (a === "vsack") sack(pend);
    else if (a === "vdev") develop(pend);
    else if (a === "vtax") collect(pend);
    else if (a === "vrest") { ow.hp = 100; save(); panel(""); msg("🛌 استراحت رایگان در آبادی خودت"); }
    else if (a === "vfeed") { ow.food = 100; save(); panel(""); msg("🍖 آذوقه‌ی رایگان"); }
    else if (a === "tav") tavern(pend);
    else if (a === "rumor") { const c = 60; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.rumorT = 90; trackT = 25; save(); panel(""); msg("🗣️ شایعه شنیدی: صندوق‌ها روی نقشه‌ی کوچک پیدایند و ردیاب فعال است"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "merc") { const base = SV.kingdomPower(), c = Math.round(120 + base * 14); if (ow.allies.length >= 4) { msg("حداکثر ۴ گروه هم‌پیمان"); return; } if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.allies.push({ k: "merc", name: "مزدوران شمشیرزن", icon: "⚔️", pow: Math.max(4, Math.round(base * 0.45)), n: 3, look: [0, 1, 2].map((i) => ({ c: ["#4a5a7a", "#6a4a4a", "#4a6a4a"][i], w: ["sword", "spear", "sword"][i], s: ["#d2a074", "#b07a50", "#8a5a3a"][i] })), x: P.x, y: P.y }); save(); panel(""); msg("⚔️ مزدوران به سپاهت پیوستند"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "heal") { const c = 70; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; ow.hp = 100; ow.food = Math.max(ow.food, 70); save(); panel(""); msg("🍲 غذای گرم و استراحت — سلامت و آذوقه پر شد"); window.dispatchEvent(new Event("wm-gain")); }
    else if (a === "arena") arena(pend);
    else if (a === "duel") duel(+b.dataset.t);
    else if (a === "atkc") { const id = b.dataset.id; quit(); cb && cb.castle && cb.castle(id); } });
  // ---- نبرد خودکار ----
  function fight(bd) {
    const mp = myPow(), a = Math.pow(mp, 1.35), b = Math.pow(bd.pow, 1.35), win = Math.random() < a / (a + b) * 1.06 - 0.03;
    battle = { bd, t: 0, win, mp }; paused = true;
  }
  let pend = null;
  function contact(b) {
    pend = b; const r = rel(b), pay = Math.round(b.pow * 9 + 40);
    panel(`<div class="owp"><h3>${b.k.icon} ${b.k.name}</h3><div class="xs">قدرت آن‌ها <b style="color:${RC[r]}">${fa(b.pow)} (${RN[r]})</b> • قدرت تو <b>${fa(Math.round(myPow()))}</b></div>
    <div class="xs mut" style="margin:4px 0 8px">${r === 0 ? "این‌ها از تو می‌ترسند؛ شکست‌شان آسان است." : r === 1 ? "نبردی هم‌قدر؛ با خودت وارد میدان شو تا شانس بیشتر شود." : "بسیار خطرناک! بهتر است فرار کنی یا با دستِ خودت بجنگی."}</div>
    <div class="row wrap" style="gap:8px;justify-content:center"><button class="btn s r" data-o="b3d">⚔️ نبرد سه‌بعدی</button><button class="btn s g" data-o="bq">⚡ نبرد سریع</button>${b.k.beast ? "" : '<button class="btn s g" data-o="btalk">🗣️ گفتگو</button>'}<button class="btn s d" data-o="bpay">💰 باج (${fa(pay)})</button><button class="btn s d" data-o="bflee">🏃 فرار</button></div></div>`);
  }
  function settle(bd, win, how) {
    const loss = Math.round(Math.min(60, 6 + 28 * bd.pow / Math.max(4, myPow())));
    if (win) { const coins = Math.round(bd.pow * (14 + S.level * 0.8) * (1 + rel(bd) * 0.25) * (how === "3d" ? 1.25 : 1)), xp = 10 + bd.pow, gem = rel(bd) === 2 ? 2 + Math.floor(Math.random() * 4) : (Math.random() < 0.15 ? 1 : 0); give({ coins, gems: gem }); addXp(xp); ow.hp = Math.max(8, ow.hp - loss * (how === "3d" ? 0.4 : 0.7)); S.stats.kills = (S.stats.kills || 0) + bd.n * 4; msg(`🏆 پیروزی! +${fa(coins)} 🪙${gem ? " +" + fa(gem) + " 💎" : ""}`); if (bd.dead !== undefined) bd.dead = 45; }
    else { ow.hp = Math.max(6, ow.hp - loss); const lost = Math.min(S.coins, Math.round(S.coins * 0.04 + 30)); S.coins -= lost; P.x = home.x; P.y = home.y + 30; camX = P.x; camY = P.y; if (ow.allies.length && Math.random() < 0.4) { const q = ow.allies.pop(); msg(`💀 شکست! ${q.name} فرار کردند • −${fa(lost)} 🪙`); } else msg(`💀 شکست! سپاه به کشور عقب نشست • −${fa(lost)} 🪙`); if (bd.st) { bd.st = "patrol"; bd.x = bd.hx; bd.y = bd.hy; } }
    save(); window.dispatchEvent(new Event("wm-gain"));
  }
  if (resume && resume.band) { setTimeout(() => settle(resume.band, resume.won, "3d"), 400); }
  // ---- گفتگو و هم‌پیمانی ----
  const joinCost = (bd) => Math.round((bd.pow * (bd.k.id === "turan" ? 13 : 10) + 70) * (1 - Math.min(0.3, ow.rep * 0.03)) * (1 + Math.max(0, -ow.rep) * 0.1));
  function talk(bd) {
    pend = bd; const r = rel(bd), c = joinCost(bd), cap = ow.allies.length >= 4;
    if (bd.k.id === "div") { panel(`<div class="owp"><h3>${bd.k.icon} ${bd.k.name}</h3><div class="xs mut" style="margin:8px 0">دیوان زبانِ آدمیان نمی‌فهمند؛ فقط غرش می‌کنند.</div><div class="row wrap" style="gap:8px;justify-content:center"><button class="btn s r" data-o="b3d">⚔️ نبرد</button><button class="btn s d" data-o="bflee">🏃 فرار</button></div></div>`); return; }
    const txt = r === 0 ? "«ما از نبرد خسته‌ایم؛ اگر مزد بدهی، زیر درفش تو می‌جنگیم.»" : r === 1 ? "«تو را می‌شناسیم، سردار. هم‌پیمانی ما بهایی دارد.»" : "«به ما فرمان می‌دهی؟ نخست ثابت کن که شایسته‌ای!»";
    panel(`<div class="owp"><h3>🗣️ ${bd.k.icon} ${bd.k.name}</h3><div class="xs" style="margin:6px 0">${txt}</div><div class="xs mut">اعتبار تو: ${fa(ow.rep)} • هم‌پیمانان: ${fa(ow.allies.length)}/۴</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin-top:8px">${r === 2 ? "" : `<button class="btn s g" data-o="bjoin" ${cap ? "disabled" : ""}>🤝 هم‌پیمان شو (${fa(c)} 🪙)</button>`}<button class="btn s g" data-o="bhag" ${cap ? "disabled" : ""}>🎲 چانه‌زنی</button><button class="btn s r" data-o="b3d">⚔️ نبرد</button><button class="btn s d" data-o="bflee">🏃 برو</button></div></div>`);
  }
  function armyPanel() {
    const list = ow.allies.map((q, i) => `<div class="row" style="justify-content:space-between;gap:8px;margin:4px 0"><span>${q.icon} ${q.name} — قدرت ${fa(q.pow)}</span><button class="btn s d" data-o="dis" data-i="${i}">اخراج</button></div>`).join("") || '<div class="xs mut">هنوز هم‌پیمانی نداری. با گروه‌های روی نقشه گفتگو کن یا از میخانه‌ی شهر مزدور بگیر.</div>';
    panel(`<div class="owp"><h3>👥 سپاه من</h3><div class="xs">قدرت کل: <b>${fa(Math.round(myPow()))}</b> • هم‌پیمانان ${fa(ow.allies.length)}/۴ • اعتبار ${fa(ow.rep)}</div><div style="margin:8px 0;max-height:150px;overflow:auto">${list}</div><div class="xs mut">هر هم‌پیمان آذوقه‌ی بیشتری مصرف می‌کند.</div><button class="btn s d" data-o="close" style="margin-top:6px">بستن</button></div>`);
  }
  // ---- روستا: غارت یا آباد کردن ----
  const vst = (v) => (ow.vs[v.name] = ow.vs[v.name] || { dev: 0, last: Date.now() });
  const devCost = (v) => Math.round(300 * (vst(v).dev + 1) * (1 + S.level * 0.05));
  function villagePanel(v) {
    pend = v; const st = vst(v), d = st.dev, tax = taxAmt(v);
    const rest = d >= 1 ? '<button class="btn s g" data-o="vrest">🛌 استراحت (رایگان)</button>' : '<button class="btn s g" data-o="rest">🛌 استراحت (۴۰ 🪙)</button>', feed = d >= 2 ? '<button class="btn s g" data-o="vfeed">🍖 آذوقه (رایگان)</button>' : '<button class="btn s g" data-o="feed">🍖 آذوقه (۳۰ 🪙)</button>';
    const vc = Math.round((150 + ow.vol * 40) * (d >= 3 ? 0.5 : 1));
    panel(`<div class="owp"><h3>🏘️ ${v.name} ${d ? "• " + "⭐".repeat(d) : ""}</h3><div class="xs mut">سلامت: ${fa(Math.round(ow.hp))}٪ • داوطلبان: ${fa(ow.vol)} • اعتبار: ${fa(ow.rep)}</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin:8px 0">${rest}${feed}<button class="btn s g" data-o="vol" data-c="${vc}">🏹 داوطلب (${fa(vc)} 🪙)</button></div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin-bottom:6px">${d < 3 ? `<button class="btn s g" data-o="vdev">🏗️ آباد کن (${fa(devCost(v))} 🪙)</button>` : '<span class="xs">✅ آبادی کامل</span>'}${d > 0 ? `<button class="btn s g" data-o="vtax" ${tax < 1 ? "disabled" : ""}>📦 مالیات (${fa(tax)})</button>` : ""}<button class="btn s r" data-o="vsack">🔥 غارت</button></div>
    <div class="xs mut">آبادی: سطح ۱ استراحت رایگان • ۲ آذوقه رایگان و مالیات بیشتر • ۳ داوطلب نیم‌قیمت. غارت اعتبار را کم می‌کند.</div><button class="btn s d" data-o="close" style="margin-top:6px">ادامه‌ی سفر</button></div>`);
  }
  const taxAmt = (v) => { const st = vst(v); return Math.floor(st.dev * 45 * (1 + S.level * 0.1) * Math.min(10, (Date.now() - st.last) / 3600000)); };
  function develop(v) { const st = vst(v), c = devCost(v); if (st.dev >= 3) return; if (S.coins < c) { msg("سکه کافی نیست"); return; } S.coins -= c; st.dev++; if (st.dev === 1) st.last = Date.now(); ow.rep = Math.min(10, ow.rep + 1); save(); msg(`🏗️ ${v.name} آباد شد (سطح ${fa(st.dev)}) • اعتبار +۱`); window.dispatchEvent(new Event("wm-gain")); villagePanel(v); }
  function collect(v) { const t = taxAmt(v); if (t < 1) return; give({ coins: t }); vst(v).last = Date.now(); save(); msg(`📦 مالیات روستا: +${fa(t)} 🪙`); window.dispatchEvent(new Event("wm-gain")); villagePanel(v); }
  function sack(v) { const st = vst(v), loot = Math.round(220 * (1 + S.level * 0.12) * (1 + st.dev * 0.8)), risk = Math.random() < 0.3; panel("");
    give({ coins: loot }); st.dev = 0; st.last = Date.now(); ow.rep = Math.max(-10, ow.rep - 2); v.cd = 20;
    if (risk) { const loss = 14 + Math.floor(Math.random() * 10); ow.hp = Math.max(8, ow.hp - loss); msg(`🔥 غارت شد: +${fa(loot)} 🪙 • مردم شورش کردند: −${fa(loss)}٪ سلامت`); } else msg(`🔥 ${v.name} غارت شد: +${fa(loot)} 🪙 • اعتبار −۲`);
    ow.food = Math.min(100, ow.food + 25); save(); window.dispatchEvent(new Event("wm-gain")); }
  // ---- شهر: میخانه، بازار، میدان ----
  function tavern(t) { pend = t; panel(`<div class="owp"><h3>🏙️ ${t.name}</h3><div class="xs mut">میخانه • بازار • میدان گلادیاتورها</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin:8px 0"><button class="btn s g" data-o="rumor">🍺 شایعه (۶۰ 🪙)</button><button class="btn s g" data-o="merc">⚔️ مزدور (${fa(Math.round(120 + SV.kingdomPower() * 14))} 🪙)</button><button class="btn s g" data-o="heal">🍲 غذا و استراحت (۷۰ 🪙)</button><button class="btn s g" data-o="arena">🏟️ میدان</button></div><button class="btn s d" data-o="close">ادامه‌ی سفر</button></div>`); }
  function arena(t) { const cs = Math.round(100 * (1 + S.level * 0.1));
    panel(`<div class="owp"><h3>🏟️ میدان گلادیاتورها</h3><div class="xs mut">تک‌نبرد با پهلوان. هرچه حریف سخت‌تر، پاداش بزرگ‌تر.</div>
    <div class="row wrap" style="gap:8px;justify-content:center;margin:8px 0"><button class="btn s g" data-o="duel" data-t="0">🥉 تازه‌کار (${fa(cs)}) ~۷۰٪</button><button class="btn s g" data-o="duel" data-t="1">🥈 جنگاور (${fa(cs * 2)}) ~۵۰٪</button><button class="btn s r" data-o="duel" data-t="2">🥇 پهلوان (${fa(cs * 4)}) ~۳۰٪</button></div><button class="btn s d" data-o="close">برگرد</button></div>`); }
  function duel(tier) { const cs = Math.round(100 * (1 + S.level * 0.1)) * [1, 2, 4][tier]; if (S.coins < cs) { msg("سکه کافی نیست"); return; } S.coins -= cs;
    const p = Math.min(0.9, [0.7, 0.5, 0.3][tier] + Math.min(0.15, SV.kingdomPower() / 400) + (ow.hp - 60) / 600), win = Math.random() < p; panel("");
    if (win) { const coins = Math.round(cs * [1.7, 2.6, 4.2][tier]), gem = tier === 2 ? 3 : tier === 1 ? 1 : 0; give({ coins, gems: gem }); addXp(15 + tier * 20); ow.hp = Math.max(8, ow.hp - 6 - tier * 4); ow.rep = Math.min(10, ow.rep + (tier === 2 ? 1 : 0)); msg(`🏆 در میدان پیروز شدی! +${fa(coins)} 🪙${gem ? " +" + fa(gem) + " 💎" : ""}`); }
    else { ow.hp = Math.max(8, ow.hp - 14 - tier * 6); msg(`🩸 در میدان شکست خوردی • −${fa(cs)} 🪙`); }
    save(); window.dispatchEvent(new Event("wm-gain")); }
  function endFight() {
    const { bd, win } = battle; battle = null; paused = false;
    const loss = Math.round(Math.min(60, 6 + 28 * bd.pow / Math.max(4, myPow())));
    if (win) { const coins = Math.round(bd.pow * (14 + S.level * 0.8) * (1 + rel(bd) * 0.25)), xp = 10 + bd.pow, gem = rel(bd) === 2 ? 2 + Math.floor(Math.random() * 4) : (Math.random() < 0.15 ? 1 : 0); give({ coins, gems: gem }); addXp(xp); ow.hp = Math.max(8, ow.hp - loss * 0.7); bd.dead = 45; S.stats.kills = (S.stats.kills || 0) + bd.n * 4; msg(`🏆 پیروزی! +${fa(coins)} 🪙${gem ? " +" + fa(gem) + " 💎" : ""} • خسارت سپاه ${fa(Math.round(loss * 0.7))}٪`); }
    else { ow.hp = Math.max(6, ow.hp - loss); const lost = Math.min(S.coins, Math.round(S.coins * 0.04 + 30)); S.coins -= lost; P.x = home.x; P.y = home.y + 30; camX = P.x; camY = P.y; bd.st = "patrol"; bd.x = bd.hx; bd.y = bd.hy; msg(`💀 شکست! سپاه به کشور عقب نشست • −${fa(lost)} 🪙`); }
    save(); window.dispatchEvent(new Event("wm-gain"));
  }
  const nearest = (f) => { let b = null, bd = 1e9; for (const q of bands) if (!q.dead && f(q)) { const d = Math.hypot(q.x - P.x, q.y - P.y); if (d < bd) { bd = d; b = q; } } return b; };
  function step(dt) {
    if (msgT > 0) { msgT -= dt; if (msgT <= 0) $("s3msg").classList.remove("on"); }
    if (trackT > 0) trackT -= dt; if (ow.rumorT > 0) ow.rumorT -= dt;
    if (battle) { battle.t += dt; if (battle.t > 3.4) endFight(); return; }
    if (paused) return;
    let mx = (key.d || key.arrowright ? 1 : 0) - (key.a || key.arrowleft ? 1 : 0), my = (key.s || key.arrowdown ? 1 : 0) - (key.w || key.arrowup ? 1 : 0);
    if (mx || my) { P.tx = null; P.path = null; P.chase = null; follow = true; }
    if (P.tx === null) P.path = null; else if (!P.path) P.path = [{ x: P.tx, y: P.ty }];
    if (P.chase) { const cb = P.chase; if (cb.dead > 0 || !bands.includes(cb)) P.chase = null; else { P.tx = cb.x; P.ty = cb.y; pT -= dt; if (pT <= 0 || !P.path) { pT = 0.5; P.path = findPath(P.x, P.y, cb.x, cb.y); } } }
    if (P.path && !mx && !my) { const w = P.path[0], dx = w.x - P.x, dy = w.y - P.y, d = Math.hypot(dx, dy); if (d < (P.path.length > 1 ? 14 : 8)) { P.path.shift(); if (!P.path.length) { P.tx = null; P.path = null; P.chase = null; } } else { mx = dx / d; my = dy / d; } }
    const l = Math.hypot(mx, my); if (l > 1) { mx /= l; my /= l; }
    const tl = walk(P.x, P.y), sp = 150 * (tl === 0 ? 0.92 : tl === 2 ? 0.65 : tl === 3 ? 0.4 : 1) * (0.7 + 0.3 * ow.hp / 100); P.boat = tl === 0;
    if (l > 0.05) { P.x = Math.max(14, Math.min(WW - 14, P.x + mx * sp * dt)); P.y = Math.max(14, Math.min(WH - 14, P.y + my * sp * dt)); P.ph += dt * 9 * Math.min(1, l); if (Math.abs(mx) > 0.1) P.dir = mx > 0 ? 1 : -1; P.mvx = mx; P.mvy = my; } else P.ph *= 0.8;
    if (follow) { camX += (P.x - camX) * Math.min(1, dt * 5); camY += (P.y - camY) * Math.min(1, dt * 5); } clampCam();
    if (l > 0.05 && !P.boat) { evDist += sp * dt; if (evDist > evNext && !battle) { evDist = 0; evNext = 700 + Math.random() * 700; roadEvent(); } }
    if (l > 0.05) { ow.food = Math.max(0, ow.food - dt * 0.3 * (1 + 0.25 * ow.allies.length)); if (ow.food <= 0) ow.hp = Math.max(5, ow.hp - dt * 1.2); } if (ow.campT > 0) ow.campT -= dt;
    const nearVillage = villages.some((v) => Math.hypot(v.x - P.x, v.y - P.y) < 70); ow.hp = Math.min(100, ow.hp + dt * (nearVillage ? 3 : 0.25));
    for (const v of villages) if (Math.hypot(v.x - P.x, v.y - P.y) < 36 && !v.cd) { v.cd = 6; P.tx = null; villagePanel(v); }
    for (const t of towns) { if (Math.hypot(t.x - P.x, t.y - P.y) < 50 && !t.cd) { t.cd = 8; P.tx = null; tavern(t); } if (t.cd) t.cd = Math.max(0, t.cd - dt) || 0; }
    const ap = ow.allies; for (let i = 0; i < ap.length; i++) { const q = ap[i], tx = P.x - P.dir * (34 + i * 30), ty = P.y + (i % 2 ? 16 : -8); q.x += (tx - q.x) * Math.min(1, dt * 3.5); q.y += (ty - q.y) * Math.min(1, dt * 3.5); q.ph = (q.ph || 0) + (Math.hypot(tx - q.x, ty - q.y) > 6 ? dt * 9 : 0); }
    for (const v of villages) if (v.cd) v.cd = Math.max(0, v.cd - dt) || 0;
    for (const c of castles) { const st = S.conquered[c.n.id] ? "conq" : (S.level >= c.n.need ? "open" : "locked"); if (Math.hypot(c.x - P.x, c.y - P.y) < 46 && !c.cd) { c.cd = 8; P.tx = null; if (st === "locked") msg(`🔒 ${c.n.name} — نیاز به سطح ${fa(c.n.need)} کشور`); else if (st === "conq") msg(`🏴 ${c.n.name} جزو قلمرو توست`); else panel(`<div class="owp"><h3>${c.n.emoji} ${c.n.name}</h3><div class="xs mut">${c.n.ruler} • قدرت ${fa(c.n.power)} • دروازه ${fa(c.n.gate)}</div><div class="xs" style="margin:6px 0">غنیمت: 🪙${fa(c.n.loot)} 💎${fa(c.n.gems)}</div><div class="row wrap" style="gap:8px;justify-content:center"><button class="btn s r" data-o="atkc" data-id="${c.n.id}">⚔️ حمله</button><button class="btn s d" data-o="close">برگرد</button></div></div>`); } if (c.cd) c.cd = Math.max(0, c.cd - dt) || 0; }
    for (const c of chests) if (!ow.found.includes(c.id) && Math.hypot(c.x - P.x, c.y - P.y) < 26) { ow.found.push(c.id); if (c.gem) { const n = 2 + Math.floor(Math.random() * 4); give({ gems: n }); msg(`🎁 صندوق گنج! +${fa(n)} 💎`); } else { const n = Math.round(140 * (1 + S.level * 0.1) * (0.8 + Math.random() * 0.5)); give({ coins: n }); msg(`🎁 صندوق گنج! +${fa(n)} 🪙`); } save(); window.dispatchEvent(new Event("wm-gain")); }
    for (const b of bands) {
      if (b.dead > 0) { b.dead -= dt; if (b.dead <= 0) { bands.splice(bands.indexOf(b), 1); spawnBand(true); } continue; }
      const d = Math.hypot(b.x - P.x, b.y - P.y), r = rel(b); b.ph += dt * 6;
      let sx = 0, sy = 0, sp2 = 70 * b.k.spd;
      if (d < 280 && r === 0 && myPow() > b.pow * 1.35) { b.st = "flee"; sx = (b.x - P.x) / d; sy = (b.y - P.y) / d; sp2 = 110 * b.k.spd; }
      else if (d < 300 && r >= 1) { b.st = "chase"; sx = (P.x - b.x) / d; sy = (P.y - b.y) / d; sp2 = (r === 2 ? 118 : 100) * b.k.spd; }
      else { b.st = "patrol"; b.tt -= dt; if (b.tt <= 0) { b.tt = 2 + Math.random() * 3; const a = Math.random() * TAU, rad = Math.random() * 120; b.tx = b.hx + Math.cos(a) * rad; b.ty = b.hy + Math.sin(a) * rad; } const dx = b.tx - b.x, dy = b.ty - b.y, dd = Math.hypot(dx, dy); if (dd > 6) { sx = dx / dd; sy = dy / dd; sp2 = 45; } }
      const nx = b.x + sx * sp2 * dt, ny = b.y + sy * sp2 * dt; if (walk(nx, ny) === 1 || walk(nx, ny) === 2) { b.x = nx; b.y = ny; } if (Math.abs(sx) > 0.1) b.dir = sx > 0 ? 1 : -1;
      if (b.noFight > 0) b.noFight -= dt; else if (d < 34 && !battle && !paused) { P.tx = null; contact(b); }
    }
    if ((hudT -= dt) <= 0) { hudT = 0.2; $("owp").textContent = "قدرت سپاه: " + fa(Math.round(myPow())); $("owhp").style.width = ow.hp + "%"; $("owhpt").textContent = "❤️ " + fa(Math.round(ow.hp)) + "٪"; $("owfd").style.width = ow.food + "%"; $("owfdt").textContent = "🍖 " + fa(Math.round(ow.food)) + "٪"; }
  }
  let GLO = false, lastD = 0; SQ.init().then((ok) => { GLO = ok && SQ.ready(); });
  const PHI = 0.62, CPH = Math.cos(PHI), SPH = Math.sin(PHI), GLW = { R: [1, 0, 0], U: [0, CPH, SPH], D: [0, -SPH, CPH], k: 27, dpr: 1, L: (() => { const l = [0.45, 0.8, -0.4], n = Math.hypot(...l); return l.map((v) => v / n); })(), fogc: [0.7, 0.8, 0.9], sky: [1, 1, 1], gnd: [0.85, 0.8, 0.7] };
  // رسم یک شخصیت سه‌بعدی؛ برمی‌گرداند true اگر رسم شد
  function gch(o, key, mk, x, y, H, face, atk, yo = 0) {
    if (!GLO) return false;
    const k = H * 1.0 / 1.9, m = o._g || (o._g = {}); let e = m[key]; if (!e) { e = m[key] = SQ.make(mk(), key.length * 7 + Math.round(x)); e.yw = face > 0 ? 1.57 : -1.57; }
    const dx = x - (e.lx ?? x), dy = y - (e.ly ?? y); e.lx = x; e.ly = y;
    if (dx * dx + dy * dy > 0.01) { const ty = Math.atan2(dx, -dy); let d = ty - e.yw; d = Math.atan2(Math.sin(d), Math.cos(d)); e.yw += d * 0.25; }
    SQ.drive(e, { x: x / k, z: -y / k, atk: atk || 0, atkMax: 0.5, hurt: 0, dt: dtO });
    GLW.k = k; GLW.dpr = dpr;
    const tl = renderInst(e, { x: 0, y: 0, z: 0, yaw: e.yw, sc: 1, fog: 0, flash: 0 }, GLW); if (!tl) return false;
    blit(g, tl, x, y + yo - 0.95 * CPH * k * (e.scale || 1));
    return true;
  }
  function drawBoat(x, y, dir, t, moving, sc = 1) {
    const bob = Math.sin(t * 2.6 + x * 0.04) * 1.8, tilt = Math.sin(t * 2.1 + y * 0.03) * 0.05;
    g.save(); g.translate(x, y + 5 + bob); g.scale(dir * sc, sc); g.rotate(tilt);
    g.fillStyle = "rgba(0,30,60,0.28)"; g.beginPath(); g.ellipse(0, 8, 30, 6, 0, 0, TAU); g.fill();
    if (moving) for (let k = 0; k < 2; k++) { const ph = (t * 1.6 + k * 0.5) % 1; g.strokeStyle = `rgba(255,255,255,${0.5 * (1 - ph)})`; g.lineWidth = 2; g.beginPath(); g.moveTo(-24, 4); g.quadraticCurveTo(-36 - ph * 24, -2 - ph * 8, -44 - ph * 26, -6 - ph * 14); g.moveTo(-24, 6); g.quadraticCurveTo(-36 - ph * 24, 10 + ph * 6, -44 - ph * 26, 14 + ph * 12); g.stroke(); }
    g.fillStyle = "rgba(255,255,255,0.35)"; g.beginPath(); g.ellipse(0, 7, 27, 4.5, 0, 0, TAU); g.fill();
    const hg = g.createLinearGradient(0, -4, 0, 10); hg.addColorStop(0, "#9a6a3a"); hg.addColorStop(1, "#5a3a1c");
    g.fillStyle = hg; g.strokeStyle = "#2a1608"; g.lineWidth = 1.4; g.beginPath(); g.moveTo(-26, -4); g.quadraticCurveTo(-22, 9, -8, 10); g.lineTo(14, 10); g.quadraticCurveTo(26, 7, 32, -7); g.quadraticCurveTo(10, -1, -26, -4); g.closePath(); g.fill(); g.stroke();
    g.strokeStyle = "rgba(30,15,5,0.55)"; g.lineWidth = 1; g.beginPath(); g.moveTo(-22, 2); g.lineTo(24, 2); g.moveTo(-18, 6); g.lineTo(18, 6); g.stroke();
    g.fillStyle = "#e8c070"; g.fillRect(-26, -5, 58, 2.5);
    g.strokeStyle = "#3a2410"; g.lineWidth = 2.4; g.beginPath(); g.moveTo(2, -2); g.lineTo(2, -50); g.stroke();
    const fl = Math.sin(t * 5) * 3; g.fillStyle = "#f4efe2"; g.strokeStyle = "#8a7a60"; g.lineWidth = 1; g.beginPath(); g.moveTo(4, -48); g.quadraticCurveTo(26 + fl, -34, 20, -10); g.lineTo(4, -8); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = "#c83a2a"; g.beginPath(); g.moveTo(2, -50); g.lineTo(-10 - fl, -47); g.lineTo(2, -44); g.fill();
    g.restore();
  }
  // ---------- هنر آبادی‌ها ----------
  const plate = (txt, x, y, col, size = 12) => { g.font = `bold ${size}px Vazirmatn, sans-serif`; g.textAlign = "center"; const w = g.measureText(txt).width + 18, h = size + 8; g.fillStyle = "rgba(14,12,26,0.78)"; g.strokeStyle = "rgba(255,214,120,0.7)"; g.lineWidth = 1.2; g.beginPath(); g.roundRect ? g.roundRect(x - w / 2, y - h / 2 - 3, w, h, h / 2) : g.rect(x - w / 2, y - h / 2 - 3, w, h); g.fill(); g.stroke(); g.fillStyle = col; g.fillText(txt, x, y + size * 0.33); };
  const smoke = (x, y, t, k = 1) => { for (let i = 0; i < 4; i++) { const ph = (((t * 0.35 + i / 4 + Math.abs(k) * 0.37) % 1) + 1) % 1; g.fillStyle = `rgba(220,220,225,${0.4 * (1 - ph)})`; g.beginPath(); g.arc(x + ph * 6 + Math.sin(ph * 6 + k) * 2, y - ph * 26, 2.5 + ph * 5, 0, TAU); g.fill(); } };
  function drawHouse(x, y, w, h, rc, wc, sd, t) {
    g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(x + w * 0.18, y + 2, w * 0.66, w * 0.17, 0, 0, TAU); g.fill();
    g.fillStyle = wc; g.fillRect(x - w / 2, y - h, w, h); g.fillStyle = "rgba(0,0,0,0.2)"; g.fillRect(x + w * 0.1, y - h, w * 0.4, h);
    g.strokeStyle = "rgba(60,36,18,0.55)"; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x - w / 2, y - h * 0.5); g.lineTo(x + w / 2, y - h * 0.5); g.moveTo(x - w * 0.15, y - h); g.lineTo(x - w * 0.15, y); g.stroke();
    const rh = h * 0.8; g.fillStyle = rc; g.beginPath(); g.moveTo(x - w / 2 - 4, y - h + 1); g.lineTo(x - 1, y - h - rh); g.lineTo(x + w / 2 + 4, y - h + 1); g.closePath(); g.fill();
    g.fillStyle = "rgba(0,0,0,0.25)"; g.beginPath(); g.moveTo(x - 1, y - h - rh); g.lineTo(x + w / 2 + 4, y - h + 1); g.lineTo(x - 1, y - h + 1); g.fill(); g.strokeStyle = "rgba(30,14,8,0.4)"; g.lineWidth = 1; for (let i = 1; i < 4; i++) { const yy = y - h - rh + rh * i / 4, ww = (w / 2 + 4) * i / 4; g.beginPath(); g.moveTo(x - ww, yy); g.lineTo(x + ww, yy); g.stroke(); }
    g.fillStyle = "#3a2410"; g.fillRect(x - w * 0.34, y - h * 0.5, w * 0.2, h * 0.5); g.fillStyle = "#ffd98a"; g.fillRect(x + w * 0.12, y - h * 0.72, w * 0.2, h * 0.24); g.strokeStyle = "#3a2410"; g.strokeRect(x + w * 0.12, y - h * 0.72, w * 0.2, h * 0.24);
    if (sd % 2 === 0) { g.fillStyle = "#6a5a50"; g.fillRect(x + w * 0.2, y - h - rh * 0.78, 5, rh * 0.5); smoke(x + w * 0.2 + 2, y - h - rh * 0.78, t, sd); }
  }
  function drawTower(x, y, w, h, roof, t, flag, cone = true) {
    g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(x + w * 0.35, y + 1, w * 0.75, w * 0.2, 0, 0, TAU); g.fill();
    const gr = g.createLinearGradient(x - w / 2, 0, x + w / 2, 0); gr.addColorStop(0, "#d4cdc0"); gr.addColorStop(0.55, "#aaa498"); gr.addColorStop(1, "#767066"); g.fillStyle = gr; g.fillRect(x - w / 2, y - h, w, h);
    g.strokeStyle = "rgba(40,34,30,0.35)"; g.lineWidth = 1; for (let yy = y - 6; yy > y - h; yy -= 8) { g.beginPath(); g.moveTo(x - w / 2, yy); g.lineTo(x + w / 2, yy); g.stroke(); }
    g.fillStyle = "#2a2230"; g.fillRect(x - 1.8, y - h * 0.6, 3.6, 8);
    if (cone) { g.fillStyle = roof; g.beginPath(); g.moveTo(x - w / 2 - 3, y - h); g.lineTo(x, y - h - w * 1.15); g.lineTo(x + w / 2 + 3, y - h); g.closePath(); g.fill(); g.fillStyle = "rgba(0,0,0,0.28)"; g.beginPath(); g.moveTo(x, y - h - w * 1.15); g.lineTo(x + w / 2 + 3, y - h); g.lineTo(x, y - h); g.fill(); }
    else { g.fillStyle = gr; g.fillRect(x - w / 2 - 2, y - h - 4, w + 4, 5); for (let i = 0; i < 4; i++) g.fillRect(x - w / 2 - 2 + i * (w + 4) / 3.5, y - h - 8, (w + 4) / 7, 5); }
    if (flag) { const ty = y - h - (cone ? w * 1.15 : 8), fl = Math.sin(t * 4 + x) * 3; g.strokeStyle = "#2a2018"; g.lineWidth = 1.6; g.beginPath(); g.moveTo(x, ty); g.lineTo(x, ty - 16); g.stroke(); g.fillStyle = flag; g.beginPath(); g.moveTo(x, ty - 16); g.quadraticCurveTo(x + 8, ty - 17 + fl, x + 15, ty - 13 + fl * 1.4); g.quadraticCurveTo(x + 8, ty - 11 + fl, x, ty - 8); g.fill(); }
  }
  function drawCastle(c, t) {
    const st = S.conquered[c.n.id] ? "conq" : S.level >= c.n.need ? "open" : "locked", x = c.x, y = c.y, roof = st === "locked" ? "#6a6a78" : st === "conq" ? "#3a62b8" : "#a8342a", flag = st === "locked" ? "#8a8a98" : st === "conq" ? "#4f86ff" : "#e0453a";
    if (st === "conq") { g.fillStyle = "rgba(79,134,255,0.1)"; g.strokeStyle = "rgba(120,170,255,0.55)"; g.lineWidth = 2; g.setLineDash([10, 8]); g.beginPath(); g.ellipse(x, y + 6, 170, 96, 0, 0, TAU); g.fill(); g.stroke(); g.setLineDash([]); for (const a of [0.6, 2.5, 3.9, 5.5]) { const bx2 = x + Math.cos(a) * 150, by2 = y + 6 + Math.sin(a) * 84, fl = Math.sin(t * 4 + a) * 3; g.strokeStyle = "#3a2a18"; g.lineWidth = 2; g.beginPath(); g.moveTo(bx2, by2); g.lineTo(bx2, by2 - 22); g.stroke(); g.fillStyle = "#4f86ff"; g.beginPath(); g.moveTo(bx2, by2 - 22); g.quadraticCurveTo(bx2 + 8, by2 - 23 + fl, bx2 + 15, by2 - 19 + fl); g.lineTo(bx2, by2 - 12); g.fill(); } }
    g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(x, y + 5, 62, 13, 0, 0, TAU); g.fill();
    drawTower(x - 24, y - 20, 16, 52, roof, t, null); drawTower(x + 24, y - 20, 16, 52, roof, t, null);
    drawTower(x, y - 26, 30, 74, roof, t, flag);
    const wg = g.createLinearGradient(0, y - 38, 0, y); wg.addColorStop(0, "#bdb6aa"); wg.addColorStop(1, "#8c8678"); g.fillStyle = wg; g.fillRect(x - 40, y - 36, 80, 36);
    g.strokeStyle = "rgba(40,34,30,0.35)"; g.lineWidth = 1; for (let yy = y - 6; yy > y - 36; yy -= 7) { g.beginPath(); g.moveTo(x - 40, yy); g.lineTo(x + 40, yy); g.stroke(); }
    g.fillStyle = "#bdb6aa"; for (let i = 0; i < 9; i++) g.fillRect(x - 40 + i * 9.6, y - 42, 6.2, 6);
    g.fillStyle = "#26180e"; g.beginPath(); g.moveTo(x - 9, y); g.lineTo(x - 9, y - 17); g.quadraticCurveTo(x, y - 29, x + 9, y - 17); g.lineTo(x + 9, y); g.fill(); g.strokeStyle = "#6a4a28"; g.lineWidth = 1.2; g.beginPath(); for (let i = -6; i <= 6; i += 4) { g.moveTo(x + i, y); g.lineTo(x + i, y - 20); } g.stroke();
    drawTower(x - 42, y + 2, 20, 60, roof, t, flag); drawTower(x + 42, y + 2, 20, 60, roof, t, flag);
    plate((st === "locked" ? "🔒 " : st === "conq" ? "🏴 " : "") + c.n.name, x, y - 118, st === "open" ? "#ffb0a0" : st === "conq" ? "#9ac0ff" : "#ddd", 12);
  }
  function drawVillage(v, t) {
    const sd = (v.x | 0) % 7, hs = [[-34, 0, 26, 18, "#b0422e", "#d8c49a"], [0, 10, 30, 21, "#3f62a8", "#e0d2ae"], [36, 2, 26, 17, "#9a5a30", "#cdb88e"], [-12, -22, 22, 16, "#a8452f", "#d4be94"]];
    for (const h of hs.sort((a, b2) => a[1] - b2[1])) drawHouse(v.x + h[0], v.y + h[1], h[2], h[3], h[4], h[5], h[0] + sd, t);
    g.fillStyle = "#7a7a80"; g.beginPath(); g.ellipse(v.x + 18, v.y - 14, 7, 3.5, 0, 0, TAU); g.fill(); g.fillStyle = "#3a6a9a"; g.beginPath(); g.ellipse(v.x + 18, v.y - 15, 5, 2.4, 0, 0, TAU); g.fill();
    g.fillStyle = "#d8b858"; for (let i = 0; i < 3; i++) { g.beginPath(); g.ellipse(v.x - 52 + i * 7, v.y + 14, 5, 4, 0, 0, TAU); g.fill(); }
    plate(v.name, v.x, v.y - 48, "#ffe9a8", 11);
  }
  function drawTown(tn, t) {
    const x = tn.x, y = tn.y; g.fillStyle = "rgba(0,0,0,0.28)"; g.beginPath(); g.ellipse(x, y + 8, 92, 16, 0, 0, TAU); g.fill();
    const cols = [["#b0422e", "#e0d0a8"], ["#3f62a8", "#d8c9a6"], ["#8a5a30", "#cdb88e"], ["#a83a52", "#e4d6b4"]];
    for (let i = -3; i <= 3; i++) drawHouse(x + i * 22, y - 36 - (i % 2) * 6, 22, 24 + ((i * 7) & 3) * 5, cols[(i + 3) % 4][0], cols[(i + 3) % 4][1], i + 9, t);
    drawTower(x, y - 38, 26, 84, "#3a62b8", t, "#ffd24a");
    const wg = g.createLinearGradient(0, y - 22, 0, y + 4); wg.addColorStop(0, "#b7ae9c"); wg.addColorStop(1, "#7e7666"); g.fillStyle = wg; g.fillRect(x - 78, y - 22, 156, 26); g.fillStyle = "#b7ae9c"; for (let i = 0; i < 16; i++) g.fillRect(x - 78 + i * 10, y - 27, 6.5, 5);
    g.fillStyle = "#26180e"; g.beginPath(); g.moveTo(x - 10, y + 4); g.lineTo(x - 10, y - 12); g.quadraticCurveTo(x, y - 25, x + 10, y - 12); g.lineTo(x + 10, y + 4); g.fill();
    for (const sx of [-1, 1]) { drawTower(x + sx * 82, y + 3, 18, 48, "#a8342a", t, "#e0453a"); }
    for (const [sx, col] of [[-52, "#c83a2a"], [52, "#2a6ac8"]]) { g.fillStyle = "#6a4a28"; g.fillRect(x + sx - 12, y + 6, 2, 12); g.fillRect(x + sx + 10, y + 6, 2, 12); g.fillStyle = col; g.beginPath(); g.moveTo(x + sx - 15, y + 6); g.lineTo(x + sx + 15, y + 6); g.lineTo(x + sx + 11, y + 13); g.lineTo(x + sx - 11, y + 13); g.fill(); g.fillStyle = "#d8b060"; g.fillRect(x + sx - 9, y + 14, 18, 4); }
    plate("🏙️ " + tn.name, x, y - 142, "#ffd9a0", 13); plate("🍺 🏟️ 🛒", x, y - 119, "#fff", 11);
  }
  function drawHome(t) {
    const x = home.x, y = home.y; drawHouse(x - 24, y + 4, 30, 22, "#2a56b8", "#e8dcc0", 1, t); drawTower(x + 12, y + 2, 20, 56, "#2a56b8", t, "#4f86ff");
    g.fillStyle = "#8a6a38"; for (let i = 0; i < 6; i++) g.fillRect(x - 46 + i * 7, y + 10, 2, 8); g.fillRect(x - 46, y + 12, 38, 2);
    plate("🏠 کشور من", x, y - 66, "#9ac0ff", 12);
  }
  // ---------- جانوران واقعی (نمای جانبی با حرکت پا، دم و سر) ----------
  const BC = { wolf: { b: "#7c808a", d: "#464a54", l: "#b9bcc4", s: "#cfd0d6" }, bear: { b: "#6c4a30", d: "#3c281a", l: "#8c6a48", s: "#a07c58" }, boar: { b: "#5c4638", d: "#2c2016", l: "#7c6450", s: "#6a5240" }, lion: { b: "#c99b48", d: "#7a5226", l: "#e4c078", s: "#ecd096" } };
  function drawBeast(type, x, y, dir, ph, sc, t, mv, atk = 0) {
    const C = BC[type] || BC.wolf, S2 = type === "bear" ? 1.55 : type === "lion" ? 1.18 : type === "boar" ? 0.95 : 1, amp = mv ? 7.5 : 0.8, bob = mv ? Math.sin(ph * 2) * 1.1 : Math.sin(t * 2.2 + x) * 0.5;
    g.save(); g.translate(x, y); g.scale(dir * sc * S2, sc * S2); g.lineCap = "round"; g.lineJoin = "round";
    g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(0, 3, 23, 5, 0, 0, TAU); g.fill();
    const leg = (hx, sw, col, th) => { const kx = hx + sw * 0.5 + 1.5, ky = -3.5 - Math.max(0, -Math.cos(ph + (sw > 0 ? 0 : 0))) * 0; g.strokeStyle = col; g.lineWidth = th; g.beginPath(); g.moveTo(hx, -10); g.quadraticCurveTo(kx, -5, hx + sw, 1.5 - Math.max(0, Math.sin(ph + hx)) * (mv ? 2.5 : 0)); g.stroke(); g.fillStyle = C.d; g.beginPath(); g.ellipse(hx + sw + 1.5, 2.4, 3.2, 1.8, 0, 0, TAU); g.fill(); };
    const s1 = Math.sin(ph) * amp, s2 = Math.sin(ph + Math.PI) * amp, s3 = Math.sin(ph + Math.PI * 0.5) * amp, s4 = Math.sin(ph + Math.PI * 1.5) * amp;
    leg(-13, s3, C.d, 4.6); leg(12, s4, C.d, 4.6);
    // دم
    g.strokeStyle = C.b; g.lineWidth = type === "wolf" ? 5 : type === "bear" ? 4 : 3; g.beginPath(); const tw = Math.sin(t * 5 + x) * (mv ? 3 : 1.5); if (type === "boar") { g.moveTo(-19, -15 + bob); g.quadraticCurveTo(-25, -20, -22, -24); } else if (type === "bear") { g.moveTo(-19, -14 + bob); g.lineTo(-23, -13); } else { g.moveTo(-19, -14 + bob); g.quadraticCurveTo(-30, -10 + tw, -35, type === "lion" ? -3 + tw : -6 + tw); } g.stroke(); if (type === "lion") { g.fillStyle = C.d; g.beginPath(); g.ellipse(-35, -3 + tw, 3.5, 4.5, 0, 0, TAU); g.fill(); }
    // تنه
    const bg2 = g.createLinearGradient(0, -22, 0, -2); bg2.addColorStop(0, C.l); bg2.addColorStop(0.45, C.b); bg2.addColorStop(1, C.d); g.fillStyle = bg2; g.beginPath(); g.ellipse(0, -13 + bob, type === "bear" ? 21 : 20, type === "bear" ? 11 : type === "boar" ? 10 : 8.4, 0, 0, TAU); g.fill();
    g.fillStyle = C.s; g.globalAlpha = 0.55; g.beginPath(); g.ellipse(2, -8 + bob, 14, 3.6, 0, 0, TAU); g.fill(); g.globalAlpha = 1;
    if (type === "bear") { g.fillStyle = C.b; g.beginPath(); g.ellipse(9, -22 + bob, 9, 6, -0.2, 0, TAU); g.fill(); }
    if (type === "boar") { g.strokeStyle = C.d; g.lineWidth = 1.6; for (let i = -14; i < 12; i += 3) { g.beginPath(); g.moveTo(i, -22 + bob + Math.abs(i) * 0.05); g.lineTo(i - 1.5, -26 + bob); g.stroke(); } }
    g.strokeStyle = "rgba(20,20,26,0.25)"; g.lineWidth = 1; for (let i = -10; i < 12; i += 5) { g.beginPath(); g.moveTo(i, -19 + bob); g.lineTo(i + 3, -12 + bob); g.stroke(); }
    leg(-14, s1, C.b, 5); leg(11, s2, C.b, 5);
    // سر
    const hx = 19, hy = -17 + bob - (type === "bear" ? 1 : 0), jaw = atk > 0 ? 0.6 * Math.sin(atk * Math.PI) : (mv ? 0.05 : 0), hd = Math.sin(ph * 2) * (mv ? 0.5 : 0);
    g.strokeStyle = C.b; g.lineWidth = type === "bear" ? 9 : 7; g.beginPath(); g.moveTo(11, -17 + bob); g.lineTo(hx, hy + hd); g.stroke();
    if (type === "lion") { const mg = g.createRadialGradient(hx, hy, 3, hx, hy, 13); mg.addColorStop(0, "#9a6a2c"); mg.addColorStop(1, "#4a2c10"); g.fillStyle = mg; g.beginPath(); for (let i = 0; i < 14; i++) { const a = i / 14 * TAU, r = 12 + (i % 2) * 3; g.lineTo(hx - 2 + Math.cos(a) * r, hy + Math.sin(a) * r); } g.closePath(); g.fill(); }
    g.save(); g.translate(hx, hy + hd);
    // آرواره پایین
    g.fillStyle = C.d; g.beginPath(); g.moveTo(2, 1); g.lineTo(type === "bear" ? 12 : 14, 2 + jaw * 8); g.lineTo(type === "boar" ? 12 : 13, 3.4 + jaw * 8); g.lineTo(1, 4); g.closePath(); g.fill();
    if (jaw > 0.1) { g.fillStyle = "#b02a2a"; g.beginPath(); g.moveTo(3, 1.5); g.lineTo(12, 2.5); g.lineTo(12, 3 + jaw * 7); g.lineTo(3, 3.5); g.fill(); }
    // جمجمه و پوزه
    g.fillStyle = C.b; g.beginPath(); g.ellipse(0, 0, type === "bear" ? 9 : 7.4, type === "bear" ? 7.6 : 6, 0, 0, TAU); g.fill();
    const snl = type === "wolf" ? 15 : type === "bear" ? 11 : type === "boar" ? 14 : 10, snh = type === "bear" ? 4.6 : type === "boar" ? 4 : 3.4;
    g.fillStyle = type === "boar" ? C.b : C.l; g.beginPath(); g.moveTo(2, -snh - 1.2 - jaw * 2); g.quadraticCurveTo(snl * 0.8, -snh - 1, snl, -1.5 - jaw * 3); g.lineTo(snl, 1.2 - jaw); g.lineTo(2, 2.6); g.closePath(); g.fill();
    g.fillStyle = "#16161a"; g.beginPath(); g.ellipse(snl - 0.4, -1.8 - jaw * 3, type === "boar" ? 3.2 : 2.3, 1.8, 0, 0, TAU); g.fill();
    if (type === "wolf" || type === "lion") { g.fillStyle = "#fff"; g.beginPath(); g.moveTo(snl - 4, 0.8 - jaw); g.lineTo(snl - 3, 3.4 + jaw * 3); g.lineTo(snl - 2, 0.8 - jaw); g.fill(); }
    if (type === "boar") { g.strokeStyle = "#f0e8d0"; g.lineWidth = 2; g.beginPath(); g.moveTo(snl - 5, 1.5); g.quadraticCurveTo(snl - 2, 6, snl + 1, 2); g.stroke(); }
    // گوش
    g.fillStyle = C.d; g.beginPath(); if (type === "bear" || type === "lion") g.arc(-2.5, -6.4, 3, 0, TAU); else { g.moveTo(-4, -4.5); g.lineTo(-2, type === "wolf" ? -13 : -9.5); g.lineTo(2, -5.4); } g.fill();
    // چشم
    g.fillStyle = type === "boar" ? "#ff6a3a" : "#ffd24a"; g.beginPath(); g.ellipse(3.4, -2.8, 1.5, 1.2, 0, 0, TAU); g.fill(); g.fillStyle = "#000"; g.fillRect(3.4, -3.8, 0.9, 2);
    g.restore();
    g.restore();
  }
  // ---------- آتش اردو، سایه‌ی ابر ----------
  const cloudC = document.createElement("canvas"); cloudC.width = cloudC.height = 128; { const cc = cloudC.getContext("2d"), gr = cc.createRadialGradient(64, 64, 4, 64, 64, 62); gr.addColorStop(0, "rgba(10,20,40,0.55)"); gr.addColorStop(1, "rgba(10,20,40,0)"); cc.fillStyle = gr; cc.fillRect(0, 0, 128, 128); }
  function drawCamp(c, t) {
    g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(c.x, c.y + 3, 26, 7, 0, 0, TAU); g.fill();
    g.fillStyle = "#c8b890"; g.strokeStyle = "#5a4628"; g.lineWidth = 1.5; g.beginPath(); g.moveTo(c.x + 14, c.y); g.lineTo(c.x + 32, c.y); g.lineTo(c.x + 23, c.y - 26); g.closePath(); g.fill(); g.stroke(); g.fillStyle = "#3a2a18"; g.beginPath(); g.moveTo(c.x + 20, c.y); g.lineTo(c.x + 26, c.y); g.lineTo(c.x + 23, c.y - 10); g.fill();
    g.strokeStyle = "#4a2e16"; g.lineWidth = 3.5; g.beginPath(); g.moveTo(c.x - 9, c.y + 1); g.lineTo(c.x + 7, c.y - 3); g.moveTo(c.x - 8, c.y - 3); g.lineTo(c.x + 8, c.y + 1); g.stroke();
    const gl = g.createRadialGradient(c.x, c.y - 8, 2, c.x, c.y - 8, 46); gl.addColorStop(0, `rgba(255,180,70,${0.45 + Math.sin(t * 17) * 0.08})`); gl.addColorStop(1, "rgba(255,140,40,0)"); g.fillStyle = gl; g.beginPath(); g.arc(c.x, c.y - 8, 46, 0, TAU); g.fill();
    for (let i = 0; i < 3; i++) { const fl = Math.sin(t * 13 + i * 2) * 2, h = 17 - i * 4; g.fillStyle = ["#ff8a2a", "#ffc83a", "#fff2a0"][i]; g.beginPath(); g.moveTo(c.x - 6 + i * 2, c.y - 2); g.quadraticCurveTo(c.x - 7 + i * 2 + fl, c.y - h * 0.6, c.x + fl, c.y - h); g.quadraticCurveTo(c.x + 7 - i * 2 + fl, c.y - h * 0.6, c.x + 6 - i * 2, c.y - 2); g.fill(); }
    for (let i = 0; i < 3; i++) { const ph = (t * 0.6 + i / 3) % 1; g.fillStyle = `rgba(210,210,215,${0.35 * (1 - ph)})`; g.beginPath(); g.arc(c.x + Math.sin(ph * 5 + i) * 4, c.y - 18 - ph * 34, 3 + ph * 6, 0, TAU); g.fill(); }
  }
  // ---------- رویدادهای مسیر ----------
  let evDist = 0, evNext = 520 + Math.random() * 380;
  const EVT = [
    () => ({ t: "🛒 تاجر دوره‌گرد", d: "تاجری کنار جاده بساط کرده است: «آذوقه‌ی تازه دارم، رفیق!»", o: [["🍖 خرید آذوقه (۶۰ 🪙)", "ev_food"], ["🗣️ شنیدن شایعه", "ev_rumor"], ["برو", "close"]] }),
    () => ({ t: "🗡️ کمین راهزنان", d: "چند راهزن از پشت صخره‌ها بیرون پریدند و راه را بستند!", o: [["💰 باج (۵۰ 🪙)", "ev_pay"], ["⚔️ مقابله", "ev_fight"], ["🏃 فرار", "ev_flee"]] }),
    () => ({ t: "🤝 کودک گم‌شده", d: "کودکی گریان کنار جاده نشسته و راه خانه را گم کرده است.", o: [["🤝 همراهی‌اش کنم", "ev_child"], ["نادیده بگیر", "close"]] }),
    () => ({ t: "🙏 زیارتگاه کهن", d: "زیارتگاهی قدیمی میان درختان پنهان است؛ آتش مقدسش هنوز روشن است.", o: [["🕯 نیایش (سلامت کامل)", "ev_pray"], ["💎 هدیه (۱ 💎) برای برکت", "ev_gift"], ["برو", "close"]] }),
    () => ({ t: "🐎 اسب سرگردان", d: "اسبی رها شده و زین‌دار میان علف‌ها می‌چرد.", o: [["🐎 بگیرش (آذوقه +۲۰٪)", "ev_horse"], ["بگذار برود", "close"]] }),
  ];
  function roadEvent() { const e = EVT[Math.floor(Math.random() * EVT.length)](); P.tx = null; P.path = null; P.chase = null; panel(`<div class="owp"><h3>${e.t}</h3><div class="xs" style="margin:6px 0 10px;max-width:300px">${e.d}</div><div class="row wrap" style="gap:8px;justify-content:center">${e.o.map(([l, a]) => a === "close" ? `<button class="btn s d" data-o="close">${l}</button>` : `<button class="btn s g" data-ev="${a}">${l}</button>`).join("")}</div></div>`); }
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-ev]"); if (!b) return; const a = b.dataset.ev, done = (m) => { panel(""); msg(m); save(); window.dispatchEvent(new Event("wm-gain")); };
    if (a === "ev_food") { if (S.coins < 60) return msg("سکه کافی نیست"); S.coins -= 60; ow.food = Math.min(100, ow.food + 40); done("🍖 آذوقه +۴۰٪"); }
    else if (a === "ev_rumor") { ow.rumorT = 30; done("🗣️ تاجر جای صندوق‌های گنج را فاش کرد — روی نقشه‌ی کوچک ببین"); }
    else if (a === "ev_pay") { if (S.coins < 50) return msg("سکه کافی نیست"); S.coins -= 50; done("💰 راهزنان با باج رفتند"); }
    else if (a === "ev_fight") { if (Math.random() < Math.min(0.9, 0.35 + myPow() / 120)) { const c = Math.round(60 + S.level * 18); give({ coins: c }); ow.hp = Math.max(8, ow.hp - 6); done(`⚔️ راهزنان را شکست دادی! +${fa(c)} 🪙`); } else { ow.hp = Math.max(6, ow.hp - 18); S.coins = Math.max(0, S.coins - 40); done("🩸 زخمی شدی و کمی سکه از دست رفت"); } }
    else if (a === "ev_flee") { ow.food = Math.max(0, ow.food - 8); done("🏃 گریختی — آذوقه −۸٪"); }
    else if (a === "ev_child") { ow.rep = (ow.rep || 0) + 1; const c = 90 + S.level * 10; give({ coins: c }); done(`🤝 خانواده‌اش سپاسگزارند! +${fa(c)} 🪙 و اعتبار +۱`); }
    else if (a === "ev_pray") { ow.hp = 100; done("🕯 نیرویی تازه در تنت دمید — سلامت کامل"); }
    else if (a === "ev_gift") { if ((S.gems || 0) < 1) return msg("الماس کافی نیست"); S.gems -= 1; ow.hp = 100; ow.food = Math.min(100, ow.food + 25); done("✨ برکت زیارتگاه — سلامت کامل و آذوقه +۲۵٪"); }
    else if (a === "ev_horse") { ow.food = Math.min(100, ow.food + 20); done("🐎 اسب را گرفتی — آذوقه +۲۰٪"); } });
  // ---------- سفر سریع ----------
  function fastTravel() { const dests = [{ n: "🏠 کشور من", x: home.x, y: home.y + 40 }, ...towns.map((t) => ({ n: "🏙️ " + t.name, x: t.x, y: t.y + 40 })), ...castles.filter((c) => S.conquered[c.n.id]).map((c) => ({ n: "🏴 " + c.n.name, x: c.x, y: c.y + 40 }))];
    panel(`<div class="owp"><h3>🐎 سفر سریع</h3><div class="xs mut" style="margin-bottom:8px">هزینه بسته به فاصله است</div><div style="display:flex;flex-direction:column;gap:7px">${dests.map((d, i) => { const c = Math.round(20 + Math.hypot(d.x - P.x, d.y - P.y) / 18); return `<button class="btn s g" data-ft="${i}" data-c="${c}">${d.n} — ${fa(c)} 🪙</button>`; }).join("")}<button class="btn s d" data-o="close">بستن</button></div></div>`);
    $("owpanel").querySelectorAll("[data-ft]").forEach((b) => b.onclick = () => { const d = dests[+b.dataset.ft], c = +b.dataset.c; if (S.coins < c) return msg("سکه کافی نیست"); S.coins -= c; P.x = d.x; P.y = d.y; P.tx = null; P.path = null; P.chase = null; camX = P.x; camY = P.y; follow = true; panel(""); msg("🐎 به مقصد رسیدی"); save(); window.dispatchEvent(new Event("wm-gain")); }); }
  root.addEventListener("click", (e) => { const b = e.target.closest("[data-oz=ft]"); if (b && !battle) fastTravel(); });
  let dtO = 0.016;
  function draw(t) {
    dtO = Math.min(0.05, Math.max(0.001, t - lastD)); lastD = t; if (GLO) frameBegin();
    g.setTransform(dpr, 0, 0, dpr, 0, 0); g.fillStyle = "#143a6a"; g.fillRect(0, 0, VW, VH); const VWw = VW / zoom, VHw = VH / zoom;
    const ox = Math.round(camX - VWw / 2), oy = Math.round(camY - VHw / 2); g.setTransform(dpr * zoom, 0, 0, dpr * zoom, 0, 0); g.save(); g.translate(-ox, -oy);
    g.drawImage(bg, 0, 0, bg.width, bg.height, 0, 0, WW, WH);
    g.lineWidth = 1.4; for (const sp of sparks) { if (sp.x < ox - 10 || sp.x > ox + VWw + 10 || sp.y < oy - 10 || sp.y > oy + VHw + 10) continue; const a = Math.sin(t * 1.3 + sp.p) * 0.5 + 0.5; if (a < 0.45) continue; g.strokeStyle = `rgba(255,255,255,${(a - 0.45) * 0.9})`; g.beginPath(); g.moveTo(sp.x - 5, sp.y); g.quadraticCurveTo(sp.x, sp.y - 2, sp.x + 5, sp.y); g.stroke(); }
    const vis = (x, y, m = 80) => x > ox - m && x < ox + VWw + m && y > oy - m && y < oy + VHw + m, items = [];
    if (ENVR) { envFrame(2); const cp = Math.cos(0.48); for (const f of flora) { if (!vis(f.x, f.y, 70)) continue; const n = f.n, wd = f.w; items.push({ y: f.y, f: () => { const sp = envSprite(n, [0.8, 2.4, 4.0][f.yw], 0.48), inf = envInfo(n); if (!sp || !inf) return; const ppu = wd / (2 * sp.hw); envBlit(g, sp, f.x, f.y - inf.h / 2 * cp * ppu, ppu, 1, f.fl); } }); } }
    if (ow.fire && ow.fire.t > 0) { ow.fire.t -= dtO; const fr = ow.fire; items.push({ y: fr.y, f: () => drawCamp(fr, t) }); }
    for (const v of villages) if (vis(v.x, v.y, 90)) items.push({ y: v.y, f: () => drawVillage(v, t) });
    for (const c of castles) if (vis(c.x, c.y, 110)) items.push({ y: c.y, f: () => drawCastle(c, t) });
    for (const c of chests) if (!ow.found.includes(c.id) && vis(c.x, c.y)) items.push({ y: c.y, f: () => { g.fillStyle = "rgba(255,230,120,0.25)"; g.beginPath(); g.arc(c.x, c.y, 16 + Math.sin(t * 4) * 2, 0, TAU); g.fill(); g.fillStyle = c.gem ? "#5fd8ff" : "#c8863a"; g.strokeStyle = "#3a2410"; g.lineWidth = 1.5; g.fillRect(c.x - 8, c.y - 6, 16, 12); g.strokeRect(c.x - 8, c.y - 6, 16, 12); g.fillStyle = "#ffd24a"; g.fillRect(c.x - 2, c.y - 3, 4, 6); } });
    for (const tn of towns) if (vis(tn.x, tn.y, 160)) items.push({ y: tn.y, f: () => drawTown(tn, t) });
    for (const q of ow.allies) items.push({ y: q.y, f: () => { const qb = walk(q.x, q.y) === 0; if (qb) drawBoat(q.x, q.y, P.dir, t, true, 0.85); for (let i = 0; i < Math.min(3, q.n); i++) { const m = q.look[i % q.look.length]; if (gch(q, "a" + i, () => SQ.spec("ally", i === 0 ? "shield" : "sword", i + 3), q.x + (i - 1) * 12, q.y + (i % 2) * 5, 46, P.dir, 0, qb ? -10 : 0)) continue; drawHuman(g, q.x + (i - 1) * 14, q.y + (i % 2) * 8, { H: 44, skin: m.s, cloth: m.c, weapon: m.w, dir: P.dir, walk: q.ph + i, pants: "#3a3030", hair: "#1a1210", armor: "#7a8498", helm: i === 0 ? "#8a94a8" : undefined }); } lab("🤝 " + q.icon + " " + fa(q.pow), q.x, q.y - 56, "#8affb0", 10); } });
    // خانه‌ی خودمان
    items.push({ y: home.y, f: () => drawHome(t) });
    for (const b of bands) if (b.dead <= 0 && vis(b.x, b.y)) items.push({ y: b.y, f: () => drawBand(b, t) });
    items.push({ y: P.y, f: () => { if (P.boat) drawBoat(P.x, P.y, P.dir, t, P.path || key.w || key.a || key.s || key.d, 1); if (!gch(P, "hero", () => SQ.heroSpec(S.avatar || {}, look), P.x, P.y, 56, P.dir, 0, P.boat ? -12 + Math.sin(t * 2.6 + P.x * 0.04) * 1.8 : 0)) drawHuman(g, P.x, P.y, { H: 52, skin: look.skin || "#d2a074", hair: look.hair || "#2a1a10", cloth: S.avatar?.tunic || "#2f5a8a", armor: "#aab4c8", helm: "#9aa4b8", plume: "#e8453a", cape: "#c83a2a", weapon: "sword", shield: "#3f6ad8", dir: P.dir, walk: P.ph }); lab("قهرمان", P.x, P.y - 64, "#9ac0ff", 10); } });
    items.sort((a, b) => a.y - b.y); for (const it of items) it.f();
    for (let k = 0; k < 9; k++) { const cx = ((k * 420 + t * 12 + hash(k, 1, 3) * 900) % (WW + 700)) - 350, cy = (hash(k, 2, 3) * WH + Math.sin(t * 0.05 + k) * 30), r = 150 + hash(k, 4, 3) * 130; if (cx + r < ox || cx - r > ox + VWw || cy + r < oy || cy - r > oy + VHw) continue; g.globalAlpha = 0.5; g.drawImage(cloudC, cx - r, cy - r * 0.55, r * 2, r * 1.1); g.globalAlpha = 1; }
    if (P.path && P.path.length) { g.save(); g.strokeStyle = "rgba(255,255,255,0.55)"; g.lineWidth = 2.5; g.setLineDash([6, 7]); g.lineDashOffset = -t * 30; g.beginPath(); g.moveTo(P.x, P.y); for (const w of P.path) g.lineTo(w.x, w.y); g.stroke(); g.restore(); const e = P.path[P.path.length - 1], r = 9 + Math.sin(t * 6) * 2; g.strokeStyle = "#ffe08a"; g.lineWidth = 2.5; g.beginPath(); g.arc(e.x, e.y, r, 0, TAU); g.stroke(); g.fillStyle = "rgba(255,224,138,0.35)"; g.fill(); }
    if (tapFx) { tapFx.t += dtO; if (tapFx.t > 0.6) tapFx = null; else { g.strokeStyle = `rgba(255,255,255,${1 - tapFx.t / 0.6})`; g.lineWidth = 2; g.beginPath(); g.arc(tapFx.x, tapFx.y, 6 + tapFx.t * 40, 0, TAU); g.stroke(); } }
    g.restore(); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (trackT > 0) for (const [f, col] of [[(q) => rel(q) === 0, RC[0]], [(q) => rel(q) === 2, RC[2]]]) { const q = nearest(f); if (!q) continue; const a = Math.atan2(q.y - P.y, q.x - P.x), cx = VW / 2 + Math.cos(a) * Math.min(VW, VH) * 0.34, cy = VH / 2 + Math.sin(a) * Math.min(VW, VH) * 0.34; g.save(); g.translate(cx, cy); g.rotate(a); g.fillStyle = col; g.strokeStyle = "#000"; g.lineWidth = 2; g.beginPath(); g.moveTo(16, 0); g.lineTo(-8, -10); g.lineTo(-8, 10); g.closePath(); g.fill(); g.stroke(); g.restore(); g.fillStyle = col; g.font = "bold 11px sans-serif"; g.textAlign = "center"; g.fillText(Math.round(Math.hypot(q.x - P.x, q.y - P.y) / 10) + "م", cx, cy + 24); }
    if (battle) { const k = Math.min(1, battle.t / 3.4); g.fillStyle = `rgba(0,0,0,${0.55 * Math.min(1, battle.t * 2)})`; g.fillRect(0, 0, VW, VH); const cx = VW / 2, cy = VH / 2;
      for (let i = 0; i < 4; i++) { drawHuman(g, cx - 90 - i * 22 + Math.sin(t * 14 + i) * 8, cy + 40 + (i % 2) * 14, { H: 90, cloth: "#2f5a8a", armor: "#aab4c8", helm: "#9aa4b8", weapon: "sword", shield: "#3f6ad8", dir: 1, walk: t * 8 + i }); }
      for (let i = 0; i < Math.min(5, battle.bd.n); i++) { const m = battle.bd.look[i]; if (battle.bd.k.beast) { drawBeast(battle.bd.k.id, cx + 100 + i * 34 - Math.sin(t * 14 + i) * 8, cy + 56 + (i % 2) * 16, -1, t * 14 + i * 2, 2.1, t, true, ((t * 2 + i * 0.3) % 1) > 0.7 ? 1 : 0); continue; } drawHuman(g, cx + 90 + i * 22 - Math.sin(t * 14 + i) * 8, cy + 40 + (i % 2) * 14, { H: 90, cloth: m.c, skin: m.s, weapon: m.w, dir: -1, walk: t * 8 + i, beard: i % 2 === 0, pants: "#3a3030" }); }
      g.fillStyle = "#fff"; g.font = "bold 22px Vazirmatn, sans-serif"; g.textAlign = "center"; g.fillText(`⚔️ ${battle.bd.k.name}`, cx, cy - 70); g.fillStyle = "#333"; g.fillRect(cx - 120, cy - 52, 240, 12); g.fillStyle = "#4f86ff"; g.fillRect(cx - 120, cy - 52, 240 * (battle.win ? 0.5 + 0.5 * k : 0.5 - 0.5 * k) * 1, 12);
      for (let i = 0; i < 9; i++) { const a = hash(i, Math.floor(t * 9), 5) * TAU, r = 16 + hash(i, Math.floor(t * 9), 6) * 34; g.strokeStyle = `rgba(255,${200 + i * 5},120,0.85)`; g.lineWidth = 2; g.beginPath(); g.moveTo(cx + Math.cos(a) * r * 0.4, cy + 48 + Math.sin(a) * r * 0.25); g.lineTo(cx + Math.cos(a) * r, cy + 48 + Math.sin(a) * r * 0.6); g.stroke(); }
      g.font = "bold 13px Vazirmatn, sans-serif"; g.fillStyle = "#9ac0ff"; g.textAlign = "right"; g.fillText(`🛡️ سپاه تو: ${fa(Math.round(battle.mp))}`, cx - 8, cy - 32); g.fillStyle = "#ff9a8a"; g.textAlign = "left"; g.fillText(`${battle.bd.k.icon} ${fa(battle.bd.pow)}`, cx + 8, cy - 32); g.textAlign = "center";
      if (k > 0.85) { const loss = Math.round(Math.min(60, 6 + 28 * battle.bd.pow / Math.max(4, battle.mp)) * 0.7); g.fillStyle = battle.win ? "#7bff9a" : "#ff6a6a"; g.font = "bold 26px Vazirmatn, sans-serif"; g.fillText(battle.win ? "پیروزی!" : "شکست!", cx, cy - 4); g.font = "12px Vazirmatn, sans-serif"; g.fillStyle = "#e8e8f0"; g.fillText(battle.win ? `تلفات سپاه ≈ ${fa(loss)}٪` : "سپاه به کشور عقب می‌نشیند", cx, cy + 14); } }
    miniDraw();
  }
  function lab(txt, x, y, col, size = 12) { g.font = `bold ${size}px Vazirmatn, sans-serif`; g.textAlign = "center"; g.lineWidth = 3.5; g.strokeStyle = "rgba(10,10,25,0.85)"; g.strokeText(txt, x, y); g.fillStyle = col; g.fillText(txt, x, y); }
  function drawBand(b, t) {
    const col = RC[rel(b)], mem = b.look;
    if (b.k.beast) { const moving = !(b.st === "patrol" && Math.hypot(b.tx - b.x, b.ty - b.y) < 8); for (let i = 0; i < b.n; i++) { const px = b.x + ((i % 3) - 1) * 24, py = b.y + Math.floor(i / 3) * 16 + (i % 2) * 4; drawBeast(b.k.id, px, py, b.dir, b.ph * 1.4 + i * 1.3, 1, t, moving, 0); } }
    else for (let i = 0; i < b.n; i++) { const m = mem[i], px = b.x + ((i % 3) - 1) * 22 + (Math.floor(i / 3) % 2) * 8, py = b.y + Math.floor(i / 3) * 16; if (gch(b, "m" + i, () => SQ.spec("foe", b.k.big ? "heavy" : b.k.armor ? "shield" : (m.w === "bow" ? "archer" : "sword"), i + 11), px, py, b.k.big ? 66 : 50, b.dir)) continue; drawHuman(g, px, py, { H: b.k.big ? 64 : 46, skin: m.s || b.k.skin, cloth: m.c, armor: b.k.armor, weapon: m.w, dir: b.dir, walk: b.st === "patrol" && Math.hypot(b.tx - b.x, b.ty - b.y) < 8 ? 0 : b.ph + i, beard: i % 2 === 0, pants: "#3a3030", hair: "#1a1210", helm: b.k.armor ? "#7a6a4a" : undefined }); }
    g.fillStyle = col; g.strokeStyle = "#000"; g.lineWidth = 1.5; const by = b.y - (b.k.big ? 82 : 66); g.beginPath(); g.roundRect ? g.roundRect(b.x - 30, by - 11, 60, 18, 8) : g.rect(b.x - 30, by - 11, 60, 18); g.globalAlpha = 0.9; g.fill(); g.globalAlpha = 1; g.stroke(); g.fillStyle = "#101018"; g.font = "bold 11px Vazirmatn, sans-serif"; g.textAlign = "center"; g.fillText(`${b.k.icon} ${fa(b.pow)} • ${RN[rel(b)]}`, b.x, by + 2);
    if (b.st === "flee") lab("💨", b.x, by - 14, "#fff", 14); else if (b.st === "chase") lab("❗", b.x, by - 14, "#ff6a6a", 14);
  }
  function miniDraw() {
    const mw = 180, mh = 120, sx = mw / WW, sy = mh / WH; mini.clearRect(0, 0, mw, mh); mini.drawImage(bg, 0, 0, bg.width, bg.height, 0, 0, mw, mh);
    for (const b of bands) if (b.dead <= 0) { mini.fillStyle = RC[rel(b)]; mini.fillRect(b.x * sx - 1.5, b.y * sy - 1.5, 3, 3); }
    mini.fillStyle = "#ffd24a"; for (const c of castles) mini.fillRect(c.x * sx - 2, c.y * sy - 2, 4, 4); mini.fillStyle = "#ff9a3a"; for (const t of towns) mini.fillRect(t.x * sx - 3, t.y * sy - 3, 6, 6); if (ow.rumorT > 0) { mini.fillStyle = "#5fd8ff"; for (const c of chests) if (!ow.found.includes(c.id)) mini.fillRect(c.x * sx - 1.5, c.y * sy - 1.5, 3, 3); } mini.fillStyle = "#fff"; for (const v of villages) mini.fillRect(v.x * sx - 1.5, v.y * sy - 1.5, 3, 3);
    mini.fillStyle = "#4f86ff"; mini.strokeStyle = "#fff"; mini.beginPath(); mini.arc(P.x * sx, P.y * sy, 3.5, 0, TAU); mini.fill(); mini.stroke(); mini.strokeStyle = "rgba(255,255,255,0.7)"; mini.strokeRect((camX - VWz() / 2) * sx, (camY - VHz() / 2) * sy, VWz() * sx, VHz() * sy);
  }
  function loop(now) { if (ended) return; const dt = Math.min(0.05, (now - last) / 1000); last = now; try { step(dt); draw(now / 1000); } catch (e) { console.error(e); } raf = requestAnimationFrame(loop); }
  window.__owdbg = { walk, goTo, spawnTest: (id) => { const k = KINDS.find((q) => q.id === id), b = bands.find((q) => q.k.beast) || bands[0]; b.k = k; b.x = P.x + 90; b.y = P.y + 20; b.hx = b.x; b.hy = b.y; b.n = 3; b.noFight = 999; return b; }, P, bands, ow, villages, towns, chests, castles, home, setZoom: (z) => setZoom(z), cam: () => ({ camX, camY, zoom }) };
  raf = requestAnimationFrame(loop); msg("🗺️ برای حرکت روی نقشه لمس کن • با دو انگشت زوم کن • 🔍 ردیاب");
}
