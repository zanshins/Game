import { NB_PERKS, NEIGHBORS } from "./data.js";
// درخت مهارت و مزدورها (الهام‌گرفته از منوی مهارت‌های «انسان و فولاد») — بدون وابستگی به save.js
export const SKILLS = [
  { id: "sdmg", br: "نبرد", icon: "⚔️", name: "ضربه‌ی سنگین", desc: "آسیب همه‌ی برج‌ها +۳٪ در هر سطح", max: 5 },
  { id: "srate", br: "نبرد", icon: "🏹", name: "چابکی تیراندازان", desc: "سرعت شلیک +۲٪ در هر سطح", max: 5 },
  { id: "srange", br: "نبرد", icon: "🦅", name: "چشم عقاب", desc: "برد برج‌ها +۲٪ در هر سطح", max: 5 },
  { id: "sgold", br: "اقتصاد", icon: "💰", name: "بازرگان زیرک", desc: "طلای نبرد +۳٪ در هر سطح", max: 5 },
  { id: "sstart", br: "اقتصاد", icon: "📦", name: "تدارکات", desc: "۲۰ طلای آغازین در هر سطح", max: 5 },
  { id: "ssell", br: "اقتصاد", icon: "🏷️", name: "چانه‌زنی", desc: "بازگشت فروش برج +۲٪ در هر سطح", max: 5 },
  { id: "slife", br: "دفاع", icon: "🛡️", name: "دژبانی", desc: "یک جان بیشتر به ازای هر دو سطح", max: 6 },
  { id: "sloot", br: "دفاع", icon: "🏆", name: "غنیمت‌گیر", desc: "سکه‌ی پاداش نبردها +۴٪ در هر سطح", max: 5 },
  { id: "shero", br: "دفاع", icon: "🦸", name: "پهلوان‌پروری", desc: "قدرت قهرمانان +۴٪ در هر سطح", max: 5 },
];
export const skillCost = (lvl) => lvl + 1;
export const sk = (S, id) => (S.skills && S.skills[id]) || 0;
export const spSpent = (S) => SKILLS.reduce((a, s) => { let c = 0; for (let l = 0; l < sk(S, s.id); l++) c += skillCost(l); return a + c; }, 0);
export const spTotal = (S) => Math.max(0, S.level - 1) + Math.floor(S.stars.reduce((a, b) => a + b, 0) / 2) + Math.floor((S.stats?.wins || 0) / 5);
export const spFree = (S) => spTotal(S) - spSpent(S);
export const MERCS = [
  { id: "m1", name: "تیرانداز تورانی", icon: "🏹", desc: "آسیب برج‌ها +۱۵٪", cost: 700, dmg: 0.15 },
  { id: "m2", name: "بازرگانِ کاروان", icon: "💰", desc: "طلای نبرد +۲۰٪", cost: 600, gold: 0.2 },
  { id: "m3", name: "نگهبان سیستانی", icon: "🛡️", desc: "۴ جان اضافه", cost: 800, life: 4 },
  { id: "m4", name: "آهنگر دوره‌گرد", icon: "🔨", desc: "برد برج‌ها +۱۰٪ و ۸۰ طلای آغازین", cost: 900, range: 0.1, start: 80 },
  { id: "m5", name: "پیک تیزپا", icon: "🐎", desc: "سرعت شلیک +۱۲٪", cost: 650, rate: 0.12 },
  { id: "m6", name: "جادوگر نیشابور", icon: "🔮", desc: "آسیب +۲۵٪ (گران‌تر)", cost: 0, gems: 25, dmg: 0.25 },
];
export const HUNTS = [
  { id: "hunt", name: "شکار", icon: "🦌", min: 20, coins: 260, desc: "شکار آهو و گراز در جنگل‌های هیرکانی" },
  { id: "fish", name: "ماهیگیری", icon: "🎣", min: 12, coins: 150, desc: "تور انداختن در دریای خزر" },
  { id: "mine", name: "کاوش گنج", icon: "⛏️", min: 45, coins: 600, gem: 0.5, desc: "جست‌وجوی غارهای کهن؛ شانس الماس" },
  { id: "isl1", name: "جزیره‌ی مرجان", icon: "⛵", min: 40, coins: 700, gem: 0.35, desc: "جزیره‌ی نخل و مروارید در جنوب‌غرب", isl: 0 },
  { id: "isl2", name: "جزیره‌ی بادها", icon: "⛵", min: 60, coins: 1000, gem: 0.6, desc: "تنگه‌ی طوفانی؛ گنج کشتی‌های غرق‌شده", isl: 1 },
  { id: "isl3", name: "جزیره‌ی آتش", icon: "⛵", min: 90, coins: 1500, gem: 0.9, desc: "آتشفشان دریایی؛ سنگ‌های گرانبها", isl: 2 },
  { id: "isl4", name: "جزیره‌ی یخ", icon: "⛵", min: 75, coins: 1250, gem: 0.75, desc: "کوه یخ‌های شمال؛ صید نهنگ و عنبر", isl: 3 },
  { id: "caravan", name: "کاروان تجاری", icon: "🐫", min: 25, coins: 380, desc: "کاروان ابریشم تا بازارهای دوردست" },
  { id: "bandit", name: "سرکوب راهزن", icon: "🗡️", min: 30, coins: 420, gem: 0.2, desc: "غنیمت‌های راهزنان کوهستان" },
];
export function dayMercs(S) { const d = Math.floor(Date.now() / 86400000); const out = []; for (let i = 0; i < 3; i++) out.push(MERCS[(d * 3 + i * 2 + i) % MERCS.length]); return [...new Map(out.map((m) => [m.id, m])).values()]; }
export function cityMods(S) { const o = { dmg: 0, rate: 0, range: 0, gold: 0, start: 0, sell: 0, life: 0, hero: 0 }; for (const n of NEIGHBORS) if (S.conquered[n.id]) { const lv = (S.cityLv && S.cityLv[n.id]) || 1, p = NB_PERKS[n.id]; if (p) for (const k in p.m) o[k] += p.m[k] * lv; } o.life = Math.floor(o.life); return o; }
export function skillMods(S) {
  const cm = cityMods(S), m = S.merc && S.merc.left > 0 ? S.merc.def : {};
  return { dmg: cm.dmg + 0.03 * sk(S, "sdmg") + (m.dmg || 0), rate: cm.rate + 0.02 * sk(S, "srate") + (m.rate || 0), range: cm.range + 0.02 * sk(S, "srange") + (m.range || 0), gold: cm.gold + 0.03 * sk(S, "sgold") + (m.gold || 0), start: cm.start + 20 * sk(S, "sstart") + (m.start || 0), sell: cm.sell + 0.02 * sk(S, "ssell"), life: cm.life + Math.floor(sk(S, "slife") / 2) + (m.life || 0), loot: 0.04 * sk(S, "sloot"), hero: cm.hero + 0.04 * sk(S, "shero") };
}
export const WEEKLY = [
  { id: "kills", name: "نابودی ۳۰۰ دشمن", icon: "💀", stat: "kills", n: 300, r: { coins: 1500 } },
  { id: "wins", name: "۸ پیروزی در نبرد", icon: "🏆", stat: "wins", n: 8, r: { coins: 1200, gems: 8 } },
  { id: "towers", name: "ساخت ۴۰ برج", icon: "🏹", stat: "towers", n: 40, r: { coins: 900 } },
  { id: "attacks", name: "۳ حمله به همسایگان", icon: "⚔️", stat: "attacks", n: 3, r: { coins: 1800, gems: 10 } },
  { id: "evolves", name: "۸ تکامل برج", icon: "✨", stat: "evolves", n: 8, r: { gems: 15 } },
];
export const weekKey = () => Math.floor((Date.now() / 86400000 + 4) / 7);
export const ISLANDS = [[0.06, 0.9, "#59d6c0"], [0.5, 0.94, "#a8c8ff"], [0.94, 0.9, "#ff7a3c"], [0.5, 0.05, "#e8f6ff"]];
