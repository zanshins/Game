// اردوگاه: مهارت‌ها، میخانه (مزدور)، شکار و ماجراجویی — الهام از «انسان و فولاد» و کلش
import { S, save, give, pay, canPay } from "./save.js";
import { fa, faTime } from "./data.js";
import { SKILLS, skillCost, sk, spFree, spTotal, dayMercs, HUNTS, WEEKLY, weekKey } from "./skills.js";

const sub = (ui) => ui.csub || "skills";
const bar = (v, m) => `<div class="bar"><i style="width:${Math.min(100, (v / Math.max(1, m)) * 100)}%"></i></div>`;

export function tabCamp(ui) {
  const s = sub(ui), tabs = [["skills", "🎓", "مهارت‌ها"], ["tavern", "🍺", "میخانه"], ["hunt", "🦌", "شکار و کاوش"], ["weekly", "📅", "هفتگی"]];
  let h = `<div class="row wrap" style="margin-bottom:8px"><div class="title">اردوگاه</div><div class="grow"></div><span class="chip">🎓 امتیاز مهارت: ${fa(spFree(S))}</span></div>
  <div class="sub row" style="gap:6px;margin-bottom:10px">${tabs.map(([k, i, n]) => `<button class="btn s ${s === k ? "" : "d"}" data-act="csub" data-k="${k}">${i} ${n}</button>`).join("")}</div>`;
  if (s === "skills") {
    h += `<div class="xs mut" style="margin-bottom:8px">امتیاز مهارت از بالا رفتن سطح، ستاره‌ها و پیروزی‌ها به دست می‌آید (کل: ${fa(spTotal(S))}).</div>`;
    for (const br of ["نبرد", "اقتصاد", "دفاع"]) {
      h += `<div class="xs gold" style="margin:8px 0 4px">${br === "نبرد" ? "⚔️" : br === "اقتصاد" ? "💰" : "🛡️"} شاخه‌ی ${br}</div>`;
      for (const k of SKILLS.filter((x) => x.br === br)) {
        const l = sk(S, k.id), mx = l >= k.max, c = skillCost(l), ok = !mx && spFree(S) >= c;
        h += `<div class="card row" style="margin-bottom:6px"><div style="font-size:26px">${k.icon}</div><div class="grow"><b>${k.name}</b> <span class="chip">سطح ${fa(l)} از ${fa(k.max)}</span><div class="xs mut">${k.desc}</div>${bar(l, k.max)}</div>${mx ? `<span class="chip">کامل ✅</span>` : `<button class="btn s g ${ok ? "" : "off"}" data-act="skillup" data-k="${k.id}">🎓 ${fa(c)}</button>`}</div>`;
      }
    }
    h += `<button class="btn s d" style="margin-top:8px" data-act="skillreset">♻️ بازنشانی مهارت‌ها (۱۰۰۰ 🪙)</button>`;
  } else if (s === "tavern") {
    const cur = S.merc && S.merc.left > 0 ? S.merc : null;
    h += `<div class="xs mut" style="margin-bottom:8px">هر روز سه مزدور تازه به میخانه می‌آیند. مزدور استخدام‌شده در ۳ نبرد بعدی همراهت می‌جنگد (بازی‌ات را تقویت می‌کند).</div>`;
    if (cur) h += `<div class="banner row" style="margin-bottom:8px"><div style="font-size:30px">${cur.def.icon}</div><div class="grow"><b>${cur.def.name}</b> همراه توست<div class="xs">${cur.def.desc} — ${fa(cur.left)} نبرد باقی‌مانده</div></div></div>`;
    for (const m of dayMercs(S)) {
      const pr = m.gems ? { gems: m.gems } : { coins: m.cost };
      h += `<div class="card row" style="margin-bottom:6px"><div style="font-size:28px">${m.icon}</div><div class="grow"><b>${m.name}</b><div class="xs mut">${m.desc}</div></div><button class="btn s g ${canPay(pr) ? "" : "off"}" data-act="hire" data-k="${m.id}">${m.gems ? "💎 " + fa(m.gems) : "🪙 " + fa(m.cost)}</button></div>`;
    }
  } else if (s === "weekly") {
    const w = weekly(); const fri = new Date().getDay() === 5;
    h += `<div class="xs mut" style="margin-bottom:8px">ماموریت‌های هفتگی هر هفته نو می‌شوند. ${fri ? "<b class='gold'>🎉 رویداد جمعه: غنیمت شکار و کاوش دو برابر!</b>" : "جمعه‌ها رویداد دوبرابر غنیمت دارد."}</div>`;
    for (const q of WEEKLY) { const v = Math.min(q.n, (S.stats[q.stat] || 0) - (w.base[q.stat] || 0)), done = v >= q.n, cl = w.claimed.includes(q.id);
      h += `<div class="card row" style="margin-bottom:6px"><div style="font-size:26px">${q.icon}</div><div class="grow"><b>${q.name}</b> <span class="chip">${fa(v)} / ${fa(q.n)}</span>${bar(v, q.n)}<div class="xs gold">${q.r.coins ? "🪙 " + fa(q.r.coins) : ""} ${q.r.gems ? "💎 " + fa(q.r.gems) : ""}</div></div>${cl ? `<span class="chip">گرفته شد ✅</span>` : `<button class="btn s g ${done ? "" : "off"}" data-act="weeklyclaim" data-k="${q.id}">🎁</button>`}</div>`; }
  } else {
    const hn = S.hunt, now = Date.now();
    h += `<div class="xs mut" style="margin-bottom:8px">سپاهیان را به ماجراجویی بفرست؛ حتی وقتی بازی بسته است کار می‌کنند. ثروتِ بازگشتی با سطحت بیشتر می‌شود. فقط یک ماموریت هم‌زمان.</div>`;
    if (hn) {
      const d = HUNTS.find((x) => x.id === hn.id), left = Math.max(0, hn.end - now), done = left <= 0;
      h += `<div class="banner row" style="margin-bottom:8px"><div style="font-size:30px">${d.icon}</div><div class="grow"><b>${d.name} در جریان</b><div class="xs">${done ? "آماده‌ی دریافت غنیمت!" : "زمان باقی‌مانده: " + faTime(left / 1000)}</div>${bar(d.min * 60000 - left, d.min * 60000)}</div>${done ? `<button class="btn s g" data-act="huntclaim">🎁 دریافت</button>` : ""}</div>`;
    }
    for (const d of HUNTS) h += `<div class="card row" style="margin-bottom:6px"><div style="font-size:28px">${d.icon}</div><div class="grow"><b>${d.name}</b> <span class="chip">⏱️ ${fa(d.min)} دقیقه</span><div class="xs mut">${d.desc}</div><div class="xs gold">≈ 🪙 ${fa(huntCoins(d))}${d.gem ? " • شانس 💎" : ""}</div></div><button class="btn s ${hn ? "off" : "g"}" data-act="huntgo" data-k="${d.id}">▶ برو</button></div>`;
  }
  return h;
}
const huntCoins = (d) => Math.round(d.coins * (1 + S.level * 0.08) * (new Date().getDay() === 5 ? 2 : 1));
function weekly() { const k = weekKey(); if (!S.weekly || S.weekly.wk !== k) S.weekly = { wk: k, base: { ...S.stats }, claimed: [] }; return S.weekly; }

export const META_ACTS = (ctx) => ({
  weeklyclaim(d) { const w = weekly(), q = WEEKLY.find((x) => x.id === d.k); if (!q || w.claimed.includes(q.id) || (S.stats[q.stat] || 0) - (w.base[q.stat] || 0) < q.n) return; w.claimed.push(q.id); give(q.r); save(); ctx.toast(`🎁 ${q.name} — پاداش گرفته شد`); ctx.refresh(); },
  csub(d) { ctx.ui.csub = d.k; ctx.refresh(); },
  skillup(d) { const k = SKILLS.find((x) => x.id === d.k), l = sk(S, d.k), c = skillCost(l); if (!k || l >= k.max) return; if (spFree(S) < c) { ctx.toast("امتیاز مهارت کافی نیست — با پیروزی و ستاره بیشتر می‌شود"); return; } (S.skills = S.skills || {})[d.k] = l + 1; save(); ctx.toast(`${k.icon} ${k.name} ← سطح ${fa(l + 1)}`); ctx.refresh(); },
  skillreset() { if (!S.skills || !Object.keys(S.skills).length) return; if (!pay({ coins: 1000 })) { ctx.toast("۱۰۰۰ سکه لازم است"); return; } S.skills = {}; save(); ctx.toast("مهارت‌ها بازنشانی شد"); ctx.refresh(); },
  hire(d) { const m = dayMercs(S).find((x) => x.id === d.k); if (!m) return; const pr = m.gems ? { gems: m.gems } : { coins: m.cost }; if (!pay(pr)) { ctx.toast("منابع کافی نیست"); return; } S.merc = { def: m, left: 3 }; save(); ctx.toast(`${m.icon} ${m.name} استخدام شد`); ctx.refresh(); },
  huntgo(d) { if (S.hunt) { ctx.toast("یک ماموریت در جریان است"); return; } const h = HUNTS.find((x) => x.id === d.k); S.hunt = { id: h.id, end: Date.now() + h.min * 60000 }; save(); ctx.toast(`${h.icon} ${h.name} آغاز شد`); ctx.refresh(); },
  huntclaim() { const hn = S.hunt; if (!hn || hn.end > Date.now()) return; const h = HUNTS.find((x) => x.id === hn.id), c = huntCoins(h); let gem = 0; if (h.gem && Math.random() < h.gem) gem = 3 + Math.floor(Math.random() * 6); give({ coins: c, gems: gem }); S.hunt = null; save(); ctx.toast(`🎁 +${fa(c)} 🪙${gem ? " و +" + fa(gem) + " 💎" : ""}`); ctx.refresh(); },
});
