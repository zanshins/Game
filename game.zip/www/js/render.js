// رندر نبرد روی canvas: زمین، برج‌ها، دشمنان، قهرمانان، افکت‌ها
import { COLS, ROWS, TOWERS, TROOPS, rng } from "./data.js";

const TAU = Math.PI * 2, FONT = "Vazirmatn, sans-serif", EMO = "'Noto Color Emoji','Apple Color Emoji','Segoe UI Emoji',sans-serif";
const mix = (a, b, t) => { const p = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)); const A = p(a), B = p(b); return "#" + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, "0")).join(""); };
const lighten = (c, t) => mix(c, "#ffffff", t), darken = (c, t) => mix(c, "#000000", t);

export class Renderer {
  constructor(cv) { this.cv = cv; this.ctx = cv.getContext("2d"); this.w = 0; this.h = 0; this.cs = 40; this.ox = 0; this.oy = 0; this.dpr = 1; this.terrain = null; this.b = null; this.wx = []; this.t = 0; this.flash = 0; this.lastLives = null; }
  resize(w, h) {
    this.dpr = Math.min(2, window.devicePixelRatio || 1); this.w = w; this.h = h; this.cv.width = Math.round(w * this.dpr); this.cv.height = Math.round(h * this.dpr); this.cv.style.width = w + "px"; this.cv.style.height = h + "px";
    const top = 46; this.cs = Math.floor(Math.min(w / COLS, (h - top) / ROWS)); this.ox = Math.floor((w - this.cs * COLS) / 2); this.oy = top + Math.floor((h - top - this.cs * ROWS) / 2); if (this.b) this.buildTerrain();
  }
  setBattle(b) { this.b = b; this.initWeather(); if (this.w) this.buildTerrain(); this.lastLives = b.lives; }
  toCell(px, py) { const r = this.cv.getBoundingClientRect(); const x = (px - r.left - this.ox) / this.cs, y = (py - r.top - this.oy) / this.cs; return { fx: x, fy: y, x: Math.floor(x), y: Math.floor(y) }; }

  // ---------- زمین ----------
  buildTerrain() {
    const b = this.b, m = b.map, cs = this.cs, ox = this.ox, oy = this.oy, W = this.w, H = this.h, c = document.createElement("canvas"); c.width = Math.round(W * this.dpr); c.height = Math.round(H * this.dpr);
    const g = c.getContext("2d"); g.scale(this.dpr, this.dpr); const r = rng(m.seed * 13 + 5);
    const grad = g.createLinearGradient(0, 0, 0, H); grad.addColorStop(0, m.col.g1); grad.addColorStop(1, darken(m.col.g2, 0.15)); g.fillStyle = grad; g.fillRect(0, 0, W, H);
    for (let y = -1; y <= ROWS; y++) for (let x = -1; x <= COLS; x++) { const px = ox + x * cs, py = oy + y * cs; g.fillStyle = (x + y) % 2 ? m.col.g1 : m.col.g2; g.fillRect(px, py, cs + 1, cs + 1); g.fillStyle = "rgba(255,255,255,0.035)"; g.fillRect(px + 1, py + 1, cs - 2, 2); g.fillStyle = "rgba(0,0,0,0.05)"; g.fillRect(px + 1, py + cs - 3, cs - 2, 2); }
    this.terrainExtras(g, m, r);
    // مسیر
    const ext = 4;
    for (const pass of [0, 1, 2]) for (const p of b.rt.paths) {
      const pts = p.pts.map((q) => ({ x: ox + q.x * cs, y: oy + q.y * cs })), a = pts[0], a2 = pts[1], z = pts[pts.length - 1], z2 = pts[pts.length - 2];
      const ua = Math.hypot(a.x - a2.x, a.y - a2.y) || 1, uz = Math.hypot(z.x - z2.x, z.y - z2.y) || 1;
      const ps = [{ x: a.x + (a.x - a2.x) / ua * cs * ext, y: a.y + (a.y - a2.y) / ua * cs * ext }, ...pts, { x: z.x + (z.x - z2.x) / uz * cs * ext, y: z.y + (z.y - z2.y) / uz * cs * ext }];
      g.lineJoin = "round"; g.lineCap = "butt"; g.beginPath(); ps.forEach((q, i) => (i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)));
      if (pass === 0) { g.strokeStyle = "rgba(0,0,0,0.25)"; g.lineWidth = cs * 1.08; g.save(); g.translate(0, cs * 0.06); g.stroke(); g.restore(); g.strokeStyle = m.col.edge; g.lineWidth = cs * 1.0; g.stroke(); }
      else if (pass === 1) { g.strokeStyle = m.col.path; g.lineWidth = cs * 0.84; g.stroke(); }
      else { g.strokeStyle = lighten(m.col.path, 0.18); g.globalAlpha = 0.35; g.lineWidth = cs * 0.5; g.setLineDash([cs * 0.35, cs * 0.5]); g.stroke(); g.setLineDash([]); g.globalAlpha = 1; }
    }
    for (const k of b.rt.cells) { const [cx, cy] = k.split(",").map(Number); for (let i = 0; i < 3; i++) { g.fillStyle = r() < 0.5 ? darken(m.col.path, 0.14) : lighten(m.col.path, 0.14); g.beginPath(); g.ellipse(ox + (cx + 0.15 + r() * 0.7) * cs, oy + (cy + 0.15 + r() * 0.7) * cs, cs * (0.02 + r() * 0.04), cs * 0.025, 0, 0, TAU); g.fill(); } }
    // دکور
    const items = b.rt.deco.slice().sort((p, q) => p.y - q.y);
    for (const d of items) this.drawDeco(g, d, m);
    this.terrain = c;
  }
  terrainExtras(g, m, r) {
    const cs = this.cs, W = this.w, H = this.h, n = 30;
    for (let i = 0; i < n; i++) {
      const x = r() * W, y = r() * H, s = cs * (0.4 + r() * 0.9);
      if (m.id === "volcano") { g.strokeStyle = "rgba(255,120,40,0.35)"; g.lineWidth = 2; g.beginPath(); g.moveTo(x, y); g.lineTo(x + s * 0.5, y + s * 0.2); g.lineTo(x + s * 0.8, y - s * 0.1); g.stroke(); }
      else if (m.id === "ice") { g.strokeStyle = "rgba(255,255,255,0.45)"; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x, y); g.lineTo(x + s * 0.6, y - s * 0.25); g.stroke(); }
      else if (m.id === "desert") { g.strokeStyle = "rgba(120,70,20,0.18)"; g.lineWidth = 2; g.beginPath(); g.arc(x, y, s * 0.6, 3.4, 5.9); g.stroke(); }
      else if (m.id === "void") { g.fillStyle = `rgba(255,255,255,${0.3 + r() * 0.5})`; g.beginPath(); g.arc(x, y, 1 + r() * 1.5, 0, TAU); g.fill(); if (i % 6 === 0) { const gr = g.createRadialGradient(x, y, 0, x, y, s * 2); gr.addColorStop(0, "rgba(140,60,200,0.18)"); gr.addColorStop(1, "rgba(140,60,200,0)"); g.fillStyle = gr; g.fillRect(x - s * 2, y - s * 2, s * 4, s * 4); } }
      else if (m.id === "swamp") { g.fillStyle = "rgba(20,40,10,0.28)"; g.beginPath(); g.ellipse(x, y, s * 0.7, s * 0.3, 0, 0, TAU); g.fill(); g.fillStyle = "rgba(160,220,80,0.12)"; g.beginPath(); g.ellipse(x - 2, y - 2, s * 0.5, s * 0.18, 0, 0, TAU); g.fill(); }
      else if (m.id === "sky") { g.fillStyle = "rgba(255,255,255,0.22)"; g.beginPath(); g.ellipse(x, y, s * 0.9, s * 0.35, 0, 0, TAU); g.fill(); }
      else if (m.id === "forest") { g.fillStyle = "rgba(10,40,25,0.3)"; g.beginPath(); g.ellipse(x, y, s * 0.8, s * 0.35, 0, 0, TAU); g.fill(); }
      else { g.fillStyle = r() < 0.5 ? "rgba(255,255,255,0.5)" : "rgba(255,210,120,0.55)"; g.beginPath(); g.arc(x, y, 2, 0, TAU); g.fill(); g.fillStyle = "#3a8a3a"; g.fillRect(x - 0.5, y, 1, 4); }
    }
  }
  drawDeco(g, d, m) {
    const cs = this.cs, cx = this.ox + (d.x + 0.5) * cs, cy = this.oy + (d.y + 0.5) * cs, s = d.s, k = d.kind;
    if (k === "tuft") { g.strokeStyle = m.id === "desert" ? "#b9852f" : m.id === "ice" ? "#e8f8ff" : m.id === "volcano" ? "#8a4a32" : m.id === "void" ? "#7a4ac0" : "#3d8a44"; g.lineWidth = 1.5; const x = cx + (d.ox - 0.5) * cs * 0.7, y = cy + (d.oy - 0.5) * cs * 0.7; for (let i = -1; i <= 1; i++) { g.beginPath(); g.moveTo(x + i * 3, y + 4); g.quadraticCurveTo(x + i * 4, y - 3, x + i * 6, y - 5 * s - 2); g.stroke(); } if (d.v > 0.7 && m.id === "meadow") { g.fillStyle = ["#ff7aa8", "#fff3a0", "#ffffff"][Math.floor(d.v * 30) % 3]; g.beginPath(); g.arc(x + 4, y - 5, 2.2, 0, TAU); g.fill(); } return; }
    g.fillStyle = "rgba(0,0,0,0.28)"; g.beginPath(); g.ellipse(cx, cy + cs * 0.3, cs * 0.34 * s, cs * 0.12 * s, 0, 0, TAU); g.fill();
    g.save(); g.translate(cx, cy + cs * 0.22); g.scale(cs / 50 * s, cs / 50 * s);
    if (k === "tree") { g.fillStyle = "#6b4426"; g.fillRect(-4, -14, 8, 18); for (const [x, y, rr, c] of [[0, -22, 17, "#2f7d3a"], [-9, -14, 12, "#3c9448"], [9, -14, 12, "#3c9448"], [0, -30, 11, "#52b05a"]]) { g.fillStyle = c; g.beginPath(); g.arc(x, y, rr, 0, TAU); g.fill(); } g.fillStyle = "rgba(255,255,255,0.13)"; g.beginPath(); g.arc(-4, -32, 6, 0, TAU); g.fill(); }
    else if (k === "mushroom" || k === "mushroom2") { const c = k === "mushroom" ? "#7cf0c8" : "#b6ff5c", c2 = k === "mushroom" ? "#4a2d8e" : "#6a4a1a"; g.fillStyle = "#e8e2c8"; g.fillRect(-4, -12, 8, 14); g.fillStyle = c2; g.beginPath(); g.ellipse(0, -14, 20, 15, 0, Math.PI, 0); g.fill(); g.fillStyle = c; for (const [x, y] of [[-8, -20], [6, -22], [0, -15]]) { g.beginPath(); g.arc(x, y, 3.2, 0, TAU); g.fill(); } g.globalAlpha = 0.25; g.fillStyle = c; g.beginPath(); g.arc(0, -14, 30, 0, TAU); g.fill(); g.globalAlpha = 1; }
    else if (k === "cactus") { g.fillStyle = "#3f8f4a"; g.beginPath(); g.roundRect(-6, -34, 12, 38, 6); g.fill(); g.beginPath(); g.roundRect(-18, -24, 10, 7, 3); g.fill(); g.beginPath(); g.roundRect(-18, -30, 6, 12, 3); g.fill(); g.beginPath(); g.roundRect(8, -18, 11, 7, 3); g.fill(); g.beginPath(); g.roundRect(13, -26, 6, 14, 3); g.fill(); g.fillStyle = "#ff7aa8"; g.beginPath(); g.arc(0, -36, 3, 0, TAU); g.fill(); }
    else if (k === "crystal") { for (const [x, h, c] of [[-10, 24, "#bfeaff"], [0, 34, "#e6f8ff"], [10, 20, "#9fd8ff"]]) { g.fillStyle = c; g.beginPath(); g.moveTo(x - 6, 2); g.lineTo(x, -h); g.lineTo(x + 6, 2); g.closePath(); g.fill(); g.fillStyle = "rgba(255,255,255,0.6)"; g.beginPath(); g.moveTo(x - 1, 0); g.lineTo(x, -h); g.lineTo(x - 5, 0); g.closePath(); g.fill(); } }
    else if (k === "lavarock") { g.fillStyle = "#2a1613"; g.beginPath(); g.moveTo(-16, 2); g.lineTo(-10, -18); g.lineTo(2, -24); g.lineTo(14, -14); g.lineTo(18, 2); g.closePath(); g.fill(); g.strokeStyle = "#ff7a2e"; g.lineWidth = 2; g.beginPath(); g.moveTo(-6, -14); g.lineTo(0, -6); g.lineTo(-3, 0); g.moveTo(6, -16); g.lineTo(8, -6); g.stroke(); }
    else if (k === "cloud") { g.fillStyle = "rgba(255,255,255,0.95)"; for (const [x, y, rr] of [[-12, -14, 11], [0, -20, 14], [12, -14, 11], [0, -10, 12]]) { g.beginPath(); g.arc(x, y, rr, 0, TAU); g.fill(); } g.fillStyle = "rgba(180,200,240,0.5)"; g.beginPath(); g.ellipse(0, -5, 22, 5, 0, 0, TAU); g.fill(); }
    else if (k === "voidshard") { g.shadowColor = "#d68cff"; g.shadowBlur = 14; g.fillStyle = "#7a3ac0"; g.beginPath(); g.moveTo(0, -36); g.lineTo(10, -18); g.lineTo(5, 0); g.lineTo(-7, -4); g.lineTo(-10, -20); g.closePath(); g.fill(); g.shadowBlur = 0; g.fillStyle = "#d68cff"; g.beginPath(); g.moveTo(0, -36); g.lineTo(3, -18); g.lineTo(-2, -4); g.lineTo(-4, -20); g.closePath(); g.fill(); }
    g.restore();
  }

  // ---------- طبیعت متحرک ----------
  initWeather() {
    const k = this.b.map.weather, n = k === "clouds" ? 7 : k === "sand" ? 40 : 55; this.wx = []; const r = rng(7);
    for (let i = 0; i < n; i++) this.wx.push({ x: r(), y: r(), s: 0.4 + r() * 0.8, p: r() * 6.28, z: r() });
  }
  drawWeather(ctx, dt) {
    const k = this.b.map.weather, W = this.w, H = this.h, t = this.t; ctx.save();
    for (const p of this.wx) {
      if (k === "snow") { p.y += dt * 0.09 * p.s; p.x += Math.sin(t + p.p) * dt * 0.02; ctx.globalAlpha = 0.85; ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(p.x * W, p.y * H, 1.2 + p.z * 2, 0, TAU); ctx.fill(); }
      else if (k === "petals") { p.y += dt * 0.05 * p.s; p.x += dt * 0.03 + Math.sin(t * 1.5 + p.p) * dt * 0.02; ctx.globalAlpha = 0.8; ctx.fillStyle = p.z > 0.5 ? "#ffc2d6" : "#fff"; ctx.save(); ctx.translate(p.x * W, p.y * H); ctx.rotate(t + p.p); ctx.beginPath(); ctx.ellipse(0, 0, 4, 2, 0, 0, TAU); ctx.fill(); ctx.restore(); }
      else if (k === "fireflies") { p.x += Math.sin(t * 0.7 + p.p) * dt * 0.03; p.y += Math.cos(t * 0.5 + p.p * 2) * dt * 0.02; ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = 0.35 + 0.65 * Math.abs(Math.sin(t * 1.3 + p.p)); ctx.fillStyle = "#c8ff7a"; ctx.beginPath(); ctx.arc(p.x * W, p.y * H, 2 + p.z * 2, 0, TAU); ctx.fill(); ctx.globalAlpha *= 0.3; ctx.beginPath(); ctx.arc(p.x * W, p.y * H, 8, 0, TAU); ctx.fill(); ctx.globalCompositeOperation = "source-over"; }
      else if (k === "sand") { p.x += dt * 0.35 * p.s; p.y += Math.sin(t + p.p) * dt * 0.01; ctx.globalAlpha = 0.35; ctx.strokeStyle = "#f4d79a"; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(p.x * W, p.y * H); ctx.lineTo(p.x * W - 16 * p.s, p.y * H - 1); ctx.stroke(); }
      else if (k === "spores") { p.y -= dt * 0.04 * p.s; p.x += Math.sin(t + p.p) * dt * 0.015; ctx.globalAlpha = 0.5; ctx.strokeStyle = "#c8ff6a"; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(p.x * W, p.y * H, 2 + p.z * 4, 0, TAU); ctx.stroke(); }
      else if (k === "embers") { p.y -= dt * 0.12 * p.s; p.x += Math.sin(t * 2 + p.p) * dt * 0.02; ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = 0.9; ctx.fillStyle = p.z > 0.5 ? "#ff9d2f" : "#ff5a2e"; ctx.beginPath(); ctx.arc(p.x * W, p.y * H, 1.5 + p.z * 1.5, 0, TAU); ctx.fill(); ctx.globalCompositeOperation = "source-over"; }
      else if (k === "clouds") { p.x += dt * 0.012 * p.s; ctx.globalAlpha = 0.14; ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.ellipse(p.x * W, p.y * H, 90 + p.z * 70, 26 + p.z * 14, 0, 0, TAU); ctx.fill(); }
      else if (k === "stars") { ctx.globalAlpha = 0.3 + 0.7 * Math.abs(Math.sin(t * (0.8 + p.z) + p.p)); ctx.fillStyle = "#e8d8ff"; ctx.fillRect(p.x * W, p.y * H, 1.8, 1.8); p.x += dt * 0.004 * p.s; }
      if (p.x > 1.05) p.x = -0.05; if (p.x < -0.1) p.x = 1.05; if (p.y > 1.05) p.y = -0.05; if (p.y < -0.1) p.y = 1.05;
    }
    ctx.restore();
  }

  // ---------- اصلی ----------
  draw(dt, ui) {
    const b = this.b; if (!b || !this.terrain) return; this.t += dt; const ctx = this.ctx, cs = this.cs;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0); ctx.clearRect(0, 0, this.w, this.h);
    let sx = 0, sy = 0; if (b.shake > 0) { const m = Math.min(1, b.shake) * cs * 0.18; sx = (Math.random() - 0.5) * m; sy = (Math.random() - 0.5) * m; }
    ctx.save(); ctx.translate(sx, sy); ctx.drawImage(this.terrain, 0, 0, this.w, this.h);
    ctx.translate(this.ox, this.oy);
    this.drawPortals(ctx, b); this.drawZones(ctx, b); this.drawGrid(ctx, b, ui);
    const list = []; for (const t of b.towers) list.push({ y: t.cy, f: () => this.drawTower(ctx, t, b) }); for (const h of b.heroes) if (h.deployed) list.push({ y: h.y + 0.01, f: () => this.drawHero(ctx, h, ui) });
    for (const e of b.enemies) if (!e.dead && !e.flying) list.push({ y: e.y, f: () => this.drawEnemy(ctx, e) });
    list.sort((p, q) => p.y - q.y); for (const it of list) it.f();
    this.drawGate(ctx, b);
    for (const e of b.enemies) if (!e.dead && e.flying) { this.shadow(ctx, e.x * cs, (e.y + 0.25) * cs, e.def.r * cs); } for (const e of b.enemies) if (!e.dead && e.flying) this.drawEnemy(ctx, e);
    this.drawProj(ctx, b); this.drawFx(ctx, b); this.drawRange(ctx, b, ui);
    ctx.restore(); this.drawWeather(ctx, dt);
    // قاب نور
    const g = ctx.createRadialGradient(this.w / 2, this.h / 2, Math.min(this.w, this.h) * 0.4, this.w / 2, this.h / 2, Math.max(this.w, this.h) * 0.75); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, "rgba(0,0,0,0.35)"); ctx.fillStyle = g; ctx.fillRect(0, 0, this.w, this.h);
    if (this.lastLives !== null && b.lives < this.lastLives) this.flash = 0.45; this.lastLives = b.lives; if (this.flash > 0) { ctx.fillStyle = `rgba(255,40,40,${this.flash * 0.5})`; ctx.fillRect(0, 0, this.w, this.h); this.flash -= dt; }
    if (b.buffT > 0) { ctx.strokeStyle = `rgba(255,90,90,${0.4 + 0.2 * Math.sin(this.t * 6)})`; ctx.lineWidth = 6; ctx.strokeRect(3, 3, this.w - 6, this.h - 6); }
  }
  shadow(ctx, x, y, r) { ctx.fillStyle = "rgba(0,0,0,0.3)"; ctx.beginPath(); ctx.ellipse(x, y, r * 1.1, r * 0.45, 0, 0, TAU); ctx.fill(); }
  drawPortals(ctx, b) {
    const cs = this.cs, t = this.t;
    for (let i = 0; i < b.rt.paths.length; i++) {
      const p = b.rt.paths[i].pts[0], x = Math.max(0.3, Math.min(COLS - 0.3, p.x)) * cs, y = p.y * cs; if (b.mode === "attack") { /* مبدأ حمله */ }
      ctx.save(); ctx.translate(x, y); ctx.globalCompositeOperation = "lighter";
      for (let k = 0; k < 3; k++) { ctx.strokeStyle = b.mode === "attack" ? "rgba(120,200,255,0.5)" : "rgba(255,90,110,0.55)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, 0, cs * (0.2 + k * 0.12) * (1 + 0.1 * Math.sin(t * 3 + k)), cs * (0.38 + k * 0.1), t * (k % 2 ? 1 : -1) * 0.8, 0, TAU); ctx.stroke(); }
      ctx.restore();
    }
  }
  drawGate(ctx, b) {
    if (b.mode !== "attack") return; const cs = this.cs, p = b.rt.paths[0].pts[b.rt.paths[0].pts.length - 1], x = (COLS - 0.7) * cs, y = p.y * cs, nb = b.nb;
    ctx.save(); ctx.translate(x, y); const w = cs * 0.9, h = cs * 1.3;
    for (const s of [-1, 1]) { ctx.fillStyle = "#6a6a78"; ctx.fillRect(s * w * 0.55 - w * 0.22, -h * 0.65, w * 0.44, h * 1.1); ctx.fillStyle = "#8a8a98"; ctx.fillRect(s * w * 0.55 - w * 0.22, -h * 0.65, w * 0.44, h * 0.12); for (let i = -1; i <= 1; i++) { ctx.fillStyle = "#8a8a98"; ctx.fillRect(s * w * 0.55 - w * 0.22 + (i + 1) * w * 0.16, -h * 0.75, w * 0.1, h * 0.12); } }
    ctx.fillStyle = "#5c3a1e"; ctx.beginPath(); ctx.roundRect(-w * 0.33, -h * 0.35, w * 0.66, h * 0.8, [w * 0.33, w * 0.33, 0, 0]); ctx.fill(); ctx.strokeStyle = "#2a1a0c"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0, -h * 0.5); ctx.lineTo(0, h * 0.45); ctx.stroke();
    ctx.fillStyle = nb.color; ctx.beginPath(); ctx.moveTo(-3, -h * 0.65); ctx.lineTo(-3, -h * 1.05); ctx.lineTo(w * 0.35, -h * 0.9 + Math.sin(this.t * 4) * 2); ctx.lineTo(-3, -h * 0.78); ctx.fill();
    const f = b.gate / b.gateMax; ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.fillRect(-w * 0.7, h * 0.55, w * 1.4, 7); ctx.fillStyle = f > 0.5 ? "#ffb347" : "#ff5a4a"; ctx.fillRect(-w * 0.7 + 1, h * 0.55 + 1, (w * 1.4 - 2) * f, 5); ctx.restore();
  }
  drawZones(ctx, b) { const cs = this.cs; for (const z of b.zones) { ctx.save(); ctx.globalAlpha = Math.min(0.5, z.t / z.max); const g = ctx.createRadialGradient(z.x * cs, z.y * cs, 0, z.x * cs, z.y * cs, z.r * cs); g.addColorStop(0, "rgba(255,140,50,0.8)"); g.addColorStop(1, "rgba(255,60,20,0)"); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(z.x * cs, z.y * cs, z.r * cs, 0, TAU); ctx.fill(); ctx.restore(); } }
  drawGrid(ctx, b, ui) {
    const cs = this.cs, t = this.t; if (!ui) return;
    if (ui.buildKind) { ctx.save(); ctx.globalAlpha = 0.18 + 0.1 * Math.sin(t * 4); ctx.fillStyle = "#fff"; for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) if (b.canBuild(x, y)) { ctx.beginPath(); ctx.roundRect(x * cs + 3, y * cs + 3, cs - 6, cs - 6, 6); ctx.fill(); } ctx.restore(); }
    if (ui.hover && ui.buildKind) { const { x, y } = ui.hover; if (x >= 0 && y >= 0 && x < COLS && y < ROWS) { const ok = b.canBuild(x, y); ctx.strokeStyle = ok ? "#7bff9a" : "#ff6a6a"; ctx.lineWidth = 3; ctx.beginPath(); ctx.roundRect(x * cs + 2, y * cs + 2, cs - 4, cs - 4, 8); ctx.stroke(); if (ok) { const d = TOWERS[ui.buildKind]; ctx.globalAlpha = 0.5; ctx.strokeStyle = d.color; ctx.setLineDash([6, 6]); ctx.beginPath(); ctx.arc((x + 0.5) * cs, (y + 0.5) * cs, d.range * b.mods.range * cs, 0, TAU); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1; } } }
  }
  drawRange(ctx, b, ui) {
    if (!ui || !ui.selTower || !b.towers.includes(ui.selTower)) return; const t = ui.selTower, s = b.stats(t), cs = this.cs;
    ctx.save(); ctx.strokeStyle = "rgba(255,255,255,0.8)"; ctx.fillStyle = "rgba(255,255,255,0.09)"; ctx.lineWidth = 2; ctx.setLineDash([8, 6]); ctx.lineDashOffset = -this.t * 20; ctx.beginPath(); ctx.arc(t.cx * cs, t.cy * cs, s.range * cs, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
    ctx.strokeStyle = "#ffe58a"; ctx.lineWidth = 3; ctx.beginPath(); ctx.roundRect(t.x * cs + 2, t.y * cs + 2, cs - 4, cs - 4, 8); ctx.stroke();
  }

  // ---------- برج ----------
  drawTower(ctx, t, b) {
    const cs = this.cs, d = TOWERS[t.kind], ev = t.evo ? d.evo[t.evo] : null, col = ev ? ev.color : d.color, x = t.cx * cs, y = t.cy * cs, tm = this.t; ctx.save(); ctx.translate(x, y); const u = cs / 50;
    if (t.hitT > 0) ctx.globalAlpha = 0.6 + 0.4 * Math.sin(tm * 60);
    const pop = Math.min(1, (b.time - t.born) / 0.25); ctx.scale(0.6 + 0.4 * pop + (1 - pop) * 0.2, 0.6 + 0.4 * pop + (1 - pop) * 0.2); ctx.scale(u, u);
    // پایه
    ctx.fillStyle = "rgba(0,0,0,0.3)"; ctx.beginPath(); ctx.ellipse(0, 14, 25, 9, 0, 0, TAU); ctx.fill();
    const rim = t.lvl === 1 ? "#9a9aa6" : t.lvl === 2 ? "#d0d6e4" : "#ffd24a"; ctx.fillStyle = "#4b4b58"; ctx.beginPath(); for (let i = 0; i < 8; i++) { const a = i * TAU / 8 + TAU / 16; ctx.lineTo(Math.cos(a) * 22, Math.sin(a) * 15 + 6); } ctx.closePath(); ctx.fill(); ctx.strokeStyle = rim; ctx.lineWidth = 3; ctx.stroke(); ctx.fillStyle = "#6b6b7c"; ctx.beginPath(); for (let i = 0; i < 8; i++) { const a = i * TAU / 8 + TAU / 16; ctx.lineTo(Math.cos(a) * 17, Math.sin(a) * 11 + 4); } ctx.closePath(); ctx.fill();
    if (ev) { ctx.globalCompositeOperation = "lighter"; const gl = ctx.createRadialGradient(0, -4, 4, 0, -4, 38); gl.addColorStop(0, col + "99"); gl.addColorStop(1, col + "00"); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(0, -4, 38, 0, TAU); ctx.fill(); for (let i = 0; i < 3; i++) { const a = tm * 1.6 + i * TAU / 3; ctx.fillStyle = col; ctx.beginPath(); ctx.arc(Math.cos(a) * 28, Math.sin(a) * 11 - 4, 2.6, 0, TAU); ctx.fill(); } ctx.globalCompositeOperation = "source-over"; }
    const rc = t.recoil, ang = t.ang;
    switch (t.kind) {
      case "bow": { ctx.save(); ctx.translate(0, -6); ctx.rotate(ang); ctx.translate(-rc * 4, 0); ctx.fillStyle = "#7a5230"; ctx.fillRect(-10, -3, 26, 6); ctx.strokeStyle = ev ? col : "#d7a35a"; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(8, 0, 16, -1.25, 1.25); ctx.stroke(); ctx.strokeStyle = "#fff"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(8 + Math.cos(-1.25) * 16, Math.sin(-1.25) * 16); ctx.lineTo(0 - rc * 2, 0); ctx.lineTo(8 + Math.cos(1.25) * 16, Math.sin(1.25) * 16); ctx.stroke(); if (rc < 0.4) { ctx.fillStyle = col; ctx.fillRect(0, -1, 22, 2); ctx.beginPath(); ctx.moveTo(22, -3); ctx.lineTo(28, 0); ctx.lineTo(22, 3); ctx.fill(); } if (ev && t.evo === "a") { ctx.fillStyle = col; ctx.fillRect(2, -7, 18, 2); ctx.fillRect(2, 5, 18, 2); } ctx.restore(); ctx.fillStyle = "#7a5230"; ctx.beginPath(); ctx.arc(0, -4, 7, 0, TAU); ctx.fill(); break; }
      case "spear": { ctx.save(); ctx.translate(0, -6); ctx.rotate(ang); ctx.translate(-rc * 5, 0); ctx.fillStyle = "#6a4a2a"; ctx.fillRect(-16, -2.5, 36, 5); ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(20, -5); ctx.lineTo(34, 0); ctx.lineTo(20, 5); ctx.fill(); ctx.strokeStyle = "#caa066"; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(-4, -12); ctx.lineTo(6, 0); ctx.lineTo(-4, 12); ctx.stroke(); ctx.restore(); ctx.fillStyle = "#5a3a1e"; ctx.beginPath(); ctx.arc(0, -3, 8, 0, TAU); ctx.fill(); break; }
      case "catapult": { ctx.fillStyle = "#6a4a2a"; ctx.fillRect(-18, -4, 36, 8); ctx.fillStyle = "#222"; for (const wx of [-14, 14]) { ctx.beginPath(); ctx.arc(wx, 8, 6, 0, TAU); ctx.fill(); ctx.fillStyle = "#7a7a88"; ctx.beginPath(); ctx.arc(wx, 8, 2.5, 0, TAU); ctx.fill(); ctx.fillStyle = "#222"; } ctx.save(); ctx.translate(0, -4); ctx.rotate(Math.cos(ang) >= 0 ? -0.6 + rc * 1.8 : 0.6 - rc * 1.8); ctx.fillStyle = "#8a5a2a"; ctx.fillRect(-3, -26, 6, 28); ctx.fillStyle = ev ? col : "#555"; ctx.beginPath(); ctx.arc(0, -27, 8, 0, TAU); ctx.fill(); if (rc < 0.3) { ctx.fillStyle = "#333"; ctx.beginPath(); ctx.arc(0, -30, 5, 0, TAU); ctx.fill(); } ctx.restore(); break; }
      case "frost": { const f = Math.sin(tm * 2 + t.id) * 3; ctx.save(); ctx.translate(0, -16 + f); ctx.rotate(tm * 0.6); ctx.fillStyle = col; ctx.globalAlpha *= 0.95; ctx.beginPath(); ctx.moveTo(0, -17); ctx.lineTo(10, 0); ctx.lineTo(0, 17); ctx.lineTo(-10, 0); ctx.closePath(); ctx.fill(); ctx.fillStyle = "rgba(255,255,255,0.75)"; ctx.beginPath(); ctx.moveTo(0, -17); ctx.lineTo(4, 0); ctx.lineTo(0, 8); ctx.closePath(); ctx.fill(); ctx.strokeStyle = "#fff"; ctx.lineWidth = 1.5; for (let i = 0; i < 3; i++) { ctx.rotate(Math.PI / 3); ctx.beginPath(); ctx.moveTo(0, -22); ctx.lineTo(0, 22); ctx.stroke(); } ctx.restore(); break; }
      case "lightning": { ctx.fillStyle = "#4a4a5a"; ctx.fillRect(-4, -22, 8, 24); ctx.fillStyle = "#7a7a8a"; for (let i = 0; i < 3; i++) ctx.fillRect(-7, -18 + i * 7, 14, 2.5); const g2 = ctx.createRadialGradient(0, -28, 1, 0, -28, 13); g2.addColorStop(0, "#fff"); g2.addColorStop(0.5, col); g2.addColorStop(1, col + "00"); ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(0, -28, 13 + rc * 4, 0, TAU); ctx.fill(); ctx.strokeStyle = col; ctx.lineWidth = 1.6; for (let i = 0; i < 3; i++) { const a = tm * 5 + i * 2.1 + t.id; ctx.beginPath(); ctx.moveTo(0, -28); ctx.lineTo(Math.cos(a) * 12 + Math.sin(tm * 40 + i) * 3, -28 + Math.sin(a) * 12); ctx.stroke(); } break; }
      case "flame": { ctx.fillStyle = "#3a2a24"; ctx.beginPath(); ctx.moveTo(-14, -8); ctx.lineTo(14, -8); ctx.lineTo(8, 6); ctx.lineTo(-8, 6); ctx.closePath(); ctx.fill(); ctx.strokeStyle = ev ? col : "#8a6a4a"; ctx.lineWidth = 3; ctx.stroke(); ctx.globalCompositeOperation = "lighter"; for (let i = 0; i < 4; i++) { const ph = tm * 7 + i * 1.7 + t.id, h = 14 + Math.sin(ph) * 5 + (i === 1 ? 8 : 0), xx = (i - 1.5) * 6; const g3 = ctx.createLinearGradient(0, -8, 0, -8 - h); g3.addColorStop(0, col); g3.addColorStop(1, "#ffd24a00"); ctx.fillStyle = g3; ctx.beginPath(); ctx.moveTo(xx - 5, -8); ctx.quadraticCurveTo(xx + Math.sin(ph) * 3, -8 - h * 0.6, xx, -8 - h); ctx.quadraticCurveTo(xx + 3, -8 - h * 0.5, xx + 5, -8); ctx.fill(); } ctx.globalCompositeOperation = "source-over"; break; }
      case "arcane": { const f = Math.sin(tm * 2 + t.id) * 3; ctx.save(); ctx.translate(0, -18 + f); const g4 = ctx.createRadialGradient(0, 0, 2, 0, 0, 14); g4.addColorStop(0, "#fff"); g4.addColorStop(0.45, col); g4.addColorStop(1, darken(col, 0.5)); ctx.fillStyle = g4; ctx.beginPath(); ctx.arc(0, 0, 11 + rc * 2, 0, TAU); ctx.fill(); ctx.strokeStyle = col; ctx.lineWidth = 2; for (let i = 0; i < 2; i++) { ctx.save(); ctx.rotate(tm * (i ? -1.5 : 1.2) + i); ctx.scale(1, 0.35); ctx.beginPath(); ctx.arc(0, 0, 19, 0, TAU); ctx.stroke(); ctx.restore(); } if (t.evo === "a") for (let i = 0; i < 4; i++) { const a = tm * 2 + i * TAU / 4; ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(Math.cos(a) * 22, Math.sin(a) * 8, 2, 0, TAU); ctx.fill(); } ctx.restore(); break; }
      case "bank": { ctx.fillStyle = "#7a4a22"; ctx.fillRect(-15, -12, 30, 18); ctx.fillStyle = "#9a6030"; ctx.beginPath(); ctx.ellipse(0, -12, 15, 7, 0, Math.PI, 0); ctx.fill(); ctx.fillStyle = col; ctx.fillRect(-15, -4, 30, 3); ctx.fillRect(-2, -8, 4, 9); ctx.globalCompositeOperation = "lighter"; ctx.fillStyle = col; for (let i = 0; i < 3; i++) { const ph = (tm * 0.8 + i / 3) % 1; ctx.globalAlpha = 1 - ph; ctx.beginPath(); ctx.arc((i - 1) * 8, -14 - ph * 16, 3, 0, TAU); ctx.fill(); } ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over"; break; }
    }
    // سطح
    ctx.fillStyle = "#ffd24a"; for (let i = 0; i < t.lvl; i++) { ctx.beginPath(); ctx.arc((i - (t.lvl - 1) / 2) * 9, 17, 2.8, 0, TAU); ctx.fill(); }
    if (ev) { ctx.fillStyle = col; ctx.strokeStyle = "#fff"; ctx.lineWidth = 1; ctx.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? 4 : 8, a = -Math.PI / 2 + i * TAU / 10; ctx.lineTo(18 + Math.cos(a) * r, -26 + Math.sin(a) * r); } ctx.closePath(); ctx.fill(); ctx.stroke(); }
    ctx.restore();
    if (t.enemyTower) { const f = Math.max(0, t.hp / t.maxhp), w = cs * 0.8; ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.fillRect(x - w / 2, y - cs * 0.62, w, 5); ctx.fillStyle = f > 0.5 ? "#ff7a5a" : "#ff3030"; ctx.fillRect(x - w / 2 + 1, y - cs * 0.62 + 1, (w - 2) * f, 3); ctx.fillStyle = "#e84a4a"; ctx.fillRect(x - 1, y - cs * 0.95, 2, cs * 0.3); ctx.beginPath(); ctx.moveTo(x + 1, y - cs * 0.95); ctx.lineTo(x + 10, y - cs * 0.85); ctx.lineTo(x + 1, y - cs * 0.78); ctx.fill(); }
    if (t.aura > 0 || b.buffT > 0) { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.fillStyle = b.buffT > 0 ? "rgba(255,90,90,0.5)" : "rgba(255,210,80,0.4)"; ctx.beginPath(); ctx.arc(x + cs * 0.3, y - cs * 0.4, 3, 0, TAU); ctx.fill(); ctx.restore(); }
  }

  // ---------- دشمن و سرباز ----------
  drawEnemy(ctx, e) {
    const cs = this.cs, b = this.b, x = e.x * cs, y = e.y * cs, r = e.def.r * cs, tm = this.t + e.wob, tint = b.map.enemyTint, face = e.dx >= 0 ? 1 : -1;
    if (!e.flying) this.shadow(ctx, x, y + r * 0.9, r);
    ctx.save(); ctx.translate(x, y + (e.flying ? -cs * 0.25 + Math.sin(tm * 5) * 3 : 0)); if (e.hitT > 0) ctx.filter = "brightness(1.8)";
    const bob = Math.abs(Math.sin(tm * (e.speed * 6 + 4))) * r * 0.25; ctx.translate(0, -bob);
    const k = e.kind, body = e.team === "troop" ? TROOPS[k].color : tint, dark = darken(body, 0.35), lite = lighten(body, 0.3);
    if (e.team === "troop") { this.drawTroop(ctx, e, r, face, tm); }
    else if (k === "scout") { ctx.scale(face, 1); ctx.fillStyle = dark; ctx.beginPath(); ctx.ellipse(0, 0, r * 0.9, r * 1.05, 0, 0, TAU); ctx.fill(); ctx.fillStyle = body; ctx.beginPath(); ctx.moveTo(-r, -r * 0.2); ctx.lineTo(0, -r * 1.7); ctx.lineTo(r, -r * 0.2); ctx.closePath(); ctx.fill(); ctx.fillStyle = "#fff"; ctx.fillRect(r * 0.1, -r * 0.4, r * 0.35, r * 0.25); ctx.fillStyle = "#111"; ctx.fillRect(r * 0.28, -r * 0.35, r * 0.15, r * 0.15); ctx.strokeStyle = dark; ctx.lineWidth = 2; const ph = Math.sin(tm * 14) * r * 0.5; ctx.beginPath(); ctx.moveTo(-r * 0.3, r * 0.8); ctx.lineTo(-r * 0.3 + ph, r * 1.4); ctx.moveTo(r * 0.3, r * 0.8); ctx.lineTo(r * 0.3 - ph, r * 1.4); ctx.stroke(); }
    else if (k === "raider") { ctx.scale(face, 1); ctx.fillStyle = dark; ctx.beginPath(); ctx.arc(0, 0, r * 1.05, 0, TAU); ctx.fill(); ctx.fillStyle = body; ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 0.9, 0, TAU); ctx.fill(); ctx.fillStyle = "#555"; ctx.beginPath(); ctx.arc(0, -r * 0.5, r * 0.7, Math.PI, 0); ctx.fill(); ctx.fillStyle = "#ffe"; ctx.fillRect(r * 0.2, -r * 0.25, r * 0.3, r * 0.25); ctx.fillStyle = "#111"; ctx.fillRect(r * 0.35, -r * 0.2, r * 0.12, r * 0.15); ctx.strokeStyle = "#ccd"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(r * 0.7, r * 0.2); ctx.lineTo(r * 1.5, -r * 0.7 + Math.sin(tm * 8) * r * 0.2); ctx.stroke(); }
    else if (k === "shield") { ctx.scale(face, 1); ctx.fillStyle = dark; ctx.beginPath(); ctx.arc(0, 0, r, 0, TAU); ctx.fill(); ctx.fillStyle = body; ctx.beginPath(); ctx.arc(-r * 0.1, -r * 0.1, r * 0.85, 0, TAU); ctx.fill(); ctx.fillStyle = "#99a"; ctx.beginPath(); ctx.arc(r * 0.35, 0, r * 0.85, -1.2, 1.2); ctx.lineTo(r * 0.35, 0); ctx.fill(); ctx.strokeStyle = "#dde"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(r * 0.35, 0, r * 0.85, -1.2, 1.2); ctx.stroke(); ctx.fillStyle = "#222"; ctx.fillRect(-r * 0.1, -r * 0.4, r * 0.25, r * 0.2); }
    else if (k === "brute") { ctx.scale(face, 1); ctx.fillStyle = dark; ctx.beginPath(); ctx.ellipse(0, 0, r * 1.1, r, 0, 0, TAU); ctx.fill(); ctx.fillStyle = body; ctx.beginPath(); ctx.ellipse(0, -r * 0.15, r * 0.95, r * 0.85, 0, 0, TAU); ctx.fill(); ctx.fillStyle = lite; ctx.beginPath(); ctx.arc(r * 0.1, -r * 0.7, r * 0.4, 0, TAU); ctx.fill(); ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.moveTo(r * 0.3, -r * 0.4); ctx.lineTo(r * 0.5, -r * 0.1); ctx.lineTo(r * 0.55, -r * 0.45); ctx.fill(); ctx.fillStyle = "#f33"; ctx.fillRect(r * 0.15, -r * 0.8, r * 0.2, r * 0.12); ctx.strokeStyle = "#6a4a2a"; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(r * 0.8, r * 0.3); ctx.lineTo(r * 1.4, -r * 0.8 + Math.sin(tm * 5) * r * 0.2); ctx.stroke(); ctx.fillStyle = "#555"; ctx.beginPath(); ctx.arc(r * 1.45, -r * 0.9, r * 0.28, 0, TAU); ctx.fill(); }
    else if (k === "flyer") { ctx.scale(face, 1); const fl = Math.sin(tm * 14); ctx.fillStyle = dark; for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(0, 0); ctx.quadraticCurveTo(s * r * 1.6, -r * (0.8 + fl * 0.9), s * r * 2.2, r * (0.2 - fl * 0.3)); ctx.quadraticCurveTo(s * r * 1.2, r * 0.3, 0, r * 0.3); ctx.fill(); } ctx.fillStyle = body; ctx.beginPath(); ctx.ellipse(0, 0, r * 0.7, r * 0.9, 0, 0, TAU); ctx.fill(); ctx.fillStyle = "#ffd24a"; ctx.beginPath(); ctx.moveTo(r * 0.5, -r * 0.2); ctx.lineTo(r * 1.1, 0); ctx.lineTo(r * 0.5, r * 0.15); ctx.fill(); ctx.fillStyle = "#fff"; ctx.fillRect(r * 0.15, -r * 0.45, r * 0.25, r * 0.2); }
    else if (k === "healer") { ctx.scale(face, 1); ctx.fillStyle = dark; ctx.beginPath(); ctx.moveTo(-r, r); ctx.lineTo(0, -r * 0.8); ctx.lineTo(r, r); ctx.closePath(); ctx.fill(); ctx.fillStyle = body; ctx.beginPath(); ctx.arc(0, -r * 0.75, r * 0.55, 0, TAU); ctx.fill(); ctx.globalCompositeOperation = "lighter"; ctx.strokeStyle = "#7bff9a"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, -r * 1.5, r * 0.6, r * 0.2, 0, 0, TAU); ctx.stroke(); ctx.fillStyle = "#7bff9a"; ctx.fillRect(-r * 0.12, -r * 0.2, r * 0.24, r * 0.7); ctx.fillRect(-r * 0.35, r * 0.03, r * 0.7, r * 0.24); ctx.globalCompositeOperation = "source-over"; }
    else if (k === "splitter" || k === "mini") { const sq = 1 + Math.sin(tm * 6) * 0.12; ctx.scale(1 / sq, sq); ctx.fillStyle = body + "cc"; ctx.beginPath(); ctx.ellipse(0, r * 0.1, r * 1.1, r * 0.9, 0, 0, TAU); ctx.fill(); ctx.fillStyle = "rgba(255,255,255,0.4)"; ctx.beginPath(); ctx.ellipse(-r * 0.3, -r * 0.35, r * 0.3, r * 0.18, -0.5, 0, TAU); ctx.fill(); ctx.fillStyle = "#111"; ctx.beginPath(); ctx.arc(-r * 0.25, 0, r * 0.14, 0, TAU); ctx.arc(r * 0.25, 0, r * 0.14, 0, TAU); ctx.fill(); }
    else if (k === "boss") { ctx.scale(face, 1); ctx.globalCompositeOperation = "lighter"; const ga = ctx.createRadialGradient(0, 0, r * 0.5, 0, 0, r * 2.1); ga.addColorStop(0, tint + "66"); ga.addColorStop(1, tint + "00"); ctx.fillStyle = ga; ctx.beginPath(); ctx.arc(0, 0, r * 2.1, 0, TAU); ctx.fill(); ctx.globalCompositeOperation = "source-over"; ctx.fillStyle = dark; ctx.beginPath(); ctx.arc(0, 0, r * 1.05, 0, TAU); ctx.fill(); ctx.fillStyle = body; ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 0.92, 0, TAU); ctx.fill(); ctx.fillStyle = "#ddd"; for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(s * r * 0.4, -r * 0.8); ctx.lineTo(s * r * 0.9, -r * 1.6); ctx.lineTo(s * r * 0.8, -r * 0.7); ctx.fill(); } ctx.fillStyle = "#ffd24a"; ctx.beginPath(); ctx.moveTo(-r * 0.5, -r * 0.85); ctx.lineTo(-r * 0.35, -r * 1.25); ctx.lineTo(-r * 0.1, -r * 0.95); ctx.lineTo(0, -r * 1.3); ctx.lineTo(r * 0.1, -r * 0.95); ctx.lineTo(r * 0.35, -r * 1.25); ctx.lineTo(r * 0.5, -r * 0.85); ctx.fill(); ctx.fillStyle = "#ff3030"; ctx.shadowColor = "#f00"; ctx.shadowBlur = 8; ctx.fillRect(r * 0.1, -r * 0.35, r * 0.32, r * 0.18); ctx.fillRect(-r * 0.4, -r * 0.35, r * 0.28, r * 0.18); ctx.shadowBlur = 0; if (e.absorb > 0) { ctx.strokeStyle = "#8fd4ff"; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, r * 1.3, 0, TAU); ctx.stroke(); } if (e.chargeT > 0) { ctx.strokeStyle = "#ffb347"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-r * 2, -r * 0.4); ctx.lineTo(-r * 1.3, -r * 0.4); ctx.moveTo(-r * 2.2, r * 0.2); ctx.lineTo(-r * 1.3, r * 0.2); ctx.stroke(); } }
    ctx.restore();
    if (e.slowT > 0 && e.stunT <= 0) { ctx.strokeStyle = "rgba(160,230,255,0.9)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, r * 1.25, 0, TAU); ctx.stroke(); }
    if (e.stunT > 0) { ctx.fillStyle = "rgba(180,235,255,0.55)"; ctx.beginPath(); ctx.arc(x, y, r * 1.2, 0, TAU); ctx.fill(); ctx.fillStyle = "#ffe45c"; for (let i = 0; i < 3; i++) { const a = this.t * 5 + i * 2.1; ctx.fillRect(x + Math.cos(a) * r - 2, y - r * 1.4 + Math.sin(a) * 4 - 2, 4, 4); } }
    if (e.hp < e.maxhp || e.boss) { const w = Math.max(cs * 0.5, r * 2.2), yy = y - r * (e.flying ? 2.6 : 1.7) - (e.boss ? 6 : 2); ctx.fillStyle = "rgba(0,0,0,0.65)"; ctx.fillRect(x - w / 2, yy, w, e.boss ? 7 : 4.5); const f = Math.max(0, e.hp / e.maxhp); ctx.fillStyle = e.team === "troop" ? "#7bd8ff" : f > 0.5 ? "#6cf08a" : f > 0.25 ? "#ffd24a" : "#ff5a4a"; ctx.fillRect(x - w / 2 + 1, yy + 1, (w - 2) * f, e.boss ? 5 : 2.5); if (e.absorb > 0) { ctx.fillStyle = "#8fd4ff"; ctx.fillRect(x - w / 2 + 1, yy - 2, (w - 2) * Math.min(1, e.absorb / e.maxhp * 4), 2); } }
    if (e.boss && e.name) { ctx.font = `bold ${Math.round(cs * 0.26)}px ${FONT}`; ctx.textAlign = "center"; ctx.fillStyle = "#ffd24a"; ctx.strokeStyle = "rgba(0,0,0,0.8)"; ctx.lineWidth = 3; ctx.strokeText(e.name, x, y - r * 1.7 - 12); ctx.fillText(e.name, x, y - r * 1.7 - 12); }
  }
  drawTroop(ctx, e, r, face, tm) {
    const d = TROOPS[e.kind]; ctx.scale(face, 1); ctx.fillStyle = darken(d.color, 0.4); ctx.beginPath(); ctx.arc(0, 0, r * 1.15, 0, TAU); ctx.fill(); ctx.fillStyle = d.color; ctx.beginPath(); ctx.arc(0, -r * 0.1, r, 0, TAU); ctx.fill(); ctx.strokeStyle = "rgba(255,255,255,0.7)"; ctx.lineWidth = 2; ctx.stroke();
    ctx.font = `${Math.round(r * 1.5)}px ${EMO}`; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillStyle = "#fff"; ctx.fillText(d.emoji, 0, -r * 0.05);
  }

  // ---------- قهرمان ----------
  drawHero(ctx, h, ui) {
    const cs = this.cs, x = h.x * cs, y = h.y * cs, tm = this.t, u = cs / 50, col = h.def.color; this.shadow(ctx, x, y + 15 * u, 14 * u);
    ctx.save(); ctx.translate(x, y); ctx.scale(u * h.face, u); const bob = h.moving ? Math.abs(Math.sin(tm * 12)) * 3 : Math.sin(tm * 2.5) * 1.2; ctx.translate(0, -bob);
    ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(0, -6, 2, 0, -6, 34); g.addColorStop(0, col + "88"); g.addColorStop(1, col + "00"); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, -6, 34, 0, TAU); ctx.fill(); ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = darken(col, 0.45); ctx.beginPath(); ctx.moveTo(-12, -8); ctx.lineTo(-18 + Math.sin(tm * 4) * 2, 16); ctx.lineTo(0, 10); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#3a3a48"; ctx.fillRect(-7, 8, 5, 9 + (h.moving ? Math.sin(tm * 14) * 3 : 0)); ctx.fillRect(2, 8, 5, 9 - (h.moving ? Math.sin(tm * 14) * 3 : 0));
    ctx.fillStyle = col; ctx.beginPath(); ctx.roundRect(-9, -12, 18, 22, 5); ctx.fill(); ctx.fillStyle = "rgba(255,255,255,0.35)"; ctx.fillRect(-9, -12, 18, 4);
    ctx.fillStyle = "#f1c9a0"; ctx.beginPath(); ctx.arc(0, -19, 8, 0, TAU); ctx.fill(); ctx.fillStyle = darken(col, 0.3); ctx.beginPath(); ctx.arc(0, -21, 8.5, Math.PI, 0); ctx.fill(); ctx.fillStyle = "#222"; ctx.fillRect(2, -20, 2.5, 2.5);
    const sw = h.swing * 1.4; ctx.save(); ctx.translate(9, -4); ctx.rotate(-0.5 + sw);
    if (h.key === "arash") { ctx.strokeStyle = "#e0b060"; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(8, 0, 16, -1.3, 1.3); ctx.stroke(); ctx.strokeStyle = "#fff"; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(8 + Math.cos(-1.3) * 16, Math.sin(-1.3) * 16); ctx.lineTo(8 + Math.cos(1.3) * 16, Math.sin(1.3) * 16); ctx.stroke(); }
    else if (h.key === "rostam") { ctx.strokeStyle = "#7a5230"; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(0, 6); ctx.lineTo(14, -14); ctx.stroke(); ctx.fillStyle = "#c0c0cc"; ctx.beginPath(); ctx.arc(16, -17, 8, 0, TAU); ctx.fill(); }
    else if (h.key === "gordafarid") { ctx.strokeStyle = "#e8f4ff"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(0, 4); ctx.lineTo(20, -16); ctx.stroke(); ctx.strokeStyle = "#ffd24a"; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(-3, 3); ctx.lineTo(3, 7); ctx.stroke(); }
    else if (h.key === "zal") { ctx.strokeStyle = "#caa066"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(0, 8); ctx.lineTo(8, -22); ctx.stroke(); ctx.fillStyle = "#d9f0ff"; ctx.shadowColor = "#fff"; ctx.shadowBlur = 10; ctx.beginPath(); ctx.arc(9, -25, 5, 0, TAU); ctx.fill(); ctx.shadowBlur = 0; }
    else { ctx.strokeStyle = "#6a4a2a"; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(0, 6); ctx.lineTo(12, -10); ctx.stroke(); ctx.fillStyle = "#555"; ctx.fillRect(6, -20, 16, 11); ctx.fillStyle = "#ff6a3c"; ctx.fillRect(6, -20, 5, 11); }
    ctx.restore(); ctx.restore();
    ctx.font = `bold ${Math.round(cs * 0.22)}px ${FONT}`; ctx.textAlign = "center"; ctx.fillStyle = "#fff"; ctx.strokeStyle = "rgba(0,0,0,0.8)"; ctx.lineWidth = 3; ctx.strokeText(h.def.name.split(" ")[0], x, y + cs * 0.55); ctx.fillText(h.def.name.split(" ")[0], x, y + cs * 0.55);
    if (ui && ui.selHero === h) { ctx.strokeStyle = "#ffe58a"; ctx.lineWidth = 3; ctx.setLineDash([5, 4]); ctx.beginPath(); ctx.arc(x, y, cs * 0.55, 0, TAU); ctx.stroke(); ctx.setLineDash([]); ctx.strokeStyle = "rgba(255,255,255,0.35)"; ctx.beginPath(); ctx.arc(x, y, h.def.range * this.b.mods.range * cs, 0, TAU); ctx.stroke(); }
    if (h.tx >= 0 && h.moving) { ctx.strokeStyle = "rgba(255,255,255,0.5)"; ctx.beginPath(); ctx.arc(h.tx * cs, h.ty * cs, 6, 0, TAU); ctx.stroke(); }
  }

  // ---------- پرتابه‌ها و افکت‌ها ----------
  drawProj(ctx, b) {
    const cs = this.cs; for (const p of b.proj) {
      const x = p.x * cs, y = p.y * cs;
      if (p.type === "arrow" || p.type === "tarrow") { ctx.save(); ctx.translate(x, y); ctx.rotate(p.ang || 0); ctx.strokeStyle = p.color; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(-cs * 0.25, 0); ctx.lineTo(cs * 0.12, 0); ctx.stroke(); ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.moveTo(cs * 0.12, -3); ctx.lineTo(cs * 0.22, 0); ctx.lineTo(cs * 0.12, 3); ctx.fill(); ctx.restore(); }
      else if (p.type === "spear") { ctx.save(); ctx.translate(x, y); ctx.rotate(p.ang || 0); ctx.strokeStyle = "#6a4a2a"; ctx.lineWidth = 3.5; ctx.beginPath(); ctx.moveTo(-cs * 0.4, 0); ctx.lineTo(cs * 0.15, 0); ctx.stroke(); ctx.fillStyle = p.color; ctx.beginPath(); ctx.moveTo(cs * 0.12, -5); ctx.lineTo(cs * 0.3, 0); ctx.lineTo(cs * 0.12, 5); ctx.fill(); ctx.restore(); }
      else if (p.type === "lob") { const hh = (p.h || 0) * cs; ctx.fillStyle = "rgba(0,0,0,0.3)"; ctx.beginPath(); ctx.ellipse(x, y, cs * 0.12, cs * 0.06, 0, 0, TAU); ctx.fill(); ctx.fillStyle = "#3a3a44"; ctx.beginPath(); ctx.arc(x, y - hh, cs * 0.14, 0, TAU); ctx.fill(); ctx.fillStyle = p.color; ctx.globalAlpha = 0.5; ctx.beginPath(); ctx.arc(x, y - hh, cs * 0.2, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; }
      else if (p.type === "orb" || p.type === "shard") { ctx.save(); ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(x, y, 0, x, y, cs * 0.28); g.addColorStop(0, "#fff"); g.addColorStop(0.4, p.color); g.addColorStop(1, p.color + "00"); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, cs * 0.28, 0, TAU); ctx.fill(); ctx.restore(); }
    }
  }
  drawFx(ctx, b) {
    const cs = this.cs; for (const f of b.fx) {
      const u = f.life / f.max;
      if (f.type === "p") { ctx.globalCompositeOperation = f.add ? "lighter" : "source-over"; ctx.globalAlpha = Math.max(0, u); ctx.fillStyle = f.color; ctx.beginPath(); ctx.arc(f.x * cs, f.y * cs, f.size * cs * (f.grow ? 1 + (1 - u) * f.grow : 1), 0, TAU); ctx.fill(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over"; }
      else if (f.type === "ring") { ctx.globalCompositeOperation = "lighter"; ctx.strokeStyle = f.color; ctx.globalAlpha = u; ctx.lineWidth = 3 + 4 * u; ctx.beginPath(); ctx.arc(f.x * cs, f.y * cs, f.r * cs * (1 - u * u), 0, TAU); ctx.stroke(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over"; }
      else if (f.type === "bolt") { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = Math.min(1, u * 1.6); for (const [w, c] of [[6, f.color + "55"], [2, "#fff"]]) { ctx.strokeStyle = c; ctx.lineWidth = w; ctx.beginPath(); for (let i = 0; i < f.pts.length - 1; i++) { const a = f.pts[i], z = f.pts[i + 1], n = 6; for (let k = 0; k <= n; k++) { const tt = k / n, jx = k && k < n ? (Math.sin(f.seed + i * 9 + k * 7) * 0.12) : 0, jy = k && k < n ? (Math.cos(f.seed * 2 + i * 5 + k * 3) * 0.12) : 0; const px = (a.x + (z.x - a.x) * tt + jx) * cs, py = (a.y + (z.y - a.y) * tt + jy) * cs; k || i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } } ctx.stroke(); } ctx.restore(); }
      else if (f.type === "beam") { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = u; ctx.strokeStyle = f.color; ctx.lineWidth = f.w * cs * (0.4 + u); ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(f.x * cs, f.y * cs); ctx.lineTo(f.x2 * cs, f.y2 * cs); ctx.stroke(); ctx.strokeStyle = "#fff"; ctx.lineWidth = f.w * cs * 0.3; ctx.stroke(); ctx.restore(); }
      else if (f.type === "text") { ctx.globalAlpha = Math.min(1, u * 2); ctx.font = `bold ${Math.round(cs * 0.3 * f.size)}px ${FONT}`; ctx.textAlign = "center"; ctx.strokeStyle = "rgba(0,0,0,0.85)"; ctx.lineWidth = 3; ctx.fillStyle = f.color; ctx.strokeText(f.txt, f.x * cs, f.y * cs); ctx.fillText(f.txt, f.x * cs, f.y * cs); ctx.globalAlpha = 1; }
      else if (f.type === "coin") { ctx.globalAlpha = Math.min(1, u * 2); ctx.fillStyle = "#ffd24a"; ctx.beginPath(); ctx.arc(f.x * cs, f.y * cs - 4, 4, 0, TAU); ctx.fill(); ctx.fillStyle = "#b8860b"; ctx.fillRect(f.x * cs - 1, f.y * cs - 6, 2, 4); ctx.globalAlpha = 1; }
      else if (f.type === "slash") { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = u; ctx.strokeStyle = f.color; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(f.x * cs, f.y * cs, cs * 0.4, f.a, f.a + 1.8); ctx.stroke(); ctx.restore(); }
      else if (f.type === "bird") { const x = f.x * cs, y = f.y * cs, wing = Math.sin(this.t * 16) * cs * 0.5; ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = Math.min(1, u * 2); const g = ctx.createRadialGradient(x, y, 0, x, y, cs * 2.2); g.addColorStop(0, "rgba(220,245,255,0.7)"); g.addColorStop(1, "rgba(220,245,255,0)"); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, cs * 2.2, 0, TAU); ctx.fill(); ctx.fillStyle = "#fff"; for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x - cs * 0.5, y + s * cs * 1.2 - wing * s, x - cs * 1.6, y + s * cs * 0.3); ctx.quadraticCurveTo(x - cs * 0.6, y + s * cs * 0.1, x, y); ctx.fill(); } ctx.beginPath(); ctx.ellipse(x, y, cs * 0.5, cs * 0.2, 0, 0, TAU); ctx.fill(); ctx.restore(); }
    }
  }
}
