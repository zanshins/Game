// رندر نبرد روی canvas: زمین، برج‌ها، دشمنان، قهرمانان، افکت‌ها
// بهینه‌سازی: همه‌ی اشکال پیچیده یک‌بار روی بوم پنهان ساخته و کش می‌شوند؛ بدون filter و shadowBlur
import { COLS, ROWS, TOWERS, TROOPS, ENEMIES, rng } from "./data.js";
import * as A from "./sprites.js";

const TAU = Math.PI * 2, FONT = "Vazirmatn, sans-serif";
const { mix, lighten, darken } = A;

export class Renderer {
  constructor(cv) { this.cv = cv; this.ctx = cv.getContext("2d", { alpha: false }); this.w = 0; this.h = 0; this.cs = 40; this.ox = 0; this.oy = 0; this.dpr = 1; this.terrain = null; this.b = null; this.wx = []; this.t = 0; this.flash = 0; this.lastLives = null; this.cache = new Map(); this.vig = null; this.storm = 0; }
  resize(w, h) {
    // سقف تعداد پیکسل: روی گوشی‌های سنگین فشار پردازش را کم می‌کند
    let d = Math.min(2, window.devicePixelRatio || 1); const budget = 1.9e6; if (w * h * d * d > budget) d = Math.max(1, Math.sqrt(budget / (w * h)));
    this.dpr = d; this.w = w; this.h = h; this.cv.width = Math.round(w * d); this.cv.height = Math.round(h * d); this.cv.style.width = w + "px"; this.cv.style.height = h + "px";
    const top = 46; this.cs = Math.floor(Math.min(w / COLS, (h - top) / ROWS)); this.ox = Math.floor((w - this.cs * COLS) / 2); this.oy = top + Math.floor((h - top - this.cs * ROWS) / 2);
    this.cache.clear(); this.vig = null; if (this.b) this.buildTerrain();
  }
  setBattle(b) { this.b = b; this.initWeather(); if (this.w) this.buildTerrain(); this.lastLives = b.lives; }
  toCell(px, py) { const r = this.cv.getBoundingClientRect(); const x = (px - r.left - this.ox) / this.cs, y = (py - r.top - this.oy) / this.cs; return { fx: x, fy: y, x: Math.floor(x), y: Math.floor(y) }; }

  // ---------- کش اسپریت ----------
  // wu,hu: ابعاد به واحد (۵۰ = یک خانه)؛ cx,cy: محل مبدأ داخل اسپریت (واحد)
  spr(key, wu, hu, cx, cy, fn) {
    let s = this.cache.get(key); if (s) return s;
    const k = this.cs / 50 * this.dpr, c = document.createElement("canvas"); c.width = Math.max(2, Math.ceil(wu * k)); c.height = Math.max(2, Math.ceil(hu * k));
    const g = c.getContext("2d"); g.scale(k, k); g.translate(cx, cy); fn(g); s = { c, cx: cx * this.cs / 50, cy: cy * this.cs / 50, w: c.width / this.dpr, h: c.height / this.dpr }; this.cache.set(key, s); return s;
  }
  put(ctx, s, x, y, flip = 1, sc = 1) {
    if (flip === 1 && sc === 1) { ctx.drawImage(s.c, x - s.cx, y - s.cy, s.w, s.h); return; }
    ctx.save(); ctx.translate(x, y); ctx.scale(flip * sc, sc); ctx.drawImage(s.c, -s.cx, -s.cy, s.w, s.h); ctx.restore();
  }
  glow(col, R = 32) { return this.spr("glow|" + col + "|" + R, R * 2, R * 2, R, R, (g) => A.glowSprite(g, col, R)); }
  putGlow(ctx, col, x, y, rPx, alpha = 1) { const s = this.glow(col, 32), sc = rPx / s.cx; ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = alpha; ctx.translate(x, y); ctx.scale(sc, sc); ctx.drawImage(s.c, -s.cx, -s.cy, s.w, s.h); ctx.restore(); }

  // ---------- زمین ----------
  buildTerrain() {
    const b = this.b, m = b.map, cs = this.cs, ox = this.ox, oy = this.oy, W = this.w, H = this.h, c = document.createElement("canvas"); c.width = Math.round(W * this.dpr); c.height = Math.round(H * this.dpr);
    const g = c.getContext("2d"); g.scale(this.dpr, this.dpr); const r = rng(m.seed * 13 + 5);
    const grad = g.createLinearGradient(0, 0, 0, H); grad.addColorStop(0, lighten(m.col.g1, 0.06)); grad.addColorStop(1, darken(m.col.g2, 0.2)); g.fillStyle = grad; g.fillRect(0, 0, W, H);
    // کاشی‌های نرم با تغییر رنگ ملایم (بدون شطرنجی خشک)
    for (let y = -1; y <= ROWS; y++) for (let x = -1; x <= COLS; x++) { const px = ox + x * cs, py = oy + y * cs; g.fillStyle = (x + y) % 2 ? m.col.g1 : m.col.g2; g.globalAlpha = 0.55 + r() * 0.3; g.fillRect(px, py, cs + 1, cs + 1); g.globalAlpha = 1; }
    // لکه‌های بزرگ و بافت ریزدانه
    for (let i = 0; i < 26; i++) { const x = r() * W, y = r() * H, rr = cs * (0.8 + r() * 1.6); g.fillStyle = r() < 0.5 ? "rgba(255,255,255,0.045)" : "rgba(0,0,0,0.06)"; g.beginPath(); g.ellipse(x, y, rr, rr * 0.6, r() * 3, 0, TAU); g.fill(); }
    const speck = Math.round(W * H / 260); for (let i = 0; i < speck; i++) { g.fillStyle = r() < 0.5 ? "rgba(255,255,255,0.07)" : "rgba(0,0,0,0.08)"; g.fillRect(r() * W, r() * H, 1.4, 1.4); }
    this.terrainExtras(g, m, r);
    // مسیر
    const ext = 4;
    for (const pass of [0, 1, 2, 3]) for (const p of b.rt.paths) {
      const pts = p.pts.map((q) => ({ x: ox + q.x * cs, y: oy + q.y * cs })), a = pts[0], a2 = pts[1], z = pts[pts.length - 1], z2 = pts[pts.length - 2];
      const ua = Math.hypot(a.x - a2.x, a.y - a2.y) || 1, uz = Math.hypot(z.x - z2.x, z.y - z2.y) || 1;
      const ps = [{ x: a.x + (a.x - a2.x) / ua * cs * ext, y: a.y + (a.y - a2.y) / ua * cs * ext }, ...pts, { x: z.x + (z.x - z2.x) / uz * cs * ext, y: z.y + (z.y - z2.y) / uz * cs * ext }];
      g.lineJoin = "round"; g.lineCap = "butt"; g.beginPath(); ps.forEach((q, i) => (i ? g.lineTo(q.x, q.y) : g.moveTo(q.x, q.y)));
      if (pass === 0) { g.strokeStyle = "rgba(0,0,0,0.28)"; g.lineWidth = cs * 1.12; g.save(); g.translate(0, cs * 0.07); g.stroke(); g.restore(); }
      else if (pass === 1) { g.strokeStyle = m.col.edge; g.lineWidth = cs * 1.02; g.stroke(); }
      else if (pass === 2) { g.strokeStyle = m.col.path; g.lineWidth = cs * 0.86; g.stroke(); }
      else { g.strokeStyle = lighten(m.col.path, 0.16); g.globalAlpha = 0.32; g.lineWidth = cs * 0.5; g.stroke(); g.globalAlpha = 1; }
    }
    // سنگفرش: سنگ‌های کوچک روی مسیر
    for (const k of b.rt.cells) { const [cx, cy] = k.split(",").map(Number); for (let i = 0; i < 7; i++) { const px = ox + (cx + 0.1 + r() * 0.8) * cs, py = oy + (cy + 0.1 + r() * 0.8) * cs, sw = cs * (0.1 + r() * 0.12), sh = sw * (0.55 + r() * 0.3); g.fillStyle = r() < 0.5 ? darken(m.col.path, 0.13 + r() * 0.1) : lighten(m.col.path, 0.08 + r() * 0.12); g.beginPath(); g.roundRect(px, py, sw, sh, sh * 0.45); g.fill(); g.fillStyle = "rgba(255,255,255,0.12)"; g.fillRect(px + 1, py, sw - 2, 1); } }
    // دکور (به ترتیب عمق)
    const items = b.rt.deco.slice().sort((p, q) => p.y - q.y);
    for (const d of items) this.drawDeco(g, d, m);
    this.terrain = c;
  }
  terrainExtras(g, m, r) {
    const cs = this.cs, W = this.w, H = this.h, n = 30, id = m.id;
    for (let i = 0; i < n; i++) {
      const x = r() * W, y = r() * H, s = cs * (0.4 + r() * 0.9);
      if (id === "volcano" || id === "firerealm") { g.strokeStyle = "rgba(255,120,40,0.4)"; g.lineWidth = 2; g.beginPath(); g.moveTo(x, y); g.lineTo(x + s * 0.5, y + s * 0.2); g.lineTo(x + s * 0.8, y - s * 0.1); g.stroke(); }
      else if (id === "ice" || id === "frostfort") { g.strokeStyle = "rgba(255,255,255,0.5)"; g.lineWidth = 1.5; g.beginPath(); g.moveTo(x, y); g.lineTo(x + s * 0.6, y - s * 0.25); g.stroke(); }
      else if (id === "desert" || id === "caravan") { g.strokeStyle = "rgba(120,70,20,0.2)"; g.lineWidth = 2; g.beginPath(); g.arc(x, y, s * 0.6, 3.4, 5.9); g.stroke(); }
      else if (id === "void") { g.fillStyle = `rgba(255,255,255,${0.3 + r() * 0.5})`; g.beginPath(); g.arc(x, y, 1 + r() * 1.5, 0, TAU); g.fill(); if (i % 6 === 0) { const gr = g.createRadialGradient(x, y, 0, x, y, s * 2); gr.addColorStop(0, "rgba(140,60,200,0.2)"); gr.addColorStop(1, "rgba(140,60,200,0)"); g.fillStyle = gr; g.fillRect(x - s * 2, y - s * 2, s * 4, s * 4); } }
      else if (id === "swamp") { g.fillStyle = "rgba(20,40,10,0.3)"; g.beginPath(); g.ellipse(x, y, s * 0.7, s * 0.3, 0, 0, TAU); g.fill(); g.fillStyle = "rgba(160,220,80,0.13)"; g.beginPath(); g.ellipse(x - 2, y - 2, s * 0.5, s * 0.18, 0, 0, TAU); g.fill(); }
      else if (id === "sky" || id === "cloudpalace") { g.fillStyle = "rgba(255,255,255,0.24)"; g.beginPath(); g.ellipse(x, y, s * 0.9, s * 0.35, 0, 0, TAU); g.fill(); }
      else if (id === "forest" || id === "fortress") { g.fillStyle = "rgba(10,40,25,0.3)"; g.beginPath(); g.ellipse(x, y, s * 0.8, s * 0.35, 0, 0, TAU); g.fill(); }
      else { g.fillStyle = r() < 0.5 ? "rgba(255,255,255,0.55)" : "rgba(255,210,120,0.6)"; g.beginPath(); g.arc(x, y, 2, 0, TAU); g.fill(); g.fillStyle = "#3a8a3a"; g.fillRect(x - 0.5, y, 1, 4); }
    }
  }
  drawDeco(g, d, m) {
    const cs = this.cs, cx = this.ox + (d.x + 0.5) * cs, cy = this.oy + (d.y + 0.5) * cs, s = d.s, k = d.kind;
    if (k === "tuft") { const x = cx + (d.ox - 0.5) * cs * 0.7, y = cy + (d.oy - 0.5) * cs * 0.7; g.strokeStyle = m.id === "desert" || m.id === "caravan" ? "#b9852f" : m.id === "ice" || m.id === "frostfort" ? "#e8f8ff" : m.id === "volcano" || m.id === "firerealm" ? "#8a4a32" : m.id === "void" ? "#7a4ac0" : m.id === "fortress" ? "#7a8a74" : "#3d8a44"; g.lineWidth = 1.5; for (let i = -1; i <= 1; i++) { g.beginPath(); g.moveTo(x + i * 3, y + 4); g.quadraticCurveTo(x + i * 4, y - 3, x + i * 6, y - 5 * s - 2); g.stroke(); } if (d.v > 0.7 && m.id === "meadow") { g.fillStyle = ["#ff7aa8", "#fff3a0", "#ffffff"][Math.floor(d.v * 30) % 3]; g.beginPath(); g.arc(x + 4, y - 5, 2.2, 0, TAU); g.fill(); } return; }
    const sp = this.spr("deco|" + k + "|" + (d.v > 0.6 ? 1 : 0), 100, 110, 50, 85, (gg) => A.decoSprite(gg, k, d.v > 0.6 ? 1 : 0)), sc = cs / 50 * s;
    g.save(); g.translate(cx, cy + cs * 0.22); g.scale(s, s); g.drawImage(sp.c, -sp.cx, -sp.cy, sp.w, sp.h); g.restore(); void sc;
  }

  // ---------- طبیعت متحرک ----------
  initWeather() {
    const k = this.b.map.weather, n = k === "clouds" ? 6 : k === "sand" ? 34 : 44; this.wx = []; const r = rng(7);
    for (let i = 0; i < n; i++) this.wx.push({ x: r(), y: r(), s: 0.4 + r() * 0.8, p: r() * 6.28, z: r() });
  }
  drawWeather(ctx, dt) {
    const k = this.b.map.weather, W = this.w, H = this.h, t = this.t; ctx.save();
    for (const p of this.wx) {
      if (k === "snow") { p.y += dt * 0.09 * p.s; p.x += Math.sin(t + p.p) * dt * 0.02; ctx.globalAlpha = 0.85; ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(p.x * W, p.y * H, 1.2 + p.z * 2, 0, TAU); ctx.fill(); }
      else if (k === "petals") { p.y += dt * 0.05 * p.s; p.x += dt * 0.03 + Math.sin(t * 1.5 + p.p) * dt * 0.02; ctx.globalAlpha = 0.8; ctx.fillStyle = p.z > 0.5 ? "#ffc2d6" : "#fff"; ctx.save(); ctx.translate(p.x * W, p.y * H); ctx.rotate(t + p.p); ctx.beginPath(); ctx.ellipse(0, 0, 4, 2, 0, 0, TAU); ctx.fill(); ctx.restore(); }
      else if (k === "fireflies") { p.x += Math.sin(t * 0.7 + p.p) * dt * 0.03; p.y += Math.cos(t * 0.5 + p.p * 2) * dt * 0.02; this.putGlow(ctx, "#c8ff7a", p.x * W, p.y * H, 8 + p.z * 4, 0.35 + 0.65 * Math.abs(Math.sin(t * 1.3 + p.p))); }
      else if (k === "sand") { p.x += dt * 0.35 * p.s; p.y += Math.sin(t + p.p) * dt * 0.01; ctx.globalAlpha = 0.35; ctx.strokeStyle = "#f4d79a"; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(p.x * W, p.y * H); ctx.lineTo(p.x * W - 16 * p.s, p.y * H - 1); ctx.stroke(); }
      else if (k === "spores") { p.y -= dt * 0.04 * p.s; p.x += Math.sin(t + p.p) * dt * 0.015; ctx.globalAlpha = 0.5; ctx.strokeStyle = "#c8ff6a"; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(p.x * W, p.y * H, 2 + p.z * 4, 0, TAU); ctx.stroke(); }
      else if (k === "embers") { p.y -= dt * 0.12 * p.s; p.x += Math.sin(t * 2 + p.p) * dt * 0.02; this.putGlow(ctx, p.z > 0.5 ? "#ff9d2f" : "#ff5a2e", p.x * W, p.y * H, 4 + p.z * 3, 0.9); }
      else if (k === "clouds") { p.x += dt * 0.012 * p.s; ctx.globalAlpha = 0.14; ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.ellipse(p.x * W, p.y * H, 90 + p.z * 70, 26 + p.z * 14, 0, 0, TAU); ctx.fill(); }
      else if (k === "stars") { ctx.globalAlpha = 0.3 + 0.7 * Math.abs(Math.sin(t * (0.8 + p.z) + p.p)); ctx.fillStyle = "#e8d8ff"; ctx.fillRect(p.x * W, p.y * H, 1.8, 1.8); p.x += dt * 0.004 * p.s; }
      if (p.x > 1.05) p.x = -0.05; if (p.x < -0.1) p.x = 1.05; if (p.y > 1.05) p.y = -0.05; if (p.y < -0.1) p.y = 1.05;
    }
    ctx.restore();
  }

  // ---------- اصلی ----------
  draw(dt, ui) {
    const b = this.b; if (!b || !this.terrain) return; this.t += dt; const ctx = this.ctx, cs = this.cs;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    let sx = 0, sy = 0; if (b.shake > 0) { const m = Math.min(1, b.shake) * cs * 0.18; sx = (Math.random() - 0.5) * m; sy = (Math.random() - 0.5) * m; }
    ctx.save(); ctx.translate(sx, sy); ctx.drawImage(this.terrain, 0, 0, this.w, this.h);
    ctx.translate(this.ox, this.oy);
    this.drawPortals(ctx, b); this.drawZones(ctx, b); this.drawHazardsGround(ctx, b); this.drawGrid(ctx, b, ui);
    const list = []; for (const t of b.towers) list.push({ y: t.cy, f: () => this.drawTower(ctx, t, b) }); for (const t of b.towers) if (t.men) for (const m of t.men) if (m.hp > 0) list.push({ y: m.y + 0.004, f: () => this.drawMan(ctx, m, t) }); for (const g of b.ghosts || []) list.push({ y: g.y + 0.005, f: () => this.drawGhost(ctx, g) }); for (const h of b.heroes) if (h.deployed) list.push({ y: h.y + 0.01, f: () => this.drawHero(ctx, h, ui) });
    for (const e of b.enemies) if (!e.dead && !e.flying) list.push({ y: e.y, f: () => this.drawEnemy(ctx, e) });
    list.sort((p, q) => p.y - q.y); for (const it of list) it.f();
    this.drawGate(ctx, b);
    for (const e of b.enemies) if (!e.dead && e.flying) { this.shadow(ctx, e.x * cs, (e.y + 0.3) * cs, e.def.r * cs); this.drawEnemy(ctx, e); }
    this.drawProj(ctx, b); this.drawFx(ctx, b); this.drawRange(ctx, b, ui); this.drawHazardsAir(ctx, b);
    ctx.restore(); this.drawWeather(ctx, dt);
    if (!this.vig) { const c = document.createElement("canvas"); c.width = 128; c.height = 128; const g = c.getContext("2d"), gr = g.createRadialGradient(64, 64, 44, 64, 64, 96); gr.addColorStop(0, "rgba(0,0,0,0)"); gr.addColorStop(1, "rgba(0,0,0,0.42)"); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); this.vig = c; }
    ctx.drawImage(this.vig, 0, 0, this.w, this.h);
    if (this.lastLives !== null && b.lives < this.lastLives && b.mode !== "attack") this.flash = 0.45; this.lastLives = b.lives; if (this.flash > 0) { ctx.fillStyle = `rgba(255,40,40,${this.flash * 0.5})`; ctx.fillRect(0, 0, this.w, this.h); this.flash -= dt; }
    if (b.buffT > 0) { ctx.strokeStyle = `rgba(255,90,90,${0.4 + 0.2 * Math.sin(this.t * 6)})`; ctx.lineWidth = 6; ctx.strokeRect(3, 3, this.w - 6, this.h - 6); }
  }
  shadow(ctx, x, y, r) { ctx.fillStyle = "rgba(0,0,0,0.3)"; ctx.beginPath(); ctx.ellipse(x, y, r * 1.1, r * 0.45, 0, 0, TAU); ctx.fill(); }
  drawPortals(ctx, b) {
    const cs = this.cs, t = this.t, atk = b.mode === "attack";
    for (let i = 0; i < b.rt.paths.length; i++) {
      const p = b.rt.paths[i].pts[0], x = Math.max(0.3, Math.min(COLS - 0.3, p.x)) * cs, y = p.y * cs;
      ctx.save(); ctx.translate(x, y); ctx.globalCompositeOperation = "lighter";
      for (let k = 0; k < 3; k++) { ctx.strokeStyle = atk ? "rgba(120,200,255,0.55)" : "rgba(255,90,110,0.6)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(0, 0, cs * (0.2 + k * 0.12) * (1 + 0.1 * Math.sin(t * 3 + k)), cs * (0.38 + k * 0.1), t * (k % 2 ? 1 : -1) * 0.8, 0, TAU); ctx.stroke(); }
      ctx.restore();
    }
  }
  drawGate(ctx, b) {
    if (b.mode !== "attack") return; const cs = this.cs, p = b.rt.paths[0].pts[b.rt.paths[0].pts.length - 1], x = (COLS - 0.62) * cs, y = p.y * cs, nb = b.nb, st = b.map.gateStyle || "wood";
    const sp = this.spr("gate|" + st + "|" + nb.color, 120, 150, 60, 105, (g) => A.gateSprite(g, st, nb.color)); this.put(ctx, sp, x, y + cs * 0.1, 1, 0.82);
    const w = cs * 1.3, f = Math.max(0, b.gate / b.gateMax), by = y + cs * 0.78; ctx.fillStyle = "rgba(0,0,0,0.65)"; ctx.fillRect(x - w / 2, by, w, 8); ctx.fillStyle = f > 0.5 ? "#ffb347" : "#ff5a4a"; ctx.fillRect(x - w / 2 + 1, by + 1, (w - 2) * f, 6);
  }
  drawZones(ctx, b) { for (const z of b.zones) { const cs = this.cs, a = Math.min(0.55, z.t / z.max); this.putGlow(ctx, "#ff6a2e", z.x * cs, z.y * cs, z.r * cs * 1.1, a); } }
  drawHazardsGround(ctx, b) {
    const cs = this.cs, t = this.t; if (!b.hazards) return;
    for (const h of b.hazards) {
      if (h.type === "ice") { ctx.save(); ctx.globalAlpha = 0.55; ctx.fillStyle = "#bfeaff"; ctx.beginPath(); ctx.ellipse(h.x * cs, h.y * cs, h.r * cs, h.r * cs * 0.7, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = "#fff"; ctx.lineWidth = 2; ctx.stroke(); ctx.globalAlpha = 0.8; ctx.strokeStyle = "#e8faff"; ctx.lineWidth = 1; for (let i = 0; i < 4; i++) { const a = i * 1.6 + 0.4; ctx.beginPath(); ctx.moveTo(h.x * cs + Math.cos(a) * h.r * cs * 0.2, h.y * cs + Math.sin(a) * h.r * cs * 0.14); ctx.lineTo(h.x * cs + Math.cos(a) * h.r * cs * 0.85, h.y * cs + Math.sin(a) * h.r * cs * 0.6); ctx.stroke(); } ctx.restore(); }
      else if (h.type === "erupt" || h.type === "strike") {
        if (h.fin) continue; const warn = h.t > h.max - h.warn, u = warn ? 1 - (h.t - (h.max - h.warn)) / h.warn : 0; ctx.save();
        if (warn) { ctx.globalAlpha = 0.25 + 0.3 * Math.abs(Math.sin(t * 12)); ctx.fillStyle = h.type === "erupt" ? "#ff4a1a" : "#bfe0ff"; ctx.beginPath(); ctx.arc(h.x * cs, h.y * cs, h.r * cs, 0, TAU); ctx.fill(); ctx.globalAlpha = 0.9; ctx.strokeStyle = h.type === "erupt" ? "#ffb347" : "#fff"; ctx.lineWidth = 2; ctx.setLineDash([6, 5]); ctx.beginPath(); ctx.arc(h.x * cs, h.y * cs, h.r * cs * (1 - u * 0.1), 0, TAU); ctx.stroke(); ctx.setLineDash([]); }
        ctx.restore();
      }
    }
  }
  drawHazardsAir(ctx, b) {
    const cs = this.cs, t = this.t, W = COLS * cs, H = ROWS * cs;
    if (b.stormT > 0) { const a = Math.min(1, b.stormT / 1.2, (b.stormMax - b.stormT) / 1.2 + 0.2); ctx.save(); ctx.globalAlpha = 0.28 * a; ctx.fillStyle = "#d8a860"; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 0.5 * a; ctx.strokeStyle = "#f4d79a"; ctx.lineWidth = 2; for (let i = 0; i < 26; i++) { const y = ((i * 97 + t * 40) % H), x = ((i * 53 + t * 520) % (W + 200)) - 100; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 60, y - 3); ctx.stroke(); } ctx.restore(); }
    for (const h of b.hazards || []) if (h.type === "strike" && h.fin) { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.strokeStyle = "#fff"; ctx.lineWidth = 5; ctx.beginPath(); let x = h.x * cs, y = -10; ctx.moveTo(x, y); const ty = h.y * cs; for (let i = 1; i <= 7; i++) { y = ty * i / 7; x = h.x * cs + (i < 7 ? Math.sin(h.x * 9 + i * 5.3) * cs * 0.3 : 0); ctx.lineTo(x, y); } ctx.stroke(); ctx.strokeStyle = "#8fd4ff"; ctx.lineWidth = 12; ctx.globalAlpha = 0.35; ctx.stroke(); ctx.restore(); }
  }
  drawGrid(ctx, b, ui) {
    const cs = this.cs, t = this.t; if (!ui) return;
    if (ui.buildKind) { ctx.save(); ctx.globalAlpha = 0.18 + 0.1 * Math.sin(t * 4); ctx.fillStyle = "#fff"; for (let y = 0; y < ROWS; y++) for (let x = 0; x < COLS; x++) if (b.canBuild(x, y)) { ctx.beginPath(); ctx.roundRect(x * cs + 3, y * cs + 3, cs - 6, cs - 6, 6); ctx.fill(); } ctx.restore(); }
    if (ui.hover && ui.buildKind) { const { x, y } = ui.hover; if (x >= 0 && y >= 0 && x < COLS && y < ROWS) { const ok = b.canBuild(x, y); ctx.strokeStyle = ok ? "#7bff9a" : "#ff6a6a"; ctx.lineWidth = 3; ctx.beginPath(); ctx.roundRect(x * cs + 2, y * cs + 2, cs - 4, cs - 4, 8); ctx.stroke(); if (ok) { const d = TOWERS[ui.buildKind]; ctx.globalAlpha = 0.5; ctx.strokeStyle = d.color; ctx.setLineDash([6, 6]); ctx.beginPath(); ctx.arc((x + 0.5) * cs, (y + 0.5) * cs, d.range * b.mods.range * cs, 0, TAU); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1; } } }
  }
  drawRange(ctx, b, ui) {
    if (!ui || !ui.selTower || !b.towers.includes(ui.selTower)) return; const t = ui.selTower, s = b.stats(t), cs = this.cs;
    ctx.save(); ctx.strokeStyle = "rgba(255,255,255,0.8)"; ctx.fillStyle = "rgba(255,255,255,0.09)"; ctx.lineWidth = 2; ctx.setLineDash([8, 6]); ctx.lineDashOffset = -this.t * 20; ctx.beginPath(); ctx.arc(t.cx * cs, t.cy * cs, s.range * cs, 0, TAU); ctx.fill(); ctx.stroke(); ctx.restore();
    ctx.strokeStyle = "#ffe58a"; ctx.lineWidth = 3; ctx.beginPath(); ctx.roundRect(t.x * cs + 2, t.y * cs + 2, cs - 4, cs - 4, 8); ctx.stroke();
  }

  // ---------- برج ----------
  drawTower(ctx, t, b) {
    const cs = this.cs, d = TOWERS[t.kind], ev = t.evo ? d.evo[t.evo] : null, col = ev ? ev.color : d.color, x = t.cx * cs, y = t.cy * cs, tm = this.t, u = cs / 50, kind = t.kind, lvl = t.lvl;
    ctx.save(); ctx.translate(x, y);
    if (t.hitT > 0) ctx.globalAlpha = 0.6 + 0.4 * Math.sin(tm * 60);
    const pop = Math.min(1, (b.time - t.born) / 0.25), ps = 0.6 + 0.4 * pop + (1 - pop) * 0.2; ctx.scale(ps, ps);
    if (t.enemyTower) { ctx.fillStyle = "rgba(230,60,60,0.28)"; ctx.beginPath(); ctx.ellipse(0, cs * 0.18, cs * 0.52, cs * 0.3, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = "rgba(255,90,90,0.8)"; ctx.lineWidth = 2; ctx.stroke(); }
    const base = this.spr(`tb|${lvl}|${t.evo || 0}|${col}`, 70, 62, 35, 30, (g) => A.towerBase(g, lvl, col, !!ev)); this.put(ctx, base, 0, 0);
    if (ev) { this.putGlow(ctx, col, 0, -cs * 0.08, cs * 0.75, 0.55 + 0.15 * Math.sin(tm * 3)); }
    const rc = t.recoil, ang = t.ang, ek = t.evo || 0, hk = `th|${kind}|${lvl}|${ek}|${col}`;
    const head = (w, h, cx, cy) => this.spr(hk, w, h, cx, cy, (g) => A.towerHead(g, kind, lvl, t.evo, col, d.color));
    switch (kind) {
      case "bow": case "spear": { const hd = head(110, 80, 40, 40); ctx.save(); ctx.translate(0, -6 * u); ctx.rotate(ang); ctx.translate(-rc * 4 * u, 0); this.put(ctx, hd, 0, 0); ctx.restore(); ctx.fillStyle = darken(kind === "bow" ? "#7a5230" : "#5a3a1e", 0.1); ctx.beginPath(); ctx.arc(0, -4 * u, 7 * u, 0, TAU); ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,0.5)"; ctx.lineWidth = 1; ctx.stroke(); break; }
      case "catapult": { this.put(ctx, head(60, 50, 30, 28), 0, 0); const ar = this.spr(`ca|${lvl}|${ek}|${col}`, 40, 50, 20, 44, (g) => A.catapultArm(g, lvl, t.evo, col)); ctx.save(); ctx.translate(0, -4 * u); ctx.rotate(Math.cos(ang) >= 0 ? -0.6 + rc * 1.8 : 0.6 - rc * 1.8); this.put(ctx, ar, 0, 0); ctx.restore(); break; }
      case "frost": { const f = Math.sin(tm * 2 + t.id) * 3 * u; this.put(ctx, head(70, 70, 35, 38), 0, -14 * u + f); if (ev) { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.strokeStyle = col; ctx.lineWidth = 1.5; for (let i = 0; i < 3; i++) { const a = tm * 1.4 + i * TAU / 3; ctx.beginPath(); ctx.arc(Math.cos(a) * 20 * u, -14 * u + f + Math.sin(a) * 8 * u, 2 * u, 0, TAU); ctx.stroke(); } ctx.restore(); } break; }
      case "lightning": { this.put(ctx, head(70, 90, 35, 66), 0, 0); this.putGlow(ctx, col, 0, -29 * u, (16 + rc * 8) * u, 0.9); ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.strokeStyle = col; ctx.lineWidth = 1.5; for (let i = 0; i < 3; i++) { const a = tm * 5 + i * 2.1 + t.id; ctx.beginPath(); ctx.moveTo(0, -29 * u); ctx.lineTo((Math.cos(a) * 12 + Math.sin(tm * 40 + i) * 3) * u, (-29 + Math.sin(a) * 12) * u); ctx.stroke(); } ctx.restore(); break; }
      case "flame": { this.put(ctx, head(60, 60, 30, 40), 0, 0); ctx.save(); ctx.globalCompositeOperation = "lighter"; const cols = ev ? [darken(col, 0.2), col, "#ffe9a0"] : ["#ff4a1a", "#ff9d2f", "#ffe45c"]; for (let L = 0; L < 3; L++) { ctx.fillStyle = cols[L]; ctx.globalAlpha = 0.75; for (let i = 0; i < 4; i++) { const ph = tm * 7 + i * 1.7 + t.id, h = (13 - L * 3.500 + Math.sin(ph) * 4 + (i === 1 ? 7 : 0)) * u, xx = (i - 1.5) * 6 * u, w = (5 - L) * u; ctx.beginPath(); ctx.moveTo(xx - w, -8 * u); ctx.quadraticCurveTo(xx + Math.sin(ph) * 3 * u, -8 * u - h * 0.6, xx, -8 * u - h); ctx.quadraticCurveTo(xx + 3 * u, -8 * u - h * 0.5, xx + w, -8 * u); ctx.fill(); } } ctx.restore(); break; }
      case "arcane": { const f = Math.sin(tm * 2 + t.id) * 3 * u; this.put(ctx, head(70, 70, 35, 56), 0, f); this.putGlow(ctx, col, 0, -22 * u + f, 18 * u, 0.55); ctx.save(); ctx.strokeStyle = col; ctx.lineWidth = 2; for (let i = 0; i < 2; i++) { ctx.save(); ctx.translate(0, -22 * u + f); ctx.rotate(tm * (i ? -1.5 : 1.2) + i); ctx.scale(1, 0.35); ctx.beginPath(); ctx.arc(0, 0, 19 * u, 0, TAU); ctx.stroke(); ctx.restore(); } ctx.restore(); break; }
      case "poison": { this.put(ctx, head(60, 60, 30, 34), 0, 0); ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.fillStyle = col; for (let i = 0; i < 3; i++) { const ph = (tm * 0.9 + i / 3 + t.id * 0.1) % 1; ctx.globalAlpha = 0.8 * (1 - ph); ctx.beginPath(); ctx.arc((i - 1) * 6 * u, (-8 - ph * 18) * u, (2.500 + ph * 2) * u, 0, TAU); ctx.fill(); } ctx.restore(); break; }
      case "guard": { this.put(ctx, head(60, 60, 30, 36), 0, 0); break; }
      case "temple": { this.put(ctx, head(60, 70, 30, 48), 0, 0); this.putGlow(ctx, col, 0, -20 * u, (14 + Math.sin(tm * 6 + t.id) * 2) * u, 0.5); break; }
      case "bank": { this.put(ctx, head(60, 60, 30, 36), 0, 0); ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.fillStyle = col; for (let i = 0; i < 3; i++) { const ph = (tm * 0.8 + i / 3) % 1; ctx.globalAlpha = 1 - ph; ctx.beginPath(); ctx.arc((i - 1) * 8 * u, (-14 - ph * 16) * u, 3 * u, 0, TAU); ctx.fill(); } ctx.restore(); break; }
    }
    if (ev) { ctx.fillStyle = col; ctx.strokeStyle = "#fff"; ctx.lineWidth = 1; ctx.beginPath(); for (let i = 0; i < 10; i++) { const r = i % 2 ? 3.5 * u : 7 * u, a = -Math.PI / 2 + i * TAU / 10; ctx.lineTo(19 * u + Math.cos(a) * r, -26 * u + Math.sin(a) * r); } ctx.closePath(); ctx.fill(); ctx.stroke(); }
    ctx.restore();
    if (t.enemyTower) { const f = Math.max(0, t.hp / t.maxhp), w = cs * 0.8; ctx.fillStyle = "rgba(0,0,0,0.65)"; ctx.fillRect(x - w / 2, y - cs * 0.66, w, 6); ctx.fillStyle = f > 0.5 ? "#ff7a5a" : "#ff3030"; ctx.fillRect(x - w / 2 + 1, y - cs * 0.66 + 1, (w - 2) * f, 4); ctx.fillStyle = "#e84a4a"; ctx.fillRect(x - 1, y - cs * 1.0, 2, cs * 0.3); ctx.beginPath(); ctx.moveTo(x + 1, y - cs * 1.0); ctx.lineTo(x + 10, y - cs * 0.9); ctx.lineTo(x + 1, y - cs * 0.83); ctx.fill(); }
    if (t.aura > 0 || b.buffT > 0) { this.putGlow(ctx, b.buffT > 0 ? "#ff5a5a" : "#ffd250", x + cs * 0.3, y - cs * 0.4, cs * 0.1, 0.9); }
  }

  // ---------- دشمن و سرباز ----------
  // پیش‌ساخت اسپرایت‌ها در زمان بیکاری، تا شروع نبرد لگ نداشته باشد
  prewarm(b, unlocked) {
    const cv = document.createElement("canvas"); cv.width = cv.height = 4; const c = cv.getContext("2d"), jobs = [];
    const keys = Object.keys(ENEMIES);
    for (const k of keys) for (let f = 0; f < 4; f++) jobs.push(() => { const def = ENEMIES[k]; this.t = f * 0.3; this.drawEnemy(c, { x: 0, y: 0, wob: 0, dx: 1, dy: 0, kind: k, def, flying: !!def.flying, speed: def.speed || 1, boss: false, hitT: 0, absorb: 0, chargeT: 0, slowT: 0, stunT: 0, mark: 0, burnT: 0, hp: 1, maxhp: 1, team: "enemy" }); });
    if (b.map && b.map.boss) for (let f = 0; f < 4; f++) jobs.push(() => { this.t = f * 0.3; this.drawEnemy(c, { x: 0, y: 0, wob: 0, dx: 1, dy: 0, kind: "boss", def: ENEMIES.boss, flying: false, speed: 0.4, boss: true, ability: b.map.boss.ability, name: "", hitT: 0, absorb: 0, chargeT: 0, slowT: 0, stunT: 0, mark: 0, burnT: 0, hp: 1, maxhp: 1, team: "enemy" }); });
    for (const k of unlocked || TOWER_ORDER) { const d = TOWERS[k]; for (let l = 1; l <= 5; l++) jobs.push(() => this.drawTower(c, { kind: k, lvl: l, evo: 0, cx: 0, cy: 0, hitT: 0, born: -9, recoil: 0, ang: 0, cool: 0, kills: 0 }, { time: 0 })); for (const ev of Object.keys(d.evo || {})) jobs.push(() => this.drawTower(c, { kind: k, lvl: 5, evo: ev, cx: 0, cy: 0, hitT: 0, born: -9, recoil: 0, ang: 0, cool: 0, kills: 0 }, { time: 0 })); }
    let i = 0; const step = () => { if (i >= jobs.length || b.state === "over") return; const t0 = performance.now(); while (i < jobs.length && performance.now() - t0 < 5) { try { jobs[i](); } catch (e) { /* ignore */ } i++; } setTimeout(step, 14); }; setTimeout(step, 120);
  }
  drawEnemy(ctx, e) {
    const cs = this.cs, b = this.b, x = e.x * cs, y = e.y * cs, tm = this.t + e.wob, tint = b.map.enemyTint, acc = b.map.col.acc, face = e.dx >= 0 ? 1 : -1, troop = e.team === "troop";
    const rU = (troop ? e.def.r : e.def.r) * 50, k = e.kind, fl = e.flying, frame = Math.floor((tm * (fl ? 9 : 3 + e.speed * 3)) % 4);
    const R = rU * (k === "boss" ? 1 : 1);
    if (!fl) this.shadow(ctx, x, y + R * cs / 50 * 0.9, R * cs / 50);
    const S = Math.ceil(R * 4.4), key = (troop ? "tr|" : "en|") + k + "|" + (troop ? "" : tint) + "|" + frame;
    const bk = !troop && e.boss && e.ability, sp = this.spr(bk ? `bs|${bk}|${frame}` : key, S * 1.0, S * 1.0, S / 2, S * 0.55, (g) => (bk ? A.bossSprite(g, bk, rU, frame) : troop ? A.troopSprite(g, k, rU, frame, TROOPS[k].color) : A.enemySprite(g, k, rU, frame, tint, acc)));
    const bob = fl ? Math.sin(tm * 5) * 3 - cs * 0.28 : Math.abs(Math.sin(tm * (e.speed * 6 + 4))) * -rU * cs / 50 * 0.12;
    if (e.boss) { this.putGlow(ctx, tint, x, y + bob, R * cs / 50 * 2.6, 0.5 + 0.15 * Math.sin(tm * 3)); }
    if (troop) { ctx.strokeStyle = "rgba(80,160,255,0.9)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(x, y + R * cs / 50 * 0.9, R * cs / 50 * 1.2, R * cs / 50 * 0.5, 0, 0, TAU); ctx.stroke(); }
    this.put(ctx, sp, x, y + bob, face);
    if (e.hitT > 0) { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = 0.55; this.put(ctx, sp, x, y + bob, face); ctx.restore(); }
    const r = R * cs / 50;
    if (e.absorb > 0) { ctx.strokeStyle = "#8fd4ff"; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y + bob, r * 1.5, 0, TAU); ctx.stroke(); }
    if (e.chargeT > 0) { ctx.strokeStyle = "#ffb347"; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(x - face * r * 2, y - r * 0.4); ctx.lineTo(x - face * r * 1.3, y - r * 0.4); ctx.moveTo(x - face * r * 2.2, y + r * 0.2); ctx.lineTo(x - face * r * 1.3, y + r * 0.2); ctx.stroke(); }
    if (e.slowT > 0 && e.stunT <= 0) { ctx.strokeStyle = "rgba(160,230,255,0.9)"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, r * 1.25, 0, TAU); ctx.stroke(); }
    if (e.stunT > 0) { ctx.fillStyle = "rgba(180,235,255,0.5)"; ctx.beginPath(); ctx.arc(x, y, r * 1.2, 0, TAU); ctx.fill(); ctx.fillStyle = "#ffe45c"; for (let i = 0; i < 3; i++) { const a = this.t * 5 + i * 2.1; ctx.fillRect(x + Math.cos(a) * r - 2, y - r * 1.8 + Math.sin(a) * 4 - 2, 4, 4); } }
    if (e.mark > 0) { ctx.strokeStyle = "#ff5a8a"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y - r * 2.1, 4, 0, TAU); ctx.moveTo(x - 7, y - r * 2.1); ctx.lineTo(x + 7, y - r * 2.1); ctx.moveTo(x, y - r * 2.1 - 7); ctx.lineTo(x, y - r * 2.1 + 7); ctx.stroke(); }
    if (e.burnT > 0) { this.putGlow(ctx, "#ff7a2e", x, y - r * 0.4, r * 1.1, 0.5); }
    if (e.hp < e.maxhp || e.boss) { const w = Math.max(cs * 0.5, r * 2.2), yy = y - r * (fl ? 2.8 : 2.1) - (e.boss ? 6 : 2); ctx.fillStyle = "rgba(0,0,0,0.7)"; ctx.fillRect(x - w / 2, yy, w, e.boss ? 7 : 4.5); const f = Math.max(0, e.hp / e.maxhp); ctx.fillStyle = troop ? "#7bd8ff" : f > 0.5 ? "#6cf08a" : f > 0.25 ? "#ffd24a" : "#ff5a4a"; ctx.fillRect(x - w / 2 + 1, yy + 1, (w - 2) * f, e.boss ? 5 : 2.5); if (e.absorb > 0) { ctx.fillStyle = "#8fd4ff"; ctx.fillRect(x - w / 2 + 1, yy - 2, (w - 2) * Math.min(1, e.absorb / e.maxhp * 4), 2); } }
    if (e.boss && e.name) { ctx.font = `bold ${Math.round(cs * 0.26)}px ${FONT}`; ctx.textAlign = "center"; ctx.fillStyle = "#ffd24a"; ctx.strokeStyle = "rgba(0,0,0,0.8)"; ctx.lineWidth = 3; ctx.strokeText(e.name, x, y - r * 2.1 - 14); ctx.fillText(e.name, x, y - r * 2.1 - 14); }
  }

  drawMan(ctx, m, t) {
    const cs = this.cs, u = cs / 50, x = m.x * cs, y = m.y * cs, col = t.evo ? TOWERS.guard.evo[t.evo].color : "#9ab8ff", big = t.evo === "b" ? 1.2 : 1;
    const sp = this.spr(`man|${col}`, 70, 80, 35, 52, (gg) => A.troopSprite(gg, "shield", 0.3, 0, col));
    this.shadow(ctx, x, y + 14 * u, 9 * u); const lunge = Math.sin(Math.PI * (1 - m.atk)) * m.atk * 6 * u * m.face;
    ctx.save(); ctx.translate(x + lunge, y); ctx.scale(big, big); ctx.translate(-x - lunge, -y); this.put(ctx, sp, x + lunge, y + Math.sin(this.t * 6 + m.id) * 1 * u, m.face); ctx.restore();
    const w = cs * 0.5, f = Math.max(0, m.hp / m.maxhp); ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.fillRect(x - w / 2, y - cs * 0.55, w, 4); ctx.fillStyle = "#7bd88f"; ctx.fillRect(x - w / 2 + 1, y - cs * 0.55 + 1, (w - 2) * f, 2);
  }
  drawGhost(ctx, g) {
    const cs = this.cs, u = cs / 50, x = g.x * cs, y = g.y * cs, rise = g.born, fade = Math.min(1, g.life / 2), tm = this.t;
    const sp = this.spr(`ghost|${g.kind}`, 70, 80, 35, 52, (gg) => A.troopSprite(gg, g.kind, 0.3, 0, "#9fe8ff"));
    ctx.save(); ctx.globalAlpha = 0.68 * fade * rise; this.shadow(ctx, x, y + 14 * u, 10 * u);
    this.putGlow(ctx, "#7fd8ff", x, y - 6 * u, 26 * u, 0.55 * fade * rise);
    ctx.beginPath(); ctx.rect(x - cs, y - cs * 1.4, cs * 2, cs * 1.4 * rise + cs * 0.55); ctx.clip();
    const bob = Math.sin(tm * 4 + g.seed) * 2 * u - (1 - rise) * 22 * u, lunge = Math.sin(Math.PI * (1 - g.swing)) * g.swing * 7 * u * g.face;
    this.put(ctx, sp, x + lunge, y + bob + (1 - rise) * 18 * u, g.face);
    ctx.globalCompositeOperation = "lighter"; ctx.fillStyle = "rgba(120,220,255,.25)"; ctx.beginPath(); ctx.ellipse(x, y + bob - 4 * u, 9 * u, 13 * u, 0, 0, TAU); ctx.fill();
    ctx.restore();
    if (rise < 1) { ctx.fillStyle = "rgba(120,95,60,.7)"; for (let i = 0; i < 5; i++) { const a = i * 1.3 + tm * 3; ctx.beginPath(); ctx.arc(x + Math.cos(a) * 9 * u, y + 12 * u - (rise * 10 + Math.sin(a) * 3) * u, 2 * u, 0, TAU); ctx.fill(); } }
  }

  // ---------- قهرمان ----------
  drawHero(ctx, h, ui) {
    const cs = this.cs, x = h.x * cs, y = h.y * cs, tm = this.t, u = cs / 50, col = h.def.color; this.shadow(ctx, x, y + 21 * u, 15 * u);
    this.putGlow(ctx, col, x, y - 6 * u, 36 * u, 0.4 + 0.1 * Math.sin(tm * 3));
    const fr = h.moving ? Math.floor(tm * 9) % 4 : 0, key = `hero|${h.key}|${fr}|${h.moving ? 1 : 0}`, sp = this.spr(key, 90, 110, 45, 70, (g) => A.heroSprite(g, h.key, fr, h.moving));
    const bob = h.moving ? Math.abs(Math.sin(tm * 12)) * -3 * u : Math.sin(tm * 2.5) * -1.2 * u, flip = h.face >= 0 ? 1 : -1;
    const swp = Math.min(1, h.swing), prog = 1 - swp, lunge = h.swing > 0 ? Math.sin(Math.PI * prog) * cs * (h.def.melee ? 0.26 : 0.08) * flip : 0, squash = h.swing > 0 ? 1 + Math.sin(Math.PI * prog) * 0.08 : 1;
    if (h.swing > 0.05 && h.def.melee) { ctx.save(); ctx.globalAlpha = 0.28 * swp; this.put(ctx, sp, x - lunge * 0.8, y + bob, flip); ctx.restore(); }
    ctx.save(); ctx.translate(x + lunge, y + bob); ctx.scale(1, squash); ctx.translate(-x - lunge, -y - bob); this.put(ctx, sp, x + lunge, y + bob, flip); ctx.restore();
    ctx.save(); ctx.translate(x + lunge, y + bob); ctx.scale(u * flip, u); A.heroWeapon(ctx, h.key, swp);
    if (h.swing > 0.08 && h.def.melee) { // رد درخشان شمشیر
      ctx.globalCompositeOperation = "lighter"; const a0 = -0.9 + swp * 1.9; ctx.lineCap = "round";
      for (let k = 0; k < 3; k++) { ctx.strokeStyle = k === 0 ? "#fff" : col; ctx.globalAlpha = (0.85 - k * 0.25) * swp; ctx.lineWidth = (7 - k * 2) * (0.4 + swp); ctx.beginPath(); ctx.arc(9, -3, 26 + k * 2, -Math.PI * 0.5 - a0 - 1.5 + k * 0.1, -Math.PI * 0.5 - a0 + 0.1); ctx.stroke(); }
    }
    ctx.restore();
    if (h.whirl > 0) { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.strokeStyle = col; ctx.lineWidth = 4; ctx.globalAlpha = 0.7; ctx.beginPath(); ctx.arc(x, y, cs * (1.4 + 0.2 * Math.sin(tm * 20)), tm * 18, tm * 18 + 4); ctx.stroke(); ctx.restore(); }
    ctx.font = `bold ${Math.round(cs * 0.22)}px ${FONT}`; ctx.textAlign = "center"; ctx.fillStyle = "#fff"; ctx.strokeStyle = "rgba(0,0,0,0.8)"; ctx.lineWidth = 3; const nm = h.def.name.split(" ")[0]; ctx.strokeText(nm, x, y + cs * 0.62); ctx.fillText(nm, x, y + cs * 0.62);
    if (h.def.melee && h.tx >= 0) { // محدوده‌ی تعقیب: نمایش حلقه‌ی لنگر
      const sel = ui && ui.selHero === h; if (sel || h.engaged) { ctx.save(); ctx.strokeStyle = sel ? "rgba(255,229,138,0.7)" : "rgba(255,120,90,0.35)"; ctx.lineWidth = 2; ctx.setLineDash([8, 7]); ctx.beginPath(); ctx.arc(h.tx * cs, h.ty * cs, h.def.leash * cs, 0, TAU); ctx.stroke(); ctx.setLineDash([]); ctx.strokeStyle = "rgba(255,255,255,0.18)"; ctx.beginPath(); ctx.arc(h.tx * cs, h.ty * cs, h.def.aggro * cs, 0, TAU); ctx.stroke(); ctx.restore(); }
      ctx.fillStyle = "rgba(255,255,255,0.6)"; ctx.beginPath(); ctx.arc(h.tx * cs, h.ty * cs, 3.5, 0, TAU); ctx.fill();
    }
    if (ui && ui.selHero === h) { ctx.strokeStyle = "#ffe58a"; ctx.lineWidth = 3; ctx.setLineDash([5, 4]); ctx.beginPath(); ctx.arc(x, y, cs * 0.55, 0, TAU); ctx.stroke(); ctx.setLineDash([]); if (!h.def.melee) { ctx.strokeStyle = "rgba(255,255,255,0.35)"; ctx.beginPath(); ctx.arc(x, y, h.def.range * this.b.mods.range * cs, 0, TAU); ctx.stroke(); } }
    if (h.tx >= 0 && h.moving && !h.def.melee) { ctx.strokeStyle = "rgba(255,255,255,0.5)"; ctx.beginPath(); ctx.arc(h.tx * cs, h.ty * cs, 6, 0, TAU); ctx.stroke(); }
    if (h.hpMax) { const w = cs * 0.8, f = Math.max(0, h.hp / h.hpMax); ctx.fillStyle = "rgba(0,0,0,0.65)"; ctx.fillRect(x - w / 2, y - cs * 0.9, w, 5); ctx.fillStyle = "#7bd8ff"; ctx.fillRect(x - w / 2 + 1, y - cs * 0.9 + 1, (w - 2) * f, 3); }
  }

  // ---------- پرتابه‌ها و افکت‌ها ----------
  drawProj(ctx, b) {
    const cs = this.cs; for (const p of b.proj) {
      const x = p.x * cs, y = p.y * cs;
      if (p.type === "arrow" || p.type === "tarrow") { ctx.save(); ctx.translate(x, y); ctx.rotate(p.ang || 0); ctx.strokeStyle = p.color; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(-cs * 0.25, 0); ctx.lineTo(cs * 0.12, 0); ctx.stroke(); ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.moveTo(cs * 0.12, -3); ctx.lineTo(cs * 0.22, 0); ctx.lineTo(cs * 0.12, 3); ctx.fill(); ctx.restore(); }
      else if (p.type === "spear") { ctx.save(); ctx.translate(x, y); ctx.rotate(p.ang || 0); ctx.strokeStyle = "#6a4a2a"; ctx.lineWidth = 3.5; ctx.beginPath(); ctx.moveTo(-cs * 0.4, 0); ctx.lineTo(cs * 0.15, 0); ctx.stroke(); ctx.fillStyle = p.color; ctx.beginPath(); ctx.moveTo(cs * 0.12, -5); ctx.lineTo(cs * 0.3, 0); ctx.lineTo(cs * 0.12, 5); ctx.fill(); ctx.restore(); }
      else if (p.type === "lob") { const hh = (p.h || 0) * cs; ctx.fillStyle = "rgba(0,0,0,0.3)"; ctx.beginPath(); ctx.ellipse(x, y, cs * 0.12, cs * 0.06, 0, 0, TAU); ctx.fill(); ctx.fillStyle = "#3a3a44"; ctx.beginPath(); ctx.arc(x, y - hh, cs * 0.14, 0, TAU); ctx.fill(); this.putGlow(ctx, p.color, x, y - hh, cs * 0.22, 0.6); }
      else if (p.type === "orb" || p.type === "shard") { this.putGlow(ctx, p.color, x, y, cs * (p.nova ? 0.42 : 0.3), 1); ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(x, y, cs * 0.07, 0, TAU); ctx.fill(); }
    }
  }
  drawFx(ctx, b) {
    const cs = this.cs; for (const f of b.fx) {
      const u = f.life / f.max;
      if (f.type === "p") { ctx.globalCompositeOperation = f.add ? "lighter" : "source-over"; ctx.globalAlpha = Math.max(0, u); ctx.fillStyle = f.color; ctx.beginPath(); ctx.arc(f.x * cs, f.y * cs, f.size * cs * (f.grow ? 1 + (1 - u) * f.grow : 1), 0, TAU); ctx.fill(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over"; }
      else if (f.type === "ring") { ctx.globalCompositeOperation = "lighter"; ctx.strokeStyle = f.color; ctx.globalAlpha = u; ctx.lineWidth = 3 + 4 * u; ctx.beginPath(); ctx.arc(f.x * cs, f.y * cs, f.r * cs * (1 - u * u), 0, TAU); ctx.stroke(); ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over"; }
      else if (f.type === "bolt") { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = Math.min(1, u * 1.6); for (const [w, c] of [[6, f.color + "55"], [2, "#fff"]]) { ctx.strokeStyle = c; ctx.lineWidth = w; ctx.beginPath(); for (let i = 0; i < f.pts.length - 1; i++) { const a = f.pts[i], z = f.pts[i + 1], n = 6; for (let k = 0; k <= n; k++) { const tt = k / n, jx = k && k < n ? (Math.sin(f.seed + i * 9 + k * 7) * 0.12) : 0, jy = k && k < n ? (Math.cos(f.seed * 2 + i * 5 + k * 3) * 0.12) : 0; const px = (a.x + (z.x - a.x) * tt + jx) * cs, py = (a.y + (z.y - a.y) * tt + jy) * cs; k || i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } } ctx.stroke(); } ctx.restore(); }
      else if (f.type === "beam") { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = u; ctx.strokeStyle = f.color; ctx.lineWidth = f.w * cs * (0.4 + u); ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(f.x * cs, f.y * cs); ctx.lineTo(f.x2 * cs, f.y2 * cs); ctx.stroke(); ctx.strokeStyle = "#fff"; ctx.lineWidth = f.w * cs * 0.3; ctx.stroke(); ctx.restore(); }
      else if (f.type === "text") { ctx.globalAlpha = Math.min(1, u * 2); ctx.font = `bold ${Math.round(cs * 0.3 * f.size)}px ${FONT}`; ctx.textAlign = "center"; ctx.strokeStyle = "rgba(0,0,0,0.85)"; ctx.lineWidth = 3; ctx.fillStyle = f.color; ctx.strokeText(f.txt, f.x * cs, f.y * cs); ctx.fillText(f.txt, f.x * cs, f.y * cs); ctx.globalAlpha = 1; }
      else if (f.type === "coin") { ctx.globalAlpha = Math.min(1, u * 2); ctx.fillStyle = "#ffd24a"; ctx.beginPath(); ctx.arc(f.x * cs, f.y * cs - 4, 4, 0, TAU); ctx.fill(); ctx.strokeStyle = "#a8700c"; ctx.lineWidth = 1; ctx.stroke(); ctx.globalAlpha = 1; }
      else if (f.type === "slash") { ctx.save(); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = u; ctx.strokeStyle = f.color; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(f.x * cs, f.y * cs, cs * 0.4, f.a, f.a + 1.8); ctx.stroke(); ctx.restore(); }
      else if (f.type === "bird") { const x = f.x * cs, y = f.y * cs, wing = Math.sin(this.t * 16) * cs * 0.5; ctx.save(); this.putGlow(ctx, "#dcf5ff", x, y, cs * 2.2, Math.min(1, u * 2) * 0.7); ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = Math.min(1, u * 2); ctx.fillStyle = "#fff"; for (const s of [-1, 1]) { ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x - cs * 0.5, y + s * cs * 1.2 - wing * s, x - cs * 1.6, y + s * cs * 0.3); ctx.quadraticCurveTo(x - cs * 0.6, y + s * cs * 0.1, x, y); ctx.fill(); } ctx.beginPath(); ctx.ellipse(x, y, cs * 0.5, cs * 0.2, 0, 0, TAU); ctx.fill(); ctx.restore(); }
    }
  }
}
