// ملت‌ها، روابط و دیپلماسی نقشه‌ی بزرگ (وضعیت پایدار در S.ow.fac)
import { NEIGHBORS } from "./data.js";
const hexRGB = (h) => { const n = parseInt(h.slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; };
export const FACS = NEIGHBORS.map((n) => ({ id: n.id, name: n.name, leader: n.ruler, emoji: n.emoji, css: n.color, rgb: hexRGB(n.color), power: n.power }));
export const ME = { id: "me", name: "کشور من", leader: "تو", emoji: "🏠", css: "#4f86ff", rgb: [0.2, 0.42, 0.9] };
export const fac = (id) => (id === "me" ? ME : FACS.find((f) => f.id === id) || null);
export const REL = { ally: "هم‌پیمان", neutral: "بی‌طرف", war: "جنگ" }, RELC = { ally: "#5be07a", neutral: "#ffd24a", war: "#ff5a4a" };
let F = null, SITES = [];
const key = (a, b) => (a < b ? a + "|" + b : b + "|" + a), hh = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return ((h >>> 0) % 10007) / 10007; };
export const state = () => F;
// sites: همه‌ی آبادی‌ها {id,kind,x,y,n?}
export function init(ow, sites, conquered) {
  F = ow.fac && ow.fac.v === 1 ? ow.fac : (ow.fac = { v: 1, rel: {}, me: {}, fav: {}, own: {}, str: {}, t: 0, since: {}, log: [] }); SITES = sites;
  FACS.forEach((f, i) => { if (!F.me[f.id]) F.me[f.id] = "neutral"; if (F.fav[f.id] === undefined) F.fav[f.id] = 0; if (!F.str[f.id]) F.str[f.id] = 16 + i * 5; });
  let wars = 0; for (let i = 0; i < FACS.length; i++) for (let j = i + 1; j < FACS.length; j++) { const k = key(FACS[i].id, FACS[j].id); if (!F.rel[k]) { F.rel[k] = hh(k) < 0.22 ? "war" : "neutral"; } if (F.rel[k] === "war") wars++; }
  if (wars < 2) { F.rel[key("n2", "n3")] = "war"; F.rel[key("n4", "n5")] = "war"; }
  const castles = sites.filter((s) => s.kind === "castle"), home = sites.find((s) => s.kind === "home");
  for (const s of sites) { if (s.kind === "camp" || s.kind === "mine") continue; if (F.own[s.id] === undefined) { if (s.kind === "castle") F.own[s.id] = s.n.id; else if (s.kind === "home") F.own[s.id] = "me"; else { let b = home, bd = Math.hypot(home.x - s.x, home.y - s.y) * 0.8; for (const c of castles) { const d = Math.hypot(c.x - s.x, c.y - s.y); if (d < bd) { bd = d; b = c; } } F.own[s.id] = b === home ? "me" : b.n.id; } } }
  for (const c of castles) if (conquered[c.n.id]) F.own[c.id] = "me"; else if (F.own[c.id] === "me") F.own[c.id] = c.n.id;
  recalc();
}
export const owner = (id) => (F && F.own[id]) || null;
export const setOwner = (id, f) => { if (F) { F.own[id] = f; recalc(); } };
export const sitesOf = (f) => SITES.filter((s) => F.own[s.id] === f);
export const alive = (f) => sitesOf(f).length > 0;
export function recalc() { for (const f of FACS) { const ss = sitesOf(f.id), base = ss.reduce((a, s) => a + (s.kind === "castle" ? 10 : s.kind === "town" ? 6 : 3), 0); F.str[f.id] = Math.round(8 + base * 2.2 + f.power * 0.25); } }
export const relMe = (f) => (F.me[f] || "neutral");
export function relAB(a, b) { if (a === b) return "ally"; if (a === "me") return relMe(b); if (b === "me") return relMe(a); return F.rel[key(a, b)] || "neutral"; }
export function setRel(a, b, r) { if (a === "me") F.me[b] = r; else if (b === "me") F.me[a] = r; else F.rel[key(a, b)] = r; F.since[a === "me" ? b : key(a, b)] = F.t; }
export const hostileToMe = (f) => relMe(f) === "war";
export const garrison = (s) => { const o = F.own[s.id]; const base = s.kind === "castle" ? 16 : s.kind === "town" ? 10 : 5; return Math.round(base + (o && o !== "me" ? F.str[o] * 0.18 : 4)); };
// ----- دیپلماسی بازیکن -----
export const giftCost = (f, lvl) => Math.round(250 * (1 + lvl * 0.1));
export function gift(f) { F.fav[f] = Math.min(8, (F.fav[f] || 0) + 1); }
export function canAlly(f) { return relMe(f) === "neutral" && F.fav[f] >= 2; }
export function declareWar(f) { setRel("me", f, "war"); F.fav[f] = Math.min(F.fav[f], -2); }
export function makePeace(f) { if (F.fav[f] < 0) return false; setRel("me", f, "neutral"); return true; }
export function makeAlly(f) { if (!canAlly(f)) return false; setRel("me", f, "ally"); return true; }
// ----- هوش مصنوعی: هر چند ثانیه یک رویداد دیپلماتیک؛ پیام‌ها برگردانده می‌شوند -----
let acc = 0;
export function tick(dt) {
  F.t += dt; acc += dt; const out = []; if (acc < 18) return out; acc = 0;
  const as = FACS.filter((f) => alive(f.id)); if (as.length < 2) return out;
  const a = as[(Math.random() * as.length) | 0]; let b = as[(Math.random() * as.length) | 0]; if (a === b) return out;
  const r = relAB(a.id, b.id), k = key(a.id, b.id), age = F.t - (F.since[k] || 0);
  if (r === "neutral" && Math.random() < 0.38) { setRel(a.id, b.id, "war"); out.push(`⚔️ ${a.name} به ${b.name} اعلان جنگ داد`); }
  else if (r === "war" && age > 80 && Math.random() < 0.35) { setRel(a.id, b.id, "neutral"); out.push(`🕊️ صلح میان ${a.name} و ${b.name}`); }
  else if (r === "neutral" && Math.random() < 0.15) { const c = as.find((x) => x !== a && x !== b && relAB(x.id, b.id) === "war" && relAB(x.id, a.id) === "war"); if (c) { setRel(a.id, b.id, "ally"); out.push(`🤝 ${a.name} و ${b.name} علیه ${c.name} هم‌پیمان شدند`); } }
  // رابطه با بازیکن
  const m = as[(Math.random() * as.length) | 0], rm = relMe(m.id), am = F.t - (F.since[m.id] || 0);
  if (rm === "neutral" && F.fav[m.id] <= -1 && Math.random() < 0.3) { setRel("me", m.id, "war"); out.push(`🚩 ${m.name} به تو اعلان جنگ داد!`); }
  else if (rm === "war" && am > 100 && F.fav[m.id] >= 0 && Math.random() < 0.25) { setRel("me", m.id, "neutral"); out.push(`🕊️ ${m.name} پیشنهاد صلح داد و پذیرفته شد`); }
  else if (rm === "neutral" && Math.random() < 0.05 && F.str[m.id] > 40) { F.fav[m.id]--; }
  return out;
}
