// پیش‌تنظیم کیفیت گرافیک (مثل بازی‌های موبایل): خودکار بر اساس دستگاه، قابل تغییر در تنظیمات + گزارش کارایی برای عیب‌یابی
import { S } from "./save.js";
const TIERS = {
  low: { name: "کم (روان‌ترین)", scale: 0.62, dpr: 1.2, inst: 2600, tri: 70000, lod: 22, sm: 12, res: 26, cap30: true, puff: 0.35 },
  mid: { name: "متوسط", scale: 0.8, dpr: 1.4, inst: 5500, tri: 130000, lod: 30, sm: 17, res: 16, cap30: false, puff: 0.7 },
  high: { name: "بالا", scale: 1, dpr: 2, inst: 9000, tri: 200000, lod: 38, sm: 22, res: 12, cap30: false, puff: 1 },
};
const touch = () => (navigator.maxTouchPoints || 0) > 0;
export function tierName() {
  const s = (S.settings && S.settings.gfx) || "auto";
  if (s !== "auto" && TIERS[s]) return s;
  if (!touch()) return "high";
  return (navigator.deviceMemory || 4) >= 8 ? "mid" : "low";
}
export const gfx = () => TIERS[tierName()];
export const TIER_LIST = TIERS;
// ---- گزارش کارایی (آخرین اجرا) ----
const KEY = "bastion_perf_log";
let ring = [];
export function logPerf(scene, st) {
  try {
    const m = performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : -1;
    ring.push([new Date().toISOString().slice(11, 19), scene, st.fps | 0, st.ms | 0, st.tris | 0, st.scale, m, tierName()].join(" "));
    if (ring.length > 40) ring.shift(); localStorage.setItem(KEY, ring.join("\n"));
  } catch (_) {}
}
export function logEvt(t) { try { ring.push(new Date().toISOString().slice(11, 19) + " ! " + t); if (ring.length > 40) ring.shift(); localStorage.setItem(KEY, ring.join("\n")); } catch (_) {} }
export function lastPerfLog() { try { return localStorage.getItem(KEY) || ""; } catch (_) { return ""; } }
addEventListener("error", (e) => logEvt("err " + String(e.message).slice(0, 80)));
addEventListener("unhandledrejection", (e) => logEvt("rej " + String(e.reason && e.reason.message || e.reason).slice(0, 80)));
document.addEventListener("visibilitychange", () => logEvt(document.hidden ? "hidden" : "visible"));
