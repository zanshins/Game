// پیش‌تنظیم کیفیت گرافیک (مثل بازی‌های موبایل): خودکار بر اساس دستگاه، قابل تغییر در تنظیمات + گزارش کارایی برای عیب‌یابی
import { S } from "./save.js";
const TIERS = {
  low: { grass: 64, cell: 1.3, tsz: 0.7, name: "کم (روان‌ترین)", scale: 0.9, dpr: 1.5, inst: 3200, tri: 90000, lod: 24, sm: 13, res: 22, tex: 1280, cap30: false, puff: 0.5, msaa: 0, floor: 0.72 },
  mid: { grass: 96, cell: 1.0, tsz: 0.5, name: "متوسط", scale: 1, dpr: 2, inst: 6500, tri: 150000, lod: 32, sm: 18, res: 15, tex: 1792, cap30: false, puff: 0.8, msaa: 0, floor: 0.78 },
  high: { grass: 128, cell: 0.8, tsz: 0.4, name: "بالا", scale: 1, dpr: 2.5, inst: 9500, tri: 230000, lod: 40, sm: 22, res: 11, tex: 2304, cap30: false, puff: 1, msaa: 4, floor: 0.85 },
  ultra: { grass: 160, cell: 0.65, tsz: 0.32, name: "فوق‌العاده (گوشی‌های قوی)", scale: 1, dpr: 3, inst: 12000, tri: 320000, lod: 48, sm: 26, res: 9, tex: 3072, cap30: false, puff: 1, msaa: 4, floor: 0.9 },
};
const touch = () => (navigator.maxTouchPoints || 0) > 0;
export function tierName() {
  const s = (S.settings && S.settings.gfx) || "auto";
  if (s !== "auto" && TIERS[s]) return s;
  if (!touch()) return "high";
  const mem = navigator.deviceMemory || 4, cores = navigator.hardwareConcurrency || 4;
  if (mem >= 8 && cores >= 8) return "high";
  if (mem >= 4 && cores >= 6) return "mid";
  return mem >= 4 ? "mid" : "low";
}
export const gfx = () => TIERS[tierName()];
export const TIER_LIST = TIERS;
// ---- گزارش کارایی (آخرین اجرا) ----
const KEY = "bastion_perf_log";
let ring = [];
export function logPerf(scene, st) {
  try {
    const m = performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1048576) : -1;
    ring.push([new Date().toISOString().slice(11, 19), scene, st.fps | 0, st.ms | 0, st.tris | 0, st.scale, m, tierName()].join(" "));
    if (ring.length > 40) ring.shift(); localStorage.setItem(KEY, ring.join("\n"));
  } catch (_) {}
}
export function logEvt(t) { try { ring.push(new Date().toISOString().slice(11, 19) + " ! " + t); if (ring.length > 40) ring.shift(); localStorage.setItem(KEY, ring.join("\n")); } catch (_) {} }
export function lastPerfLog() { try { return localStorage.getItem(KEY) || ""; } catch (_) { return ""; } }
addEventListener("error", (e) => logEvt("err " + String(e.message).slice(0, 80)));
addEventListener("unhandledrejection", (e) => logEvt("rej " + String(e.reason && e.reason.message || e.reason).slice(0, 80)));
document.addEventListener("visibilitychange", () => logEvt(document.hidden ? "hidden" : "visible"));
