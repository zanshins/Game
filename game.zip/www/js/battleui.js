// صفحه‌ی نبرد: ساخت DOM، ورودی لمسی، حلقه‌ی بازی
import { COLS, ROWS, TOWERS, TOWER_ORDER, HEROES, TROOPS, TROOP_ORDER, MAX_ENERGY, ATTACK_TIME, fa, faTime } from "./data.js";
import { Battle } from "./battle.js";
import { Renderer } from "./render.js";
import { Sound } from "./audio.js";
import { S, saveSoon } from "./save.js";

const $ = (s, r = document) => r.querySelector(s);
const MODE_LABEL = { first: "اولین", close: "نزدیک", strong: "قوی‌ترین" };
let active = null;
export function pauseActive() { if (active) active.setPause(true); }
export function backActive() { if (active) { active.togglePause(); return true; } return false; }

export function startBattle(cfg, onExit) {
  const b = new Battle(cfg), atk = cfg.mode === "attack", map = b.map;
  b.speed = atk ? 1 : S.settings.speed || 1; b.autoStart = !atk && !!S.settings.auto;
  const ui = { buildKind: null, selTower: null, selHero: null, placeHero: -1, hover: null, cell: null, paused: false };
  document.body.classList.add("inbattle");
  const kinds = atk ? [] : TOWER_ORDER;
  $("#app").innerHTML = `<div id="battle"><div id="stage"><canvas id="cv"></canvas>
    <div id="hud"><button class="hbtn" id="bPause">⏸</button><button class="hbtn" id="bSpeed">×${fa(b.speed)}</button>${atk ? "" : `<button class="hbtn ${b.autoStart ? "on" : ""}" id="bAuto" title="شروع خودکار">A</button>`}<div style="flex:1"></div>${atk ? "" : `<button class="btn g" id="bWave" style="padding:7px 12px;font-size:13px;white-space:nowrap">▶ شروع نبرد</button>`}
    ${atk ? `<div class="hchip">🚪 <span id="hGate"></span></div><div class="hchip">⏱️ <span id="hTime"></span></div>` : `<div class="hchip">❤️ <span id="hLives"></span></div><div class="hchip">🪙 <span id="hGold"></span></div><div class="hchip">🌊 <span id="hWave" dir="ltr"></span></div><div class="hchip" id="hCd" style="display:none">⏳ <span id="hCdv"></span></div>`}</div>
    <div id="panel"></div><div id="hint" style="display:none"></div>
    </div>
    <div id="tray">${atk ? `<div class="energy" id="eBar">${Array.from({ length: MAX_ENERGY }, () => "<i></i>").join("")}</div><div class="tgrid">${cfg.troops.map((k) => `<div class="tb" data-troop="${k}"><div class="i">${TROOPS[k].emoji}</div><div class="n">${TROOPS[k].name}</div><div class="p">⚡${fa(TROOPS[k].energy)}</div></div>`).join("")}<div class="tb" data-spell="rally"><div class="i">📯</div><div class="n">یورش</div><div class="p">+سرعت</div><div class="cd" style="display:none"></div></div><div class="tb" data-spell="heal"><div class="i">💚</div><div class="n">درمان</div><div class="p">۶۰٪</div><div class="cd" style="display:none"></div></div></div>`
    : `<div class="tgrid">${kinds.map((k) => { const lk = !b.unlocked.includes(k); return `<div class="tb ${lk ? "lk" : ""}" data-kind="${k}"><div class="i">${lk ? "🔒" : TOWERS[k].icon}</div><div class="n">${TOWERS[k].name}</div><div class="p">${lk ? "قفل" : fa(TOWERS[k].cost)}</div></div>`; }).join("")}${b.heroes.map((h, i) => `<div class="tb hero" data-hero="${i}"><div class="i">${h.def.emoji}</div><div class="grow"><div class="n" style="color:#fff">${h.def.name.split(" ")[0]}</div><div class="p xs" data-hl>استقرار</div></div><div class="cd" style="display:none"></div></div>`).join("")}</div>`}</div></div>`;
  const cv = $("#cv"), stage = $("#stage"), R = new Renderer(cv);
  const fit = () => { R.resize(stage.clientWidth, stage.clientHeight); };
  R.setBattle(b); fit(); const ro = new ResizeObserver(fit); ro.observe(stage);
  Sound.playMusic(cfg.music || map.music, { intensity: 0.3 });
  let raf = 0, last = performance.now(), ended = false, hudT = 0, musT = 0, hintOff = false;

  const hint = (t) => { const h = $("#hint"); if (!h) return; if (!t) { h.style.display = "none"; return; } h.style.display = "block"; h.innerHTML = t; };
  if (!atk && !S.seen.tut) hint("۱) از ستون سمت راست یک برج انتخاب کن  ۲) روی یک خانه‌ی خالی بزن  ۳) دکمه‌ی «شروع نبرد» را بزن 🏹"); if (atk) hint("روی سربازان بزن تا به مسیر بروند. کماندارها برج‌ها را می‌زنند، دروازه‌شکن‌ها دروازه را!");
  const clearHint = () => { if (!hintOff) { hintOff = true; hint(null); if (!atk) { S.seen.tut = true; saveSoon(); } } };
  setTimeout(() => clearHint(), atk ? 6000 : 14000);

  // ---------- پنل برج ----------
  const panel = $("#panel");
  const place = (cx) => { panel.style.left = cx < COLS / 2 ? "auto" : "10px"; panel.style.right = cx < COLS / 2 ? "10px" : "auto"; };
  function renderPanel() {
    if (ui.cell && !ui.selTower) { const { x, y } = ui.cell; place(x); panel.classList.add("on"); panel.innerHTML = `<div class="row"><b>ساخت برج</b><div class="grow"></div><button class="hbtn" style="width:30px;height:30px" data-p="close">✕</button></div><div class="tgrid" style="margin-top:6px">${kinds.filter((k) => b.unlocked.includes(k)).map((k) => `<div class="tb ${b.gold < TOWERS[k].cost ? "no" : ""}" data-pbuild="${k}"><div class="i">${TOWERS[k].icon}</div><div class="n">${TOWERS[k].name}</div><div class="p">${fa(TOWERS[k].cost)}</div></div>`).join("")}</div>`; return; }
    const t = ui.selTower; if (!t || !b.towers.includes(t)) { panel.classList.remove("on"); ui.selTower = null; return; }
    const d = TOWERS[t.kind], s = b.stats(t), ev = t.evo ? d.evo[t.evo] : null, uc = b.upgradeCost(t), ec = b.evolveCost(t); place(t.x);
    panel.classList.add("on");
    panel.innerHTML = `<div class="row"><span style="font-size:24px">${d.icon}</span><div class="grow"><b style="color:${ev ? ev.color : "#fff"}">${ev ? ev.name : d.name}</b><div class="xs mut">${"★".repeat(t.lvl)}${ev ? " • شکل نهایی" : ""}</div></div><button class="hbtn" style="width:30px;height:30px" data-p="close">✕</button></div>
    <div style="margin:6px 0">${t.kind === "bank" ? `<div class="kv"><span>درآمد هر موج</span><b>🪙 ${fa(s.income * b.mods.gold)}</b></div>` : `<div class="kv"><span>آسیب</span><b>${fa(s.dmg)}</b></div><div class="kv"><span>سرعت</span><b>${s.rate.toFixed(1)}/ث</b></div>`}<div class="kv"><span>برد</span><b>${s.range.toFixed(1)}</b></div><div class="kv"><span>نابودی‌ها</span><b>${fa(t.kills)}</b></div>${ev ? `<div class="xs" style="color:${ev.color}">${ev.desc}</div>` : ""}</div>
    ${t.kind !== "bank" ? `<div class="row" style="gap:4px">${["first", "close", "strong"].map((m) => `<button class="btn s ${t.mode === m ? "" : "d"} grow" style="padding:5px 2px" data-pmode="${m}">${MODE_LABEL[m]}</button>`).join("")}</div>` : ""}
    ${uc != null ? `<button class="btn s g ${b.gold < uc ? "off" : ""}" style="width:100%;margin-top:6px" data-p="up">⬆️ ارتقا 🪙 ${fa(uc)}</button>` : ""}
    ${ec != null ? `<div class="xs gold" style="margin-top:6px">✨ شکل نهایی (🪙 ${fa(ec)}) را انتخاب کن:</div>${["a", "b"].map((k) => `<div class="evo ${b.gold < ec ? "off" : ""}" data-pevo="${k}" style="border-color:${d.evo[k].color}88;${b.gold < ec ? "opacity:.5" : ""}"><b style="color:${d.evo[k].color}">${d.evo[k].name}</b><div class="xs mut">${d.evo[k].desc}</div></div>`).join("")}` : ""}
    <button class="btn s r" style="width:100%;margin-top:6px" data-p="sell">فروش 🪙 ${fa(b.sellValue(t))}</button>`;
  }
  panel.addEventListener("pointerdown", (e) => e.stopPropagation());
  panel.addEventListener("click", (e) => {
    const t = ui.selTower, el = e.target.closest("[data-p],[data-pmode],[data-pevo],[data-pbuild]"); if (!el) return; Sound.init();
    if (el.dataset.pbuild) { const c = ui.cell; if (c && b.build(el.dataset.pbuild, c.x, c.y)) { clearHint(); ui.cell = null; ui.selTower = b.towerAtCell(c.x, c.y); } renderPanel(); return; }
    if (el.dataset.p === "close") { ui.selTower = null; ui.cell = null; }
    else if (el.dataset.pmode && t) t.mode = el.dataset.pmode;
    else if (el.dataset.p === "up" && t) b.upgrade(t);
    else if (el.dataset.pevo && t) b.evolve(t, el.dataset.pevo);
    else if (el.dataset.p === "sell" && t) { b.sell(t); ui.selTower = null; }
    renderPanel();
  });

  // ---------- ورودی ----------
  const pt = (e) => { const c = R.toCell(e.clientX, e.clientY); return c; };
  cv.addEventListener("pointermove", (e) => { ui.hover = pt(e); });
  cv.addEventListener("pointerdown", (e) => {
    Sound.init(); if (ended || ui.paused) return; const c = pt(e); ui.hover = c; if (c.x < 0 || c.y < 0 || c.x >= COLS || c.y >= ROWS) { ui.selTower = null; ui.cell = null; renderPanel(); return; }
    const hx = Math.max(0.3, Math.min(COLS - 0.3, c.fx)), hy = Math.max(0.3, Math.min(ROWS - 0.3, c.fy));
    if (ui.placeHero >= 0) { b.deployHero(ui.placeHero, hx, hy); ui.placeHero = -1; clearHint(); return; }
    if (atk) { const t = b.towerAtCell(c.x, c.y); if (t) b.fxText(t.cx, t.cy - 0.6, TOWERS[t.kind].name + " ★" + t.lvl, "#fff", 1); return; }
    const t = b.towerAtCell(c.x, c.y);
    if (ui.selHero) { const h = ui.selHero; if (Math.hypot(h.x - c.fx, h.y - c.fy) < 0.6) ui.selHero = null; else { h.tx = hx; h.ty = hy; ui.selHero = null; } return; }
    if (t) { ui.selTower = t; ui.cell = null; ui.buildKind = null; markTray(); renderPanel(); return; }
    const near = b.heroes.find((h) => h.deployed && Math.hypot(h.x - c.fx, h.y - c.fy) < 0.7); if (near) { ui.selHero = near; ui.selTower = null; renderPanel(); return; }
    if (ui.buildKind && b.canBuild(c.x, c.y)) { if (b.build(ui.buildKind, c.x, c.y)) { clearHint(); if (b.gold < TOWERS[ui.buildKind].cost) { ui.buildKind = null; markTray(); } } return; }
    if (b.canBuild(c.x, c.y)) { ui.cell = { x: c.x, y: c.y }; ui.selTower = null; renderPanel(); return; }
    ui.selTower = null; ui.cell = null; renderPanel();
  });
  const trayEl = $("#tray");
  const markTray = () => trayEl.querySelectorAll("[data-kind]").forEach((el) => el.classList.toggle("sel", el.dataset.kind === ui.buildKind));
  trayEl.addEventListener("click", (e) => {
    Sound.init(); const el = e.target.closest(".tb"); if (!el || ended) return;
    if (el.dataset.kind) { const k = el.dataset.kind; if (!b.unlocked.includes(k)) { toast("با پیشروی در مراحل باز می‌شود"); Sound.sfx("error"); return; } ui.buildKind = ui.buildKind === k ? null : k; ui.cell = null; ui.selTower = null; renderPanel(); markTray(); Sound.sfx("click"); }
    else if (el.dataset.hero !== undefined) { const i = +el.dataset.hero, h = b.heroes[i]; if (!h.deployed) { ui.placeHero = i; hint(`روی نقشه بزن تا ${h.def.name.split(" ")[0]} مستقر شود`); setTimeout(() => !hintOff && hint(null), 2500); } else if (h.cd > 0) Sound.sfx("error"); else { b.useSkill(i); ui.selHero = null; } }
    else if (el.dataset.troop) { clearHint(); b.deploy(el.dataset.troop); }
    else if (el.dataset.spell) { if (!b.cast(el.dataset.spell)) Sound.sfx("error"); }
  });
  function toast(msg) { const t = document.createElement("div"); t.className = "toast"; t.innerHTML = msg; $("#toasts").appendChild(t); setTimeout(() => t.remove(), 2700); }

  // ---------- دکمه‌ها ----------
  $("#bPause").onclick = () => togglePause();
  $("#bSpeed").onclick = () => { b.speed = b.speed >= 3 ? 1 : b.speed + 1; if (atk) b.speed = Math.min(b.speed, 2); S.settings.speed = b.speed; saveSoon(); $("#bSpeed").textContent = "×" + fa(b.speed); Sound.sfx("click"); };
  if (!atk) { $("#bAuto").onclick = () => { b.autoStart = !b.autoStart; S.settings.auto = b.autoStart; saveSoon(); $("#bAuto").classList.toggle("on", b.autoStart); Sound.sfx("click"); if (b.autoStart && b.state === "running" && b.countdown > 0 && b.countdown < 9) b.startWave(); }; $("#bWave").onclick = () => { Sound.init(); clearHint(); b.startWave(); Sound.sfx("click"); }; }
  function setPause(v) { if (ended) return; ui.paused = v; if (v) { Sound.sfx("click"); const m = $("#modal"); m.innerHTML = `<div class="dlg"><h2>⏸ توقف</h2><div class="col"><button class="btn g l" id="pRes">ادامه ▶</button><button class="btn" id="pRe">شروع دوباره 🔁</button><button class="btn r" id="pQuit">خروج از نبرد</button></div></div>`; m.classList.add("on"); $("#pRes").onclick = () => setPause(false); $("#pRe").onclick = () => { cleanup(); m.classList.remove("on"); m.innerHTML = ""; startBattle(cfg, onExit); }; $("#pQuit").onclick = () => { m.classList.remove("on"); m.innerHTML = ""; cleanup(); onExit(result(false, true)); }; } else { const m = $("#modal"); m.classList.remove("on"); m.innerHTML = ""; } }
  const togglePause = () => setPause(!ui.paused);
  const onVis = () => { if (document.hidden) { setPause(true); Sound.pause(); } else Sound.resume(); };
  document.addEventListener("visibilitychange", onVis);

  // ---------- رویدادها ----------
  b.on = (type, d) => {
    if (type === "toast") toast(d);
    else if (type === "wave") { const prog = (d + 1) / b.waves.length; Sound.setIntensity(0.3 + 0.5 * prog + (b.waves[d].groups.some((g) => g.kind === "boss") ? 0.15 : 0)); }
    else if (type === "waveclear") toast(`🌊 موج ${fa(d.idx + 1)} پاک شد  +${fa(d.bonus)} 🪙`);
    else if (type === "leak") { if (S.settings.vibrate && navigator.vibrate) navigator.vibrate(60); }
    else if (type === "win" || type === "lose") finish(type === "win");
    else if (type === "evolve") { toast(`✨ ${TOWERS[d.kind].evo[d.evo].name}`); }
  };
  function result(quit) { return { won: b.state === "won", stars: b.stars || 0, kills: b.kills, lives: b.lives, maxLives: b.maxLives, wave: Math.max(0, b.waveIdx + (b.state === "won" ? 1 : 0)), built: b.built, skills: b.skillsUsed, evolves: b.evolves, timeLeft: b.timeLeft, quit }; }
  function finish(won) {
    if (ended) return; ended = true; const el = document.createElement("div"); el.style.cssText = "position:absolute;inset:0;z-index:9;display:flex;align-items:center;justify-content:center;pointer-events:none;font-family:Lalezar;font-size:72px;color:" + (won ? "#ffd24a" : "#ff6a6a") + ";text-shadow:0 6px 30px #000;animation:pop .5s"; el.textContent = won ? "پیروزی!" : "شکست!"; stage.appendChild(el);
    if (won) Sound.sfx("wave_clear"); setTimeout(() => { cleanup(); onExit(result(false)); }, 2200);
  }
  function cleanup() { cancelAnimationFrame(raf); ro.disconnect(); document.removeEventListener("visibilitychange", onVis); active = null; document.body.classList.remove("inbattle"); const m = $("#modal"); m.classList.remove("on"); m.innerHTML = ""; }

  // ---------- HUD ----------
  const el = (id) => document.getElementById(id);
  function hud() {
    if (atk) { el("hGate").textContent = fa(b.gate) + " / " + fa(b.gateMax); el("hTime").textContent = faTime(b.timeLeft); const n = Math.floor(b.energy); el("eBar").querySelectorAll("i").forEach((i, k) => i.classList.toggle("f", k < n)); trayEl.querySelectorAll("[data-troop]").forEach((t) => t.classList.toggle("no", b.energy < TROOPS[t.dataset.troop].energy)); trayEl.querySelectorAll("[data-spell]").forEach((t) => { const cd = b.spells[t.dataset.spell], c = t.querySelector(".cd"); c.style.display = cd > 0 ? "flex" : "none"; c.textContent = Math.ceil(cd); }); return; }
    el("hLives").textContent = fa(b.lives) + " / " + fa(b.maxLives); el("hGold").textContent = fa(b.gold); el("hWave").textContent = fa(Math.max(0, b.waveIdx + 1)) + " / " + fa(b.waves.length); const cdOn = b.countdown > 0 && b.state === "running"; el("hCd").style.display = cdOn ? "flex" : "none"; if (cdOn) el("hCdv").textContent = fa(Math.ceil(b.countdown));
    trayEl.querySelectorAll("[data-kind]").forEach((t) => { const k = t.dataset.kind; if (b.unlocked.includes(k)) t.classList.toggle("no", b.gold < TOWERS[k].cost); });
    trayEl.querySelectorAll("[data-hero]").forEach((t) => { const h = b.heroes[+t.dataset.hero], c = t.querySelector(".cd"), l = t.querySelector("[data-hl]"); if (!h.deployed) { c.style.display = "none"; l.textContent = "استقرار"; t.classList.remove("ready"); } else if (h.cd > 0) { c.style.display = "flex"; c.textContent = Math.ceil(h.cd); l.textContent = h.def.skill.name; t.classList.remove("ready"); } else { c.style.display = "none"; l.textContent = "✨ " + h.def.skill.name; t.classList.add("ready"); } });
    const w = el("bWave"); if (w) { const last = b.waveIdx >= b.waves.length - 1; w.style.display = last || b.state === "won" || b.state === "lost" ? "none" : "block"; w.textContent = b.waveIdx < 0 ? "▶ شروع نبرد" : b.countdown > 0 ? `▶ موج بعدی +${fa(Math.round(b.countdown * 2.5 * b.mods.gold))}` : "▶ موج بعدی"; }
    if (ui.selTower && b.towers.includes(ui.selTower)) { const u = ui.selTower; if (u._k !== b.gold + "|" + u.lvl + (u.evo || "")) { u._k = b.gold + "|" + u.lvl + (u.evo || ""); renderPanel(); } } else if (ui.selTower) { ui.selTower = null; renderPanel(); }
  }

  // ---------- حلقه ----------
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    if (!ui.paused) { const steps = b.speed; for (let i = 0; i < steps; i++) b.update(dt); }
    R.draw(dt, ui); hudT -= dt; if (hudT <= 0) { hudT = 0.1; hud(); } musT -= dt; if (musT <= 0) { musT = 2; if (!atk && b.state === "running") { const boss = b.enemies.some((e) => e.boss && !e.dead); Sound.setIntensity(Math.min(1, 0.3 + 0.5 * ((b.waveIdx + 1) / b.waves.length) + (boss ? 0.15 : 0) + (b.lives < b.maxLives * 0.4 ? 0.1 : 0))); } else if (atk) Sound.setIntensity(0.75); }
    raf = requestAnimationFrame(frame);
  }
  active = { setPause, togglePause };
  Sound.setIntensity(atk ? 0.75 : 0.3); hud(); raf = requestAnimationFrame((t) => { last = t; frame(t); });
  window.__battle = { b, R, ui };
}
