// رندر سه‌بعدی نقشه‌ی بزرگ: زمین ارتفاعی، جنگل/پوشش گیاهی تکه‌بندی‌شده (chunk) با LOD، آبادی‌ها، قایق، برچسب‌ها
// همه‌چیز روی یک بوم GL (world3d)؛ برچسب‌ها و راهنماها روی یک بوم دوبعدیِ شفاف.
import { takeCanvas, W3, initWorld, setTerrain, resize as wResize, frameBegin, drawTerrain, flushModels, drawWater, frameEnd, inst, drawChar, heightAt, ENV, shadow, puff, project, pick, addMesh, growModel, growBuf, frustumPlanes } from "./world3d.js";
export { W3, puff, shadow, heightAt, takeCanvas };
export const K = 0.06; // هر پیکسل منطقیِ نقشه = K واحد جهان (قهرمان ≈ ۱٫۹ واحد)
const TAU = Math.PI * 2, sst = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const cl01 = (x) => (x < 0 ? 0 : x > 1 ? 1 : x), mix = (a, b, t) => a + (b - a) * t;
// ---------- ساخت مش‌های رویه‌ای (پایین‌چندضلعی) ----------
function MB() {
  const P = [], N = [], C = [];
  const tri = (a, b, c, col) => { const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2]; let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l; for (const p of [a, b, c]) { P.push(p[0], p[1], p[2]); N.push(nx, ny, nz); C.push(col[0], col[1], col[2], col[3] === undefined ? 0 : col[3]); } };
  const quad = (a, b, c, d, col) => { tri(a, b, c, col); tri(a, c, d, col); };
  const box = (cx, cy, cz, sx, sy, sz, col) => { const x0 = cx - sx / 2, x1 = cx + sx / 2, y0 = cy - sy / 2, y1 = cy + sy / 2, z0 = cz - sz / 2, z1 = cz + sz / 2; quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], col); quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], col); quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], col); quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], col); quad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], col); };
  const cone = (cx, y0, cz, r, h, seg, col, r2 = 0) => { for (let i = 0; i < seg; i++) { const a0 = (i / seg) * TAU, a1 = ((i + 1) / seg) * TAU; const p0 = [cx + Math.cos(a0) * r, y0, cz + Math.sin(a0) * r], p1 = [cx + Math.cos(a1) * r, y0, cz + Math.sin(a1) * r]; if (r2 > 0) { const q0 = [cx + Math.cos(a0) * r2, y0 + h, cz + Math.sin(a0) * r2], q1 = [cx + Math.cos(a1) * r2, y0 + h, cz + Math.sin(a1) * r2]; quad(p1, p0, q0, q1, col); } else tri(p1, p0, [cx, y0 + h, cz], col); } };
  return { tri, quad, box, cone, build(name, o = {}) { addMesh(name, { pos: new Float32Array(P), nor: new Float32Array(N), col: new Uint8Array(C), h: o.h || 1, w: o.w || 1, cap: o.cap || 256 }); if (o.sway) W3.models[name].sway = o.sway; } };
}
const GR = (r, g, b) => [r, g, b, 0];
function buildProcModels() {
  // درخت‌های دور (LOD): کاج، پهن‌برگ، نخل — ابعاد برابر با مدل اصلی
  const pine = (name, h, w) => { const m = MB(); m.box(0, h * 0.15, 0, w * 0.1, h * 0.3, w * 0.1, GR(70, 48, 31)); for (let i = 0; i < 3; i++) m.cone(0, h * (0.14 + i * 0.26), 0, w * (0.5 - i * 0.12), h * 0.44, 6, GR(32 + i * 4, 72 + i * 5, 41), 0); m.build(name, { h, w, cap: 2048, sway: 0.012 }); };
  const leaf = (name, h, w, c) => { const m = MB(); m.box(0, h * 0.22, 0, w * 0.1, h * 0.44, w * 0.1, GR(76, 51, 33)); m.cone(0, h * 0.28, 0, w * 0.5, h * 0.3, 6, GR(...c), w * 0.34); m.cone(0, h * 0.58, 0, w * 0.34, h * 0.4, 6, GR(c[0] * 0.9, c[1] * 0.9, c[2] * 0.9), 0); m.build(name, { h, w, cap: 2048, sway: 0.012 }); };
  const palm = (name, h, w) => { const m = MB(); m.box(0, h * 0.45, 0, w * 0.06, h * 0.9, w * 0.06, GR(120, 98, 56)); for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU, c = Math.cos(a), s = Math.sin(a); m.quad([0, h * 0.92, 0], [c * w * 0.5 - s * w * 0.1, h * 0.78, s * w * 0.5 + c * w * 0.1], [c * w * 0.5 + s * w * 0.1, h * 0.78, s * w * 0.5 - c * w * 0.1], [c * w * 0.2, h * 0.95, s * w * 0.2], GR(88, 136, 52)); } m.build(name, { h, w, cap: 1024, sway: 0.012 }); };
  pine("ow_pine5", 4.3, 3.3); pine("ow_pine3", 2.35, 1.76); leaf("ow_leaf4", 3.59, 2.77, [123, 67, 32]); leaf("ow_leaf1", 3.59, 2.77, [90, 120, 40]); palm("ow_palm1", 5.1, 5.0);
  // قایق: بدنه، دکل، بادبان، پرچم تیم (a=255)
  { const m = MB(), brown = GR(122, 84, 46), dark = GR(84, 56, 30), sail = GR(240, 234, 220);
    const L = 2.3, Wd = 0.75;
    const prof = (z) => { const t = Math.abs(z) / L; return Wd * (1 - Math.pow(t, 2.2)) + 0.05; };
    const zs = []; for (let i = -4; i <= 4; i++) zs.push((i / 4) * L);
    for (let i = 0; i < zs.length - 1; i++) { const z0 = zs[i], z1 = zs[i + 1], w0 = prof(z0), w1 = prof(z1), r0 = z0 > 0 ? 0.55 + z0 * 0.15 : 0.5, r1 = z1 > 0 ? 0.55 + z1 * 0.15 : 0.5;
      m.quad([-w0, r0, z0], [-w1, r1, z1], [-w1 * 0.5, 0, z1], [-w0 * 0.5, 0, z0], brown); m.quad([w0, r0, z0], [w0 * 0.5, 0, z0], [w1 * 0.5, 0, z1], [w1, r1, z1], brown);
      m.quad([-w0, r0, z0], [w0, r0, z0], [w1, r1, z1], [-w1, r1, z1], dark); m.quad([-w0 * 0.5, 0.02, z0], [-w1 * 0.5, 0.02, z1], [w1 * 0.5, 0.02, z1], [w0 * 0.5, 0.02, z0], dark); }
    m.box(0, 0.62, 0, Wd * 1.6, 0.1, 0.16, [200, 160, 90, 0]); m.box(0, 2.0, 0.1, 0.1, 3.0, 0.1, dark);
    m.quad([0.05, 3.3, 0.1], [0.05, 0.95, 0.1], [0.05, 0.95, 1.55], [0.05, 3.1, 0.7], sail); m.quad([0.05, 3.3, 0.1], [0.05, 3.1, 0.7], [0.05, 0.95, 1.55], [0.05, 0.95, 0.1], sail);
    m.tri([0, 3.35, 0.1], [0, 3.0, 0.1], [0, 3.18, -0.7], [220, 60, 50, 255]); m.tri([0, 3.0, 0.1], [0, 3.35, 0.1], [0, 3.18, -0.7], [220, 60, 50, 255]);
    m.build("ow_boat", { h: 3.4, w: 4.6, cap: 128, sway: 0 }); }
  // پرچم: صفحه‌ی عمودیِ دو رو (x طول، y ارتفاع)
  { const m = MB(), n = 6, L = 1.7, hh = 1.0; for (let i = 0; i < n; i++) { const x0 = (i / n) * L, x1 = ((i + 1) / n) * L, e0 = hh * (1 - 0.25 * i / n), e1 = hh * (1 - 0.25 * (i + 1) / n); m.quad([x0, 0, 0], [x1, 0, 0], [x1, e1, 0], [x0, e0, 0], [255, 255, 255, 255]); m.quad([x1, 0, 0], [x0, 0, 0], [x0, e0, 0], [x1, e1, 0], [255, 255, 255, 255]); } m.build("ow_flag", { h: 1.0, w: 1.7, cap: 512, sway: 0.1 }); }
  { const m = MB(); m.box(0, 1.5, 0, 0.12, 3, 0.12, GR(80, 56, 34)); m.build("ow_pole", { h: 3, w: 0.2, cap: 512 }); }
  // خیمه‌ی ساده، گل‌میخ و سنگ مرز، بسته‌ی علف (فقط برای دور)
  { const m = MB(); m.cone(0, 0, 0, 1.2, 0.5, 5, GR(100, 150, 70), 0.0); m.build("ow_tuft", { h: 0.5, w: 2.4, cap: 4096, sway: 0.04 }); }
}
// ---------- نویز ----------
const hash = (x, y, s) => { let h = (x * 374761393 + y * 668265263 + s * 2147483647) | 0; h = (h ^ (h >> 13)) * 1274126177; return ((h ^ (h >> 16)) >>> 0) / 4294967295; };
const vn = (x, y, s) => { const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, sm = (t) => t * t * (3 - 2 * t), a = hash(xi, yi, s), b = hash(xi + 1, yi, s), c = hash(xi, yi + 1, s), d = hash(xi + 1, yi + 1, s); return a + (b - a) * sm(fx) + (c - a) * sm(fy) + (a - b - c + d) * sm(fx) * sm(fy); };
export { hash, vn };
// ---------- ساخت صحنه ----------
// M: { WW, WH, E(px,py) -> ارتفاع نویز با افت لبه, cls(px,py) -> 0 آب 1 دشت 2 جنگل 3 کوه, fn(px,py) -> نویز جنگل, roads:[[{x,y}]], sites:[{kind,x,y,r,name,...}] , fields:[{x,y,w,h,a}] }
export function createOW3D(canvas, overlay, M) {
  const WW = M.WW, WH = M.WH, RES = M.WW > 4000 ? ((navigator.maxTouchPoints || 0) > 0 ? 20 : 16) : 10, NX = Math.round(WW / RES) + 1, NZ = Math.round(WH / RES) + 1;
  const R = { M, K, ok: false, cam: { x: M.start ? M.start.x : WW / 2, y: M.start ? M.start.y : WH / 2, yaw: Math.PI, dist: 36, pitch: 0.9 }, lodD: (navigator.maxTouchPoints || 0) > 0 ? 30 : 46, smallD: (navigator.maxTouchPoints || 0) > 0 ? 17 : 30, lodMax: (navigator.maxTouchPoints || 0) > 0 ? 36 : 52, smMax: (navigator.maxTouchPoints || 0) > 0 ? 21 : 32, tris: 0, fps: 60, ms: 16 };
  const ov = overlay.getContext("2d"); let ovDpr = 1, vw = 800, vh = 450;
  // ----- ارتفاع -----
  const flats = [];
  function hBase(px, py) {
    const e = M.E(px, py), t = e - 0.25; let y = t < 0 ? t * 16 : t * 7; const m = sst(0.6, 0.92, e);
    y += m * m * 16 + (vn(px / 90, py / 90, 11) - 0.5) * m * 5 + (vn(px / 24, py / 24, 12) - 0.5) * (t > 0 ? 0.5 : 0.2) * (1 + m * 2.2) + (vn(px / 7, py / 7, 13) - 0.5) * 0.12 * (t > 0 ? 1 : 0);
    return y;
  }
  function H(px, py) { let y = hBase(px, py); for (let i = 0; i < flats.length; i++) { const f = flats[i], d = Math.hypot(px - f.x, py - f.y); if (d < f.r1) y += (f.h - y) * (1 - sst(f.r0, f.r1, d)); } return y; }
  R.H = H;
  R.gy = (px, py) => heightAt(px * K, py * K);
  // ----- جاده و مزرعه: شبکه‌های تقریبی هم‌اندازه‌ی رأس‌های زمین -----
  const roadG = new Float32Array(NX * NZ).fill(1e9), fieldG = new Uint8Array(NX * NZ), dirtG = new Float32Array(NX * NZ);
  function smooth(pts) { let p = pts; for (let it = 0; it < 2; it++) { const q = [p[0]]; for (let i = 0; i < p.length - 1; i++) { const a = p[i], b = p[i + 1]; q.push({ x: a.x * 0.75 + b.x * 0.25, y: a.y * 0.75 + b.y * 0.25 }, { x: a.x * 0.25 + b.x * 0.75, y: a.y * 0.25 + b.y * 0.75 }); } q.push(p[p.length - 1]); p = q; } return p; }
  R.roadPts = [];
  function rasterRoads() {
    for (const r of M.roads) { const p = smooth(r); R.roadPts.push(p);
      for (let i = 0; i + 1 < p.length; i++) { const a = p[i], b = p[i + 1], ex = 22, x0 = Math.max(0, Math.floor((Math.min(a.x, b.x) - ex) / RES)), x1 = Math.min(NX - 1, Math.ceil((Math.max(a.x, b.x) + ex) / RES)), y0 = Math.max(0, Math.floor((Math.min(a.y, b.y) - ex) / RES)), y1 = Math.min(NZ - 1, Math.ceil((Math.max(a.y, b.y) + ex) / RES)), dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy || 1;
        for (let j = y0; j <= y1; j++) for (let k = x0; k <= x1; k++) { const px = k * RES, py = j * RES; let t = ((px - a.x) * dx + (py - a.y) * dy) / l2; t = t < 0 ? 0 : t > 1 ? 1 : t; const d = Math.hypot(px - (a.x + dx * t), py - (a.y + dy * t)), gi = j * NX + k; if (d < roadG[gi]) roadG[gi] = d; } } }
  }
  function rasterFields() {
    for (const f of M.fields) { const c = Math.cos(f.a), s = Math.sin(f.a), ex = Math.max(f.w, f.h) + 12, x0 = Math.max(0, Math.floor((f.x - ex) / RES)), x1 = Math.min(NX - 1, Math.ceil((f.x + ex) / RES)), y0 = Math.max(0, Math.floor((f.y - ex) / RES)), y1 = Math.min(NZ - 1, Math.ceil((f.y + ex) / RES));
      for (let j = y0; j <= y1; j++) for (let k = x0; k <= x1; k++) { const px = k * RES - f.x, py = j * RES - f.y, u = px * c + py * s, v = -px * s + py * c; if (Math.abs(u) > f.w || Math.abs(v) > f.h) continue; const edge = Math.abs(u) > f.w - 5 || Math.abs(v) > f.h - 5; fieldG[j * NX + k] = edge ? 1 : 2 + ((Math.floor((v + f.h) / 14) + f.k) % 3); } }
  }
  function rasterSites() {
    for (const s of M.sites) { const r = (s.dirt || s.r * 0.6), x0 = Math.max(0, Math.floor((s.x - r) / RES)), x1 = Math.min(NX - 1, Math.ceil((s.x + r) / RES)), y0 = Math.max(0, Math.floor((s.y - r) / RES)), y1 = Math.min(NZ - 1, Math.ceil((s.y + r) / RES));
      for (let j = y0; j <= y1; j++) for (let k = x0; k <= x1; k++) { const d = Math.hypot(k * RES - s.x, j * RES - s.y), w = 1 - sst(r * 0.55, r, d); if (w > dirtG[j * NX + k]) dirtG[j * NX + k] = w * (s.kind === "town" || s.kind === "castle" ? 1 : 0.7); } }
  }
  // ----- رنگ زمین -----
  const FARM = [[0.5, 0.62, 0.22], [0.8, 0.68, 0.28], [0.42, 0.3, 0.18], [0.35, 0.55, 0.2]];
  function colorAt(wx, wz, y, sl) {
    const px = wx / K, py = wz / K, ix = Math.min(NX - 1, Math.round(px / RES)), iz = Math.min(NZ - 1, Math.round(py / RES)), gi = iz * NX + ix;
    const n1 = vn(px / 70, py / 70, 5), n2 = vn(px / 20, py / 20, 6), n3 = vn(px / 8, py / 8, 7);
    let r, g, b;
    if (y < 0.5 && y > -0.1) { const f = sst(0.5, 0.05, y); r = mix(0.5, 0.86, f); g = mix(0.6, 0.79, f); b = mix(0.3, 0.56, f); }
    else if (y <= -0.1) { const f = sst(-2.8, -0.1, y); r = mix(0.2, 0.74, f); g = mix(0.3, 0.68, f); b = mix(0.34, 0.5, f); }
    else {
      const gm = n1 * 0.7 + n2 * 0.3; r = mix(0.27, 0.5, gm); g = mix(0.5, 0.62, gm); b = mix(0.17, 0.26, gm);
      const c = M.cls(px, py); if (c === 2) { const k = sst(0.62, 0.7, M.fn(px, py)); r = mix(r, 0.14, k * 0.7); g = mix(g, 0.32, k * 0.7); b = mix(b, 0.12, k * 0.7); }
      const f0 = fieldG[gi]; if (f0) { const fc = f0 === 1 ? [0.42, 0.34, 0.2] : FARM[f0 - 2]; r = mix(r, fc[0], 0.9); g = mix(g, fc[1], 0.9); b = mix(b, fc[2], 0.9); }
      const rk = Math.max(sst(0.12, 0.3, sl), sst(6, 10, y + (n2 - 0.5) * 3)), rv = 0.42 + n3 * 0.16; r = mix(r, rv, rk); g = mix(g, rv * 0.97, rk); b = mix(b, rv * 0.95, rk);
      const sn = sst(11.5, 14.5, y + (n2 - 0.5) * 3.5 - sl * 6); r = mix(r, 0.93, sn); g = mix(g, 0.95, sn); b = mix(b, 0.99, sn);
    }
    const dd = dirtG[gi]; if (dd > 0 && y > 0.25) { r = mix(r, 0.56 + n3 * 0.08, dd * 0.85); g = mix(g, 0.48 + n3 * 0.07, dd * 0.85); b = mix(b, 0.34, dd * 0.85); }
    const rd = roadG[gi]; if (rd < 26 && y > 0.2) { const w = 1 - sst(8, 20, rd); r = mix(r, 0.6 + n3 * 0.07, w * 0.92); g = mix(g, 0.49 + n3 * 0.06, w * 0.92); b = mix(b, 0.33, w * 0.92); }
    return [cl01(r), cl01(g), cl01(b)];
  }
  // ----- پوشش گیاهی -----
  const CS = 14, NCX = Math.ceil(WW * K / CS), NCZ = Math.ceil(WH * K / CS), chunks = new Array(NCX * NCZ);
  for (let i = 0; i < chunks.length; i++) chunks[i] = { cx: ((i % NCX) + 0.5) * CS, cz: (((i / NCX) | 0) + 0.5) * CS, g: new Map(), ymax: 0, ymin: 99, groups: [] };
  const LOMAP = { sn_c5: "sn_c5@lo", sn_c4: "sn_c4@lo", PineTree_5: "ow_pine5", PineTree_3: "ow_pine3", MapleTree_4: "ow_leaf4", NormalTree_5: "ow_leaf1", PalmTree_1: "ow_palm1", DeadTree_9: "DeadTree_9@lo", Rock_3: "Rock_3@lo", Rock_5: "Rock_5@lo", Rock_1: null, Rock_2: null, Rock_4: null, mtn3: "mtn3@lo", mtn2: "mtn2@lo" };
  const SMALL = new Set(["Grass_Small", "Grass_Large_Extruded", "Flower_1_Clump", "Flower_2_Clump", "Flower_3_Clump", "Flower_4_Clump", "Flower_5_Clump", "Bush_Small", "Bush", "Bush_Flowers", "Bush_Large_Flowers", "Plant_2", "Plant_Flowers", "Petals_1"]);
  function packInst(a, b, x, y, z, yaw, s, tr, tg, tb) { const c = Math.cos(yaw), sn = Math.sin(yaw); a[b] = c * s; a[b + 1] = 0; a[b + 2] = -sn * s; a[b + 3] = 0; a[b + 4] = 0; a[b + 5] = s; a[b + 6] = 0; a[b + 7] = 0; a[b + 8] = sn * s; a[b + 9] = 0; a[b + 10] = c * s; a[b + 11] = 0; a[b + 12] = x; a[b + 13] = y; a[b + 14] = z; a[b + 15] = 1; a[b + 16] = tr; a[b + 17] = tg; a[b + 18] = tb; a[b + 19] = 0; a[b + 20] = 0; a[b + 21] = 0; a[b + 22] = 0; a[b + 23] = 0; }
  const tmpI = new Float32Array(24);
  function addStatic(name, px, py, yaw, s, tint, sink = 0, y0) {
    const x = px * K, z = py * K, y = (y0 === undefined ? heightAt(x, z) : y0) - sink, ci = Math.min(NCX - 1, (x / CS) | 0) + Math.min(NCZ - 1, (z / CS) | 0) * NCX, ch = chunks[ci];
    let g = ch.g.get(name); if (!g) { g = []; ch.g.set(name, g); }
    packInst(tmpI, 0, x, y, z, yaw, s, tint[0], tint[1], tint[2]); for (let i = 0; i < 24; i++) g.push(tmpI[i]); if (y + 6 > ch.ymax) ch.ymax = y + 6; if (y < ch.ymin) ch.ymin = y;
  }
  const rr = (i, j, s) => hash(i, j, s);
  function blockedAt(px, py, pad = 0) { const ix = Math.min(NX - 1, Math.round(px / RES)), iz = Math.min(NZ - 1, Math.round(py / RES)), gi = iz * NX + ix; if (roadG[gi] < 34 + pad || fieldG[gi]) return true; for (const s of M.sites) { if (Math.hypot(px - s.x, (py - s.y) * 1.15) < (s.clear || s.r) + pad) return true; } return false; }
  function scatter() {
    const T = { pine: [["PineTree_5", 1.5, 2.2], ["PineTree_3", 1.9, 2.6], ["PineTree_5", 1.3, 1.9], ["sn_pine_1", 1.0, 1.4], ["sn_pine_3", 1.0, 1.4], ["sn_pine_5", 0.9, 1.3], ["sn_pine_2", 1.0, 1.4]], mix: [["MapleTree_4", 1.3, 1.9], ["PineTree_5", 1.4, 2.1], ["PineTree_3", 1.8, 2.4], ["MapleTree_4", 1.2, 1.7], ["sn_c5", 0.9, 1.3], ["sn_c4", 1.0, 1.4], ["sn_commontree_2", 0.9, 1.3], ["sn_commontree_3", 0.9, 1.3]] };
    const TT = 34;
    for (let j = 0; j * TT < WH; j++) for (let i = 0; i * TT < WW; i++) {
      const px = (i + rr(i, j, 41) * 0.9) * TT, py = (j + rr(i, j, 43) * 0.9) * TT, c = M.cls(px, py); if (c === 0) continue;
      const h = rr(i, j, 44), h2 = rr(i, j, 45), h3 = rr(i, j, 46), zone = vn(px / 280, py / 280, 31), clear = vn(px / 75, py / 75, 21), y = heightAt(px * K, py * K);
      const tn = [0.82 + h2 * 0.3, 0.88 + h3 * 0.24, 0.82 + h * 0.3];
      if (c === 2) { if (clear < 0.3 || blockedAt(px, py, 6)) continue; if (h < 0.92) { const set = zone < 0.45 ? T.pine : T.mix, t = set[(h2 * set.length) | 0]; addStatic(t[0], px, py, h3 * TAU, t[1] + (t[2] - t[1]) * h, tn); } }
      else if (c === 1) { if (blockedAt(px, py, 4)) continue; if (y < 1.0 && y > 0.2) { if (h < 0.05) addStatic("PalmTree_1", px, py, h2 * TAU, 0.6 + h3 * 0.3, [1, 1, 1]); } else if (h < 0.055) addStatic(h2 < 0.15 ? "DeadTree_9" : zone < 0.5 ? "PineTree_5" : "MapleTree_4", px, py, h3 * TAU, 1.2 + h * 8, tn); }
      else if (c === 3) { if (blockedAt(px, py, 0)) continue; if (h < 0.25) addStatic(h2 < 0.55 ? (h3 < 0.5 ? "Rock_" + (1 + ((h3 * 10) | 0)) : "sn_rock_medium_" + (1 + ((h * 12) | 0) % 3)) : "DeadTree_9", px, py, h3 * TAU, h2 < 0.55 ? 1.8 + h * 6 : 1.4 + h, [0.85, 0.85, 0.88]); else if (h < 0.3 && y < 11) addStatic("PineTree_3", px, py, h3 * TAU, 1.3 + h2, tn); }
    }
    // ریزه‌ها: علف، گل، بوته (فقط نزدیک دوربین)
    const TS2 = 17, GRS = ["Grass_Small", "Grass_Small", "Grass_Large_Extruded"], FLS = ["Flower_2_Clump", "Flower_3_Clump", "Flower_4_Clump", "Flower_5_Clump", "Flower_1_Clump", "Plant_Flowers", "sn_plant_1_big", "sn_plant_7_big", "sn_grass_common_tall", "sn_plant_1", "sn_fern_1", "sn_flower_3_group", "sn_flower_4_group", "sn_grass_wispy_short", "sn_grass_wispy_tall", "sn_mushroom_common"], BUS = ["Bush_Small", "Bush", "Bush_Flowers", "Bush_Large_Flowers"];
    for (let j = 0; j * TS2 < WH; j++) for (let i = 0; i * TS2 < WW; i++) {
      const px = (i + rr(i, j, 51)) * TS2, py = (j + rr(i, j, 52)) * TS2, c = M.cls(px, py); if (c === 0 || c === 3) continue; const y = heightAt(px * K, py * K); if (y < 0.45 || blockedAt(px, py, -8)) continue;
      const h = rr(i, j, 53), h2 = rr(i, j, 54), mdw = vn(px / 120, py / 120, 55);
      if (c === 1) { if (h < 0.3) addStatic(GRS[(h2 * 3) | 0], px, py, h2 * TAU, 0.9 + h2 * 0.8, [0.8 + h2 * 0.3, 0.9 + h * 0.2, 0.7 + h2 * 0.3]); else if (h < 0.3 + 0.1 * mdw) addStatic(FLS[(h2 * 6) | 0], px, py, h2 * TAU, 1.0 + h2 * 0.9, [1, 1, 1]); else if (h < 0.4 + 0.1 * mdw) addStatic(BUS[(h2 * 4) | 0], px, py, h2 * TAU, 1.1 + h2 * 0.9, [0.9, 1, 0.85]); }
      else if (h < 0.22) addStatic(h2 < 0.6 ? "Bush_Small" : "Grass_Small", px, py, h2 * TAU, 1 + h2, [0.55, 0.8, 0.5]);
    }
    // کوه‌ها: مدل‌های mtn روی قله‌ها
    for (let j = 0; j * 110 < WH; j++) for (let i = 0; i * 110 < WW; i++) { const px = (i + rr(i, j, 61)) * 110, py = (j + rr(i, j, 62)) * 110, y = heightAt(px * K, py * K); if (y < 9 || M.cls(px, py) !== 3 || blockedAt(px, py)) continue; const h2 = rr(i, j, 63); addStatic(h2 < 0.5 ? "mtn3" : "mtn2", px, py, h2 * TAU, 2.6 + h2 * 2.4, [0.8, 0.8, 0.84], 0.5); }
  }
  function finalizeChunks() {
    for (const ch of chunks) { ch.groups.length = 0; for (const [name, arr] of ch.g) { const lo = LOMAP[name] === undefined ? (SMALL.has(name) ? null : (W3.models[name + "@lo"] ? name + "@lo" : null)) : LOMAP[name]; ch.groups.push({ name, lo, arr: new Float32Array(arr), n: arr.length / 24, small: SMALL.has(name) }); } ch.g = null; }
    R.instTotal = chunks.reduce((a, c) => a + c.groups.reduce((b, g) => b + g.n, 0), 0);
  }
  // ----- آبادی‌ها -----
  R.sites = []; // هر آبادی: { x,z (جهان), r, pieces:[{name,x,y,z,yaw,s,o}], ... }
  R.setSites = (list) => { R.sites = list; };
  // ----- راه‌اندازی -----
  R.init = async () => {
    const ok = await initWorld(canvas); W3.mirrorX = false; if (!ok) { R.err = "init: " + (W3.err || "?"); return false; }
    for (const s of M.sites) { const f0 = s.flat || s.r * 0.7; flats.push({ x: s.x, y: s.y, r0: f0, r1: f0 + 90, h: Math.max(0.55, Math.min(3.4, hBase(s.x, s.y))) }); }
    rasterRoads(); rasterFields(); rasterSites();
    buildProcModels();
    setTerrain({ x0: 0, z0: 0, x1: WW * K, z1: WH * K, nx: NX, nz: NZ, wl: 0, h: (x, z) => H(x / K, z / K), color: colorAt });
    for (const n of ["PineTree_5", "PineTree_3", "MapleTree_4", "PalmTree_1", "DeadTree_9", "NormalTree_5", "sn_c5", "sn_c4", "Rock_1", "Rock_2", "Rock_3", "Rock_4", "Rock_5", "Bush_Small", "Bush", "Bush_Flowers", "Bush_Large_Flowers", "Grass_Small", "Grass_Large_Extruded", "Flower_1_Clump", "Flower_2_Clump", "Flower_3_Clump", "Flower_4_Clump", "Flower_5_Clump", "Plant_Flowers", "mtn2", "mtn3"]) growModel(n, 3072);
    for (const n in W3.models) if (/^sn_/.test(n)) growModel(n, 3072);
    for (const n of ["PineTree_5@lo", "ow_pine5", "ow_pine3", "ow_leaf4", "ow_leaf1", "ow_palm1", "DeadTree_9@lo", "Rock_3@lo", "Rock_5@lo", "mtn3@lo", "mtn2@lo", "PineTree_3@lo", "MapleTree_4@lo", "sn_c5@lo", "sn_c4@lo"]) growModel(n, 4096);
    scatter(); finalizeChunks();
    ENV.fogd = [80, 250]; ENV.fogc = [0.74, 0.82, 0.9]; ENV.hor = [0.78, 0.86, 0.94]; ENV.top = [0.3, 0.52, 0.88];
    R.ok = true; return true;
  };
  { const _i = R.init; R.init = async () => { try { return await _i(); } catch (e) { R.err = "build: " + (e && e.message || e); console.error(e); return false; } }; }
  // ----- اندازه و دوربین -----
  R.resize = () => { vw = canvas.parentElement.clientWidth || innerWidth; vh = canvas.parentElement.clientHeight || innerHeight; wResize(vw, vh, 1.5); ovDpr = Math.min(devicePixelRatio || 1, 1.5); overlay.width = Math.round(vw * ovDpr); overlay.height = Math.round(vh * ovDpr); overlay.style.width = vw + "px"; overlay.style.height = vh + "px"; R.vw = vw; R.vh = vh; };
  const fp = new Float32Array(24); let adaptN = 0, adaptSum = 0, goodN = 0; R.adapt = true; W3.scale = (navigator.maxTouchPoints || 0) > 0 ? 0.85 : 1;
  // شروع فریم: دوربین، آسمان، زمین، پوشش گیاهی
  const visCh = [], TOUCH = (navigator.maxTouchPoints || 0) > 0;
  R.instBudget = TOUCH ? 5500 : 14000; R.triBudget = TOUCH ? 130000 : 320000;
  R.begin = (dt) => {
    const c = R.cam, w = W3.cam; w.x = c.x * K; w.z = c.y * K; w.y = heightAt(w.x, w.z) + 1.2; w.yaw = c.yaw; w.pitch = c.pitch; w.dist = c.dist; w.minY = 2.2; w.fov = 0.75;
    frameBegin(dt); W3.stats.tris = 0; drawTerrain(); frustumPlanes(fp);
    const e = W3.eye, ex = e[0], ez = e[2], lodD = R.lodD, smD = R.smallD; let tris = 0;
    const vis = visCh; vis.length = 0;
    for (let ci = 0; ci < chunks.length; ci++) {
      const ch = chunks[ci]; if (!ch.groups.length) continue; const cy = (ch.ymax + ch.ymin) * 0.5, rad = CS * 0.75 + (ch.ymax - ch.ymin) * 0.5 + 6; let ok = true;
      for (let k = 0; k < 6; k++) if (fp[k * 4] * ch.cx + fp[k * 4 + 1] * cy + fp[k * 4 + 2] * ch.cz + fp[k * 4 + 3] < -rad) { ok = false; break; }
      if (!ok) continue; ch.d = Math.hypot(ch.cx - ex, ch.cz - ez) - CS * 0.5; vis.push(ch);
    }
    vis.sort((a, b) => a.d - b.d);
    let instN = 0; const BUD = R.instBudget, TB = R.triBudget;
    for (let vi = 0; vi < vis.length; vi++) {
      const ch = vis[vi], d = ch.d, far = d > lodD;
      for (let gi = 0; gi < ch.groups.length; gi++) {
        const g = ch.groups[gi]; if (g.small && d > smD) continue; let nm = g.name; if (far && g.lo !== undefined) { if (g.lo === null) { if (g.small || d > lodD * 1.35) continue; } else nm = g.lo; }
        const m = W3.models[nm]; if (!m) continue; let n = g.n; if (instN + n > BUD || tris > TB) { if (d > lodD * 0.6) continue; }
        while (m.cnt + n > m.cap && m.cap < 4096) { const nc = m.cap * 2, od = m.data; m.data = new Float32Array(nc * 24); m.data.set(od); m.cap = nc; growBuf(m); }
        if (m.cnt + n > m.cap) n = m.cap - m.cnt; if (n <= 0) continue; m.data.set(n === g.n ? g.arr : g.arr.subarray(0, n * 24), m.cnt * 24); m.cnt += n; instN += n; tris += (m.n / 3) * n;
      }
    }
    R.tris = tris; R.t0 = performance.now();
    ov.setTransform(ovDpr, 0, 0, ovDpr, 0, 0); ov.clearRect(0, 0, vw, vh);
  };
  // پایان فریم: مدل‌ها، آب، ذرات، تطبیق کیفیت
  R.end = (dt) => {
    flushModels(); drawWater(); frameEnd(); const st = W3.stats; R.tris = st.tris || R.tris; R.draws = st.draws;
    adaptSum += dt * 1000; adaptN++;
    if (adaptN >= 24) { const avg = adaptSum / adaptN; R.ms = avg; R.fps = 1000 / avg; adaptN = 0; adaptSum = 0;
      if (R.adapt && !R.pauseAdapt) { if (avg > 21 && W3.scale > 0.5) { W3.scale = Math.max(0.5, W3.scale - 0.1); wResize(vw, vh, 1.5); goodN = 0; R.lodD = Math.max(26, R.lodD * 0.92); R.smallD = Math.max(14, R.smallD * 0.9); } else if (avg > 21 && R.lodD > 26) { R.lodD *= 0.9; R.smallD = Math.max(10, R.smallD * 0.88); } else if (avg < 15 && ++goodN >= 6) { goodN = 0; if (W3.scale < 1) { W3.scale = Math.min(1, W3.scale + 0.05); wResize(vw, vh, 1.5); } else { R.lodD = Math.min(R.lodMax, R.lodD * 1.04); R.smallD = Math.min(R.smMax, R.smallD * 1.05); } } if (avg >= 15 && avg <= 21) goodN = 0; } }
  };
  // ----- ابزارها -----
  R.proj = (px, py, h = 0) => { const x = px * K, z = py * K; return project(x, heightAt(x, z) + h, z); };
  R.pick = (sx, sy) => { const p = pick(sx, sy); return p ? [p[0] / K, p[1] / K] : null; };
  R.inst = (name, px, py, yaw, s, o, y0) => { const x = px * K, z = py * K; return inst(name, x, y0 === undefined ? heightAt(x, z) : y0, z, yaw, s, o || {}); };
  R.instW = (name, x, y, z, yaw, s, o) => inst(name, x, y, z, yaw, s, o || {});
  R.char = (ins, px, py, yaw, sc = 1, yo = 0, flash = 0) => { const x = px * K, z = py * K, y = Math.max(0.05, heightAt(x, z)) + yo; shadow(x, y, z, 0.9 * sc, 0.38); return drawChar(ins, x, y, z, yaw, { sc, flash }); };
  R.shadow = (px, py, r, a) => { const x = px * K, z = py * K; shadow(x, Math.max(0.05, heightAt(x, z)), z, r, a); };
  R.dist = (px, py) => { const e = W3.eye; return e ? Math.hypot(px * K - e[0], py * K - e[2]) : 0; };
  // برچسب روی بوم رویه
  R.label = (txt, px, py, h, col, size = 12, opt) => { const p = R.proj(px, py, h); if (!p || p[2] > 190) return null; const x = p[0], y = p[1]; if (x < -80 || x > vw + 80 || y < -30 || y > vh + 30) return null; const sc = opt && opt.fix ? 1 : Math.max(0.7, Math.min(1.15, 60 / p[2] + 0.3)), fs = size * sc; ov.font = `800 ${fs}px Vazirmatn, sans-serif`; ov.textAlign = "center";
    if (opt && opt.plate) { const w = ov.measureText(txt).width + 16, hh = fs + 8; ov.fillStyle = "rgba(14,12,26,0.74)"; ov.strokeStyle = opt.edge || "rgba(255,214,120,0.8)"; ov.lineWidth = 1.2; ov.beginPath(); ov.roundRect ? ov.roundRect(x - w / 2, y - hh / 2 - 2, w, hh, hh / 2) : ov.rect(x - w / 2, y - hh / 2 - 2, w, hh); ov.fill(); ov.stroke(); if (opt.dot) { ov.fillStyle = opt.dot; ov.beginPath(); ov.arc(x - w / 2 + 8, y - 2, 3.4, 0, TAU); ov.fill(); } ov.fillStyle = col; ov.fillText(txt, x + (opt.dot ? 4 : 0), y + fs * 0.33); }
    else { ov.lineWidth = 3.2; ov.strokeStyle = "rgba(10,10,25,0.85)"; ov.strokeText(txt, x, y); ov.fillStyle = col; ov.fillText(txt, x, y); } return p; };

  // ----- ساخت آبادی‌ها از مدل‌های RTS -----
  const hex3 = (h) => { const n = parseInt(h.slice(1), 16); return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255]; };
  R.teamOf = (s) => s.teamArr;
  R.setTeam = (s, rgb) => { if (!s.teamArr) s.teamArr = [1, 1, 1]; s.teamArr[0] = rgb[0]; s.teamArr[1] = rgb[1]; s.teamArr[2] = rgb[2]; };
  R.setupSites = (list, ctx) => {
    R.sites = list.slice();
    for (const s of list) {
      if (!s.teamArr) R.setTeam(s, s.team || [0.8, 0.7, 0.5]);
      const P = s.pieces = [], SM = s.smoke = [], X0 = s.x * K, Z0 = s.y * K; let hs = 0;
      const F = s.kind === "castle" ? 0.7 : s.kind === "town" ? 0.75 : 1; const put = (name, lx, lz, yaw, sc, o = {}) => { lx *= F; lz *= F; sc *= F; if (o.sy) o = Object.assign({}, o, { sy: o.sy * F }); const x = X0 + lx, z = Z0 + lz, y = heightAt(x, z) - (o.sink === undefined ? 0.2 : o.sink); P.push({ name, x, y, z, yaw, s: sc, o: { sy: o.sy, team: o.plain ? undefined : s.teamArr, tint: o.tint, rx: o.rx } }); return P[P.length - 1]; };
      const ring = (n, rad, f, a0 = 0) => { for (let i = 0; i < n; i++) { const a = a0 + (i / n) * TAU; f(Math.sin(a) * rad, Math.cos(a) * rad, a, i); } };
      const rnd = (i, k) => hash(s.x | 0, i, 200 + k);
      const flagAt = (lx, lz, h, sc = 1.3) => { put("ow_pole", lx, lz, 0, sc / F, { sink: -h * F, plain: true }); put("ow_flag", lx + 0.06, lz, 0.2, sc / F, { sink: -(h * F + (3 * sc - 1.1 * sc)) }); };
      const house = (lx, lz, yaw, i, sc = 5) => { const nm = ["house1", "house2", "house3", "hut1", "hut2", "house4"][(rnd(i, 1) * 6) | 0]; put(nm, lx, lz, yaw, sc * (nm === "house4" ? 0.7 : 1), { tint: [0.9 + rnd(i, 2) * 0.2, 0.9 + rnd(i, 3) * 0.15, 0.9] }); if (rnd(i, 4) > 0.5 && nm !== "house4") SM.push([X0 + lx * F + 0.9, heightAt(X0 + lx * F, Z0 + lz * F) + 0.78 * sc * F * 0.95, Z0 + lz * F + 0.5, i]); };
      if (s.kind === "castle") {
        const hsz = 11;
        put("keep2", 0, -1.5, 0, 7); flagAt(0, -1.5, 7.2, 1.6);
        for (const sx of [-1, 1]) for (const sz of [-1, 1]) { put("stower1", sx * hsz, sz * hsz, 0, 5.6); }
        for (const sx of [-1, 1]) { flagAt(sx * hsz, -hsz, 6.7, 1.0); }
        // دیوارها: شمال/غرب/شرق با برج وسط، جنوب با دروازه
        const side = (nx, nz, yaw, gate) => { put(gate ? "sgate" : "swalltower", nx * hsz, nz * hsz, yaw, 5, { sy: 6.2 }); for (const q of [-1, 1]) put("swall", nx * hsz + (nz ? q * 7.7 : 0), nz * hsz + (nx ? q * 7.7 : 0), yaw, 3.8, { sy: 6.2 }); };
        side(0, -1, 0, false); side(0, 1, 0, true); side(-1, 0, Math.PI / 2, false); side(1, 0, Math.PI / 2, false);
        put("barracks", -6, 5.5, 0.3, 5); put("house2", 6.5, 5.5, -0.4, 4.2); put("house1", -6.2, -6.8, 0.2, 4.2); put("house3", 6.8, -6.5, 0.5, 4.5); put("market", 0, 6.5, 0, 3.3);
        s.big = true; hs = 12;
      } else if (s.kind === "town") {
        put("tc2", 0, -2.5, 0, 6.5); flagAt(0, -2.5, 8.6, 1.4); put("market", 6.5, 3.5, 0.2, 4.6); put("temple", -6.8, -4.5, 0, 3.0, { tint: [1, 0.96, 0.9] });
        ring(9, 8.6, (x, z, a, i) => { if (z > 7 && Math.abs(x) < 2.6) return; house(x, z, a + Math.PI, i, 4.6); }, 0.35);
        const hs2 = 10; put("wwalltower", 0, -hs2, 0, 4.4, { sy: 5 }); put("wwall", -6.4, -hs2, 0, 4.4, { sy: 5 }); put("wwall", 6.4, -hs2, 0, 4.4, { sy: 5 }); put("wgate", 0, hs2, 0, 4.4, { sy: 5 }); put("wwall", -6.4, hs2, 0, 4.4, { sy: 5 }); put("wwall", 6.4, hs2, 0, 4.4, { sy: 5 });
        for (const sx of [-1, 1]) for (const sz of [-1, 1]) put("wtower3", sx * hs2, sz * hs2, 0, 3.4);
        s.big = true; hs = 10;
      } else if (s.kind === "village") {
        ring(5, 3.6, (x, z, a, i) => house(x, z, a + Math.PI + 0.3, i, 5), rnd(1, 9) * 3);
        put("windmill", 5.2, -3.6, 0.5, 4.2); put("farm", -5.0, -4.6, 0.2, 3.6);
        // اسکله اگر نزدیک آب است
        for (let k = 0; k < 16; k++) { const a = (k / 16) * TAU; let found = -1; for (let d = 120; d < 300; d += 20) if (M.cls(s.x + Math.sin(a) * d, s.y + Math.cos(a) * d) === 0) { found = d; break; } if (found > 0) { const d = (found - 20) * K; put("dock", Math.sin(a) * d, Math.cos(a) * d, a, 5, { sink: 0.3 }); break; } }
        hs = 6;
      } else if (s.kind === "home") {
        put("keep1", 0, -1, 0, 7.5); flagAt(0, -1, 7.9, 1.5); put("stower1", -7.5, -4, 0, 4.2); put("stower1", 7.5, -4, 0, 4.2);
        house(-6, 4.5, 0.3, 1, 4.6); house(6.2, 4.8, -0.3, 2, 4.6); house(0.5, 7, 0.1, 3, 4.2); put("barracks", -8.5, 0.5, 1.4, 4.2);
        hs = 8;
      } else if (s.kind === "camp") {
        put("c_campfire", 0, 0, 0, 1.5); put("c_tent", -3.4, -1.2, 0.5, 2.2); put("c_tent", 3.2, -1.8, -0.6, 2.0); put("c_tent", 0.5, 3.8, 0.1, 2.1); put("c_log", -1.5, 1.6, 0.8, 1.6); put("c_rock", 4.5, 2.5, 0, 1.6); put("c_tree", -5, 3, 0, 2.2);
        s.fire = [X0, heightAt(X0, Z0), Z0]; hs = 3;
      } else if (s.kind === "mine") {
        put("mine", 0, -1, 0.3, 5); put("gold1", 3.6, 2.5, 0.4, 3, { plain: true }); put("gold1", -3.4, 3.2, 1.2, 2.4, { plain: true }); put("logs", -4, -2, 0.5, 3); put("c_rock", 4, -3, 0, 2.5); put("c_rock", -5.4, 0.6, 1, 2);
        hs = 4;
      }
      s.cull = { x: X0, z: Z0, r: s.r * K * 1.15 + hs * 0.7 + 8, y: heightAt(X0, Z0) + 4 };
    }
  };
  R.drawSites = (t) => {
    const e = W3.eye;
    for (const s of R.sites) {
      const c = s.cull; if (!c) continue; const d = Math.hypot(c.x - e[0], c.z - e[2]); if (d > 200 + c.r) continue;
      let vis = true; for (let k = 0; k < 6; k++) if (fp[k * 4] * c.x + fp[k * 4 + 1] * c.y + fp[k * 4 + 2] * c.z + fp[k * 4 + 3] < -c.r) { vis = false; break; } if (!vis) continue;
      const P = s.pieces; for (let i = 0; i < P.length; i++) { const p = P[i]; inst(p.name, p.x, p.y, p.z, p.yaw, p.s, p.o); }
      if (d < 70) { for (const m of s.smoke) { for (let k = 0; k < 4; k++) { const ph = (((t * 0.33 + k / 4 + m[3] * 0.37) % 1) + 1) % 1; puff(m[0] + ph * 0.8, m[1] + ph * 3.4, m[2], 0.35 + ph * 1.1, 0.86, 0.86, 0.88, 0.42 * (1 - ph)); } }
        if (s.fire) { const f = s.fire; puff(f[0], f[1] + 0.9, f[2], 1.9 + Math.sin(t * 17 + f[0]) * 0.25, 1, 0.62, 0.2, 0.55, true); for (let k = 0; k < 3; k++) { const ph = (t * 0.5 + k / 3) % 1; puff(f[0] + Math.sin(ph * 5 + k) * 0.3, f[1] + 1.6 + ph * 4.5, f[2], 0.6 + ph * 1.7, 0.78, 0.78, 0.8, 0.36 * (1 - ph)); } } }
    }
  };
  R.ov = ov; R.camTo = (px, py) => { R.cam.x = px; R.cam.y = py; };
  return R;
}
