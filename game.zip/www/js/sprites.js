import { drawHead } from "./gear.js";
// نقاشی اسپریت‌ها (برج، دشمن، سرباز، قهرمان، دکور). همه در «واحد» رسم می‌شوند: ۵۰ واحد = یک خانه.
// اسپریت‌ها یک‌بار روی بوم‌های پنهان ساخته و کش می‌شوند تا هر فریم فقط drawImage باشد.
export const TAU = Math.PI * 2;
const hx = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
export const mix = (a, b, t) => { const A = hx(a), B = hx(b); return "#" + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, "0")).join(""); };
export const lighten = (c, t) => mix(c, "#ffffff", t), darken = (c, t) => mix(c, "#000000", t);
const INK = "rgba(10,8,20,0.62)";

function path(g, pts, close = true) { g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); if (close) g.closePath(); }
function fillStroke(g, fill, lw = 1.2, stroke = INK) { if (fill) { g.fillStyle = fill; g.fill(); } if (lw) { g.strokeStyle = stroke; g.lineWidth = lw; g.lineJoin = "round"; g.stroke(); } }
function ell(g, x, y, rx, ry, fill, lw = 1.2, stroke = INK, rot = 0) { g.beginPath(); g.ellipse(x, y, Math.abs(rx), Math.abs(ry), rot, 0, TAU); fillStroke(g, fill, lw, stroke); }
function rect(g, x, y, w, h, rad, fill, lw = 1.2, stroke = INK) { g.beginPath(); g.roundRect(x, y, w, h, rad); fillStroke(g, fill, lw, stroke); }
function lin(g, x1, y1, x2, y2, c1, c2) { const gr = g.createLinearGradient(x1, y1, x2, y2); gr.addColorStop(0, c1); gr.addColorStop(1, c2); return gr; }
function rad(g, x, y, r0, r1, c1, c2) { const gr = g.createRadialGradient(x, y, r0, x, y, r1); gr.addColorStop(0, c1); gr.addColorStop(1, c2); return gr; }
function line(g, x1, y1, x2, y2, c, w) { g.strokeStyle = c; g.lineWidth = w; g.lineCap = "round"; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); }
const shine = (g, x, y, rx, ry, rot = -0.5, a = 0.45) => { g.fillStyle = `rgba(255,255,255,${a})`; g.beginPath(); g.ellipse(x, y, rx, ry, rot, 0, TAU); g.fill(); };

// ---------------------------------------------------------------- جلوه‌ی درخشش (کش‌شده)
export function glowSprite(g, col, R = 32) { g.fillStyle = rad(g, 0, 0, 0, R, col + "cc", col + "00"); g.beginPath(); g.arc(0, 0, R, 0, TAU); g.fill(); }

// ================================================================ باس‌ها — هرکدام شکل و شخصیت اختصاصی
export function bossSprite(g, ab, r, f) {
  const fl = Math.sin(f * 1.57), bob = fl * r * 0.04;
  if (ab === "summon") { // سالار دشت: جنگسالار شاخدار با درفش
    path(g, [[-r * 1.0, -r * 0.5], [-r * 1.8, r * 0.9 + fl * r * 0.12], [-r * 0.8, r * 1.1], [0, r * 0.6]]); fillStroke(g, lin(g, -r * 1.8, 0, 0, 0, "#7a1020", "#3a0810"), 1.6);
    line(g, r * 1.15, r * 1.0, r * 1.15, -r * 1.9, "#6a4a2a", r * 0.1); path(g, [[r * 1.15, -r * 1.9], [r * 1.95, -r * 1.65 + fl * r * 0.1], [r * 1.15, -r * 1.2]]); fillStroke(g, "#d8302a", 1.4); ell(g, r * 1.5, -r * 1.55, r * 0.12, r * 0.12, "#ffd24a", 0.6);
    rect(g, -r * 0.55, r * 0.45, r * 0.45, r * 0.7, r * 0.15, "#3a2a20", 1.4); rect(g, r * 0.1, r * 0.45, r * 0.45, r * 0.7, r * 0.15, "#3a2a20", 1.4);
    ell(g, 0, bob, r * 1.0, r * 0.95, lin(g, 0, -r, 0, r, "#8a96b0", "#3a4258"), 2); rect(g, -r * 0.6, -r * 0.2, r * 1.2, r * 0.8, r * 0.2, lin(g, 0, 0, 0, r, "#a83028", "#5a1410"), 1.6);
    for (const s2 of [-1, 1]) ell(g, s2 * r * 0.95, -r * 0.35, r * 0.34, r * 0.26, lin(g, 0, -r * 0.5, 0, 0, "#d8c070", "#7a5a1a"), 1.4);
    drawHead(g, 0, -r * 0.8, r * 0.52, { skin: "#b88a66", hair: "#1a1a1a", helm: { kind: "horned", color: "#5a4a58" }, face: { shape: "square", jaw: 0.9, eye: "narrow", eyeCol: "#ff3a2a", brow: "angry", browTh: 0.9, browAng: 0.8, nose: "broad", noseSz: 1.1, mouth: "stern", beard: "full", hairStyle: "short", head: 1.05 } }, 0.3, {});
    path(g, [[r * 0.6, -r * 0.1], [r * 1.45, -r * 0.4], [r * 1.5, r * 0.1], [r * 0.7, r * 0.4]]); fillStroke(g, lin(g, r * 0.6, 0, r * 1.5, 0, "#cfd6df", "#6a7388"), 1.4);
  } else if (ab === "regen") { // پیر جنگل: غول درختی
    for (const s2 of [-1, 1]) { path(g, [[s2 * r * 0.5, r * 0.3], [s2 * r * 0.9, r * 1.1], [s2 * r * 0.2, r * 1.1]]); fillStroke(g, lin(g, 0, 0, 0, r, "#6a4a2a", "#3a2412"), 1.4); }
    rect(g, -r * 0.8, -r * 0.7, r * 1.6, r * 1.6, r * 0.35, lin(g, -r, 0, r, 0, "#7a5632", "#3e2814"), 2); for (let i = 0; i < 4; i++) line(g, -r * 0.6 + i * r * 0.4, -r * 0.4, -r * 0.55 + i * r * 0.4, r * 0.8, "rgba(0,0,0,.28)", 1.4);
    for (const s2 of [-1, 1]) { path(g, [[s2 * r * 0.7, -r * 0.4], [s2 * r * 1.7, -r * 0.8 + fl * r * 0.15], [s2 * r * 1.8, -r * 0.3], [s2 * r * 0.9, r * 0.2]]); fillStroke(g, lin(g, 0, 0, s2 * r * 1.8, 0, "#6a4a2a", "#3e2814"), 1.4); for (let i = 0; i < 3; i++) ell(g, s2 * (r * 1.5 + i * r * 0.14), -r * 0.8 + i * r * 0.2, r * 0.17, r * 0.1, "#58c84a", 0.8, INK, 0.6 * s2); }
    for (let i = 0; i < 7; i++) { const a = i / 7 * Math.PI + Math.PI; ell(g, Math.cos(a) * r * 0.85, -r * 0.85 + Math.sin(a) * r * 0.65, r * 0.4, r * 0.32, lin(g, 0, -r, 0, 0, "#58c84a", "#2a7a2a"), 1.2); }
    ell(g, 0, -r * 1.2, r * 0.55, r * 0.35, "#58c84a", 1.2);
    for (const s2 of [-1, 1]) { ell(g, s2 * r * 0.28, -r * 0.3, r * 0.17, r * 0.1, "#d8ff7a", 0.8); ell(g, s2 * r * 0.28, -r * 0.3, r * 0.06, r * 0.06, "#1a3a0a", 0); } path(g, [[-r * 0.3, 0], [0, r * 0.2], [r * 0.3, 0]], false); g.strokeStyle = "#1a0f08"; g.lineWidth = 2; g.stroke();
  } else if (ab === "charge") { // عقرب سرخ
    for (let i = 0; i < 6; i++) { const s2 = i < 3 ? -1 : 1, k = i % 3; line(g, s2 * r * 0.5, r * (0.1 + k * 0.25), s2 * r * (1.3 + (k % 2) * 0.2), r * (0.55 + k * 0.25) + (i % 2 ? fl : -fl) * r * 0.08, "#5a1410", r * 0.12); }
    ell(g, 0, r * 0.25, r * 1.0, r * 0.7, lin(g, 0, -r * 0.3, 0, r, "#e04a2a", "#7a1810"), 2);
    for (let i = 0; i < 4; i++) line(g, -r * 0.7 + i * r * 0.45, r * 0.0, -r * 0.7 + i * r * 0.45, r * 0.6, "rgba(0,0,0,.3)", 1.5);
    path(g, [[-r * 0.7, 0], [-r * 1.5, -r * 0.6], [-r * 1.4, -r * 1.3 + fl * r * 0.1], [-r * 0.9, -r * 1.6]]); g.lineWidth = r * 0.28; g.strokeStyle = "#a82818"; g.lineCap = "round"; g.stroke(); path(g, [[-r * 0.9, -r * 1.6], [-r * 0.5, -r * 1.55], [-r * 0.7, -r * 1.15]]); fillStroke(g, "#ffd24a", 1.2); // نیش
    for (const s2 of [-1, 1]) { path(g, [[s2 * r * 0.7, -r * 0.1], [s2 * r * 1.4, -r * 0.6], [s2 * r * 1.0, -r * 1.1], [s2 * r * 0.55, -r * 0.7]]); fillStroke(g, lin(g, 0, 0, s2 * r, -r, "#e0603a", "#8a2010"), 1.6); path(g, [[s2 * r * 1.4, -r * 0.6], [s2 * r * 1.75, -r * 0.9], [s2 * r * 1.0, -r * 1.1]]); fillStroke(g, "#c83a22", 1.4); }
    ell(g, r * 0.3, -r * 0.2, r * 0.22, r * 0.14, "#ffe45c", 0.8); ell(g, r * 0.3, -r * 0.2, r * 0.07, r * 0.07, "#000", 0); ell(g, r * 0.65, -r * 0.1, r * 0.18, r * 0.12, "#ffe45c", 0.8);
  } else if (ab === "frostimmune") { // غول یخی
    legs(g, r, f, "#7ab0d8", 0.34, 0.5, 0.6);
    path(g, [[-r * 0.8, r * 0.7], [-r * 1.0, -r * 0.5], [-r * 0.45, -r * 1.0], [r * 0.45, -r * 1.0], [r * 1.0, -r * 0.5], [r * 0.8, r * 0.7]]); fillStroke(g, lin(g, 0, -r, 0, r, "#e8f6ff", "#6aa0d0"), 2);
    for (const q of [[-0.5, -0.2, 0.8], [0.3, 0.0, 0.7], [-0.1, 0.35, 0.6]]) { path(g, [[r * q[0], r * q[1]], [r * (q[0] + 0.25), r * (q[1] + q[2] * 0.4)], [r * (q[0] - 0.1), r * (q[1] + q[2])]]); g.fillStyle = "rgba(255,255,255,.35)"; g.fill(); }
    for (const s2 of [-1, 1]) for (let i = 0; i < 3; i++) { path(g, [[s2 * r * (0.5 + i * 0.3), -r * 1.0], [s2 * r * (0.65 + i * 0.3), -r * (1.8 - i * 0.2)], [s2 * r * (0.8 + i * 0.3), -r * 0.95]]); fillStroke(g, lin(g, 0, -r * 2, 0, -r, "#f4fbff", "#5a98d0"), 1.4); }
    for (const s2 of [-1, 1]) { rect(g, s2 * r * 0.95, -r * 0.5 + fl * r * 0.08, r * 0.45, r * 1.3, r * 0.2, lin(g, 0, 0, 0, r, "#d8eeff", "#6aa0d0"), 1.6); }
    ell(g, 0, -r * 0.45, r * 0.5, r * 0.45, lin(g, 0, -r, 0, 0, "#f4fbff", "#9ac8ec"), 1.8); for (const s2 of [-1, 1]) { path(g, [[s2 * r * 0.1, -r * 0.55], [s2 * r * 0.4, -r * 0.62], [s2 * r * 0.3, -r * 0.45]]); g.fillStyle = "#2a8aff"; g.fill(); } path(g, [[-r * 0.25, -r * 0.2], [0, -r * 0.05], [r * 0.25, -r * 0.2]]); g.fillStyle = "#3a5a8a"; g.fill();
  } else if (ab === "aura") { // اژدهای مرداب
    path(g, [[-r * 0.3, 0], [-r * 1.8, -r * 0.9 + fl * r * 0.2], [-r * 1.3, r * 0.2], [-r * 0.4, r * 0.5]]); fillStroke(g, lin(g, -r * 1.8, 0, 0, 0, "#5a7a2a", "#2a3a10"), 1.6); path(g, [[r * 0.3, 0], [r * 1.8, -r * 0.9 + fl * r * 0.2], [r * 1.3, r * 0.2], [r * 0.4, r * 0.5]]); fillStroke(g, lin(g, r * 1.8, 0, 0, 0, "#5a7a2a", "#2a3a10"), 1.6);
    ell(g, 0, r * 0.3, r * 0.95, r * 0.8, lin(g, 0, -r * 0.5, 0, r, "#7ab83a", "#2e4a14"), 2); for (let i = 0; i < 5; i++) ell(g, -r * 0.6 + i * r * 0.3, r * 0.55, r * 0.13, r * 0.18, "#d8e87a", 0.6);
    path(g, [[-r * 0.4, -r * 0.1], [-r * 0.6, -r * 0.9], [r * 0.2, -r * 1.35], [r * 0.9, -r * 1.0], [r * 1.0, -r * 0.55], [r * 0.5, -r * 0.3]]); fillStroke(g, lin(g, 0, -r * 1.3, 0, 0, "#8ac84a", "#3a5a18"), 2);
    for (const s2 of [0, 1]) { path(g, [[-r * 0.1 + s2 * r * 0.4, -r * 1.2], [-r * 0.2 + s2 * r * 0.4, -r * 1.75], [r * 0.1 + s2 * r * 0.4, -r * 1.3]]); fillStroke(g, "#e8e0c0", 1.2); }
    ell(g, r * 0.35, -r * 0.8, r * 0.17, r * 0.11, "#ffe45c", 0.8); ell(g, r * 0.37, -r * 0.8, r * 0.05, r * 0.08, "#000", 0); g.fillStyle = "#fff"; for (let i = 0; i < 3; i++) { path(g, [[r * 0.6 + i * r * 0.1, -r * 0.4], [r * 0.65 + i * r * 0.1, -r * 0.25], [r * 0.7 + i * r * 0.1, -r * 0.4]]); g.fill(); }
    for (let i = 0; i < 3; i++) { g.fillStyle = `rgba(120,255,90,${0.5 - i * 0.12})`; g.beginPath(); g.arc(-r * 0.5 + i * r * 0.5, -r * 1.5 - i * r * 0.1 + fl * 2, r * 0.12 + i * 1.2, 0, TAU); g.fill(); }
  } else if (ab === "enrage") { // ضحاک: مار روی دوش
    path(g, [[-r * 1.0, -r * 0.3], [-r * 1.6, r * 0.9], [-r * 0.6, r * 1.1], [0, r * 0.5]]); fillStroke(g, lin(g, -r * 1.6, 0, 0, 0, "#2a0a12", "#6a1a1a"), 1.6);
    rect(g, -r * 0.55, r * 0.4, r * 0.45, r * 0.7, r * 0.15, "#2a1a1a", 1.4); rect(g, r * 0.1, r * 0.4, r * 0.45, r * 0.7, r * 0.15, "#2a1a1a", 1.4);
    ell(g, 0, 0, r * 0.95, r * 0.9, lin(g, 0, -r, 0, r, "#5a1a1a", "#1e0808"), 2); rect(g, -r * 0.55, -r * 0.2, r * 1.1, r * 0.8, r * 0.2, lin(g, 0, 0, 0, r, "#8a2a1a", "#3a0e0a"), 1.6);
    for (const s2 of [-1, 1]) { const w = fl * s2 * r * 0.15; g.beginPath(); g.moveTo(s2 * r * 0.7, -r * 0.3); g.bezierCurveTo(s2 * r * 1.5, -r * 0.4 + w, s2 * r * 1.0, -r * 1.2, s2 * r * 1.5, -r * 1.55 + w); g.lineWidth = r * 0.3; g.strokeStyle = "#2a6a2a"; g.lineCap = "round"; g.stroke(); g.lineWidth = r * 0.16; g.strokeStyle = "#4aa84a"; g.stroke(); ell(g, s2 * r * 1.55, -r * 1.65 + w, r * 0.27, r * 0.2, lin(g, 0, 0, 0, 1, "#4aa84a", "#2a6a2a"), 1.4); ell(g, s2 * r * 1.62, -r * 1.7 + w, r * 0.05, r * 0.05, "#ff3a2a", 0); }
    drawHead(g, 0, -r * 0.8, r * 0.52, { skin: "#a86a44", hair: "#0a0a0a", helm: { kind: "crown", color: "#c8a030" }, face: { shape: "long", jaw: 0.5, eye: "narrow", eyeCol: "#ff3a2a", brow: "angry", browTh: 1, browAng: 1, nose: "hooked", noseSz: 1.15, mouth: "grin", beard: "mgoat", hairStyle: "long", head: 1.03, scar: true } }, 0.3, {});
  } else if (ab === "shieldphase") { // فرمانده ابر
    for (let i = 0; i < 3; i++) { g.fillStyle = `rgba(255,255,255,${0.55 - i * 0.12})`; g.beginPath(); g.ellipse(-r * 0.5 + i * r * 0.5, r * 0.85 - i * 2, r * (0.7 - i * 0.1), r * 0.3, 0, 0, TAU); g.fill(); }
    path(g, [[-r * 0.8, -r * 0.3], [-r * 1.7, r * 0.5 + fl * r * 0.12], [-r * 0.6, r * 0.7]]); fillStroke(g, lin(g, -r * 1.7, 0, 0, 0, "#f4f8ff", "#9ab8e8"), 1.4); path(g, [[r * 0.8, -r * 0.3], [r * 1.7, r * 0.5 + fl * r * 0.12], [r * 0.6, r * 0.7]]); fillStroke(g, lin(g, r * 1.7, 0, 0, 0, "#f4f8ff", "#9ab8e8"), 1.4);
    ell(g, 0, bob, r * 0.85, r * 0.9, lin(g, 0, -r, 0, r, "#e8f0ff", "#6a88c8"), 2); path(g, [[-r * 0.5, -r * 0.3], [0, r * 0.2], [r * 0.5, -r * 0.3], [r * 0.4, r * 0.8], [-r * 0.4, r * 0.8]]); fillStroke(g, lin(g, 0, 0, 0, r, "#5a78c8", "#2a3a78"), 1.4);
    drawHead(g, 0, -r * 0.8, r * 0.5, { skin: "#f2d0a8", hair: "#f4f7fc", helm: { kind: "winged", color: "#cfe6ff", plume: "#7ad0ff" }, face: { shape: "oval", jaw: 0.2, eye: "almond", eyeCol: "#2a8aff", brow: "straight", browTh: 0.4, browAng: 0.2, nose: "straight", noseSz: 0.95, mouth: "stern", beard: "none", hairStyle: "long", head: 1 } }, 0.3, {});
    for (let i = 0; i < 3; i++) { const a = i / 3 * TAU + f * 0.5; const ox = Math.cos(a) * r * 1.35, oy = Math.sin(a) * r * 0.5 - r * 0.2; g.beginPath(); g.arc(ox, oy, r * 0.22, 0, TAU); fillStroke(g, rad(g, ox, oy, 0, r * 0.22, "#fff", "#7bd8ff"), 1.2); }
  } else if (ab === "all") { // اهریمن
    for (const s2 of [-1, 1]) { path(g, [[s2 * r * 0.6, -r * 0.2], [s2 * r * 1.9, -r * 1.2 + fl * r * 0.15], [s2 * r * 1.6, r * 0.1], [s2 * r * 1.0, -r * 0.1], [s2 * r * 0.8, r * 0.5]]); fillStroke(g, lin(g, 0, -r, s2 * r * 1.8, 0, "#2a1048", "#0e0420"), 1.6); line(g, s2 * r * 0.7, -r * 0.2, s2 * r * 1.8, -r * 1.1 + fl * r * 0.15, "#7a3ad8", 2); }
    for (let i = 0; i < 6; i++) { const a = i / 6 * TAU + f * 0.4; g.fillStyle = `rgba(170,90,255,${0.45})`; g.beginPath(); g.ellipse(Math.cos(a) * r * 0.9, r * 0.8 + Math.sin(a) * r * 0.2, r * 0.2, r * 0.45, 0, 0, TAU); g.fill(); }
    ell(g, 0, 0, r * 0.95, r * 0.95, lin(g, 0, -r, 0, r, "#4a2480", "#120628"), 2); for (const q of [-0.4, 0, 0.4]) { g.strokeStyle = "rgba(190,120,255,.8)"; g.lineWidth = 1.5; g.beginPath(); g.moveTo(r * q, -r * 0.1); g.lineTo(r * q * 1.2, r * 0.7); g.stroke(); }
    ell(g, 0, -r * 0.75, r * 0.6, r * 0.55, lin(g, 0, -r * 1.3, 0, -r * 0.2, "#5a2e96", "#1a0836"), 1.8);
    for (const s2 of [-1, 1]) { path(g, [[s2 * r * 0.3, -r * 1.1], [s2 * r * 1.0, -r * 2.0], [s2 * r * 0.75, -r * 1.0]]); fillStroke(g, lin(g, 0, -r * 2, 0, -r, "#e8d8ff", "#7a4ad8"), 1.4); path(g, [[s2 * r * 0.1, -r * 0.8], [s2 * r * 0.5, -r * 0.95], [s2 * r * 0.35, -r * 0.65]]); g.fillStyle = "#ff3aff"; g.fill(); }
    path(g, [[-r * 0.35, -r * 0.45], [-r * 0.2, -r * 0.3], [0, -r * 0.45], [r * 0.2, -r * 0.3], [r * 0.35, -r * 0.45], [0, -r * 0.2]]); g.fillStyle = "#fff"; g.fill();
    ell(g, 0, -r * 1.35, r * 0.15, r * 0.15, rad(g, 0, -r * 1.35, 0, r * 0.15, "#fff", "#c850ff"), 0.8);
  }
}

// ================================================================ برج‌ها
// پایه (ثابت): سکو با آجر، رنگ لبه بر اساس سطح و شکل نهایی
export function towerBase(g, lvl, col, evo) {
  g.fillStyle = "rgba(0,0,0,0.32)"; g.beginPath(); g.ellipse(0, 15, 27, 10, 0, 0, TAU); g.fill();
  const rim = lvl === 1 ? "#a2a2b0" : lvl === 2 ? "#dfe5f2" : "#ffd24a";
  const oct = (rx, ry, cy) => { g.beginPath(); for (let i = 0; i < 8; i++) { const a = i * TAU / 8 + TAU / 16; g.lineTo(Math.cos(a) * rx, Math.sin(a) * ry + cy); } g.closePath(); };
  oct(24, 16, 7); g.fillStyle = "#3d3d4c"; g.fill(); g.strokeStyle = INK; g.lineWidth = 1.5; g.stroke();
  oct(24, 16, 3); g.fillStyle = lin(g, 0, -12, 0, 18, "#8a8a9c", "#55556a"); g.fill(); g.strokeStyle = rim; g.lineWidth = 3; g.stroke();
  g.strokeStyle = "rgba(0,0,0,0.22)"; g.lineWidth = 1; for (let i = 0; i < 8; i++) { const a = i * TAU / 8 + TAU / 16; g.beginPath(); g.moveTo(Math.cos(a) * 9, Math.sin(a) * 6 + 3); g.lineTo(Math.cos(a) * 23, Math.sin(a) * 15 + 3); g.stroke(); }
  oct(15, 10, 1); g.fillStyle = lin(g, 0, -9, 0, 11, lighten("#7a7a90", 0.1), "#5a5a70"); g.fill(); g.strokeStyle = "rgba(255,255,255,0.18)"; g.lineWidth = 1; g.stroke();
  if (evo) { g.strokeStyle = col; g.globalAlpha = 0.9; g.lineWidth = 2; g.beginPath(); g.ellipse(0, 3, 21, 13, 0, 0, TAU); g.stroke(); for (let i = 0; i < 8; i++) { const a = i * TAU / 8; g.fillStyle = col; g.fillRect(Math.cos(a) * 21 - 1.5, Math.sin(a) * 13 + 1.5, 3, 3); } g.globalAlpha = 1; }
  // نشانه‌ی سطح: پرچم‌های کوچک
  for (let i = 0; i < lvl; i++) { const x = (i - (lvl - 1) / 2) * 9; g.fillStyle = "#ffd24a"; g.strokeStyle = "#7a4a08"; g.lineWidth = 1; g.beginPath(); g.moveTo(x, 19); g.lineTo(x - 3.5, 23.5); g.lineTo(x + 3.5, 23.5); g.closePath(); g.fill(); g.stroke(); }
}
// سر (بخش بالایی). پیکان به راست؛ چرخش در زمان اجرا انجام می‌شود (برای برج‌های چرخان)
export function towerHead(g, kind, lvl, evo, col, tint) {
  const gold = lvl >= 3 ? "#ffd24a" : lvl === 2 ? "#cfd8e8" : "#b98a50", wood = lvl >= 3 ? "#8a5a2a" : "#7a5230", ec = evo ? col : tint;
  if (kind === "bow") { // کمان بلند / کروسبو
    const L = 15 + lvl * 2 + (evo === "b" ? 5 : 0);
    rect(g, -8, -3.5, 30, 7, 3, lin(g, 0, -3, 0, 4, lighten(wood, 0.25), darken(wood, 0.2)));
    g.strokeStyle = INK; g.lineWidth = 6.5; g.lineCap = "round"; g.beginPath(); g.arc(9, 0, L, -1.2, 1.2); g.stroke();
    g.strokeStyle = evo ? ec : gold; g.lineWidth = 4; g.beginPath(); g.arc(9, 0, L, -1.2, 1.2); g.stroke();
    g.strokeStyle = "rgba(255,255,255,0.85)"; g.lineWidth = 1; g.beginPath(); g.moveTo(9 + Math.cos(-1.2) * L, Math.sin(-1.2) * L); g.lineTo(-1, 0); g.lineTo(9 + Math.cos(1.2) * L, Math.sin(1.2) * L); g.stroke();
    if (evo === "a") { for (const s of [-1, 1]) { g.strokeStyle = ec; g.lineWidth = 3; g.beginPath(); g.arc(9, s * 3, L - 4, s * -1.1, s * 1.1); g.stroke(); } ell(g, 20, 0, 3, 3, ec, 1); }
    if (evo === "b") { rect(g, 4, -8, 14, 4, 2, "#2a2a38"); ell(g, 18, -6, 3, 3, ec, 1); g.fillStyle = ec; g.fillRect(-6, -1, 10, 2); }
    for (let i = 0; i < lvl; i++) rect(g, 1 + i * 5, -5, 3, 10, 1.5, gold, 0.8);
  } else if (kind === "spear") { // بالیستا
    rect(g, -14, -4, 38, 8, 3, lin(g, 0, -4, 0, 5, lighten(wood, 0.25), darken(wood, 0.25)));
    g.strokeStyle = INK; g.lineWidth = 7; g.lineCap = "round"; g.beginPath(); g.moveTo(-2, -15 - lvl); g.quadraticCurveTo(14, 0, -2, 15 + lvl); g.stroke();
    g.strokeStyle = evo ? ec : gold; g.lineWidth = 4; g.beginPath(); g.moveTo(-2, -15 - lvl); g.quadraticCurveTo(14, 0, -2, 15 + lvl); g.stroke();
    g.strokeStyle = "#fff"; g.lineWidth = 0.9; g.beginPath(); g.moveTo(-2, -15 - lvl); g.lineTo(-8, 0); g.lineTo(-2, 15 + lvl); g.stroke();
    const sz = evo === "a" ? 1.5 : 1; g.save(); g.scale(sz, sz); path(g, [[18, -5], [34, 0], [18, 5]]); fillStroke(g, evo ? ec : "#e8eef7", 1.3); g.restore();
    rect(g, -16, -2, 26, 4, 2, evo ? darken(ec, 0.2) : "#6a4a2a", 0.8);
    if (evo === "b") for (let i = 0; i < 3; i++) { g.strokeStyle = ec; g.lineWidth = 1.5; g.beginPath(); g.arc(-8 + i * 9, 8, 3, 0, TAU); g.stroke(); }
    if (evo === "a") { ell(g, 4, 0, 4, 4, ec, 1); }
  } else if (kind === "catapult") { // بدنه‌ی منجنیق؛ بازو جداگانه رسم می‌شود
    rect(g, -22, -7, 44, 12, 4, lin(g, 0, -7, 0, 6, lighten(wood, 0.2), darken(wood, 0.3)));
    for (const wx of [-15, 15]) { ell(g, wx, 8, 8, 8, "#2b2b34", 1.5); ell(g, wx, 8, 3, 3, "#9a9aaa", 1); g.strokeStyle = "#9a9aaa"; g.lineWidth = 1; for (let i = 0; i < 6; i++) { const a = i * TAU / 6; g.beginPath(); g.moveTo(wx, 8); g.lineTo(wx + Math.cos(a) * 7, 8 + Math.sin(a) * 7); g.stroke(); } }
    rect(g, -3, -14, 6, 10, 2, "#5a3a1e"); rect(g, -10, -3, 20, 3, 1, evo ? ec : gold, 0.8);
  } else if (kind === "frost") { // کریستال یخی شناور + حلقه‌ها
    g.save(); const S = 1 + lvl * 0.12 + (evo ? 0.18 : 0);
    path(g, [[0, -20 * S], [10 * S, -3 * S], [6 * S, 12 * S], [0, 17 * S], [-6 * S, 12 * S], [-10 * S, -3 * S]]); fillStroke(g, lin(g, -10, -20, 10, 17, lighten(ec, 0.7), darken(ec, 0.15)), 1.5);
    path(g, [[0, -20 * S], [10 * S, -3 * S], [0, 2 * S]]); g.fillStyle = "rgba(255,255,255,0.55)"; g.fill();
    path(g, [[0, 2 * S], [-10 * S, -3 * S], [-6 * S, 12 * S], [0, 17 * S]]); g.fillStyle = "rgba(20,70,120,0.22)"; g.fill();
    for (const [x, y, h] of [[-15, 6, 9], [15, 7, 8], [-20, 2, 6]]) { path(g, [[x - 3, y + 6], [x, y - h], [x + 3, y + 6]]); fillStroke(g, lighten(ec, 0.55), 1); }
    g.restore();
  } else if (kind === "lightning") { // برج تسلا
    rect(g, -5, -24, 10, 28, 3, lin(g, -5, 0, 5, 0, "#6a6a80", "#34344a"));
    for (let i = 0; i < 3 + lvl; i++) rect(g, -9 + (i % 2), -21 + i * 6, 18 - (i % 2) * 2, 3, 1.5, lin(g, 0, 0, 0, 3, "#b8b8cc", "#6a6a80"), 0.8);
    ell(g, 0, -29, 8, 8, lin(g, 0, -37, 0, -21, "#fff", ec), 1.3); ell(g, 0, 5, 12, 4, "#4a4a5e", 1.2);
    if (evo === "b") { for (const s of [-1, 1]) { rect(g, s * 14 - 2, -12, 4, 16, 2, "#4a4a5e"); ell(g, s * 14, -14, 4, 4, ec, 1); } }
    if (evo === "a") { for (const s of [-1, 1]) { path(g, [[s * 6, -20], [s * 17, -26], [s * 8, -12]]); fillStroke(g, ec, 1); } }
  } else if (kind === "flame") { // سبد آتش / اژدها
    path(g, [[-15, -7], [15, -7], [10, 8], [-10, 8]]); fillStroke(g, lin(g, 0, -7, 0, 8, "#5a4034", "#2a1a14"), 1.5);
    g.strokeStyle = evo ? ec : gold; g.lineWidth = 3; g.beginPath(); g.moveTo(-15, -7); g.lineTo(15, -7); g.stroke();
    for (let i = -1; i <= 1; i++) { g.fillStyle = "#ff6a2e"; g.fillRect(i * 6 - 1, -3, 2, 8); }
    if (evo === "a") { path(g, [[-6, -8], [0, -22], [6, -8]]); fillStroke(g, ec, 1); ell(g, 0, -14, 6, 5, darken(ec, 0.2), 1); g.fillStyle = "#ffd24a"; g.fillRect(-3, -15, 2, 2); g.fillRect(2, -15, 2, 2); }
    if (evo === "b") { path(g, [[-14, -7], [-6, -20], [0, -12], [6, -20], [14, -7]]); fillStroke(g, lin(g, 0, -20, 0, -7, "#5a2a1a", "#2a1a14"), 1.3); }
  } else if (kind === "arcane") { // ستون با گوی
    path(g, [[-9, 6], [-5, -10], [5, -10], [9, 6]]); fillStroke(g, lin(g, -9, 0, 9, 0, "#7a6aa8", "#3a2a64"), 1.3);
    g.fillStyle = "#ffd24a"; g.fillRect(-7, -12, 14, 3);
    const R = 10 + lvl + (evo ? 2 : 0); ell(g, 0, -22, R, R, rad(g, -3, -25, 1, R, "#fff", ec), 1.3); shine(g, -3, -26, 4, 2.500);
    if (evo === "a") for (let i = 0; i < 3; i++) { const a = i * TAU / 3; ell(g, Math.cos(a) * 17, -22 + Math.sin(a) * 6, 2.500, 2.500, "#fff", 0.8); }
    if (evo === "b") { path(g, [[-4, -33], [0, -42], [4, -33]]); fillStroke(g, ec, 1); }
  } else if (kind === "poison") { // دیگ زهر
    ell(g, 0, 12, 15, 5, "rgba(0,0,0,0.25)", 0, "");
    g.beginPath(); g.ellipse(0, 2, 14, 11, 0, 0, TAU); fillStroke(g, rad(g, -4, -2, 2, 16, "#5a5a68", "#25252e"), 1.5);
    g.beginPath(); g.ellipse(0, -6, 12, 5, 0, 0, TAU); fillStroke(g, rad(g, 0, -6, 1, 12, "#d6ff7a", evo ? ec : "#5aa81c"), 1.3);
    for (const [x, y, r] of [[-5, -7, 2.500], [3, -5, 2], [6, -8, 1.600]]) ell(g, x, y, r, r, "rgba(230,255,160,0.9)", 0.8);
    ell(g, -9, 3, 3, 3, evo ? ec : "#8fe04a", 0.8); if (evo === "b") { path(g, [[-12, -9], [-6, -16], [-2, -9]]); fillStroke(g, ec, 1); }
    if (evo === "a") for (let i = 0; i < 3; i++) ell(g, -8 + i * 8, -16 - (i % 2) * 4, 3.500, 3.500, "rgba(160,220,80,0.55)", 0.8);
  } else if (kind === "guard") { // برج دیده‌بانی با پرچم
    rect(g, -13, -8, 26, 20, 3, lin(g, 0, -8, 0, 12, "#b8a58a", "#6e5e48")); for (let i = -2; i <= 2; i++) rect(g, i * 5.500 - 2, -13, 4, 6, 1, "#cdbb9e", 1);
    path(g, [[-5, 12], [-5, 2], [0, -2], [5, 2], [5, 12]]); fillStroke(g, "#2a2018", 1.2);
    g.fillStyle = evo ? ec : tint; g.strokeStyle = INK; g.lineWidth = 1.2; g.beginPath(); g.moveTo(8, -13); g.lineTo(8, -30); g.stroke(); g.beginPath(); g.moveTo(8, -30); g.lineTo(20, -26); g.lineTo(8, -21); g.closePath(); g.fill(); g.stroke();
    if (evo) { path(g, [[-16, -8], [0, -17], [16, -8]]); fillStroke(g, ec, 1); }
  } else if (kind === "temple") { // آتشکده با شعله‌ی مقدس
    rect(g, -14, 6, 28, 6, 2, lin(g, 0, 6, 0, 12, "#d8cfc0", "#8a7e6a")); rect(g, -10, 0, 20, 7, 2, lin(g, 0, 0, 0, 7, "#cfc5b2", "#8a7e6a"));
    rect(g, -8, -6, 16, 7, 2, lin(g, 0, -6, 0, 1, "#e0d6c2", "#9a8e78"));
    g.beginPath(); g.ellipse(0, -8, 9, 3.500, 0, 0, TAU); fillStroke(g, lin(g, 0, -12, 0, -4, "#ffd24a", "#a06a10"), 1.3);
    path(g, [[-6, -9], [-5, -20 - lvl], [0, -30 - lvl * 1.500], [5, -20 - lvl], [6, -9]]); fillStroke(g, rad(g, 0, -14, 1, 14, "#fff3a0", evo ? ec : "#ff8a1a"), 1.2);
    if (evo === "b") { g.strokeStyle = ec; g.lineWidth = 1.500; g.beginPath(); g.ellipse(0, -12, 14, 5, 0, 0, TAU); g.stroke(); }
  } else if (kind === "bank") { // صندوق گنج
    rect(g, -16, -10, 32, 20, 3, lin(g, 0, -10, 0, 10, "#9a6030", "#5a3418"));
    g.beginPath(); g.ellipse(0, -10, 16, 8, 0, Math.PI, 0); fillStroke(g, lin(g, 0, -18, 0, -10, "#b87838", "#7a4a22"), 1.5);
    rect(g, -16, -4, 32, 3.5, 0, evo ? ec : gold, 0.8); rect(g, -3, -9, 6, 9, 1.500, evo ? ec : gold, 1);
    for (const [x, y] of [[-10, -17], [0, -20], [10, -17]]) ell(g, x, y, 4.500, 4.500, "#ffd24a", 1, "#7a4a08");
    ell(g, 0, 18, 7, 2.500, "rgba(0,0,0,0.2)", 0, "");
  }
}
// بازوی منجنیق (به‌صورت جدا برای انیمیشن)
export function catapultArm(g, lvl, evo, col) { rect(g, -3, -28, 6, 32, 2, lin(g, -3, 0, 3, 0, "#a06a34", "#5a3a1e")); ell(g, 0, -28, 8, 8, evo ? darken(col, 0.1) : "#4a4a58", 1.4); g.fillStyle = "#222"; g.beginPath(); g.arc(0, -31, 5, 0, TAU); g.fill(); }

// ================================================================ دشمنان (رو به راست)
function legs(g, r, f, col, w = 0.2, y0 = 0.55, len = 0.7) { const s = Math.sin(f * Math.PI / 2); for (const sg of [-1, 1]) { const off = s * sg * r * 0.5; g.strokeStyle = INK; g.lineWidth = r * (w + 0.18); g.lineCap = "round"; g.beginPath(); g.moveTo(sg * r * 0.28, r * y0); g.lineTo(sg * r * 0.28 + off, r * (y0 + len)); g.stroke(); g.strokeStyle = col; g.lineWidth = r * w; g.stroke(); } }
function eye(g, x, y, r, c = "#ffe45c") { ell(g, x, y, r, r * 0.8, "#fff", 0.8); ell(g, x + r * 0.2, y, r * 0.55, r * 0.55, c, 0); g.fillStyle = "#000"; g.beginPath(); g.arc(x + r * 0.3, y, r * 0.25, 0, TAU); g.fill(); }

export function enemySprite(g, kind, r, f, tint, accent) {
  const dark = darken(tint, 0.38), lite = lighten(tint, 0.3), skinC = mix(tint, "#7da05a", 0.55);
  if (kind === "scout") { // گابلین دونده
    legs(g, r, f, dark, 0.2, 0.5, 0.75);
    path(g, [[-r * 0.7, r * 0.55], [-r * 0.3, -r * 0.5], [r * 0.5, -r * 0.45], [r * 0.7, r * 0.55]]); fillStroke(g, lin(g, 0, -r * 0.5, 0, r * 0.6, lite, dark), 1.2);
    path(g, [[-r * 0.1, -r * 0.5], [r * 0.2, -r * 0.1], [-r * 0.5, r * 0.4]]); g.fillStyle = "rgba(0,0,0,0.18)"; g.fill();
    path(g, [[r * 0.2, -r * 0.3], [r * 0.2 - r * 1.25, -r * 0.8], [-r * 0.1, -r * 0.1]]); fillStroke(g, tint, 1);
    ell(g, r * 0.35, -r * 0.8, r * 0.62, r * 0.58, skinC, 1.3); path(g, [[r * 0.6, -r * 1.0], [r * 1.35, -r * 1.35], [r * 0.85, -r * 0.7]]); fillStroke(g, skinC, 1); path(g, [[r * 0.0, -r * 1.0], [-r * 0.65, -r * 1.35], [-r * 0.2, -r * 0.7]]); fillStroke(g, skinC, 1);
    eye(g, r * 0.55, -r * 0.85, r * 0.22); g.fillStyle = "#fff"; path(g, [[r * 0.45, -r * 0.5], [r * 0.6, -r * 0.3], [r * 0.7, -r * 0.55]]); g.fill();
    line(g, r * 0.65, -r * 0.1, r * 1.35, -r * 0.5, "#cdd6e6", r * 0.16); line(g, r * 0.65, -r * 0.1, r * 0.95, -r * 0.22, "#7a4a22", r * 0.22);
  } else if (kind === "raider") { // اُرک جنگجو
    legs(g, r, f, dark, 0.26, 0.5, 0.7);
    rect(g, -r * 0.8, -r * 0.55, r * 1.6, r * 1.3, r * 0.3, lin(g, 0, -r * 0.5, 0, r * 0.8, lite, dark), 1.4);
    rect(g, -r * 0.8, r * 0.3, r * 1.6, r * 0.18, 2, "#4a3a28", 0.8); ell(g, 0, r * 0.4, r * 0.18, r * 0.14, "#ffd24a", 0.8);
    ell(g, r * 0.05, -r * 0.95, r * 0.62, r * 0.6, skinC, 1.4);
    g.beginPath(); g.arc(r * 0.05, -r * 1.02, r * 0.66, Math.PI, 0); g.closePath(); fillStroke(g, lin(g, 0, -r * 1.7, 0, -r * 1.0, "#9aa3b6", "#4f586c"), 1.3);
    for (const s of [-1, 1]) { path(g, [[s * r * 0.5, -r * 1.35], [s * r * 0.95, -r * 1.95], [s * r * 0.75, -r * 1.15]]); fillStroke(g, "#eee8d8", 1); }
    eye(g, r * 0.3, -r * 0.92, r * 0.18, "#ff4a3a"); g.fillStyle = "#fff"; g.fillRect(r * 0.1, -r * 0.5, r * 0.12, r * 0.18); g.fillRect(r * 0.4, -r * 0.5, r * 0.12, r * 0.18);
    ell(g, -r * 0.55, r * 0.1, r * 0.46, r * 0.5, lin(g, -r, 0, 0, 0, "#8a6a3a", "#5a3a1e"), 1.4); ell(g, -r * 0.55, r * 0.1, r * 0.14, r * 0.14, "#c8c8d8", 1);
    line(g, r * 0.55, r * 0.15, r * 1.55, -r * 0.65 + Math.sin(f * 1.57) * r * 0.2, "#cdd6e6", r * 0.2); line(g, r * 0.5, r * 0.2, r * 0.85, -r * 0.12, "#6a4a2a", r * 0.25);
  } else if (kind === "shield") { // شوالیه‌ی سپردار
    legs(g, r, f, "#6a7388", 0.28, 0.5, 0.7);
    rect(g, -r * 0.75, -r * 0.55, r * 1.5, r * 1.3, r * 0.3, lin(g, 0, -r * 0.5, 0, r * 0.8, "#c3cadc", "#6a7388"), 1.4);
    ell(g, 0, -r * 0.95, r * 0.62, r * 0.62, lin(g, 0, -r * 1.6, 0, -r * 0.3, "#d9deec", "#7a849a"), 1.4); rect(g, -r * 0.1, -r * 1.2, r * 0.7, r * 0.18, 1, "#1a1d28", 0.6);
    path(g, [[-r * 0.3, -r * 1.55], [0, -r * 2.2], [r * 0.3, -r * 1.55]]); fillStroke(g, tint, 1);
    path(g, [[r * 0.15, -r * 0.7], [r * 1.15, -r * 0.6], [r * 1.15, r * 0.3], [r * 0.65, r * 0.95], [r * 0.15, r * 0.3]]); fillStroke(g, lin(g, r * 0.1, -r * 0.7, r * 1.1, r * 0.9, lite, dark), 1.6);
    g.strokeStyle = "#e6ecfa"; g.lineWidth = r * 0.1; g.beginPath(); g.moveTo(r * 0.65, -r * 0.55); g.lineTo(r * 0.65, r * 0.8); g.moveTo(r * 0.2, -r * 0.05); g.lineTo(r * 1.1, -r * 0.05); g.stroke(); ell(g, r * 0.65, -r * 0.05, r * 0.16, r * 0.16, accent, 0.8);
  } else if (kind === "brute") { // غول با گرز
    legs(g, r, f, dark, 0.3, 0.45, 0.65);
    ell(g, 0, -r * 0.05, r * 1.05, r * 0.95, lin(g, 0, -r, 0, r, lite, dark), 1.6);
    ell(g, r * 0.05, r * 0.1, r * 0.7, r * 0.6, "rgba(255,255,255,0.12)", 0);
    for (const s of [-1, 1]) { ell(g, s * r * 0.85, -r * 0.5, r * 0.36, r * 0.3, "#5a4a3a", 1.3); for (let i = 0; i < 3; i++) { path(g, [[s * r * (0.7 + i * 0.12) - r * 0.07, -r * 0.7], [s * r * (0.78 + i * 0.12), -r * 1.05], [s * r * (0.7 + i * 0.12) + r * 0.07, -r * 0.7]]); fillStroke(g, "#d9d4c4", 0.8); } }
    ell(g, r * 0.12, -r * 0.95, r * 0.48, r * 0.44, skinC, 1.4); rect(g, -r * 0.3, -r * 1.35, r * 0.8, r * 0.16, 2, "#3a2a1c", 0.6);
    eye(g, r * 0.3, -r * 1.0, r * 0.14, "#ff3a2a"); path(g, [[r * 0.2, -r * 0.7], [r * 0.3, -r * 0.45], [r * 0.4, -r * 0.7]]); fillStroke(g, "#fff", 0.8); path(g, [[r * 0.5, -r * 0.72], [r * 0.58, -r * 0.5], [r * 0.64, -r * 0.74]]); fillStroke(g, "#fff", 0.8);
    const sw = Math.sin(f * 1.57) * r * 0.2; line(g, r * 0.75, r * 0.3, r * 1.45, -r * 0.8 + sw, "#7a5230", r * 0.26); ell(g, r * 1.5, -r * 0.95 + sw, r * 0.38, r * 0.38, "#686878", 1.5); for (let i = 0; i < 5; i++) { const a = i * TAU / 5; ell(g, r * 1.5 + Math.cos(a) * r * 0.36, -r * 0.95 + sw + Math.sin(a) * r * 0.36, r * 0.07, r * 0.07, "#ddd", 0.6); }
  } else if (kind === "flyer") { // عقاب تاریکی
    const fl = Math.sin(f * 1.57 + 0.4), fy = -r * 0.9 * fl;
    for (const s of [-1, 1]) { path(g, [[0, -r * 0.1], [-r * 1.3, -r * 0.5 + fy], [-r * 2.2, r * 0.1 + fy * 0.6], [-r * 1.7, r * 0.45], [-r * 1.2, r * 0.3], [-r * 0.8, r * 0.55], [0, r * 0.3]]); if (s === 1) { g.save(); g.scale(1, 1); } fillStroke(g, lin(g, 0, 0, -r * 2.2, 0, dark, darken(tint, 0.6)), 1.3); if (s === 1) g.restore(); break; }
    g.save(); g.translate(0, -r * 0.2); path(g, [[0, 0], [-r * 0.9, -r * 0.7 + fy * 0.8], [-r * 1.7, -r * 0.2 + fy * 0.6], [-r * 1.2, r * 0.1], [-r * 0.6, 0]]); fillStroke(g, tint, 1.2); g.restore();
    ell(g, 0, 0, r * 0.95, r * 0.6, lin(g, 0, -r * 0.6, 0, r * 0.6, lite, dark), 1.4); ell(g, r * 0.7, -r * 0.15, r * 0.45, r * 0.4, dark, 1.3);
    path(g, [[r * 0.95, -r * 0.2], [r * 1.65, 0], [r * 0.95, r * 0.15]]); fillStroke(g, "#ffd24a", 1); eye(g, r * 0.8, -r * 0.25, r * 0.15, "#ff3a2a");
    for (const [x, y] of [[-r * 0.8, r * 0.45], [-r * 0.5, r * 0.6]]) line(g, x, y, x - r * 0.1, y + r * 0.4, "#ffd24a", r * 0.1);
  } else if (kind === "healer") { // شمن
    const sw = Math.sin(f * 1.57);
    path(g, [[-r * 0.95, r * 1.0], [-r * 0.35, -r * 0.6], [r * 0.35, -r * 0.6], [r * 0.95, r * 1.0]]); fillStroke(g, lin(g, 0, -r * 0.6, 0, r, "#8ee0a8", darken("#3a9a60", 0.2)), 1.5);
    g.strokeStyle = "#ffe9a8"; g.lineWidth = r * 0.12; g.beginPath(); g.moveTo(-r * 0.7, r * 0.7); g.lineTo(r * 0.7, r * 0.7); g.stroke();
    path(g, [[-r * 0.55, -r * 0.45], [0, -r * 1.75], [r * 0.55, -r * 0.45]]); fillStroke(g, lin(g, 0, -r * 1.7, 0, -r * 0.4, "#4a3a8a", "#2a2058"), 1.4);
    ell(g, r * 0.1, -r * 0.8, r * 0.38, r * 0.34, "#2a2038", 1); eye(g, r * 0.25, -r * 0.82, r * 0.1, "#7bff9a"); eye(g, r * 0.02, -r * 0.82, r * 0.1, "#7bff9a");
    line(g, r * 0.75, r * 0.7, r * 0.95, -r * 1.3, "#8a6a3a", r * 0.14); ell(g, r * 0.95, -r * 1.5 + sw * r * 0.05, r * 0.32, r * 0.32, rad(g, r * 0.95, -r * 1.5, 0, r * 0.35, "#fff", "#3fd47a"), 1);
    g.strokeStyle = "#fff"; g.lineWidth = r * 0.1; g.beginPath(); g.moveTo(r * 0.95, -r * 1.65); g.lineTo(r * 0.95, -r * 1.35); g.moveTo(r * 0.8, -r * 1.5); g.lineTo(r * 1.1, -r * 1.5); g.stroke();
  } else if (kind === "splitter" || kind === "mini") { // ژله
    const sq = 1 + Math.sin(f * 1.57) * 0.12;
    g.save(); g.scale(1 / sq, sq); g.translate(0, r * (sq - 1) * 0.5);
    g.beginPath(); g.moveTo(-r * 1.05, r * 0.65); g.bezierCurveTo(-r * 1.2, -r * 0.6, -r * 0.5, -r * 1.1, 0, -r * 1.1); g.bezierCurveTo(r * 0.55, -r * 1.1, r * 1.2, -r * 0.6, r * 1.05, r * 0.65); g.quadraticCurveTo(0, r * 1.0, -r * 1.05, r * 0.65); fillStroke(g, lin(g, 0, -r * 1.1, 0, r, lighten(tint, 0.45) + "", darken(tint, 0.1)), 1.5);
    g.globalAlpha = 0.5; for (const [x, y, q] of [[-r * 0.4, r * 0.25, 0.2], [r * 0.4, -r * 0.1, 0.15], [r * 0.1, r * 0.35, 0.1]]) { g.fillStyle = "#fff"; g.beginPath(); g.arc(x, y, r * q, 0, TAU); g.fill(); } g.globalAlpha = 1;
    shine(g, -r * 0.4, -r * 0.55, r * 0.3, r * 0.16); eye(g, -r * 0.05, -r * 0.1, r * 0.2, "#fff"); eye(g, r * 0.5, -r * 0.1, r * 0.2, "#fff"); g.fillStyle = "#222"; g.beginPath(); g.arc(r * 0.2, r * 0.3, r * 0.1, 0, Math.PI); g.fill();
    g.restore();
  } else if (kind === "boss") { // سالار
    const fl = Math.sin(f * 1.57);
    path(g, [[-r * 0.9, -r * 0.4], [-r * 1.7, r * 0.9 + fl * r * 0.1], [-r * 0.8, r * 1.1], [0, r * 0.6]]); fillStroke(g, lin(g, -r * 1.7, 0, 0, 0, "#7a1020", "#3a0810"), 1.6);
    legs(g, r, f, dark, 0.32, 0.55, 0.55);
    ell(g, 0, 0, r * 1.05, r * 1.0, lin(g, 0, -r, 0, r, lite, dark), 2);
    rect(g, -r * 0.7, -r * 0.2, r * 1.4, r * 0.9, r * 0.2, lin(g, 0, 0, 0, r, "#4a4a5c", "#22222e"), 1.6); for (let i = -1; i <= 1; i++) ell(g, i * r * 0.4, r * 0.3, r * 0.1, r * 0.1, accent, 0.6);
    ell(g, r * 0.05, -r * 0.7, r * 0.62, r * 0.58, skinC, 1.8);
    for (const s of [-1, 1]) { path(g, [[s * r * 0.35, -r * 1.05], [s * r * 1.15, -r * 1.95], [s * r * 0.95, -r * 0.95]]); fillStroke(g, "#f2ead8", 1.4); }
    path(g, [[-r * 0.5, -r * 1.1], [-r * 0.4, -r * 1.55], [-r * 0.15, -r * 1.2], [0, -r * 1.7], [r * 0.15, -r * 1.2], [r * 0.4, -r * 1.55], [r * 0.5, -r * 1.1]]); fillStroke(g, "#ffd24a", 1.4, "#7a4a08");
    ell(g, 0, -r * 1.3, r * 0.08, r * 0.08, "#ff4d6a", 0.6);
    for (const s of [-1, 1]) { path(g, [[s * r * 0.15, -r * 0.8], [s * r * 0.55, -r * 0.9], [s * r * 0.4, -r * 0.65]]); g.fillStyle = "#ff3a2a"; g.fill(); }
    g.fillStyle = "#fff"; for (let i = 0; i < 4; i++) { path(g, [[-r * 0.3 + i * r * 0.2, -r * 0.4], [-r * 0.2 + i * r * 0.2, -r * 0.25], [-r * 0.1 + i * r * 0.2, -r * 0.4]]); g.fill(); }
  } else { ell(g, 0, 0, r, r, tint, 1.4); }
}

// ================================================================ سربازان (بازیکن)
export function troopSprite(g, kind, r, f, col) {
  const team = "#3f7bff", team2 = "#1d3f9a", gold = "#ffd24a", sw = Math.sin(f * Math.PI / 2), skin = "#f0c9a0";
  if (kind === "horse") {
    for (const [x, ph] of [[-r * 0.95, 0], [-r * 0.5, 2], [r * 0.5, 1], [r * 0.95, 3]]) { const a = Math.sin((f + ph) * 1.57) * r * 0.35; line(g, x, r * 0.4, x + a, r * 1.2, INK, r * 0.38); line(g, x, r * 0.4, x + a, r * 1.2, "#b87a3a", r * 0.24); }
    ell(g, 0, 0, r * 1.25, r * 0.7, lin(g, 0, -r * 0.7, 0, r * 0.7, "#d9954a", "#8a5222"), 1.6); path(g, [[r * 0.85, -r * 0.2], [r * 1.5, -r * 1.05], [r * 1.9, -r * 0.8], [r * 1.9, -r * 0.4], [r * 1.35, -r * 0.1]]); fillStroke(g, "#c8843a", 1.5);
    path(g, [[r * 1.2, -r * 0.85], [r * 0.7, -r * 1.2], [r * 0.9, -r * 0.5]]); fillStroke(g, "#3a2410", 1); eye(g, r * 1.65, -r * 0.65, r * 0.1, "#222");
    rect(g, -r * 0.55, -r * 0.7, r * 1.0, r * 0.3, 2, team, 0.8);
    rect(g, -r * 0.3, -r * 1.55, r * 0.7, r * 0.95, r * 0.2, lin(g, 0, -r * 1.5, 0, -r * 0.6, "#8fb4ff", team2), 1.3); ell(g, r * 0.05, -r * 1.8, r * 0.34, r * 0.34, skin, 1.2); g.beginPath(); g.arc(r * 0.05, -r * 1.85, r * 0.37, Math.PI, 0); fillStroke(g, "#c8d0e0", 1); path(g, [[r * 0.05, -r * 2.2], [r * 0.25, -r * 2.7], [r * 0.4, -r * 2.15]]); fillStroke(g, "#e8453a", 0.8);
    line(g, r * 0.3, -r * 1.2, r * 1.9, -r * 1.9, "#e8eef7", r * 0.1); line(g, r * 0.3, -r * 1.2, r * 0.8, -r * 1.4, "#7a4a22", r * 0.16);
    return;
  }
  if (kind === "ram") {
    for (const x of [-r * 0.7, r * 0.7]) { ell(g, x, r * 0.8, r * 0.38, r * 0.38, "#4a3220", 1.5); ell(g, x, r * 0.8, r * 0.14, r * 0.14, "#aaa", 1); }
    rect(g, -r * 1.1, -r * 0.4, r * 2.2, r * 1.0, r * 0.1, lin(g, 0, -r * 0.4, 0, r * 0.6, "#a87a44", "#5a3a1e"), 1.6);
    path(g, [[-r * 1.2, -r * 0.35], [0, -r * 1.3], [r * 1.2, -r * 0.35]]); fillStroke(g, lin(g, 0, -r * 1.3, 0, -r * 0.3, "#c0392b", "#7a1a12"), 1.6);
    g.strokeStyle = "rgba(0,0,0,0.3)"; g.lineWidth = 1; for (let i = -2; i <= 2; i++) { g.beginPath(); g.moveTo(i * r * 0.4, -r * 0.35); g.lineTo(i * r * 0.2, -r * 1.1); g.stroke(); }
    const th = Math.sin(f * 1.57) * r * 0.15; rect(g, r * 0.3 + th, r * 0.1, r * 1.6, r * 0.32, r * 0.1, "#6a4a2a", 1.4); path(g, [[r * 1.9 + th, r * 0.02], [r * 2.35 + th, r * 0.26], [r * 1.9 + th, r * 0.5]]); fillStroke(g, "#d0d6e6", 1.2);
    for (const x of [-r * 0.5, r * 0.5]) { ell(g, x, r * 0.0, r * 0.2, r * 0.2, skin, 1); }
    return;
  }
  legs(g, r, f, "#4a4a68", 0.26, 0.5, 0.7);
  const big = kind === "shield" ? 1.25 : 1;
  rect(g, -r * 0.7 * big, -r * 0.55, r * 1.4 * big, r * 1.3, r * 0.3, lin(g, 0, -r * 0.5, 0, r * 0.8, kind === "archer" ? "#7bcf94" : "#9ab8ff", kind === "archer" ? "#2f6a44" : team2), 1.4);
  g.fillStyle = gold; g.fillRect(-r * 0.7 * big, r * 0.3, r * 1.4 * big, r * 0.14);
  ell(g, 0, -r * 0.95, r * 0.55, r * 0.55, skin, 1.4);
  if (kind === "archer") { g.beginPath(); g.arc(0, -r * 0.95, r * 0.62, Math.PI * 0.9, Math.PI * 2.1); fillStroke(g, "#2f6a44", 1.3); path(g, [[-r * 0.4, -r * 1.3], [r * 0.5, -r * 1.2], [r * 0.15, -r * 1.9]]); fillStroke(g, "#2f6a44", 1); }
  else { g.beginPath(); g.arc(0, -r * 1.0, r * 0.6, Math.PI, 0); g.closePath(); fillStroke(g, lin(g, 0, -r * 1.6, 0, -r * 1.0, "#e0e6f4", "#8a94ac"), 1.3); rect(g, -r * 0.08, -r * 1.55, r * 0.16, r * 0.5, 2, "#e8453a", 0.6); path(g, [[-r * 0.1, -r * 1.55], [r * 0.1, -r * 2.1 + sw * r * 0.05], [r * 0.4, -r * 1.55]]); fillStroke(g, "#e8453a", 0.8); }
  eye(g, r * 0.22, -r * 0.95, r * 0.12, "#2a6aa8");
  if (kind === "sword") { ell(g, -r * 0.55, r * 0.05, r * 0.42, r * 0.5, lin(g, -r, 0, 0, 0, "#ffd24a", "#b8860b"), 1.4); line(g, r * 0.55, r * 0.15, r * 1.5, -r * 0.7 + sw * r * 0.25, "#e8eef7", r * 0.2); line(g, r * 0.5, r * 0.25, r * 0.85, -r * 0.1, "#7a4a22", r * 0.25); }
  if (kind === "shield") { path(g, [[r * 0.2, -r * 0.8], [r * 1.35, -r * 0.7], [r * 1.35, r * 0.4], [r * 0.8, r * 1.05], [r * 0.2, r * 0.4]]); fillStroke(g, lin(g, r * 0.2, -r * 0.8, r * 1.3, r, "#6a9cff", team2), 1.8); g.strokeStyle = gold; g.lineWidth = r * 0.12; g.beginPath(); g.moveTo(r * 0.8, -r * 0.7); g.lineTo(r * 0.8, r * 0.95); g.moveTo(r * 0.25, -r * 0.1); g.lineTo(r * 1.3, -r * 0.1); g.stroke(); ell(g, r * 0.8, -r * 0.1, r * 0.2, r * 0.2, gold, 0.8); }
  if (kind === "archer") { g.strokeStyle = INK; g.lineWidth = r * 0.3; g.lineCap = "round"; g.beginPath(); g.arc(r * 0.6, -r * 0.1, r * 1.0, -1.1, 1.1); g.stroke(); g.strokeStyle = "#e0a860"; g.lineWidth = r * 0.16; g.beginPath(); g.arc(r * 0.6, -r * 0.1, r * 1.0, -1.1, 1.1); g.stroke(); g.strokeStyle = "#fff"; g.lineWidth = 1; g.beginPath(); g.moveTo(r * 0.6 + Math.cos(-1.1) * r, -r * 0.1 + Math.sin(-1.1) * r); g.lineTo(r * 0.5, -r * 0.1); g.lineTo(r * 0.6 + Math.cos(1.1) * r, -r * 0.1 + Math.sin(1.1) * r); g.stroke(); }
}

// ================================================================ قهرمانان (رو به راست، ارتفاع ~۷۰ واحد)
function heroBody(g, o) {
  const f = o.f, sw = Math.sin(f * Math.PI / 2);
  // شنل
  if (o.cape) { g.beginPath(); g.moveTo(-6, -14); g.quadraticCurveTo(-26 - sw * 2, 0, -22 + sw * 3, 22); g.lineTo(-4, 18); g.closePath(); fillStroke(g, lin(g, -20, -14, -4, 20, o.cape, darken(o.cape, 0.45)), 1.5); }
  // پاها
  for (const s of [-1, 1]) { const off = o.moving ? sw * s * 5 : 0; rect(g, s * 4 - 3 + off * 0.3, 8, 6.500, 14 - Math.abs(off) * 0.3, 2.500, o.boots || "#3a3040", 1.2); rect(g, s * 4 - 4 + off * 0.3, 19, 9, 4.500, 2, darken(o.boots || "#3a3040", 0.2), 1); }
  // تن
  rect(g, -11, -16, 22, 28, 7, lin(g, -11, -16, 11, 12, lighten(o.armor, 0.25), darken(o.armor, 0.25)), 1.6);
  if (o.trim) { rect(g, -11, 5, 22, 4, 0, o.trim, 0.8); rect(g, -2, -16, 4, 28, 0, o.trim, 0.5); }
  if (o.pauldron) for (const s of [-1, 1]) ell(g, s * 12, -12, 6, 5, lin(g, 0, -17, 0, -7, lighten(o.pauldron, 0.3), darken(o.pauldron, 0.2)), 1.3);
}
export function heroSprite(g, key, f, moving) {
  const o = { f, moving };
  if (key === "arash") {
    heroBody(g, { ...o, armor: "#2f6f5a", trim: "#ffd24a", cape: "#e8c24a", boots: "#5a3a1e", pauldron: "#e8c24a" });
    ell(g, 0, -25, 9.5, 10, "#d9a070", 1.5); g.beginPath(); g.arc(0, -27, 10.500, Math.PI * 0.92, Math.PI * 2.08); fillStroke(g, lin(g, 0, -38, 0, -26, "#f0d070", "#a87a1a"), 1.5); path(g, [[-1, -37], [4, -45], [8, -35]]); fillStroke(g, "#e8453a", 1);
    eye(g, 4, -25, 2.600, "#2a1a0a"); path(g, [[-5, -19], [0, -14], [5, -19]]); g.fillStyle = "#2a1a0a"; g.fill();
    g.strokeStyle = INK; g.lineWidth = 2; g.beginPath(); g.moveTo(-9, 10); g.lineTo(-13, 18); g.stroke(); rect(g, -16, -2, 7, 18, 3, "#7a4a22", 1.2); for (const x of [-14.500, -12.500, -10.500]) line(g, x, -2, x, -9, "#e8eef7", 1.500);
  } else if (key === "rostam") {
    heroBody(g, { ...o, armor: "#a8321e", trim: "#ffd24a", cape: "#b03020", boots: "#3a2a20", pauldron: "#d8a040" });
    rect(g, -10, -15, 20, 8, 3, "#c88a50", 1); // پوست ببر روی سینه
    ell(g, 0, -25, 10, 10.500, "#c88a5a", 1.5);
    g.beginPath(); g.arc(0, -27, 11.500, Math.PI * 0.95, Math.PI * 2.05); g.closePath(); fillStroke(g, lin(g, 0, -38, 0, -27, "#c3cadc", "#6a7388"), 1.6); rect(g, -11.500, -28, 23, 3.500, 1, "#ffd24a", 0.8); path(g, [[-4, -37], [0, -48], [4, -37]]); fillStroke(g, "#e8453a", 1);
    for (const s of [-1, 1]) { path(g, [[s * 9, -33], [s * 17, -41], [s * 13, -29]]); fillStroke(g, "#f2ead8", 1); }
    eye(g, 4.200, -24, 2.500, "#1a0a05"); path(g, [[0, -29], [8, -27.500], [8, -25]]); g.fillStyle = "rgba(0,0,0,0.5)"; g.fill();
    g.beginPath(); g.moveTo(-8, -20); g.quadraticCurveTo(-9, -8, 0, -6); g.quadraticCurveTo(9, -8, 8, -20); g.quadraticCurveTo(0, -14, -8, -20); fillStroke(g, "#1a0f08", 1.2);
  } else if (key === "gordafarid") {
    heroBody(g, { ...o, armor: "#e8f2ff", trim: "#5aa8e8", cape: "#3a8ac8", boots: "#3a5a8a", pauldron: "#bfe0ff" });
    g.beginPath(); g.moveTo(-8, -30); g.quadraticCurveTo(-24, -10 + Math.sin(f * 1.57) * 3, -14, 20); g.lineTo(-6, 8); g.closePath(); fillStroke(g, lin(g, -20, -20, -6, 10, "#4a3a5a", "#1a1020"), 1.3); // موی بلند
    ell(g, 0, -25, 9.500, 10, "#f2cba8", 1.5); g.beginPath(); g.arc(0, -27, 10.500, Math.PI * 0.92, Math.PI * 2.08); fillStroke(g, lin(g, 0, -38, 0, -26, "#e8f2ff", "#7aa6d8"), 1.5);
    for (const s of [-1, 1]) { path(g, [[s * 9, -31], [s * 22, -38], [s * 20, -28], [s * 10, -27]]); fillStroke(g, "#fff", 1); } // بال‌های کلاهخود
    path(g, [[-3, -37], [0, -44], [3, -37]]); fillStroke(g, "#ffd24a", 1);
    eye(g, 4, -25, 2.500, "#2a6aa8"); line(g, 1, -19, 6, -19, "#c8484a", 1.800);
  } else if (key === "zal") {
    heroBody(g, { ...o, armor: "#7a6ae8", trim: "#ffd24a", cape: "#e8e0f8", boots: "#3a2a64" });
    g.beginPath(); g.moveTo(-9, -30); g.quadraticCurveTo(-22, -10, -12, 24); g.lineTo(-4, 6); g.closePath(); fillStroke(g, "#f4f7fc", 1.2);
    ell(g, 0, -25, 9.500, 10, "#f0d0b0", 1.5); g.beginPath(); g.arc(0, -27, 10.500, Math.PI * 0.9, Math.PI * 2.1); fillStroke(g, "#f4f7fc", 1.4);
    line(g, -8, -33, 8, -33, "#ffd24a", 2.500); ell(g, 0, -33, 2.800, 2.800, "#5fd8ff", 0.8, "#fff");
    eye(g, 4, -25, 2.500, "#4a8ad8"); g.beginPath(); g.moveTo(-6, -20); g.quadraticCurveTo(0, 2, 6, -20); g.quadraticCurveTo(0, -14, -6, -20); fillStroke(g, "#f4f7fc", 1);
    for (let i = 0; i < 3; i++) { const a = -2.6 + i * 0.5; path(g, [[-10, -8], [-10 + Math.cos(a) * 16, -8 + Math.sin(a) * 16], [-6, -4]]); g.fillStyle = "rgba(223,240,255,0.7)"; g.fill(); }
  } else if (key === "sohrab") {
    heroBody(g, { ...o, armor: "#c43a52", trim: "#ffd24a", cape: "#2a2a4a", boots: "#2a1a20", pauldron: "#e8b040" });
    ell(g, 0, -25, 9.800, 10.200, "#d9a070", 1.5); g.beginPath(); g.arc(0, -27, 10.800, Math.PI * 0.92, Math.PI * 2.08); fillStroke(g, lin(g, 0, -38, 0, -26, "#b8bfd0", "#5a6278"), 1.5); path(g, [[-2, -37], [3, -47], [7, -36]]); fillStroke(g, "#ff6a8a", 1);
    eye(g, 4, -25, 2.600, "#2a1a0a");
  } else if (key === "tahmineh") {
    heroBody(g, { ...o, armor: "#e0709a", trim: "#ffe08a", cape: "#f6c8dc", boots: "#6a2a4a", pauldron: "#ffd0e4" });
    g.beginPath(); g.moveTo(-8, -30); g.quadraticCurveTo(-23, -8 + Math.sin(f * 1.57) * 3, -13, 22); g.lineTo(-5, 8); g.closePath(); fillStroke(g, lin(g, -20, -20, -6, 10, "#3a1a2a", "#14080e"), 1.3);
    ell(g, 0, -25, 9.500, 10, "#f2cba8", 1.5); g.beginPath(); g.arc(0, -27, 10.500, Math.PI * 0.92, Math.PI * 2.08); fillStroke(g, "#3a1a2a", 1.5);
    path(g, [[-7, -36], [-3, -42], [0, -37], [3, -42], [7, -36]]); fillStroke(g, "#ffd24a", 1); ell(g, 0, -38, 2.200, 2.200, "#ff5a8a", 0.8, "#fff");
    eye(g, 4, -25, 2.500, "#5a2a3a"); line(g, 1, -19, 6, -19, "#d8486a", 1.800);
  } else if (key === "kaveh") {
    heroBody(g, { ...o, armor: "#5a4636", trim: "#2a1a10", boots: "#2a1a10", pauldron: "#8a96b0" });
    rect(g, -10, -4, 20, 20, 3, lin(g, 0, -4, 0, 16, "#8a5a38", "#4a2e1c"), 1.2); rect(g, -9, -12, 18, 8, 2, "#c8d0e0", 0.8);
    ell(g, 0, -25, 10, 10.500, "#c88a60", 1.5); g.beginPath(); g.arc(0, -28, 10, Math.PI * 0.95, Math.PI * 2.05); fillStroke(g, "#2a1a10", 1.3); rect(g, -11, -30, 22, 5, 1, "#e8453a", 0.9);
    eye(g, 4.200, -24, 2.500, "#1a0a05"); g.beginPath(); g.moveTo(-9, -20); g.quadraticCurveTo(-8, -6, 0, -4); g.quadraticCurveTo(8, -6, 9, -20); g.quadraticCurveTo(0, -13, -9, -20); fillStroke(g, "#4a3a30", 1.2);
    line(g, -14, -6, -14, -44, "#7a4a22", 2.500); path(g, [[-14, -44], [-3, -42], [-14, -34]]); fillStroke(g, "#e8453a", 1);
  }
  const HL = HERO_LOOK[key]; if (HL) drawHead(g, 0, -25, 10.2, HL, 0.55, {});
}
export const HERO_LOOK = {
  arash: { skin: "#e0b184", hair: "#2a1a10", helm: { kind: "cap", color: "#e8c24a" }, face: { shape: "oval", jaw: 0.3, eye: "almond", eyeCol: "#3a2a1a", brow: "arched", browTh: 0.4, browAng: 0.1, nose: "straight", noseSz: 1, mouth: "neutral", beard: "none", hairStyle: "short", head: 1 } },
  rostam: { skin: "#c68e5e", hair: "#1a1a2a", helm: { kind: "helm", color: "#c3cadc" }, face: { shape: "square", jaw: 0.9, eye: "narrow", eyeCol: "#1a1a22", brow: "thick", browTh: 0.9, browAng: 0.5, nose: "broad", noseSz: 1.15, mouth: "stern", beard: "full", hairStyle: "short", head: 1.05 } },
  gordafarid: { skin: "#f6dcbc", hair: "#2a1a2a", helm: { kind: "winged", color: "#e8f2ff", plume: "#7ad0ff" }, face: { shape: "oval", jaw: 0.15, eye: "big", eyeCol: "#2a6aa8", brow: "soft", browTh: 0.25, browAng: -0.2, nose: "small", noseSz: 0.85, mouth: "smile", beard: "none", hairStyle: "long", head: 0.97 } },
  zal: { skin: "#f2d0a8", hair: "#f4f7fc", helm: { kind: "crown", color: "#ffd24a" }, face: { shape: "long", jaw: 0.5, eye: "round", eyeCol: "#4a8ad8", brow: "soft", browTh: 0.5, browAng: -0.3, nose: "hooked", noseSz: 1, mouth: "neutral", beard: "long", hairStyle: "long", head: 1 } },
  sohrab: { skin: "#d9a070", hair: "#1a1218", helm: { kind: "helm", color: "#b8bfd0" }, face: { shape: "oval", jaw: 0.45, eye: "almond", eyeCol: "#2a1a1a", brow: "thick", browTh: 0.6, browAng: 0.35, nose: "straight", noseSz: 1, mouth: "grin", beard: "none", hairStyle: "short", head: 1 } },
  tahmineh: { skin: "#f4d6b8", hair: "#2a1220", helm: { kind: "crown", color: "#ffd24a" }, face: { shape: "oval", jaw: 0.1, eye: "big", eyeCol: "#5a2a3a", brow: "soft", browTh: 0.25, browAng: -0.2, nose: "small", noseSz: 0.8, mouth: "smile", beard: "none", hairStyle: "long", head: 0.97 } },
  kaveh: { skin: "#a8703f", hair: "#1a1a1a", helm: null, face: { shape: "round", jaw: 0.7, eye: "round", eyeCol: "#3a2a1a", brow: "angry", browTh: 0.8, browAng: 0.7, nose: "broad", noseSz: 1.1, mouth: "grin", beard: "mgoat", hairStyle: "bald", head: 1.02, scar: true } },
};
// سلاح قهرمان (پویا): زاویه‌ی ضربه از swing
export function heroWeapon(g, key, sw) {
  if (key === "arash") { g.save(); g.translate(8, -4); g.strokeStyle = INK; g.lineWidth = 6; g.lineCap = "round"; g.beginPath(); g.arc(6, 0, 20, -1.3, 1.3); g.stroke(); g.strokeStyle = "#e8b060"; g.lineWidth = 3; g.beginPath(); g.arc(6, 0, 20, -1.3, 1.3); g.stroke(); g.strokeStyle = "#fff"; g.lineWidth = 1; g.beginPath(); g.moveTo(6 + Math.cos(-1.3) * 20, Math.sin(-1.3) * 20); g.lineTo(6 - sw * 6, 0); g.lineTo(6 + Math.cos(1.3) * 20, Math.sin(1.3) * 20); g.stroke(); if (sw < 0.3) { line(g, 6, 0, 34, 0, "#e8eef7", 2); path(g, [[34, -3], [41, 0], [34, 3]]); fillStroke(g, "#fff", 0.8); } g.restore(); return; }
  g.save(); g.translate(9, -3); g.rotate(-0.9 + sw * 1.9);
  if (key === "rostam") { line(g, 0, 8, 14, -22, "#6a4a2a", 5); ell(g, 15, -25, 10, 9, lin(g, 6, -34, 24, -16, "#d8dce8", "#6a7088"), 1.6); for (let i = 0; i < 6; i++) { const a = i * TAU / 6; path(g, [[15 + Math.cos(a - 0.2) * 9, -25 + Math.sin(a - 0.2) * 8], [15 + Math.cos(a) * 15, -25 + Math.sin(a) * 14], [15 + Math.cos(a + 0.2) * 9, -25 + Math.sin(a + 0.2) * 8]]); fillStroke(g, "#c8ccd8", 0.8); } ell(g, 12, -28, 3, 2, "rgba(255,255,255,0.7)", 0); }
  else if (key === "gordafarid") { path(g, [[-2, 4], [1, 2], [24, -22], [26, -19], [3, 6]]); fillStroke(g, "#f4f9ff", 1.3); rect(g, -5, 3, 11, 3.500, 1.500, "#ffd24a", 1); g.save(); g.rotate(0.2); ell(g, -6, 6, 6, 7, lin(g, -12, 0, 0, 12, "#9ad0ff", "#3a6ab0"), 1.4); g.restore(); }
  else if (key === "zal") { line(g, 0, 10, 8, -26, "#caa066", 3); g.globalAlpha = 1; ell(g, 9, -30, 7, 7, rad(g, 9, -30, 0, 8, "#fff", "#7bd8ff"), 1.3); g.strokeStyle = "rgba(255,255,255,0.8)"; g.lineWidth = 1.500; g.beginPath(); g.arc(9, -30, 10, 0, TAU); g.stroke(); }
  else if (key === "sohrab") { line(g, 0, 8, 14, -20, "#6a4a2a", 5); ell(g, 15, -24, 9, 9, lin(g, 6, -33, 24, -15, "#ff8aa0", "#8a2a40"), 1.6); for (let i = 0; i < 5; i++) { const a = i * TAU / 5; path(g, [[15 + Math.cos(a - 0.25) * 8, -24 + Math.sin(a - 0.25) * 8], [15 + Math.cos(a) * 14, -24 + Math.sin(a) * 14], [15 + Math.cos(a + 0.25) * 8, -24 + Math.sin(a + 0.25) * 8]]); fillStroke(g, "#ffd0d8", 1); } }
  else if (key === "tahmineh") { line(g, 0, 10, 8, -26, "#caa066", 3); for (let i = 0; i < 5; i++) { const a = i * TAU / 5; ell(g, 9 + Math.cos(a) * 5, -30 + Math.sin(a) * 5, 4, 4, "#ff6a9a", 1); } ell(g, 9, -30, 3, 3, "#ffd24a", 0.8); }
  else { line(g, 0, 8, 12, -14, "#7a4a22", 5.500); rect(g, 4, -26, 20, 13, 3, lin(g, 4, -26, 24, -13, "#9aa6c0", "#4a5470"), 1.6); rect(g, 4, -26, 6, 13, 3, "#e8603c", 1); }
  g.restore();
}

// ================================================================ دکور زمین (رو به بالا، مرکز پایین ریشه)
export function decoSprite(g, k, v) {
  const sh = () => { g.fillStyle = "rgba(0,0,0,0.28)"; g.beginPath(); g.ellipse(0, 3, 17, 6, 0, 0, TAU); g.fill(); };
  const blob = (x, y, r, c1, c2) => { ell(g, x, y, r, r * 0.95, lin(g, x - r, y - r, x + r, y + r, c1, c2), 1.1); };
  sh();
  switch (k) {
    case "tree": rect(g, -4, -14, 8, 18, 2, "#6b4426"); blob(0, -22, 16, "#52b05a", "#1f6a2a"); blob(-10, -14, 11, "#3c9448", "#1f6a2a"); blob(10, -14, 11, "#3c9448", "#1f6a2a"); blob(1, -32, 10, "#74c870", "#2f8a3a"); shine(g, -4, -33, 5, 3); if (v > 0.6) { g.fillStyle = "#ff7aa8"; for (const [x, y] of [[-8, -18], [8, -24], [2, -12]]) { g.beginPath(); g.arc(x, y, 2, 0, TAU); g.fill(); } } break;
    case "bush": blob(-8, -5, 9, "#4aa850", "#1f6a2a"); blob(7, -5, 9, "#4aa850", "#1f6a2a"); blob(0, -9, 10, "#66c068", "#2a7a34"); g.fillStyle = "#ff5a7a"; for (const [x, y] of [[-6, -8], [4, -12], [8, -5]]) { g.beginPath(); g.arc(x, y, 1.800, 0, TAU); g.fill(); } break;
    case "rock": path(g, [[-15, 2], [-11, -10], [-3, -16], [8, -13], [15, -4], [14, 3]]); fillStroke(g, lin(g, -10, -16, 12, 4, "#b4b4c0", "#62626e"), 1.5); path(g, [[-3, -16], [8, -13], [3, -6], [-6, -8]]); g.fillStyle = "rgba(255,255,255,0.3)"; g.fill(); break;
    case "flowers": for (const [x, y, c] of [[-9, -2, "#ff7aa8"], [0, -6, "#fff3a0"], [9, -3, "#ffffff"], [-3, 0, "#c58bff"]]) { line(g, x, 2, x, y, "#3d8a44", 1.600); for (let i = 0; i < 5; i++) { const a = i * TAU / 5; g.fillStyle = c; g.beginPath(); g.arc(x + Math.cos(a) * 2.600, y + Math.sin(a) * 2.600, 1.800, 0, TAU); g.fill(); } ell(g, x, y, 1.400, 1.400, "#ffcc33", 0); } break;
    case "pine": rect(g, -3, -6, 6, 10, 1, "#5a3a22"); for (let i = 0; i < 4; i++) { const w = 17 - i * 3.200, y = -4 - i * 8; path(g, [[-w, y], [0, y - 15], [w, y]]); fillStroke(g, lin(g, 0, y - 15, 0, y, "#2f8a5a", "#14503a"), 1.300); } break;
    case "icepine": rect(g, -3, -6, 6, 10, 1, "#5a4a3a"); for (let i = 0; i < 4; i++) { const w = 17 - i * 3.200, y = -4 - i * 8; path(g, [[-w, y], [0, y - 15], [w, y]]); fillStroke(g, lin(g, 0, y - 15, 0, y, "#2a6a68", "#154848"), 1.300); path(g, [[-w * 0.75, y - 4], [0, y - 15], [w * 0.75, y - 4], [w * 0.3, y - 7], [0, y - 3], [-w * 0.3, y - 7]]); g.fillStyle = "#f4fcff"; g.fill(); } break;
    case "mushroom": case "mushroom2": { const c = k === "mushroom" ? "#7cf0c8" : "#b6ff5c", c2 = k === "mushroom" ? "#4a2d8e" : "#6a4a1a"; rect(g, -4, -12, 8, 15, 3, "#e8e2c8"); g.beginPath(); g.ellipse(0, -13, 20, 15, 0, Math.PI, 0); g.closePath(); fillStroke(g, lin(g, 0, -28, 0, -12, lighten(c2, 0.25), c2), 1.5); g.fillStyle = c; for (const [x, y] of [[-8, -20], [6, -22], [0, -15]]) { g.beginPath(); g.arc(x, y, 3.200, 0, TAU); g.fill(); } g.globalAlpha = 0.18; g.fillStyle = c; g.beginPath(); g.arc(0, -14, 26, 0, TAU); g.fill(); g.globalAlpha = 1; break; }
    case "stump": rect(g, -10, -10, 20, 14, 3, lin(g, -10, 0, 10, 0, "#8a5a30", "#5a3a1e")); ell(g, 0, -10, 10, 4.500, "#c8955a", 1.2); g.strokeStyle = "rgba(90,50,20,0.6)"; g.lineWidth = 1; g.beginPath(); g.ellipse(0, -10, 6, 2.500, 0, 0, TAU); g.stroke(); g.beginPath(); g.ellipse(0, -10, 2.500, 1, 0, 0, TAU); g.stroke(); break;
    case "cactus": rect(g, -6, -34, 12, 38, 6, lin(g, -6, 0, 6, 0, "#4fa05a", "#2f7a3a")); rect(g, -18, -24, 10, 7, 3, "#3f8f4a"); rect(g, -18, -30, 6, 12, 3, "#3f8f4a"); rect(g, 8, -18, 11, 7, 3, "#3f8f4a"); rect(g, 13, -26, 6, 14, 3, "#3f8f4a"); g.fillStyle = "#ff7aa8"; g.beginPath(); g.arc(0, -36, 3, 0, TAU); g.fill(); g.strokeStyle = "rgba(255,255,255,0.5)"; g.lineWidth = 1; for (let i = 0; i < 5; i++) { g.beginPath(); g.moveTo(-3, -28 + i * 6); g.lineTo(-5, -30 + i * 6); g.stroke(); } break;
    case "palm": g.strokeStyle = INK; g.lineWidth = 7; g.beginPath(); g.moveTo(0, 3); g.quadraticCurveTo(6, -18, 2, -36); g.stroke(); g.strokeStyle = "#a87a44"; g.lineWidth = 4.500; g.stroke(); for (let i = 0; i < 6; i++) { const a = -Math.PI / 2 + (i - 2.500) * 0.55; path(g, [[2, -36], [2 + Math.cos(a - 0.2) * 18, -36 + Math.sin(a - 0.2) * 14 + 6], [2 + Math.cos(a) * 24, -36 + Math.sin(a) * 18 + 10], [2 + Math.cos(a + 0.2) * 18, -36 + Math.sin(a + 0.2) * 14 + 6]]); fillStroke(g, "#3f9a4a", 1.100); } ell(g, 0, -33, 3, 3, "#7a4a22", 0.8); ell(g, 4, -33, 3, 3, "#7a4a22", 0.8); break;
    case "bones": ell(g, 0, -4, 10, 8, "#eee8d8", 1.3); ell(g, -3.500, -5, 2.500, 3, "#2a2a30", 0); ell(g, 3.500, -5, 2.500, 3, "#2a2a30", 0); line(g, -16, 0, 12, 3, "#eee8d8", 3.500); break;
    case "crystal": for (const [x, h, c] of [[-10, 24, "#bfeaff"], [0, 36, "#e6f8ff"], [10, 20, "#9fd8ff"]]) { path(g, [[x - 6, 2], [x, -h], [x + 6, 2]]); fillStroke(g, lin(g, x - 6, -h, x + 6, 2, c, "#6ab0e8"), 1.300); path(g, [[x - 1, 0], [x, -h], [x - 5, 0]]); g.fillStyle = "rgba(255,255,255,0.6)"; g.fill(); } break;
    case "icespire": path(g, [[-9, 3], [-4, -26], [0, -40], [5, -24], [10, 3]]); fillStroke(g, lin(g, -9, -40, 10, 3, "#f4fcff", "#6ab0e8"), 1.500); path(g, [[-4, -26], [0, -40], [2, -10], [-3, 0]]); g.fillStyle = "rgba(255,255,255,0.55)"; g.fill(); break;
    case "snowman": ell(g, 0, -4, 11, 9, "#f4f9ff", 1.300, "#8aa8c8"); ell(g, 0, -17, 8, 7, "#f4f9ff", 1.300, "#8aa8c8"); ell(g, 0, -27, 6, 5.500, "#f4f9ff", 1.300, "#8aa8c8"); g.fillStyle = "#222"; g.fillRect(-3, -28, 1.500, 1.500); g.fillRect(2, -28, 1.500, 1.500); path(g, [[0, -26], [7, -25], [0, -24]]); g.fillStyle = "#ff8a3c"; g.fill(); rect(g, -6, -35, 12, 3, 1, "#e8453a", 0.8); rect(g, -4, -39, 8, 5, 1, "#e8453a", 0.8); break;
    case "deadtree": g.strokeStyle = INK; g.lineWidth = 7; g.lineCap = "round"; g.beginPath(); g.moveTo(0, 3); g.lineTo(0, -22); g.stroke(); g.strokeStyle = "#5a4a3a"; g.lineWidth = 4; g.stroke(); for (const [x1, y1, x2, y2] of [[0, -14, -14, -26], [0, -18, 12, -30], [-7, -22, -12, -34], [6, -25, 8, -38]]) line(g, x1, y1, x2, y2, "#5a4a3a", 2.500); break;
    case "reeds": for (let i = -2; i <= 2; i++) { line(g, i * 4, 3, i * 4 + i * 1.5, -18 - (i % 2 ? 6 : 0), "#7a9a3a", 2); ell(g, i * 4 + i * 1.5, -20 - (i % 2 ? 6 : 0), 1.800, 4, "#6a4a2a", 0.8); } break;
    case "lavarock": path(g, [[-16, 3], [-10, -18], [2, -26], [14, -14], [18, 3]]); fillStroke(g, lin(g, -10, -26, 14, 3, "#4a2a22", "#1a0c0a"), 1.500); g.strokeStyle = "#ff7a2e"; g.lineWidth = 2; g.beginPath(); g.moveTo(-6, -14); g.lineTo(0, -6); g.lineTo(-3, 1); g.moveTo(6, -16); g.lineTo(8, -6); g.stroke(); break;
    case "lavapool": ell(g, 0, -1, 17, 8, "#3a1a10", 1.500); ell(g, 0, -1, 14, 6, rad(g, 0, -1, 0, 14, "#ffe45c", "#ff5a1a"), 0); g.fillStyle = "rgba(255,255,255,0.5)"; g.beginPath(); g.ellipse(-4, -3, 4, 1.500, 0, 0, TAU); g.fill(); break;
    case "charred": g.strokeStyle = INK; g.lineWidth = 6; g.beginPath(); g.moveTo(0, 3); g.lineTo(0, -20); g.stroke(); g.strokeStyle = "#2a1a16"; g.lineWidth = 3.500; g.stroke(); for (const [x2, y2] of [[-10, -28], [9, -26]]) line(g, 0, -14, x2, y2, "#2a1a16", 2.500); ell(g, 0, -22, 2.500, 3.500, "#ff6a2e", 0); break;
    case "obelisk": path(g, [[-8, 3], [-5, -34], [0, -42], [5, -34], [8, 3]]); fillStroke(g, lin(g, -8, 0, 8, 0, "#6a6a82", "#34344a"), 1.600); g.strokeStyle = "#d68cff"; g.lineWidth = 1.800; g.beginPath(); g.moveTo(-2, -28); g.lineTo(2, -22); g.lineTo(-2, -16); g.lineTo(2, -10); g.stroke(); break;
    case "cloud": g.globalAlpha = 0.97; for (const [x, y, r] of [[-12, -14, 11], [0, -20, 14], [12, -14, 11], [0, -10, 12]]) ell(g, x, y, r, r, lin(g, 0, y - r, 0, y + r, "#ffffff", "#dfe8ff"), 0); g.fillStyle = "rgba(160,180,230,0.35)"; g.beginPath(); g.ellipse(0, -4, 22, 5, 0, 0, TAU); g.fill(); g.globalAlpha = 1; break;
    case "pillar": rect(g, -9, -4, 18, 7, 2, "#eef2fb"); rect(g, -6, -34, 12, 30, 1, lin(g, -6, 0, 6, 0, "#fafcff", "#bcc6dc")); rect(g, -9, -40, 18, 7, 2, "#eef2fb"); g.strokeStyle = "rgba(120,140,190,0.5)"; g.lineWidth = 1; for (const x of [-2, 2]) { g.beginPath(); g.moveTo(x, -33); g.lineTo(x, -5); g.stroke(); } break;
    case "banner": line(g, 0, 3, 0, -40, "#8a6a3a", 3); path(g, [[0, -38], [18, -34], [14, -28], [18, -20], [0, -22]]); fillStroke(g, lin(g, 0, -38, 18, -20, "#ff5a5a", "#a01a2a"), 1.300); ell(g, 7, -29, 3, 3, "#ffd24a", 0.6); ell(g, 0, -41, 2.500, 2.500, "#ffd24a", 0.8); break;
    case "voidshard": path(g, [[0, -38], [10, -18], [5, 0], [-7, -4], [-10, -20]]); fillStroke(g, lin(g, -10, -38, 10, 0, "#9a5ae0", "#3a1a7a"), 1.300, "#d68cff"); path(g, [[0, -38], [3, -18], [-2, -4], [-4, -20]]); g.fillStyle = "rgba(214,140,255,0.8)"; g.fill(); g.globalAlpha = 0.2; g.fillStyle = "#d68cff"; g.beginPath(); g.arc(0, -18, 24, 0, TAU); g.fill(); g.globalAlpha = 1; break;
    case "orbstone": rect(g, -8, -6, 16, 9, 2, "#34285a"); ell(g, 0, -16, 8, 8, rad(g, -2, -18, 1, 8, "#fff", "#a05ae0"), 1.200, "#d68cff"); break;
    case "house": rect(g, -15, -14, 30, 18, 2, lin(g, 0, -14, 0, 4, "#f4e2bc", "#c8ac80")); path(g, [[-19, -13], [0, -30], [19, -13]]); fillStroke(g, lin(g, 0, -30, 0, -13, "#d8603e", "#8a2e1a"), 1.500); rect(g, -4, -8, 8, 12, 2, "#7a4a22", 1); rect(g, -12, -10, 6, 6, 1, "#9fd8ff", 1); rect(g, 6, -10, 6, 6, 1, "#9fd8ff", 1); rect(g, 8, -34, 5, 9, 1, "#8a6a50", 1); break;
    case "fence": for (let i = -2; i <= 2; i++) rect(g, i * 7 - 1.500, -12, 3.500, 15, 1, "#b88a52", 1); rect(g, -18, -9, 36, 3, 1, "#d6a868", 1); rect(g, -18, -3, 36, 3, 1, "#d6a868", 1); break;
    case "haystack": ell(g, 0, -6, 13, 11, lin(g, 0, -17, 0, 5, "#f0d070", "#b8902a"), 1.400); g.strokeStyle = "rgba(120,80,10,0.5)"; g.lineWidth = 1; for (let i = -2; i <= 2; i++) { g.beginPath(); g.moveTo(i * 4, -14); g.lineTo(i * 5, 1); g.stroke(); } break;
    case "wall": rect(g, -16, -20, 32, 24, 2, lin(g, 0, -20, 0, 4, "#9a9aa8", "#5a5a6a")); for (let i = -2; i <= 2; i++) rect(g, i * 7 - 3, -26, 6, 7, 1, "#a8a8b8", 1); g.strokeStyle = "rgba(0,0,0,0.3)"; g.lineWidth = 1; for (const y of [-12, -4]) { g.beginPath(); g.moveTo(-16, y); g.lineTo(16, y); g.stroke(); } rect(g, -3, -14, 6, 12, 3, "#2a2a34", 1); break;
    case "tent": path(g, [[-18, 3], [0, -28], [18, 3]]); fillStroke(g, lin(g, -18, 0, 18, 0, "#e8c070", "#b87a2a"), 1.500); path(g, [[-4, 3], [0, -12], [4, 3]]); fillStroke(g, "#4a2e18", 1); path(g, [[-18, 3], [0, -28], [-8, 3]]); g.fillStyle = "rgba(255,255,255,0.18)"; g.fill(); line(g, 0, -28, 0, -34, "#7a4a22", 2); path(g, [[0, -34], [9, -32], [0, -29]]); g.fillStyle = "#e8453a"; g.fill(); break;
    case "crates": rect(g, -14, -10, 14, 13, 1, "#b88a52", 1.200); rect(g, 1, -14, 15, 17, 1, "#a07a44", 1.200); rect(g, -6, -22, 12, 12, 1, "#c89a60", 1.200); g.strokeStyle = "rgba(60,30,10,0.55)"; g.lineWidth = 1.200; for (const [x, y, w, h] of [[-14, -10, 14, 13], [1, -14, 15, 17], [-6, -22, 12, 12]]) { g.beginPath(); g.moveTo(x, y); g.lineTo(x + w, y + h); g.moveTo(x + w, y); g.lineTo(x, y + h); g.stroke(); } break;
    default: blob(0, -8, 10, "#999", "#555");
  }
}

// ================================================================ دروازه‌ی قلعه (حمله)
export function gateSprite(g, style, col) {
  const pal = { wood: ["#7a4a22", "#a8723c", "#c8a070"], iron: ["#3a3a46", "#5a5a6a", "#8a8a98"], gold: ["#a8801c", "#d6a830", "#f0d070"], ice: ["#4a8ab8", "#8ad0f0", "#e8faff"], obsidian: ["#241420", "#4a2230", "#ff6a2e"], white: ["#aab4d4", "#dfe6f8", "#ffffff"] }[style] || ["#555", "#777", "#aaa"];
  g.fillStyle = "rgba(0,0,0,0.3)"; g.beginPath(); g.ellipse(0, 28, 34, 9, 0, 0, TAU); g.fill();
  for (const s of [-1, 1]) { rect(g, s * 26 - 10, -34, 20, 62, 2, lin(g, 0, -34, 0, 28, pal[1], pal[0]), 1.600); for (let i = -1; i <= 1; i++) rect(g, s * 26 - 10 + (i + 1) * 7, -42, 6, 9, 1, pal[2], 1); g.strokeStyle = "rgba(0,0,0,0.3)"; g.lineWidth = 1; for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(s * 26 - 10, -26 + i * 9); g.lineTo(s * 26 + 10, -26 + i * 9); g.stroke(); } if (style === "obsidian") { g.strokeStyle = pal[2]; g.lineWidth = 1.500; g.beginPath(); g.moveTo(s * 26, -30); g.lineTo(s * 26 + 4, -10); g.lineTo(s * 26 - 2, 10); g.stroke(); } }
  g.beginPath(); g.moveTo(-16, 28); g.lineTo(-16, -6); g.arc(0, -6, 16, Math.PI, 0); g.lineTo(16, 28); g.closePath(); fillStroke(g, lin(g, 0, -22, 0, 28, pal[1], pal[0]), 2);
  g.strokeStyle = "rgba(0,0,0,0.4)"; g.lineWidth = 1.500; g.beginPath(); g.moveTo(0, -22); g.lineTo(0, 28); g.stroke(); for (const y of [-8, 6, 18]) { g.beginPath(); g.moveTo(-16, y); g.lineTo(16, y); g.stroke(); }
  ell(g, -5, 10, 2, 2, pal[2], 0.8); ell(g, 5, 10, 2, 2, pal[2], 0.8);
  line(g, 0, -42, 0, -62, "#6a4a2a", 2.500); path(g, [[0, -62], [20, -56], [0, -50]]); fillStroke(g, col, 1.300);
}
