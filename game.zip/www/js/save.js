// ذخیره‌ی پیشرفت و منطق پیشرفت بازیکن (کشور، قهرمان، اتحاد، ماموریت)
import { defaultAvatar, defaultOwned } from "./gear.js";
import { HEROES, TROOPS, BUILDINGS, BUILDING_ORDER, MISSION_POOL, DAILY_REWARDS, NEIGHBORS, RESEARCH, PLAYER_XP, ALLIANCE_PERK, BOT_NAMES, BOT_MSGS, KINGDOM_TIERS, rng, CHESTS } from "./data.js";

const KEY = "bastion-saga-v2";
const dayStr = (t = Date.now()) => { const d = new Date(t); return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); };

function fresh() {
  const now = Date.now();
  return {
    v: 2, coins: 900, gems: 40, xp: 0, level: 1, created: now,
    stars: Array(8).fill(0), hard: Array(8).fill(0),
    heroes: { arash: { lvl: 1 } }, loadout: ["arash", null],
    buildings: { mine: 1, gem: 0, barracks: 1, walls: 1, market: 0, academy: 0, forge: 0, hall: 0 },
    mineT: now, gemT: now, research: {}, troops: { sword: 1, shield: 1, archer: 1, horse: 1, ram: 1 },
    avatar: defaultAvatar(), gear: defaultOwned(), conquered: {}, boosters: { gold: 0, life: 0, power: 0 }, picked: { gold: false, life: false, power: false },
    alliance: null, daily: { idx: 0, last: "", claimed: false }, missions: { date: "", list: [] },
    settings: { music: 0.7, sfx: 0.85, speed: 1, auto: false, vibrate: true },
    raid: { next: now + 8 * 60000, pending: null },
    stats: { kills: 0, wins: 0, towers: 0, attacks: 0, evolves: 0 }, seen: {},
  };
}
export let S = fresh();
let timer = null;
export function load() {
  try { const raw = localStorage.getItem(KEY); if (raw) { const o = JSON.parse(raw); S = Object.assign(fresh(), o); S.settings = Object.assign(fresh().settings, o.settings || {}); S.buildings = Object.assign(fresh().buildings, o.buildings || {}); S.stats = Object.assign(fresh().stats, o.stats || {}); S.avatar = Object.assign(defaultAvatar(), o.avatar || {}); S.gear = Object.assign(defaultOwned(), o.gear || {}); } } catch (e) { S = fresh(); }
  dailyCheck(); return S;
}
export function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* ignore */ } }
export function saveSoon() { if (timer) return; timer = setTimeout(() => { timer = null; save(); }, 400); }
export function resetAll() { try { localStorage.removeItem(KEY); } catch (e) { /* */ } S = fresh(); save(); }

// ---------- پول ----------
export const canPay = (p) => (!p.coins || S.coins >= p.coins) && (!p.gems || S.gems >= p.gems);
export function pay(p) { if (!canPay(p)) return false; S.coins -= p.coins || 0; S.gems -= p.gems || 0; saveSoon(); return true; }
export function give(r) { if (r.coins) S.coins += Math.round(r.coins); if (r.gems) S.gems += Math.round(r.gems); saveSoon(); }
export function addXp(n) { S.xp += n; let up = 0; while (S.xp >= PLAYER_XP(S.level)) { S.xp -= PLAYER_XP(S.level); S.level++; S.gems += 5; up++; } saveSoon(); return up; }

// ---------- ضرایب ----------
export const rLvl = (k) => S.research[k] || 0;
export function kingdomLevel() { return BUILDING_ORDER.reduce((a, k) => a + S.buildings[k], 0) + Object.keys(S.conquered).length * 4; }
export function kingdomTier() { const l = kingdomLevel(); let t = KINGDOM_TIERS[0][1]; for (const [n, name] of KINGDOM_TIERS) if (l >= n) t = name; return t; }
export function conqPerk() { return NEIGHBORS.reduce((a, n) => a + (S.conquered[n.id] ? n.perk : 0), 0); }
export function mods() {
  const ap = S.alliance ? ALLIANCE_PERK(S.alliance.level) : { coin: 0, dmg: 0 };
  return {
    dmg: 1 + 0.04 * rLvl("dmg") + ap.dmg + (S.picked.power && S.boosters.power > 0 ? 0.2 : 0), rate: 1 + 0.03 * rLvl("rate"), range: 1 + 0.02 * rLvl("range"),
    gold: 1 + 0.04 * rLvl("gold") + ap.coin + conqPerk(), start: 25 * rLvl("start") + (S.picked.gold && S.boosters.gold > 0 ? 150 : 0),
    life: rLvl("life") + (S.picked.life && S.boosters.life > 0 ? 5 : 0), sell: 0.03 * rLvl("sell"),
  };
}
export const coinBonus = () => 1 + conqPerk() + (S.alliance ? ALLIANCE_PERK(S.alliance.level).coin : 0);
export const discount = (b, perLvl) => Math.max(0.5, 1 - perLvl * S.buildings[b]);
export const kingdomPower = () => Math.round(BUILDING_ORDER.reduce((a, k) => a + S.buildings[k] * (k === "walls" ? 5 : 2), 0) + Object.values(S.heroes).reduce((a, h) => a + h.lvl * 2, 0) + Object.values(S.troops).reduce((a, l) => a + l, 0));
export function consumeBoosters() { for (const k of Object.keys(S.picked)) { if (S.picked[k] && S.boosters[k] > 0) S.boosters[k]--; S.picked[k] = false; } saveSoon(); }

// ---------- معدن ----------
export const provinceRate = () => NEIGHBORS.reduce((a, n) => a + (S.conquered[n.id] ? Math.round(n.loot * 0.012) : 0), 0);
export function claimEmpire() { if (S.empire || NEIGHBORS.some((n) => !S.conquered[n.id])) return null; S.empire = true; S.coins += 8000; S.gems += 150; saveSoon(); return { coins: 8000, gems: 150 }; }
export function minePending() {
  const now = Date.now(), lm = S.buildings.mine, lg = S.buildings.gem;
  const cH = Math.min(8, (now - S.mineT) / 3600000), gH = Math.min(24, (now - S.gemT) / 3600000);
  const pr = provinceRate();
  return { coins: Math.floor(cH * (70 * lm + pr) * coinBonus()), gems: lg ? Math.floor(gH * 0.35 * lg) : 0, capCoins: Math.floor(8 * (70 * lm + pr) * coinBonus()), fullH: cH >= 8 };
}
export function collectMine() {
  const p = minePending(); if (p.coins > 0) { S.coins += p.coins; S.mineT = Date.now(); }
  if (p.gems > 0) { S.gems += p.gems; S.gemT = Date.now(); }
  if (p.coins > 0 || p.gems > 0) mission("collect", 1); saveSoon(); return p;
}

// ---------- ماموریت‌ها / روزانه ----------
export function dailyCheck() {
  const today = dayStr();
  if (S.daily.last !== today) {
    const prev = S.daily.last ? new Date(S.daily.last.split("-").join("/")) : null; const y = new Date(); y.setDate(y.getDate() - 1);
    const consecutive = prev && dayStr(y.getTime()) === S.daily.last;
    if (S.daily.last && !consecutive) S.daily.idx = 0; else if (S.daily.last && S.daily.claimed) S.daily.idx = (S.daily.idx + 1) % 7;
    S.daily.last = today; S.daily.claimed = false;
  }
  if (S.missions.date !== today) {
    const r = rng((Date.now() / 86400000 | 0) + 17), pool = MISSION_POOL.slice(), list = [];
    while (list.length < 3) { const m = pool.splice(Math.floor(r() * pool.length), 1)[0]; list.push({ id: m.id, p: 0, claimed: false }); }
    S.missions = { date: today, list };
  }
  save();
}
export function claimDaily() { if (S.daily.claimed) return null; const r = DAILY_REWARDS[S.daily.idx]; give(r); S.daily.claimed = true; save(); return r; }
export function mission(id, n = 1) { const m = S.missions.list.find((x) => x.id === id); if (m) { const def = MISSION_POOL.find((d) => d.id === id); m.p = Math.min(def.target, m.p + n); saveSoon(); } }
export function claimMission(i) { const m = S.missions.list[i], def = MISSION_POOL.find((d) => d.id === m.id); if (m.claimed || m.p < def.target) return null; m.claimed = true; give(def.reward); save(); return def.reward; }

// ---------- حمله‌ی همسایه ----------
export function raidTick() {
  const now = Date.now(), r = S.raid;
  if (!r.pending && now >= r.next && S.stars[0] > 0) {
    const pool = NEIGHBORS.filter((n) => n.need <= kingdomLevel() + 6 || S.conquered[n.id]); const rr = Math.random();
    const nb = pool[Math.floor(rr * pool.length)] || NEIGHBORS[0];
    r.pending = { id: nb.id, power: Math.round(nb.power * (0.8 + Math.random() * 0.4)), t: now };
  }
  if (r.pending && now - r.pending.t > 40 * 60000) { resolveRaid(true); return "expired"; }
  return r.pending ? "pending" : "none";
}
export function raidAutoChance() { const r = S.raid.pending; if (!r) return 0; return Math.max(0.1, Math.min(0.9, 0.55 + (kingdomPower() - r.power * 1.6) / 120)); }
export function resolveRaid(forceLoss = false, won = false, auto = false) {
  const r = S.raid.pending; if (!r) return null; const nb = NEIGHBORS.find((n) => n.id === r.id);
  let result = { won, nb };
  if (auto) result.won = !forceLoss && Math.random() < raidAutoChance();
  if (forceLoss) result.won = false;
  if (result.won) { result.loot = Math.round(nb.loot * 0.25 * (auto ? 0.6 : 1)); result.gems = auto ? 0 : Math.round(nb.gems / 3); give({ coins: result.loot, gems: result.gems }); }
  else { const p = minePending(); const lost = Math.floor(p.coins * 0.3); S.mineT = Math.min(Date.now(), S.mineT + 0); if (lost > 0) { S.mineT += Math.min(Date.now() - S.mineT, 0); } result.lost = Math.min(lost, Math.floor(S.coins * 0.1)); S.coins -= result.lost; }
  S.raid.pending = null; S.raid.next = Date.now() + (20 + Math.random() * 20) * 60000; save(); return result;
}

// ---------- اتحاد ----------
const ALLY_NAMES = [["شیران ایران", "🦁"], ["پهلوانان نیمروز", "🛡️"], ["سیمرغ‌های البرز", "🦅"], ["یلان دشت", "🐎"], ["آذرخش", "⚡"], ["پاسداران پارس", "🏺"]];
export function allianceOffers() { const r = rng(Math.floor(Date.now() / 86400000) + 3); return ALLY_NAMES.slice(0, 4).map(([name, emoji], i) => ({ name, emoji, level: 1 + Math.floor(r() * 4), members: 8 + Math.floor(r() * 12), min: i * 3 })); }
export function createAlliance(name, emoji) { S.alliance = newAlliance(name, emoji, 1); S.alliance.members.unshift({ name: "تو", power: kingdomPower(), don: 0, me: true }); save(); }
export function joinAlliance(offer) { S.alliance = newAlliance(offer.name, offer.emoji, offer.level); S.alliance.members.unshift({ name: "تو", power: kingdomPower(), don: 0, me: true }); S.alliance.feed.push({ who: "سیستم", msg: "به اتحاد خوش آمدی!", t: Date.now() }); save(); }
export function leaveAlliance() { S.alliance = null; save(); }
function newAlliance(name, emoji, level) {
  const r = rng(name.length * 977 + level), members = [];
  for (let i = 0; i < 6 + level * 2; i++) members.push({ name: BOT_NAMES[(i * 5 + level) % BOT_NAMES.length], power: 10 + Math.floor(r() * 60), don: Math.floor(r() * 3000) });
  return { name, emoji, level, xp: 0, members, goal: { week: weekNo(), target: 60 + level * 20, progress: 0, claimed: false }, feed: [], tick: Date.now() };
}
const weekNo = () => Math.floor(Date.now() / (7 * 86400000));
export const allyNeed = (lvl) => Math.round(500 * Math.pow(lvl, 1.5));
export const allyCap = () => 10 + S.buildings.hall * 4;
export function allianceTick() {
  const a = S.alliance; if (!a) return; const now = Date.now();
  if (a.goal.week !== weekNo()) a.goal = { week: weekNo(), target: 60 + a.level * 20, progress: 0, claimed: false };
  const hours = Math.min(48, (now - a.tick) / 3600000);
  if (hours > 0.02) {
    const add = Math.floor(hours * (2 + a.members.length * 0.5) * (0.7 + Math.random() * 0.6));
    a.goal.progress = Math.min(a.goal.target, a.goal.progress + add);
    const msgs = Math.min(4, Math.floor(hours * 3 + Math.random() * 1.2));
    for (let i = 0; i < msgs; i++) { const m = a.members[1 + Math.floor(Math.random() * (a.members.length - 1))]; if (m) a.feed.push({ who: m.name, msg: BOT_MSGS[Math.floor(Math.random() * BOT_MSGS.length)], t: now - Math.random() * hours * 3600000 }); }
    a.feed = a.feed.sort((x, y) => x.t - y.t).slice(-30); a.xp += Math.floor(hours * 30);
    while (a.xp >= allyNeed(a.level)) { a.xp -= allyNeed(a.level); a.level++; a.feed.push({ who: "سیستم", msg: `اتحاد به سطح ${a.level} رسید! 🎉`, t: now }); }
    a.tick = now; saveSoon();
  }
}
export function donate(amount) {
  const a = S.alliance; if (!a || S.coins < amount) return false; S.coins -= amount; a.xp += Math.round(amount / 8); const me = a.members.find((m) => m.me); if (me) me.don += amount;
  while (a.xp >= allyNeed(a.level)) { a.xp -= allyNeed(a.level); a.level++; a.feed.push({ who: "سیستم", msg: `اتحاد به سطح ${a.level} رسید! 🎉`, t: Date.now() }); }
  mission("donate", 1); a.feed.push({ who: "تو", msg: `${amount} سکه کمک کردی`, t: Date.now() }); save(); return true;
}
export function allianceWin(stars) { if (S.alliance) { S.alliance.goal.progress = Math.min(S.alliance.goal.target, S.alliance.goal.progress + stars * 3); S.alliance.xp += stars * 15; saveSoon(); } }
export function claimAllianceGoal() { const a = S.alliance; if (!a || a.goal.claimed || a.goal.progress < a.goal.target) return null; a.goal.claimed = true; const r = { coins: 1500 * a.level, gems: 15 + a.level * 3 }; give(r); save(); return r; }

// ---------- صندوق ----------
export function openChest(kind) {
  const r = Math.random(), out = { coins: 0, gems: 0, hero: null, extra: [] };
  if (kind === "wood") { out.coins = 350 + Math.floor(Math.random() * 700); if (r < 0.2) out.gems = 3 + Math.floor(Math.random() * 5); }
  else if (kind === "silver") { out.coins = 1500 + Math.floor(Math.random() * 2500); out.gems = 10 + Math.floor(Math.random() * 25); if (r < 0.25) out.extra.push("power"); }
  else { out.coins = 4000 + Math.floor(Math.random() * 5000); out.gems = 30 + Math.floor(Math.random() * 70); const locked = Object.keys(HEROES).filter((h) => !S.heroes[h]); if (locked.length && r < 0.5) out.hero = locked[Math.floor(Math.random() * locked.length)]; else out.extra.push("power", "gold"); }
  give(out); for (const b of out.extra) S.boosters[b]++; if (out.hero) S.heroes[out.hero] = { lvl: 1 }; save(); return out;
}
export { dayStr, CHESTS, HEROES, TROOPS, BUILDINGS, RESEARCH };
