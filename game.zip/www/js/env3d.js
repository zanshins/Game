// محیط سه‌بعدی: درخت/سنگ/گل/بوته (FBX → env.bin) با اسپرایت‌کش بر اساس زاویه‌ی دوربین
// استفاده: await loadEnv(); envFrame(); const s = envSprite(name, yaw, pitch); envBlit(ctx, s, cx, cy, pxPerUnit, flip, alpha)
export const EV = { ok: false, meta: null, names: [] };
const SLOT = 192, ATL = 3072, PER = ATL / SLOT, YB = 16, PB = 0.08;
let gl, cvs, prog, loc, bin, meshes = {}, cache = new Map(), slotFree = [], budget = 0, tick = 0;
const VS = `#version 300 es
in vec3 a_p; in vec3 a_n; in vec3 a_c; uniform mat4 u_vp; uniform vec3 u_L; uniform float u_h; out vec3 v_c; out float v_l;
void main(){ vec3 n = normalize(a_n); float d = max(dot(n,u_L),0.0); float hemi = 0.5+0.5*n.y; float ao = mix(0.55,1.0,clamp(a_p.y/(u_h*0.55),0.0,1.0));
 float lt = (0.38 + 0.52*d + 0.18*hemi) * ao; v_c = a_c; v_l = lt; gl_Position = u_vp*vec4(a_p,1.0); }`;
const FS = `#version 300 es
precision mediump float; in vec3 v_c; in float v_l; out vec4 o;
void main(){ vec3 c = v_c * v_l; c = mix(c, c*vec3(1.08,1.02,0.9), 0.4); o = vec4(c,1.0); }`;
function sh(t, s) { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(o)); return o; }
export async function loadEnv(base = "assets/env/") {
  try {
    cvs = document.createElement("canvas"); cvs.width = ATL; cvs.height = ATL;
    gl = cvs.getContext("webgl2", { alpha: true, premultipliedAlpha: true, antialias: false, preserveDrawingBuffer: true }); if (!gl) throw new Error("no webgl2");
    prog = gl.createProgram(); gl.attachShader(prog, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(prog, sh(gl.FRAGMENT_SHADER, FS));
    gl.bindAttribLocation(prog, 0, "a_p"); gl.bindAttribLocation(prog, 1, "a_n"); gl.bindAttribLocation(prog, 2, "a_c"); gl.linkProgram(prog);
    loc = { vp: gl.getUniformLocation(prog, "u_vp"), L: gl.getUniformLocation(prog, "u_L"), h: gl.getUniformLocation(prog, "u_h") };
    const [meta, buf] = await Promise.all([fetch(base + "env.json").then((r) => r.json()), fetch(base + "env.bin").then((r) => r.arrayBuffer())]);
    bin = buf; EV.meta = meta; EV.names = Object.keys(meta);
    for (const n of EV.names) {
      const m = meta[n], vao = gl.createVertexArray(); gl.bindVertexArray(vao);
      const mk = (off, bytes, idx, type, norm) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Uint8Array(bin, off, bytes), gl.STATIC_DRAW); gl.enableVertexAttribArray(idx); gl.vertexAttribPointer(idx, 3, type, norm, 0, 0); };
      mk(m.pos, m.n * 12, 0, gl.FLOAT, false); mk(m.nor, m.n * 3, 1, gl.BYTE, true); mk(m.col, m.n * 3, 2, gl.UNSIGNED_BYTE, true);
      meshes[n] = { vao, n: m.n, h: m.h, w: m.w, hw: Math.max(m.h, m.w) * 0.68 };
    }
    gl.bindVertexArray(null);
    for (let i = PER * PER - 1; i >= 0; i--) slotFree.push(i);
    EV.ok = true; return true;
  } catch (e) { console.warn("env3d", e); EV.ok = false; return false; }
}
export function envFrame(maxRender = 8) { budget = maxRender; tick++; }
const L0 = (() => { const l = [0.45, 0.8, -0.4], n = Math.hypot(...l); return l.map((v) => v / n); })();
function renderTo(name, yawB, pitB, slot) {
  const m = meshes[name], yaw = (yawB / YB) * Math.PI * 2, pit = pitB * PB, cs = Math.cos(yaw), sn = Math.sin(yaw), cp = Math.cos(pit), sp = Math.sin(pit), hw = m.hw;
  const R = [cs, 0, -sn], U = [sn * sp, cp, cs * sp], D = [sn * cp, -sp, cs * cp], cx = 0, cy = m.h * 0.5, cz = 0, zr = 40, vp = new Float32Array(16);
  vp[0] = R[0] / hw; vp[4] = R[1] / hw; vp[8] = R[2] / hw; vp[12] = -(R[0] * cx + R[1] * cy + R[2] * cz) / hw;
  vp[1] = U[0] / hw; vp[5] = U[1] / hw; vp[9] = U[2] / hw; vp[13] = -(U[0] * cx + U[1] * cy + U[2] * cz) / hw;
  vp[2] = D[0] / zr; vp[6] = D[1] / zr; vp[10] = D[2] / zr; vp[14] = -(D[0] * cx + D[1] * cy + D[2] * cz) / zr; vp[15] = 1;
  const sx = (slot % PER) * SLOT, sy = Math.floor(slot / PER) * SLOT;
  gl.enable(gl.SCISSOR_TEST); gl.viewport(sx, ATL - sy - SLOT, SLOT, SLOT); gl.scissor(sx, ATL - sy - SLOT, SLOT, SLOT);
  gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE); gl.useProgram(prog);
  gl.uniformMatrix4fv(loc.vp, false, vp); gl.uniform3f(loc.L, L0[0], L0[1], L0[2]); gl.uniform1f(loc.h, m.h);
  gl.bindVertexArray(m.vao); gl.drawArrays(gl.TRIANGLES, 0, m.n); gl.bindVertexArray(null);
  return { sx, sy, hw, h: m.h };
}
// برگرداندن اسپرایت (یا null اگر فعلاً سهمیه‌ی رندر تمام شده)
export function envSprite(name, camYaw, camPitch) {
  if (!EV.ok || !meshes[name]) return null;
  const yawB = ((Math.round((camYaw / (Math.PI * 2)) * YB) % YB) + YB) % YB, pitB = Math.max(0, Math.round(camPitch / PB)), key = name + "|" + yawB + "|" + pitB;
  let e = cache.get(key);
  if (e) { e.t = tick; return e; }
  if (budget <= 0) return null;
  let slot = slotFree.pop();
  if (slot === undefined) { let old = null; for (const [k, v] of cache) if (v.t < tick - 1 && (!old || v.t < old[1].t)) old = [k, v]; if (!old) return null; cache.delete(old[0]); slot = old[1].slot; }
  budget--; const r = renderTo(name, yawB, pitB, slot); e = { ...r, slot, t: tick, S: SLOT, canvas: cvs }; cache.set(key, e); return e;
}
// ‌رسم: (cx,cy) مرکز اسپرایت روی صفحه؛ ppu پیکسل به ازای واحد جهان (برای مقیاس 1)
export function envBlit(ctx, s, cx, cy, ppu, sc = 1, flip = false, alpha = 1) {
  if (!s) return; const w = 2 * s.hw * ppu * sc, a = ctx.globalAlpha;
  if (alpha !== 1) ctx.globalAlpha = a * alpha;
  if (flip) { ctx.save(); ctx.translate(cx, cy); ctx.scale(-1, 1); ctx.drawImage(cvs, s.sx, s.sy, SLOT, SLOT, -w / 2, -w / 2, w, w); ctx.restore(); }
  else ctx.drawImage(cvs, s.sx, s.sy, SLOT, SLOT, cx - w / 2, cy - w / 2, w, w);
  if (alpha !== 1) ctx.globalAlpha = a;
}
export const envInfo = (n) => meshes[n]; // {h,w,hw}
// گروه‌بندی برای انتخاب تصادفی
export const ENVK = { tree: ["NormalTree_1", "NormalTree_5", "NormalTree_3", "BirchTree_4", "BirchTree_1", "MapleTree_4", "MapleTree_1"], pine: ["PineTree_5", "PineTree_1", "PineTree_3"], palm: ["PalmTree_1", "PalmTree_5"], dead: ["DeadTree_5", "DeadTree_9", "DeadTree_4"], bush: ["Bush", "Bush_Small", "Bush_Large_Flowers", "Bush_Flowers"], flower: ["Flower_1_Clump", "Flower_2_Clump", "Flower_3_Clump", "Flower_4_Clump", "Flower_5_Clump", "Plant_2", "Plant_Flowers", "Petals_1"], rock: ["Rock_1", "Rock_2", "Rock_3", "Rock_4", "Rock_5"], grass: ["Grass_Small", "Grass_Large_Extruded"] };
