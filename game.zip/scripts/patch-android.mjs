// اصلاح پروژه‌ی اندروید: حالت افقی، تمام‌صفحه، آیکون و صفحه‌ی شروع
import fs from "fs"; import path from "path";
const root = path.resolve("android"), res = path.join(root, "app/src/main/res");
const walk = (d, out = []) => { for (const f of fs.readdirSync(d)) { const p = path.join(d, f); fs.statSync(p).isDirectory() ? walk(p, out) : out.push(p); } return out; };

// 1) مانیفست: افقی
const mf = path.join(root, "app/src/main/AndroidManifest.xml"); let m = fs.readFileSync(mf, "utf8");
if (!m.includes("screenOrientation")) m = m.replace("<activity", '<activity\n            android:screenOrientation="sensorLandscape"\n            android:hardwareAccelerated="true"');
fs.writeFileSync(mf, m);

// 2) MainActivity: حالت فراگیر (بدون نوار سیستم) و روشن ماندن صفحه
const javaDir = walk(path.join(root, "app/src/main/java")).find((f) => f.endsWith("MainActivity.java"));
const pkg = fs.readFileSync(javaDir, "utf8").match(/package\s+([\w.]+);/)[1];
fs.writeFileSync(javaDir, `package ${pkg};

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    hideBars();
  }
  @Override
  public void onWindowFocusChanged(boolean hasFocus) {
    super.onWindowFocusChanged(hasFocus);
    if (hasFocus) hideBars();
  }
  private void hideBars() {
    getWindow().getDecorView().setSystemUiVisibility(
      View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
      | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
  }
}
`);

// 3) استایل: پر کردن ناحیه‌ی دوربین/ناچ
const st = path.join(res, "values/styles.xml");
if (fs.existsSync(st)) { let s = fs.readFileSync(st, "utf8"); if (!s.includes("windowLayoutInDisplayCutoutMode")) s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>'); fs.writeFileSync(st, s); }

// 4) آیکون‌ها
for (const dens of fs.readdirSync("resources/android")) {
  const dst = path.join(res, dens); fs.mkdirSync(dst, { recursive: true });
  for (const f of fs.readdirSync(path.join("resources/android", dens))) fs.copyFileSync(path.join("resources/android", dens, f), path.join(dst, f));
}
const bgx = path.join(res, "values/ic_launcher_background.xml");
fs.writeFileSync(bgx, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#1A2A55</color>\n</resources>\n');

// 5) صفحه‌ی شروع
for (const f of walk(res)) if (path.basename(f) === "splash.png") fs.copyFileSync("resources/splash.png", f);
console.log("android patched for", pkg);
